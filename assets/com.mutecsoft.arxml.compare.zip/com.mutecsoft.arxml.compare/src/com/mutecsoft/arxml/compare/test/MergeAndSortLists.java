package com.mutecsoft.arxml.compare.test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MergeAndSortLists {
	public static void main(String[] args) {
		// ù ��° ����Ʈ
		List<Integer> list1 = new ArrayList<>();
		list1.add(1);
		list1.add(2);
		list1.add(3);
		list1.add(4);
		list1.add(12);

		// �� ��° ����Ʈ
		List<Integer> list2 = new ArrayList<>();
		list2.add(1);
		list2.add(4);
		list2.add(7);
		list2.add(8);
		list2.add(10);

		// ����Ʈ ����
		list1.addAll(list2);

		// �ߺ� ����
		List<Integer> mergedList = new ArrayList<>();
		for (Integer number : list1) {
			if (!mergedList.contains(number)) {
				mergedList.add(number);
			}
		}

		// ����Ʈ ����
		Collections.sort(mergedList);

		// ��� ���
		System.out.println(mergedList);
	}
}
