package com.mutecsoft.arxml.compare.test;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeColumn;
import org.eclipse.swt.widgets.TreeItem;

import com.mutecsoft.arxml.compare.model.FileModel;
import com.mutecsoft.arxml.compare.model.FolderModel;
import com.mutecsoft.arxml.compare.model.folder.FolderModelBuilder;
import com.mutecsoft.arxml.compare.view.dialog.ProgressDialogManager;

public class FolderTree {

	public static void main(String[] args) {
		Display display = new Display();
		Shell shell = new Shell(display);
		shell.setLayout(new GridLayout(1, false));
		shell.setSize(800, 600);

		// 상단에 버튼 추가
		Composite buttonComposite = new Composite(shell, SWT.NONE);
		buttonComposite.setLayout(new GridLayout(5, true));
		buttonComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));

		Text positionText = new Text(buttonComposite, SWT.BORDER);
		positionText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false));

		// 가운데 트리 추가
		Composite treeComposite = new Composite(shell, SWT.NONE);
		treeComposite.setLayout(new GridLayout(2, true));
		treeComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));

		Tree tree1 = createTree(treeComposite);
		Tree tree2 = createTree(treeComposite);

		createButton(buttonComposite, "Expand All", e -> {
			expandAll(display, tree1, true);
			expandAll(display, tree2, true);
		});

		createButton(buttonComposite, "Collapse All", e -> {
			expandAll(display, tree1, false);
			expandAll(display, tree2, false);
		});

		createButton(buttonComposite, "Expand Position", e -> {
			int position = Integer.parseInt(positionText.getText());
			expandPosition(display, tree1, position, true);
			expandPosition(display, tree2, position, true);
		});

		createButton(buttonComposite, "Collapse Position", e -> {
			int position = Integer.parseInt(positionText.getText());
			expandPosition(display, tree1, position, false);
			expandPosition(display, tree2, position, false);
		});

		// 폴더 구조 생성
		String rootPath = "C:\\dev\\new"; // 적절한 경로로 변경
		FolderModel rootModel = new FolderModelBuilder().create(rootPath);

		// 데이터 설정
		populateTree(tree1, rootModel);
		populateTree(tree2, rootModel);

		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		display.dispose();
	}

	private static Button createButton(Composite parent, String text, Listener listener) {
		Button button = new Button(parent, SWT.PUSH);
		button.setText(text);
		button.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false));
		button.addListener(SWT.Selection, listener);
		return button;
	}

	private static Tree createTree(Composite parent) {
		Tree tree = new Tree(parent, SWT.BORDER | SWT.V_SCROLL | SWT.H_SCROLL | SWT.FULL_SELECTION);
		tree.setHeaderVisible(true);
		tree.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));

//		TreeColumn column0 = new TreeColumn(tree, SWT.LEFT);
//		column0.setText("POSITION"); // 첫 번째 열을 비워둠
//		column0.setWidth(60); // 너비를 0으로 설정
////		column0.setResizable(false); // 사용자가 너비를 조정할 수 없도록 설정

		TreeColumn column1 = new TreeColumn(tree, SWT.LEFT);
		column1.setText("Name");
		column1.setWidth(200);

		TreeColumn column2 = new TreeColumn(tree, SWT.LEFT);
		column2.setText("Date");
		column2.setWidth(150);

		TreeColumn column3 = new TreeColumn(tree, SWT.RIGHT);
		column3.setText("Size");
		column3.setWidth(100);

		return tree;
	}

	private static void populateTree(Tree tree, FolderModel rootModel) {
		TreeItem rootItem = new TreeItem(tree, SWT.NONE);
		setItemData(rootItem, rootModel);

		for (FolderModel subFolder : rootModel.getSubFolders()) {
			populateTreeItem(rootItem, subFolder);
		}

		for (FileModel file : rootModel.getFiles()) {
			TreeItem fileItem = new TreeItem(rootItem, SWT.NONE);
			setItemData(fileItem, file);
		}
	}

	private static void populateTreeItem(TreeItem parentItem, FolderModel model) {
		TreeItem item = new TreeItem(parentItem, SWT.NONE);
		setItemData(item, model);

		for (FolderModel subFolder : model.getSubFolders()) {
			populateTreeItem(item, subFolder);
		}

		for (FileModel file : model.getFiles()) {
			TreeItem fileItem = new TreeItem(item, SWT.NONE);
			setItemData(fileItem, file);
		}
	}

	private static void setItemData(TreeItem item, FolderModel model) {
		item.setText(
				new String[] { model.getName(), model.getCreatedDate().toString(), Long.toString(model.getSize()) });
		item.setData("position", model.getPosition()); // 위치 정보를 데이터 필드에 저장
		item.setExpanded(model.isExpanded());

	}

	private static void setItemData(TreeItem item, FileModel model) {
		item.setText(
				new String[] { model.getName(), model.getCreatedDate().toString(), "" });
		item.setData("position", model.getPosition()); // 위치 정보를 데이터 필드에 저장
	}

	private static void expandAll(Display display, Tree tree, boolean expand) {
		int totalItems = countTreeItems(tree.getItems());
		ProgressDialogManager progressDialogManager = new ProgressDialogManager(display,
				expand ? "Expanding all items..." : "Collapsing all items...", totalItems);
		display.asyncExec(() -> {
			expandAllItems(tree.getItems(), expand, progressDialogManager);
			progressDialogManager.done();
		});
	}

	private static void expandAllItems(TreeItem[] items, boolean expand, ProgressDialogManager progressDialogManager) {
		for (TreeItem item : items) {
			if (progressDialogManager.isCanceled()) {
				return;
			}
			item.setExpanded(expand);
			expandAllItems(item.getItems(), expand, progressDialogManager);
			progressDialogManager.updateProgress(1);
		}
	}

	private static void expandPosition(Display display, Tree tree, int position, boolean expand) {
		int totalItems = countTreeItems(tree.getItems());
		ProgressDialogManager progressDialogManager = new ProgressDialogManager(display,
				expand ? "Expanding position..." : "Collapsing position...", totalItems);
		display.asyncExec(() -> {
			expandPositionItems(tree.getItems(), position, expand, progressDialogManager);
			progressDialogManager.done();
		});
	}

	private static boolean expandPositionItems(TreeItem[] items, int position, boolean expand,
			ProgressDialogManager progressDialogManager) {
		for (TreeItem item : items) {
			if (progressDialogManager.isCanceled()) {
				return false;
			}
			Integer itemPosition = (Integer) item.getData("position");
			if (itemPosition != null && itemPosition == position) {
				item.setExpanded(expand);
				progressDialogManager.updateProgress(1);
				return true;
			}
			boolean found = expandPositionItems(item.getItems(), position, expand, progressDialogManager);
			if (found) {
				item.setExpanded(true);
				progressDialogManager.updateProgress(1);
				return true;
			}
			progressDialogManager.updateProgress(1);
		}
		return false;
	}

	private static int countTreeItems(TreeItem[] items) {
		int count = items.length;
		for (TreeItem item : items) {
			count += countTreeItems(item.getItems());
		}
		return count;
	}
}