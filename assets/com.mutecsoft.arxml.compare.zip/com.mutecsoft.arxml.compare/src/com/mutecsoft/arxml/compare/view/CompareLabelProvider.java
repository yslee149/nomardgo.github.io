package com.mutecsoft.arxml.compare.view;

import org.eclipse.jface.viewers.LabelProvider;

import com.mutecsoft.arxml.compare.model.FileModel;
import com.mutecsoft.arxml.compare.model.FolderModel;

public class CompareLabelProvider extends LabelProvider {
	@Override
	public String getText(Object element) {
		if (element instanceof FolderModel) {
			FolderModel folder = (FolderModel) element;
			return String.format("[Folder] %s (Type: %s, Created: %s, Size: %d bytes, Position: %d)", folder.getName(),
					folder.getType(), folder.getCreatedDate(), folder.getSize(), folder.getPosition());
		} else if (element instanceof FileModel) {
			FileModel file = (FileModel) element;
			return String.format("[File] %s (Type: %s, Created: %s, Size: %d bytes, Position: %d)", file.getName(),
					file.getType(), file.getCreatedDate(), file.getSize(), file.getPosition());
		}
		return "[Unknown] " + element.toString();
	}
}
