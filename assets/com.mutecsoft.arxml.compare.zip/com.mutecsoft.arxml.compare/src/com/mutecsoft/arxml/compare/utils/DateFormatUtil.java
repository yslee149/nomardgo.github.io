package com.mutecsoft.arxml.compare.utils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DateFormatUtil {

	public static String formatSizeToKB(long sizeInBytes) {
		double sizeInKB = sizeInBytes / 1024.0;
		return String.format("%.1f KB", sizeInKB);
	}

	public static String formatDate(Date date) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd a hh:mm:ss", Locale.KOREA);
		return dateFormat.format(date);
	}

}
