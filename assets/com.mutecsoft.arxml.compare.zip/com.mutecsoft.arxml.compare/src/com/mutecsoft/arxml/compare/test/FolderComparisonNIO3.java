package com.mutecsoft.arxml.compare.test;

import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.HashSet;
import java.util.Set;

import com.mutecsoft.arxml.compare.model.FileModel;
import com.mutecsoft.arxml.compare.model.FolderModel;
import com.mutecsoft.arxml.compare.model.folder.FolderModelBuilder;

public class FolderComparisonNIO3 {

    public static class ComparisonResult {
        private FolderModel originalFolder;
        private FolderModel comparisonFolder;

        public ComparisonResult(FolderModel originalFolder, FolderModel comparisonFolder) {
            this.originalFolder = originalFolder;
            this.comparisonFolder = comparisonFolder;
        }

        public FolderModel getOriginalFolder() {
            return originalFolder;
        }

        public FolderModel getComparisonFolder() {
            return comparisonFolder;
        }
    }

    public static ComparisonResult compareFolders(String originalFolderPath, String comparisonFolderPath, String extension) throws IOException {
        Path folder1 = Paths.get(originalFolderPath);
        Path folder2 = Paths.get(comparisonFolderPath);

        FolderModelBuilder builder = new FolderModelBuilder();
        FolderModel folderModel1 = builder.create(folder1.toFile());
        FolderModel folderModel2 = builder.create(folder2.toFile());

        Set<Path> files1 = new HashSet<>();
        Set<Path> files2 = new HashSet<>();

        Files.walkFileTree(folder1, new SimpleFileVisitor<Path>() {
            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                if (file.toString().endsWith(extension)) {
                    files1.add(folder1.relativize(file));
                }
                return FileVisitResult.CONTINUE;
            }
        });

        Files.walkFileTree(folder2, new SimpleFileVisitor<Path>() {
            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                if (file.toString().endsWith(extension)) {
                    files2.add(folder2.relativize(file));
                }
                return FileVisitResult.CONTINUE;
            }
        });

        for (Path relativePath : files1) {
            Path file1 = folder1.resolve(relativePath);
            Path file2 = folder2.resolve(relativePath);

            if (Files.exists(file2)) {
                boolean isEqual = compareFiles(file1, file2);
                System.out.println(file1 + " and " + file2 + " are " + (isEqual ? "identical" : "different"));
                // Add file comparison result to FolderModel
                addComparisonResult(folderModel1, folderModel2, relativePath.toString(), isEqual);
            } else {
                System.out.println(file2 + " does not exist in folder2");
            }
        }

        for (Path relativePath : files2) {
            Path file1 = folder1.resolve(relativePath);
            if (!Files.exists(file1)) {
                System.out.println(file1 + " does not exist in folder1");
            }
        }

        return new ComparisonResult(folderModel1, folderModel2);
    }

    private static boolean compareFiles(Path file1, Path file2) throws IOException {
        if (Files.size(file1) != Files.size(file2)) {
            return false;
        }
        byte[] file1Bytes = Files.readAllBytes(file1);
        byte[] file2Bytes = Files.readAllBytes(file2);
        for (int i = 0; i < file1Bytes.length; i++) {
            if (file1Bytes[i] != file2Bytes[i]) {
                return false;
            }
        }
        return true;
    }

    private static void addComparisonResult(FolderModel folderModel1, FolderModel folderModel2, String relativePath, boolean isEqual) {
        for (FileModel file : folderModel1.getFiles()) {
            if (file.getName().equals(relativePath)) {
                file.setComparisonResult(isEqual);
            }
        }
        for (FileModel file : folderModel2.getFiles()) {
            if (file.getName().equals(relativePath)) {
                file.setComparisonResult(isEqual);
            }
        }
    }

    public static void main(String[] args) throws IOException {
        String originalFolderPath = "C:\\dev\\new\\현대오토에버_전달파일";
        String comparisonFolderPath = "C:\\dev\\new\\현대오토에버_전달파일 - 복사본";
        String extension = ".arxml";

        ComparisonResult result = compareFolders(originalFolderPath, comparisonFolderPath, extension);

        // Print comparison results (example)
        printFolderModel(result.getOriginalFolder());
        printFolderModel(result.getComparisonFolder());
    }

    private static void printFolderModel(FolderModel folderModel) {
        System.out.println("Folder: " + folderModel.getName());
        for (FileModel file : folderModel.getFiles()) {
            System.out.println("File: " + file.getName() + ", Comparison Result: " + (file.isComparisonResult() ? "identical" : "different"));
        }
        for (FolderModel subFolder : folderModel.getSubFolders()) {
            printFolderModel(subFolder);
        }
    }
}
