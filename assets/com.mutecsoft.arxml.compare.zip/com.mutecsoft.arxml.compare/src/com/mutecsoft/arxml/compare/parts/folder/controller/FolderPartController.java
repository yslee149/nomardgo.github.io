package com.mutecsoft.arxml.compare.parts.folder.controller;

import javax.inject.Inject;

import org.eclipse.e4.ui.model.application.MApplication;
import org.eclipse.e4.ui.model.application.ui.basic.MPart;
import org.eclipse.e4.ui.workbench.modeling.EModelService;
import org.eclipse.e4.ui.workbench.modeling.EPartService;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import com.mutecsoft.arxml.compare.parts.folder.view.FolderPartView;

public class FolderPartController {

	private ButtonAction buttonAction;
	private FolderPartView view;
	private MPart part;
	private Shell shell;

	private EPartService partService;

	private EModelService modelService;

	private Display display;
	
	private MApplication application;

	public void setup(FolderPartView view, ButtonAction buttonAction, MPart part, Shell shell, Display display,
			EPartService partService, EModelService modelService, MApplication application) {
		this.view = view;
		this.buttonAction = buttonAction;
		this.part = part;
		this.shell = shell;
		this.display = display;
		this.partService = partService;
		this.modelService = modelService;
		this.application = application;
		
		initialize();
	}

	private void initialize() {

		view.createButton(view.topComposite, "Open Left", e -> buttonAction.openFolderLeft(shell, view));
		view.createButton(view.topComposite, "Open Right", e -> buttonAction.openFolderRight(shell, view));

		view.createButton(view.topComposite, "Compare Folder", e -> buttonAction.startFolderCompare(shell, view));
		view.createButton(view.topComposite, "Compare File", e -> buttonAction.compareFile(shell, view, display, partService, modelService, application));

		view.createButton(view.topComposite, "Expand All", e -> buttonAction.expandAll(part));
		view.createButton(view.topComposite, "Collapse All", e -> buttonAction.collapseAll(part));
		view.createButton(view.topComposite, "Expand Position",
				e -> buttonAction.logAction("Expand Position button clicked"));
		view.createButton(view.topComposite, "Collapse Position",
				e -> buttonAction.logAction("Collapse Position button clicked"));
		view.createButton(view.topComposite, "Search", e -> buttonAction.logAction("Search button clicked"));
		view.createButton(view.topComposite, "Refresh", e -> buttonAction.logAction("Refresh button clicked"));
		view.createButton(view.topComposite, "Add Row", e -> buttonAction.logAction("Add Row button clicked"));
		view.createButton(view.topComposite, "Remove Row", e -> buttonAction.logAction("Remove Row button clicked"));
	}
}
