package com.mutecsoft.arxml.compare.view.dialog;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.dialogs.ProgressMonitorDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.swt.widgets.Display;

public class ProgressDialogManager {
	private ProgressMonitorDialog progressDialog;
	private IProgressMonitor monitor;

	public ProgressDialogManager(Display display, String taskName, int totalWork) {
		progressDialog = new ProgressMonitorDialog(display.getActiveShell());
		try {
			progressDialog.run(true, true, new IRunnableWithProgress() {
				@Override
				public void run(IProgressMonitor monitor) {
					ProgressDialogManager.this.monitor = monitor;
					monitor.beginTask(taskName, totalWork);
					display.asyncExec(() -> {
						// Placeholder to keep the dialog open
					});
				}
			});
		} catch (InvocationTargetException | InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void updateProgress(int work) {
		if (monitor != null) {
			monitor.worked(work);
		}
	}

	public void done() {
		if (monitor != null) {
			monitor.done();
		}
	}

	public boolean isCanceled() {
		return monitor != null && monitor.isCanceled();
	}
}
