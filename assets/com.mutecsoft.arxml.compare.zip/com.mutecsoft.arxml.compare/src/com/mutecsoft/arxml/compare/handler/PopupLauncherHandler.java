package com.mutecsoft.arxml.compare.handler;

import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.handlers.HandlerUtil;

import com.mutecsoft.arxml.compare.MyConstant.ProjectType;
import com.mutecsoft.arxml.compare.builder.ProjectDataBuilder;
import com.mutecsoft.arxml.compare.model.ProjectData;
import com.mutecsoft.arxml.compare.util.SimpleLogger;

/**
 * �� �������� - �˾�
 * 
 * FileName : PopupLauncherHandler.java Comment :
 * 
 * @version : 1.0
 * @author : 9468029
 */
public class PopupLauncherHandler extends AbstractHandler {

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {

		IWorkbenchWindow window = HandlerUtil.getActiveWorkbenchWindowChecked(event);
		ISelection selection = window.getSelectionService().getSelection();

		if (selection != null && selection instanceof IStructuredSelection) {
			IStructuredSelection structuredSelection = (IStructuredSelection) selection;
			if (structuredSelection.size() == 2) {
				Iterator<?> it = structuredSelection.iterator();
				IProject project1 = (IProject) it.next();
				IProject project2 = (IProject) it.next();

				ProjectDataBuilder dataBuilder = new ProjectDataBuilder();
				try {
					Map<ProjectType, List<ProjectData>> projectsDatas = dataBuilder.processProjectsData(project1,
							project2);

					List<ProjectData> projectData1 = projectsDatas.get(ProjectType.ORIGIN);
					List<ProjectData> projectData2 = projectsDatas.get(ProjectType.TARGET);

					SimpleLogger.d("\n\n");

					SimpleLogger.d("1.������Ʈ ũ�� : " + projectData1.size());

					projectData1.forEach(data -> SimpleLogger.d(data.toString()));

					SimpleLogger.d("\n\n");

					SimpleLogger.d("2. ������Ʈ ũ�� : " + projectData2.size());

					projectData2.forEach(data -> SimpleLogger.d(data.toString()));

					Display display = window.getShell().getDisplay();

					Shell shell = new Shell(display);
					shell.setText("New Window");
					shell.setSize(400, 300);
					shell.open();

					while (!shell.isDisposed()) {
						if (!display.readAndDispatch()) {
							display.sleep();
						}
					}

				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (CoreException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		return null;
	}

}
