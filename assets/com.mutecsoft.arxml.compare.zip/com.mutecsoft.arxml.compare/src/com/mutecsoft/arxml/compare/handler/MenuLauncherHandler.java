package com.mutecsoft.arxml.compare.handler;

import java.util.Iterator;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.resources.IProject;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.handlers.HandlerUtil;

import com.mutecsoft.arxml.compare.util.SimpleLogger;

/**
 * �� ���� ���� - �޴�
 * 
 * FileName : MenuLauncherHandler.java Comment :
 * 
 * @version : 1.0
 * @author : 9468029
 */
public class MenuLauncherHandler extends AbstractHandler {

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		
		SimpleLogger.d("yslee ==================================>");

		IWorkbenchWindow window = HandlerUtil.getActiveWorkbenchWindowChecked(event);
		ISelection selection = window.getSelectionService().getSelection();

		if (selection != null && selection instanceof IStructuredSelection) {
			IStructuredSelection structuredSelection = (IStructuredSelection) selection;
			if (structuredSelection.size() == 2) {
				Iterator<?> it = structuredSelection.iterator();
				IProject project1 = (IProject) it.next();
				IProject project2 = (IProject) it.next();

				SimpleLogger.d("project1=" + project1.getName() + ", project2=" + project2.getName());

			}
		}

		return null;
	}

}
