package com.mutecsoft.arxml.compare.strategy;

public class FileComparisonStrategy {

}
