package com.mutecsoft.arxml.compare.model.folder;

import java.io.File;
import java.util.Date;

import com.mutecsoft.arxml.compare.model.FileModel;
import com.mutecsoft.arxml.compare.model.FolderModel;
import com.mutecsoft.arxml.compare.utils.DateFormatUtil;

public class FolderModelBuilder {

	private int positionCounter = 0;

	public FolderModel create(String rootPath) {
		File rootDir = new File(rootPath);
		return create(rootDir);
	}

	public FolderModel create(File file) {
		return createFolderModel(file, file.getAbsolutePath());
	}

	private FolderModel createFolderModel(File file, String path) {
		String folderType = "Directory";
		String createfolderDate = DateFormatUtil.formatDate(new Date(file.lastModified()));
		long folderSize = 0; // 폴더 크기를 저장할 변수

		FolderModel folderModel = new FolderModel(file.getName(), positionCounter++, createfolderDate, 0, folderType);
		if (file.isDirectory()) {
			File[] files = file.listFiles();
			if (files != null) {
				for (File child : files) {
					String childPath = path + File.separator + child.getName();
					if (child.isDirectory()) {
						FolderModel subFolder = createFolderModel(child, childPath);
						folderModel.addSubFolder(subFolder);
						folderSize += subFolder.getSize(); // 하위 폴더의 크기를 합산
					} else {
						if (child.getName().toLowerCase().endsWith(".arxml")) {
							FileModel fileModel = createFile(child);
							folderModel.addFile(fileModel);
							folderSize += child.length(); // 파일의 크기를 합산
						}
					}
				}
			}
		} else {
			folderSize = file.length(); // 폴더가 아닌 경우 파일 크기 설정
		}
		folderModel.setSize(folderSize); // 폴더 크기 설정
		return folderModel;
	}

	public FileModel createFile(File file) {
		String fileType = getFileType(file);
		String createfileDate = DateFormatUtil.formatDate(new Date(file.lastModified()));
		String fileSize = DateFormatUtil.formatSizeToKB(file.length());
		return new FileModel(file.getName(), positionCounter++, createfileDate, fileSize, fileType);
	}

	private String getFileType(File file) {
		String fileName = file.getName();
		int lastDot = fileName.lastIndexOf('.');
		return (lastDot == -1) ? "Unknown" : fileName.substring(lastDot + 1).toUpperCase();
	}
}