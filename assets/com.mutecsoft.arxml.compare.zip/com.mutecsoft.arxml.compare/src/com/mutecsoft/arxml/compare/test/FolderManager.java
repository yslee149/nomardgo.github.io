package com.mutecsoft.arxml.compare.test;

import java.io.File;

import com.mutecsoft.arxml.compare.model.FileModel;
import com.mutecsoft.arxml.compare.model.FolderModel;
import com.mutecsoft.arxml.compare.model.folder.FolderModelBuilder;

public class FolderManager {

	public static void main(String[] args) {
		// Example usage
		
//"C:\\dev\\new\\현대오토에버_전달파일\\r44_project_config"
		FolderModelBuilder builder = new FolderModelBuilder();
		File rootFolder = new File("C:\\dev\\new");
		FolderModel rootFolderModel = builder.create(rootFolder.getAbsolutePath());

		// Code to display or use the folder model
		displayFolderModel(rootFolderModel);
	}

	private static void displayFolderModel(FolderModel folderModel) {
		// Implement a method to display folder model information
		System.out.println("Folder: " + folderModel.getName());
		for (FileModel file : folderModel.getFiles()) {
			System.out.println("  File: " + file.getName());
		}
		for (FolderModel subFolder : folderModel.getSubFolders()) {
			displayFolderModel(subFolder);
		}
	}
}
