package com.mutecsoft.arxml.compare.model;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.IResource;

import com.mutecsoft.arxml.compare.MyConstant.CompareType;
import com.mutecsoft.arxml.compare.MyConstant.FileType;

public class ProjectDataModel {

	private int folderIndex;
	private int fileIndex;
	private int parentIndex;
	private int position;
	private FileType type;
	private String name;
	private IResource resource;
	private CompareType compareType;

	public Object autoSarObj; // TODO ���� AUTOSAR �� �����ؾ� ��

	private List<ProjectDataModel> children;

	public ProjectDataModel(int folderIndex, int fileIndex, int parentIndex, int position, FileType type, String name,
			IResource resource) {
		this.folderIndex = folderIndex;
		this.fileIndex = fileIndex;
		this.parentIndex = parentIndex;
		this.position = position;
		this.type = type;
		this.name = name;
		this.resource = resource;
		this.compareType = CompareType.SAME;
		this.children = new ArrayList<>();
	}

	public ProjectDataModel(int folderIndex, int fileIndex, int parentIndex, int position, FileType type, String name,
			IResource resource, CompareType compareType) {
		this.folderIndex = folderIndex;
		this.fileIndex = fileIndex;
		this.parentIndex = parentIndex;
		this.position = position;
		this.type = type;
		this.name = name;
		this.resource = resource;
		this.compareType = compareType;
		this.children = new ArrayList<>();
	}

	public int getFolderIndex() {
		return folderIndex;
	}

	public int getFileIndex() {
		return fileIndex;
	}

	public int getParentIndex() {
		return parentIndex;
	}

	public int getPosition() {
		return position;
	}

	public FileType getType() {
		return type;
	}

	public String getName() {
		return name;
	}

	public CompareType getCompareType() {
		return compareType;
	}
	
	public IResource getResource() {
		return resource;
	}

	public List<ProjectDataModel> getChildren() {
		return children;
	}

	// Ʈ�� ��ü�� ��� ������ ���ϴ� �޼���
	public int getTotalNodeCount() {
		int count = 1; // ���� ��带 �����Ͽ� ����
		for (ProjectDataModel child : children) {
			count += child.getTotalNodeCount(); // �ڽ� ����� ��� ������ ����
		}
		return count;
	}

}
