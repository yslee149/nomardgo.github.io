package com.mutecsoft.arxml.compare;

import javax.annotation.PreDestroy;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.eclipse.e4.core.contexts.IEclipseContext;
import org.eclipse.e4.ui.workbench.lifecycle.PostContextCreate;
import org.eclipse.e4.ui.workbench.lifecycle.PreSave;
import org.eclipse.e4.ui.workbench.lifecycle.ProcessAdditions;
import org.eclipse.e4.ui.workbench.lifecycle.ProcessRemovals;
import org.eclipse.swt.widgets.Display;

@SuppressWarnings("restriction")
public class E4LifeCycle {

	private static final Logger logger = LogManager.getLogger(E4LifeCycle.class);

	@PostContextCreate
	void postContextCreate(IEclipseContext workbenchContext, Display display) {
		logLifecycleEvent("postContextCreate");
	}

	@PreSave
	void preSave(IEclipseContext workbenchContext) {
		logLifecycleEvent("preSave");
	}

	@ProcessAdditions
	void processAdditions(IEclipseContext workbenchContext) {
		logLifecycleEvent("processAdditions");
	}

	@ProcessRemovals
	void processRemovals(IEclipseContext workbenchContext) {
		logLifecycleEvent("processRemovals");
	}

	@PreDestroy
	void preDestroy(IEclipseContext workbenchContext) {
		logLifecycleEvent("preDestroy");
		disposeDisplay();
		System.exit(0);
	}

	private void logLifecycleEvent(String eventName) {
		logger.info("E4LifeCycle " + eventName);
	}

	private void disposeDisplay() {
		Display display = Display.getCurrent();
		if (display != null) {
			display.dispose();
		}
	}
}