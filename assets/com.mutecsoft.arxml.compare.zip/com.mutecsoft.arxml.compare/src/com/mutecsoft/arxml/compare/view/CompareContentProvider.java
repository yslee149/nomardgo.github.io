package com.mutecsoft.arxml.compare.view;

import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.Viewer;

import com.mutecsoft.arxml.compare.model.FolderModel;

import java.util.ArrayList;
import java.util.List;

public class CompareContentProvider implements ITreeContentProvider {
	@Override
	public Object[] getElements(Object inputElement) {
		if (inputElement instanceof FolderModel) {
			return new Object[] { inputElement };
		}
		return new Object[0];
	}

	@Override
	public Object[] getChildren(Object parentElement) {
		if (parentElement instanceof FolderModel) {
			FolderModel folder = (FolderModel) parentElement;
			List<Object> children = new ArrayList<>();
			children.addAll(folder.getSubFolders());
			children.addAll(folder.getFiles());
			return children.toArray();
		}
		return new Object[0];
	}

	@Override
	public Object getParent(Object element) {
		return null; // �� ���������� �θ� ������ �ʿ����� ����
	}

	@Override
	public boolean hasChildren(Object element) {
		if (element instanceof FolderModel) {
			return ((FolderModel) element).hasChildren();
		}
		return false;
	}

	@Override
	public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
	}
}
