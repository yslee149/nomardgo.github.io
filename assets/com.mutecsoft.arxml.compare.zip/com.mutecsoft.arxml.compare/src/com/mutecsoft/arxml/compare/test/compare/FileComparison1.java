package com.mutecsoft.arxml.compare.test.compare;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.TrueFileFilter;
import org.apache.commons.io.filefilter.SuffixFileFilter;

import java.io.File;
import java.io.IOException;
import java.util.Collection;

public class FileComparison1 {

    public static void main(String[] args) {

        File folder1 = new File("C:\\dev\\new\\compare-test\\Configuration");
        File folder2 = new File("C:\\dev\\new\\compare-test\\Configuration2");

        if (!folder1.isDirectory() || !folder2.isDirectory()) {
            System.out.println("Both arguments must be directories.");
            return;
        }

        // .arxml 파일 필터 적용하여 파일 목록 가져오기
        Collection<File> filesInFolder1 = FileUtils.listFiles(folder1, new SuffixFileFilter(".arxml"), TrueFileFilter.INSTANCE);
        Collection<File> filesInFolder2 = FileUtils.listFiles(folder2, new SuffixFileFilter(".arxml"), TrueFileFilter.INSTANCE);

        System.out.println("Files in folder1: " + filesInFolder1.size());
        System.out.println("Files in folder2: " + filesInFolder2.size());

        // 폴더1의 파일들을 폴더2와 비교
        for (File file1 : filesInFolder1) {
            File file2 = new File(folder2, file1.getName());
            if (file2.exists()) {
                try {
                    if (FileUtils.contentEquals(file1, file2)) {
                        System.out.println("Files are identical: " + file1.getName());
                    } else {
                        System.out.println("Files are different: " + file1.getName());
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else {
                System.out.println("File " + file1.getName() + " not found in " + folder2.getAbsolutePath());
            }
        }

        // 폴더2의 파일들을 폴더1에서 찾기
        for (File file2 : filesInFolder2) {
            File file1 = new File(folder1, file2.getName());
            if (!file1.exists()) {
                System.out.println("File " + file2.getName() + " not found in " + folder1.getAbsolutePath());
            }
        }
    }
}
