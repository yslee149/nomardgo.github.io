package com.mutecsoft.arxml.compare.handlers;

import javax.annotation.PostConstruct;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.eclipse.e4.core.di.annotations.CanExecute;
import org.eclipse.e4.core.di.annotations.Execute;
import org.eclipse.e4.ui.model.application.ui.basic.MWindow;
import org.eclipse.e4.ui.workbench.modeling.EPartService;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class ScreenHandler {

	private static final Logger logger = LogManager.getLogger(ScreenHandler.class);

	@PostConstruct
	public void load(final MWindow window) {
		logger.info("WindowHandler load");

		Display display = Display.getDefault();
		if (display == null) {
			return;
		}
		display.asyncExec(() -> {
			Shell shell = (Shell) window.getWidget();
			if (shell != null) {
				setShellSize(shell, ScreenSize.EIGHTY_PERCENT_SCREEN);
				shell.setMinimumSize(800, 600);
			}
		});
	}

	@CanExecute
	public boolean canExecute(EPartService partService) {
		logger.info("canExecute load");
		return false;
	}

	@Execute
	public void execute(EPartService partService) {
		logger.info("execute load");
	}

	private void setShellSize(Shell shell, ScreenSize screenSize) {
		if (screenSize == null) {
			throw new IllegalArgumentException("ScreenSize must not be null.");
		}

		Display display = shell.getDisplay();
		Rectangle screenSizeBounds = display.getPrimaryMonitor().getBounds();

		int newWidth = (int) (screenSizeBounds.width * screenSize.getRatio());
		int newHeight = (int) (screenSizeBounds.height * screenSize.getRatio());

		int newX = (screenSizeBounds.width - newWidth) / 2;
		int newY = (screenSizeBounds.height - newHeight) / 2;

		shell.setBounds(newX, newY, newWidth, newHeight);
	}

	public enum ScreenSize {
		FULL_SCREEN(1.0), HALF_SCREEN(0.5), THIRD_SCREEN(1.0 / 3.0), QUARTER_SCREEN(0.25), EIGHTY_PERCENT_SCREEN(0.8);

		private final double ratio;

		ScreenSize(double ratio) {
			this.ratio = ratio;
		}

		public double getRatio() {
			return ratio;
		}
	}
}
