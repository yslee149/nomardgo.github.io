package com.mutecsoft.arxml.compare.db;

public class QuerySet {

	public enum ProjectQueryKey {
		CREATE_TABLE_PROJECT_DATA,
		CREATE_INDEX_PROJECT_ID, 
		CREATE_INDEX_FILE_PATH, 
		CREATE_INDEX_PARENT_ID, 
		DELETE_ALL, 
		DELETE_ONE,
		UPDATE_COMPARE_RESULT,
		INSERT_DATA,
		SELECT_COMPARE_ALL,
		SELECT_COMPARE_DIFFERENT,
		SELECT_COMPARE_SAME
	}

}
