package com.mutecsoft.arxml.compare.model.folder;

import com.mutecsoft.arxml.compare.model.GenericModel;

public class GenericModelBuilder {

	private int positionCounter = 0;

	public GenericModel<String> createInputData() {
		GenericModel<String> root = new GenericModel<>("Root", "Root Data", positionCounter++, true);

		GenericModel<String> child1 = new GenericModel<>("Child 1", "Child 1 Data", positionCounter++, false);
		GenericModel<String> child2 = new GenericModel<>("Child 2", "Child 2 Data", positionCounter++, false);

		root.addChild(child1);
		root.addChild(child2);

		GenericModel<String> grandChild1 = new GenericModel<>("GrandChild 1", "GrandChild 1 Data", positionCounter++,
				false);
		GenericModel<String> grandChild2 = new GenericModel<>("GrandChild 2", "GrandChild 2 Data", positionCounter++,
				false);

		child1.addChild(grandChild1);
		child2.addChild(grandChild2);

		return root;
	}

}
