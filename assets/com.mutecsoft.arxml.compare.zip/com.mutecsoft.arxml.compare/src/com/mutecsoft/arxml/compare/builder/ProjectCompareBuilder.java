package com.mutecsoft.arxml.compare.builder;

import com.mutecsoft.arxml.compare.MyConstant.CompareType;
import com.mutecsoft.arxml.compare.MyConstant.FileType;
import com.mutecsoft.arxml.compare.model.ProjectDataModel;
import com.mutecsoft.arxml.compare.util.SimpleLogger;

public class ProjectCompareBuilder {

	// �� ���� Ʈ���� ���Ͽ� �������� �����ϴ� Ʈ�� ��ȯ
	public ProjectDataModel[] compareTrees(ProjectDataModel root1, ProjectDataModel root2) {

		SimpleLogger.d("PRJ-1 SIZE=" + root1.getTotalNodeCount());
		SimpleLogger.d("PRJ-2 SIZE=" + root2.getTotalNodeCount());

		ProjectDataModel resultRoot1 = new ProjectDataModel(0, 0, 0, 0, root1.getType(), root1.getName(), null,
				CompareType.SAME);
		ProjectDataModel resultRoot2 = new ProjectDataModel(0, 0, 0, 0, root2.getType(), root2.getName(), null,
				CompareType.SAME);

		compareNodes(root1, root2, resultRoot1, resultRoot2);

		SimpleLogger.d("PRJ-COMP-1 SIZE=" + resultRoot1.getTotalNodeCount());
		SimpleLogger.d("PRJ-COMP-2 SIZE=" + resultRoot2.getTotalNodeCount());

		logProjectDataModel(resultRoot1);
		logProjectDataModel(resultRoot2);

		ProjectDataModel[] results = { resultRoot1, resultRoot2 };
		return results;
	}

	// ���� ��带 ���Ͽ� �������� ��� ����Ʈ�� �߰�
	private void compareNodes(ProjectDataModel node1, ProjectDataModel node2, ProjectDataModel resultNode1,
			ProjectDataModel resultNode2) {
		if (node1 == null && node2 == null)
			return;

		if (node1 != null && node2 != null) {
			// node1�� node2�� �Ӽ� ��
			if (!node1.getName().equals(node2.getName())
					|| !compareAutoSarObjects(node1.autoSarObj, node2.autoSarObj)) {
				resultNode1.getChildren().add(new ProjectDataModel(0, 0, 0, 0, node1.getType(), node1.getName(), null,
						CompareType.DIFFERENT));
				resultNode2.getChildren().add(new ProjectDataModel(0, 0, 0, 0, node2.getType(), node2.getName(), null,
						CompareType.DIFFERENT));
			} else {
				ProjectDataModel newNode1 = new ProjectDataModel(node1.getFolderIndex(), node1.getFileIndex(),
						node1.getParentIndex(), node1.getPosition(), node1.getType(), node1.getName(),
						node1.getResource(), node1.getCompareType());
				ProjectDataModel newNode2 = new ProjectDataModel(node2.getFolderIndex(), node2.getFileIndex(),
						node2.getParentIndex(), node2.getPosition(), node2.getType(), node2.getName(),
						node2.getResource(), node2.getCompareType());
				resultNode1.getChildren().add(newNode1);
				resultNode2.getChildren().add(newNode2);

				// �ڽ� ��� ��
				int maxChildren = Math.max(node1.getChildren().size(), node2.getChildren().size());

				for (int i = 0; i < maxChildren; i++) {
					ProjectDataModel child1 = (i < node1.getChildren().size()) ? node1.getChildren().get(i)
							: createEmptyNode(node2.getType(), CompareType.ONLY_IN_TREE2);
					ProjectDataModel child2 = (i < node2.getChildren().size()) ? node2.getChildren().get(i)
							: createEmptyNode(node1.getType(), CompareType.ONLY_IN_TREE1);

					ProjectDataModel newChildNode1 = new ProjectDataModel(child1.getFolderIndex(),
							child1.getFileIndex(), child1.getParentIndex(), child1.getPosition(), child1.getType(),
							child1.getName(), child1.getResource(), child1.getCompareType());
					ProjectDataModel newChildNode2 = new ProjectDataModel(child2.getFolderIndex(),
							child2.getFileIndex(), child2.getParentIndex(), child2.getPosition(), child2.getType(),
							child2.getName(), child2.getResource(), child2.getCompareType());

					compareNodes(child1, child2, newChildNode1, newChildNode2);
					newNode1.getChildren().add(newChildNode1);
					newNode2.getChildren().add(newChildNode2);
				}
			}
		} else if (node1 != null) {
			CompareType compareType = CompareType.ONLY_IN_TREE1;
			ProjectDataModel newNode1 = new ProjectDataModel(0, 0, 0, 0, node1.getType(), node1.getName(), null,
					compareType);
			ProjectDataModel newNode2 = createEmptyNode(node1.getType(), CompareType.ONLY_IN_TREE1);
			resultNode1.getChildren().add(newNode1);
			resultNode2.getChildren().add(newNode2);
			for (ProjectDataModel child : node1.getChildren()) {
				ProjectDataModel newChildNode1 = new ProjectDataModel(child.getFolderIndex(), child.getFileIndex(),
						child.getParentIndex(), child.getPosition(), child.getType(), child.getName(),
						child.getResource(), child.getCompareType());
				ProjectDataModel newChildNode2 = createEmptyNode(child.getType(), CompareType.ONLY_IN_TREE1);
				compareNodes(child, newChildNode2, newChildNode1, newChildNode2);
				newNode1.getChildren().add(newChildNode1);
				newNode2.getChildren().add(newChildNode2);
			}
		} else {
			CompareType compareType = CompareType.ONLY_IN_TREE2;
			ProjectDataModel newNode1 = createEmptyNode(node2.getType(), CompareType.ONLY_IN_TREE2);
			ProjectDataModel newNode2 = new ProjectDataModel(0, 0, 0, 0, node2.getType(), node2.getName(), null,
					compareType);
			resultNode1.getChildren().add(newNode1);
			resultNode2.getChildren().add(newNode2);
			for (ProjectDataModel child : node2.getChildren()) {
				ProjectDataModel newChildNode1 = createEmptyNode(child.getType(), CompareType.ONLY_IN_TREE2);
				ProjectDataModel newChildNode2 = new ProjectDataModel(child.getFolderIndex(), child.getFileIndex(),
						child.getParentIndex(), child.getPosition(), child.getType(), child.getName(),
						child.getResource(), child.getCompareType());
				compareNodes(newChildNode1, child, newChildNode1, newChildNode2);
				newNode1.getChildren().add(newChildNode1);
				newNode2.getChildren().add(newChildNode2);
			}
		}
	}

	// TODO: autoSarObj�� ���ϴ� �޼���
	private boolean compareAutoSarObjects(Object obj1, Object obj2) {
		return true;
	}

	private ProjectDataModel createEmptyNode(FileType type, CompareType compareType) {
		return new ProjectDataModel(0, 0, 0, 0, type, "", null, compareType);
	}

	private void logProjectDataModel(ProjectDataModel data) {
		StringBuilder log = new StringBuilder();

		log.append("FoderIdx=").append(data.getFolderIndex()).append(",").append("ParentIdx=")
				.append(data.getParentIndex()).append(",").append("position=").append(data.getPosition()).append(",")
				.append("FileIdx=").append(data.getFileIndex()).append(",").append("Name=").append(data.getName())
				.append(",").append("Type=").append(data.getType().name());

		SimpleLogger.d(log.toString());

		for (ProjectDataModel child : data.getChildren()) {
			logProjectDataModel(child);
		}
	}

}
