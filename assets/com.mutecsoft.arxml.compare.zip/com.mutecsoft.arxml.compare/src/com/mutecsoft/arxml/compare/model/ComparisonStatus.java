package com.mutecsoft.arxml.compare.model;

public enum ComparisonStatus {
	IDENTICAL, DIFFERENT, ONLY_IN_ORIGINAL, ONLY_IN_COMPARISON
}
