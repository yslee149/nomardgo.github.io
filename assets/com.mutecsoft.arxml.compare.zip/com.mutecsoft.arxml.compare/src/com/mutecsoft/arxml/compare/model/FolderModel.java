package com.mutecsoft.arxml.compare.model;

import java.util.ArrayList;
import java.util.List;

public class FolderModel {
	private String name;
	private List<FolderModel> subFolders;
	private List<FileModel> files;
	private boolean isExpanded;
	private int position;
	private String createdDate;
	private long size;
	private String type;
	private ComparisonStatus comparisonStatus; // 추가된 필드

	public FolderModel(String name, int position, String createdDate, long size, String type) {
		this.name = name;
		this.position = position;
		this.createdDate = createdDate;
		this.size = size;
		this.type = type;
		this.isExpanded = false;
		this.subFolders = new ArrayList<>();
		this.files = new ArrayList<>();
		this.comparisonStatus = ComparisonStatus.IDENTICAL; // 기본값
	}

	public FolderModel(String name, int position, String createdDate, long size, String type, ComparisonStatus status) {
		this(name, position, createdDate, size, type);
		this.comparisonStatus = status;
	}

	public String getName() {
		return name;
	}

	public List<FolderModel> getSubFolders() {
		return subFolders;
	}

	public List<FileModel> getFiles() {
		return files;
	}

	public boolean isExpanded() {
		return isExpanded;
	}

	public void setExpanded(boolean isExpanded) {
		this.isExpanded = isExpanded;
	}

	public int getPosition() {
		return position;
	}

	public void setPosition(int position) {
		this.position = position;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public long getSize() {
		return size;
	}

	public String getType() {
		return type;
	}

	public void addSubFolder(FolderModel folder) {
		subFolders.add(folder);
	}

	public void addFile(FileModel file) {
		files.add(file);
	}

	public boolean hasChildren() {
		return !subFolders.isEmpty() || !files.isEmpty();
	}

	public void setSize(long size) {
		this.size = size;
	}

	public ComparisonStatus getComparisonStatus() {
		return comparisonStatus;
	}

	public void setComparisonStatus(ComparisonStatus comparisonStatus) {
		this.comparisonStatus = comparisonStatus;
	}
}
