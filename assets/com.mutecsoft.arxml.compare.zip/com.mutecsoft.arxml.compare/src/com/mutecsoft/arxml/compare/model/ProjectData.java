package com.mutecsoft.arxml.compare.model;

public class ProjectData {

	int id;
	int project_id;
	int parent_id;
	String file_name;
	String file_path;
	String file_full_path;
	int file_type;
	String file_date;
	int compare_result;
	int version;

	public ProjectData() {

	}

	public int getId() {
		return id;
	}

	public int getProject_id() {
		return project_id;
	}

	public int getParent_id() {
		return parent_id;
	}

	public String getFile_name() {
		return file_name;
	}

	public String getFile_path() {
		return file_path;
	}

	public String getFile_full_path() {
		return file_full_path;
	}

	public int getFile_type() {
		return file_type;
	}

	public String getFile_date() {
		return file_date;
	}

	public int getCompare_result() {
		return compare_result;
	}

	public int getVersion() {
		return version;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setProject_id(int project_id) {
		this.project_id = project_id;
	}

	public void setParent_id(int parent_id) {
		this.parent_id = parent_id;
	}

	public void setFile_name(String file_name) {
		this.file_name = file_name;
	}

	public void setFile_path(String file_path) {
		this.file_path = file_path;
	}

	public void setFile_full_path(String file_full_path) {
		this.file_full_path = file_full_path;
	}

	public void setFile_type(int file_type) {
		this.file_type = file_type;
	}

	public void setFile_date(String file_date) {
		this.file_date = file_date;
	}

	public void setCompare_result(int compare_result) {
		this.compare_result = compare_result;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	@Override
	public String toString() {
		return "ProjectData [id=" + id + ", project_id=" + project_id + ", parent_id=" + parent_id + ", file_name="
				+ file_name + ", file_path=" + file_path + ", file_full_path=" + file_full_path + ", file_type="
				+ file_type + ", file_date=" + file_date + ", compare_result=" + compare_result + ", version=" + version
				+ "]";
	}

}
