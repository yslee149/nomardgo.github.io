package com.mutecsoft.arxml.compare.parts.folder.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Insets;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.tree.DefaultTreeCellRenderer;

import org.eclipse.swt.SWT;
import org.eclipse.swt.awt.SWT_AWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.jdesktop.swingx.JXTreeTable;
import org.jdesktop.swingx.decorator.ColorHighlighter;
import org.jdesktop.swingx.decorator.Highlighter;

import com.mutecsoft.arxml.compare.model.FileModel;
import com.mutecsoft.arxml.compare.model.FolderModel;
import com.mutecsoft.arxml.compare.parts.folder.model.LeftFolderTreeTableModel;

public class LeftTreeTable {
	private JXTreeTable treeTable;
	private LeftFolderTreeTableModel treeTableModel;

	public LeftTreeTable(Composite parent, LeftFolderTreeTableModel model) {
		this.treeTableModel = model;
		createTreeTable(parent);
	}

	private void createTreeTable(Composite parent) {
		Composite treeComposite = new Composite(parent, SWT.NONE);
		GridData gridData = new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1);
		treeComposite.setLayoutData(gridData);

		GridLayout gridLayout = new GridLayout(1, false);
		gridLayout.marginHeight = 0;
		gridLayout.marginWidth = 0;
		gridLayout.horizontalSpacing = 0;
		gridLayout.verticalSpacing = 0;
		treeComposite.setLayout(gridLayout);

		Composite swingComposite = new Composite(treeComposite, SWT.EMBEDDED | SWT.NO_BACKGROUND);
		swingComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));

		java.awt.Frame frame = SWT_AWT.new_Frame(swingComposite);

		SwingUtilities.invokeLater(() -> configureSwingComponents(frame));
	}

	private void configureSwingComponents(java.awt.Frame frame) {
		try {
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException
				| UnsupportedLookAndFeelException e) {
			e.printStackTrace();
		}

		JPanel panel = new JPanel(new BorderLayout());
		frame.add(panel);

		// Define the custom border
		Border customBorder = new Border() {
//            Color color = Color.YELLOW;
			int thickness = 0;

			@Override
			public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
//                g.setColor(color);
//                for (int i = 0; i < thickness; i++) {
//                    g.drawRect(x + i, y + i, width - i - i - 1, height - i - i - 1);
//                }
			}

			@Override
			public boolean isBorderOpaque() {
				return true;
			}

			@Override
			public Insets getBorderInsets(Component c) {
				return new Insets(thickness, thickness, thickness, thickness);
			}
		};

		treeTable = new JXTreeTable(treeTableModel);
		treeTable.setRootVisible(true);

		setColumnWidth(treeTable);
		setCustomRenderer(treeTable, 3);
		configureTreeTable();

		JScrollPane scrollPane = new JScrollPane(treeTable);
		scrollPane.setBorder(customBorder); // Set custom border
		scrollPane.getVerticalScrollBar().setPreferredSize(new Dimension(0, 0));
		scrollPane.getHorizontalScrollBar().setPreferredSize(new Dimension(0, 0));
		panel.add(scrollPane, BorderLayout.CENTER);
	}

	private void setColumnWidth(JXTreeTable treeTable) {

		int[] fixedColumnWidths = { 100, 200, 50 }; // 각 컬럼의 넓이 (두 번째 컬럼부터)

		for (int i = 1; i < fixedColumnWidths.length + 1; i++) {
			TableColumn column = treeTable.getColumnModel().getColumn(i);
			column.setPreferredWidth(fixedColumnWidths[i - 1]);
			column.setMinWidth(fixedColumnWidths[i - 1]);
			column.setMaxWidth(fixedColumnWidths[i - 1]);
		}

		// 첫 번째 컬럼의 넓이를 나머지 공간으로 채움
		TableColumn firstColumn = treeTable.getColumnModel().getColumn(0);
		firstColumn.setPreferredWidth(300); // 기본 넓이 설정
		firstColumn.setMinWidth(100); // 최소 넓이 설정

	}

	private void setCustomRenderer(JXTreeTable treeTable, int specialColumn) {
		TableCellRenderer defaultRenderer = treeTable.getDefaultRenderer(Object.class);
//		treeTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
//			@Override
//			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
//					boolean hasFocus, int row, int column) {
//				Component c = defaultRenderer.getTableCellRendererComponent(table, value, isSelected, hasFocus, row,
//						column);
//
////				if (isSelected) {
////					if (column == specialColumn) {
////						c.setBackground(new Color(0, 0, 0, 0)); // 투명 배경색 설정
////						((JComponent) c).setOpaque(false); // 불투명성 설정
////					} else {
////						c.setBackground(table.getSelectionBackground()); // 기본 선택 색상
////						((JComponent) c).setOpaque(true); // 불투명성 설정
////					}
////				} else {
////					c.setBackground(table.getBackground()); // 기본 배경색
////					((JComponent) c).setOpaque(true); // 불투명성 설정
////				}
//				
////				if (isSelected) {
////					c.setBackground(Color.WHITE); // 투명 배경색 설정
////					c.setForeground(Color.RED);
////				} else {
////					c.setBackground(Color.WHITE); // 투명 배경색 설정
////					c.setForeground(Color.YELLOW);	
////				}
//				
//				return c;
//			}
//		});
	}

	private void configureTreeTable() {
		treeTable.putClientProperty("JTree.lineStyle", "Angled");
		treeTable.setRowHeight(25);
		treeTable.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

		configureTreeTableRendering();
	}

	private void configureTreeTableRendering() {
		Highlighter oddHighlighter = new ColorHighlighter((component, adapter) -> adapter.row % 2 != 0, Color.WHITE,
				Color.BLACK);
		Highlighter evenHighlighter = new ColorHighlighter((component, adapter) -> adapter.row % 2 == 0,
				new Color(248, 250, 249), Color.BLACK);
		treeTable.addHighlighter(oddHighlighter);
		treeTable.addHighlighter(evenHighlighter);

//        DefaultTableCellRenderer leftRenderer = new DefaultTableCellRenderer();
//        leftRenderer.setHorizontalAlignment(DefaultTableCellRenderer.LEFT);
//        treeTable.getColumn(0).setCellRenderer(leftRenderer);
//
//        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
//        rightRenderer.setHorizontalAlignment(DefaultTableCellRenderer.RIGHT);
//        for (int i = 1; i < treeTable.getColumnCount(); i++) {
//            treeTable.getColumn(i).setCellRenderer(rightRenderer);
//        }
	}

	public void setTreeData(FolderModel newRootNode) {

		treeTableModel.setRoot(newRootNode);
		treeTableModel.reload();

		SwingUtilities.invokeLater(() -> {

			setColumnWidth(treeTable);
			
//			treeTable.setForeground(Color.RED);
//			setCustomRenderer(treeTable);
//			treeTable.setTreeCellRenderer(new CustomTreeCellRenderer());
			
//			printFolderModel(newRootNode, 0);

		});

	}
	
	public void printFolderModel(FolderModel folderModel, int level) {
		printIndent(level);
		System.out.println("Folder: " + folderModel.getName() + ", Size: " + folderModel.getSize() + " bytes");

		for (FileModel file : folderModel.getFiles()) {
			printIndent(level + 1);
			System.out.println("File: " + file.getName() + ", Size: " + file.getSize());
		}

		for (FolderModel subFolder : folderModel.getSubFolders()) {
			printFolderModel(subFolder, level + 1);
		}
	}

	private void printIndent(int level) {
		for (int i = 0; i < level; i++) {
			System.out.print("  ");
		}
	}

//	void setCustomRenderer(JXTreeTable treeTable) {
//		TableCellRenderer defaultRenderer = treeTable.getDefaultRenderer(Object.class);
//		treeTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
//
//			private static final long serialVersionUID = 1L;
//
//			@Override
//			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
//					boolean hasFocus, int row, int column) {
//				Component c = defaultRenderer.getTableCellRendererComponent(table, value, isSelected, hasFocus, row,
//						column);
//
////				// 특정 조건에 따라 배경색 변경
////				if (value != null && value.toString().equals("Data 1")) {
//				c.setForeground(Color.YELLOW); // 조건을 만족하면 배경색을 노란색으로 설정
////				} else if (isSelected) {
////					c.setBackground(table.getSelectionBackground()); // 기본 선택 색상
////				} else {
////					c.setBackground(table.getBackground()); // 기본 배경색
////				}
//
//				return c;
//			}
//		});
//	}

	public JXTreeTable getTreeTable() {
		return treeTable;
	}

	class CustomTreeCellRenderer extends DefaultTreeCellRenderer {
		@Override
		public Component getTreeCellRendererComponent(JTree tree, Object value, boolean sel, boolean expanded,
				boolean leaf, int row, boolean hasFocus) {
			Component c = super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);

			// 원하는 색상으로 설정 (예: 배경색, 전경색)
//			c.setForeground(Color.BLUE);
//			c.setBackground(Color.LIGHT_GRAY);

//			if (sel) {
//				c.setForeground(Color.RED);
//			}

//			c.setForeground(Color.RED);

			JLabel label = new JLabel();
			label.setText("[" + row + "] , " + value.toString());
//              label.setOpaque(true);
//              return label;

			return c;
		}

	}
}
