package com.mutecsoft.arxml.compare.utils;

public class StringUtils {

	/**
	 * 문자열이 빈 값인지 확인합니다.
	 * 
	 * @param str 확인할 문자열
	 * @return 문자열이 빈 값이면 true, 그렇지 않으면 false
	 */
	public static boolean isEmpty(String str) {
		return str == null || str.isEmpty();
	}

	/**
	 * 문자열이 빈 값이거나 공백만 포함하는지 확인합니다.
	 * 
	 * @param str 확인할 문자열
	 * @return 문자열이 빈 값이거나 공백만 포함하면 true, 그렇지 않으면 false
	 */
	public static boolean isBlank(String str) {
		return str == null || str.trim().isEmpty();
	}
}
