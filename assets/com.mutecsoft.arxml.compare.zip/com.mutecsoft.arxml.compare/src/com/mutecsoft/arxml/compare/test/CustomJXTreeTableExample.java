package com.mutecsoft.arxml.compare.test;

import org.jdesktop.swingx.JXTreeTable;
import org.jdesktop.swingx.decorator.ColorHighlighter;
import org.jdesktop.swingx.decorator.Highlighter;
import org.jdesktop.swingx.treetable.AbstractTreeTableModel;

import javax.swing.*;
import javax.swing.event.MouseInputAdapter;
import javax.swing.table.TableColumn;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.TreePath;
import java.awt.*;
import java.awt.event.MouseEvent;

public class CustomJXTreeTableExample {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Custom JXTreeTable Example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // 트리 노드 생성
        DefaultMutableTreeNode root = new DefaultMutableTreeNode("Root");
        DefaultMutableTreeNode child1 = new DefaultMutableTreeNode("Child 1");
        DefaultMutableTreeNode child2 = new DefaultMutableTreeNode("Child 2");
        DefaultMutableTreeNode subChild1 = new DefaultMutableTreeNode("Sub Child 1");
        DefaultMutableTreeNode subChild2 = new DefaultMutableTreeNode("Sub Child 2");

        child1.add(subChild1);
        child2.add(subChild2);
        root.add(child1);
        root.add(child2);

        // 트리 테이블 모델 생성
        MyTreeTableModel treeTableModel = new MyTreeTableModel(root);

        // JXTreeTable 생성
        JXTreeTable treeTable = new JXTreeTable(treeTableModel);

        // 기본 아이콘 및 들여쓰기 제거를 위한 커스텀 렌더러 설정
        DefaultTreeCellRenderer treeCellRenderer = new DefaultTreeCellRenderer() {
            @Override
            public Component getTreeCellRendererComponent(JTree tree, Object value,
                                                          boolean sel, boolean expanded,
                                                          boolean leaf, int row,
                                                          boolean hasFocus) {
                JLabel label = (JLabel) super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);
                label.setIcon(null);  // 아이콘 제거
                label.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));  // 들여쓰기 제거
                return label;
            }
        };

        treeTable.setTreeCellRenderer(treeCellRenderer);
        treeTable.setRowHeight(20);  // 행 높이 설정

        // 첫 번째 컬럼 숨기기
        TableColumn column = treeTable.getColumnModel().getColumn(0);
        column.setMinWidth(0);
        column.setMaxWidth(0);
        column.setPreferredWidth(0);
        column.setResizable(false);

        
    	// 짝수 열과 홀수 열 배경색 다르게 설정
		Highlighter oddHighlighter = new ColorHighlighter((component, adapter) -> adapter.row % 2 != 0,
				new Color(255, 255, 255, 255), Color.BLACK);
		Highlighter evenHighlighter = new ColorHighlighter((component, adapter) -> adapter.row % 2 == 0,
				new Color(248, 250, 249, 255), Color.BLACK);
		treeTable.addHighlighter(oddHighlighter);
		treeTable.addHighlighter(evenHighlighter);
        
        // 더블 클릭 이벤트 처리
        treeTable.addMouseListener(new MouseInputAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int row = treeTable.rowAtPoint(e.getPoint());
                    if (row != -1) {
                        TreePath treePath = treeTable.getPathForRow(row);
                        if (treePath != null) {
                            if (treeTable.isExpanded(treePath)) {
                                treeTable.collapsePath(treePath);
                            } else {
                                treeTable.expandPath(treePath);
                            }
                        }
                    }
                }
            }
        });

        // JScrollPane에 추가하여 표시
        frame.add(new JScrollPane(treeTable), BorderLayout.CENTER);
        frame.pack();
        frame.setVisible(true);
    }

    // 커스텀 TreeTableModel 클래스
    static class MyTreeTableModel extends AbstractTreeTableModel {
        private String[] columnNames = {"Column 1", "Column 2"};

        public MyTreeTableModel(Object root) {
            super(root);
        }

        @Override
        public int getColumnCount() {
            return columnNames.length;
        }

        @Override
        public String getColumnName(int column) {
            return columnNames[column];
        }

        @Override
        public Object getValueAt(Object node, int column) {
            if (node instanceof DefaultMutableTreeNode) {
                DefaultMutableTreeNode treeNode = (DefaultMutableTreeNode) node;
                switch (column) {
                    case 0:
                        return treeNode.getUserObject();
                    case 1:
                        return "";
                }
            }
            return null;
        }

        @Override
        public Object getChild(Object parent, int index) {
            if (parent instanceof DefaultMutableTreeNode) {
                return ((DefaultMutableTreeNode) parent).getChildAt(index);
            }
            return null;
        }

        @Override
        public int getChildCount(Object parent) {
            if (parent instanceof DefaultMutableTreeNode) {
                return ((DefaultMutableTreeNode) parent).getChildCount();
            }
            return 0;
        }

        @Override
        public int getIndexOfChild(Object parent, Object child) {
            if (parent instanceof DefaultMutableTreeNode && child instanceof DefaultMutableTreeNode) {
                return ((DefaultMutableTreeNode) parent).getIndex((DefaultMutableTreeNode) child);
            }
            return -1;
        }

        @Override
        public boolean isLeaf(Object node) {
            if (node instanceof DefaultMutableTreeNode) {
                return ((DefaultMutableTreeNode) node).isLeaf();
            }
            return true;
        }
    }
}
