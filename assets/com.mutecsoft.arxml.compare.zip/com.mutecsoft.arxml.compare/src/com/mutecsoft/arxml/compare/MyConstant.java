package com.mutecsoft.arxml.compare;

public class MyConstant {

	public enum ProjectType {
		ORIGIN(1), TARGET(2)

		;
		int code;

		ProjectType(int code) {
			this.code = code;
		}

		public int getCode() {
			return code;
		}
	}

	public enum FileType {
		PROJECT(0), FOLDER(1), FILE(2)

		;

		int code;

		FileType(int code) {
			this.code = code;
		}

		public int getCode() {
			return code;
		}
	}

	public enum FixedExtension {
		ARXML, BMD, TXT
	}

	public enum CompareType {
		SAME(0), DIFFERENT(1), ONLY_IN_TREE1(2), ONLY_IN_TREE2(3)

		;

		int code;

		CompareType(int code) {
			this.code = code;
		}

		public int getCode() {
			return code;
		}

	}

}
