package com.mutecsoft.arxml.compare.global;

public class MyApp {

	public static String ORIGINAL_FOLDER_PATH = null;
	public static String COMPARISON_FOLDER_PATH = null;

}
