package com.mutecsoft.arxml.compare.parts.folder.view;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;
import javax.swing.tree.TreePath;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.jdesktop.swingx.JXTreeTable;

import com.mutecsoft.arxml.compare.model.FolderModel;
import com.mutecsoft.arxml.compare.parts.folder.model.LeftFolderTreeTableModel;
import com.mutecsoft.arxml.compare.parts.folder.model.RightFolderTreeTableModel;

public class FolderPartView {

	private static final Logger logger = LogManager.getLogger(FolderPartView.class);

	private Composite parent;
	public Composite topComposite;

	private LeftFolderTreeTableModel treeTableModelLeft = new LeftFolderTreeTableModel(null);
	private RightFolderTreeTableModel treeTableModelRight = new RightFolderTreeTableModel(null);

	private LeftTreeTable leftTreeTable;
	private RightTreeTable rightTreeTable;

	public FolderPartView(Composite parent) {
		this.parent = parent;
		createComposite();
	}

	private void createComposite() {
		GridLayout gridLayout = new GridLayout(2, false);
		gridLayout.marginWidth = 0;
		gridLayout.marginHeight = 0;
		gridLayout.horizontalSpacing = 0;
		gridLayout.verticalSpacing = 0;
		parent.setLayout(gridLayout);
	}

	public void createTopArea() {
		topComposite = new Composite(parent, SWT.BORDER);
		topComposite.setLayout(new GridLayout(16, false));
		GridData gridData = new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1);
		gridData.heightHint = 50;
		topComposite.setLayoutData(gridData);
	}

	public void createButton(Composite parent, String text, Listener listener) {
		Button button = new Button(parent, SWT.PUSH);
		button.setText(text);
		button.addListener(SWT.Selection, listener);
		button.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, true));
	}

	public void createLeftArea() {
		leftTreeTable = new LeftTreeTable(parent, treeTableModelLeft);
		// Ensure the JXTreeTable is properly initialized before configuration
		SwingUtilities.invokeLater(() -> configureTreeTable(leftTreeTable.getTreeTable()));
	}

	public void createRightArea() {
		rightTreeTable = new RightTreeTable(parent, treeTableModelRight);
		// Ensure the JXTreeTable is properly initialized before configuration
		SwingUtilities.invokeLater(() -> configureTreeTable(rightTreeTable.getTreeTable()));
	}

	public void setLeftTreeData(FolderModel newRootNode) {
		leftTreeTable.setTreeData(newRootNode);
	}

	public void setRightTreeData(FolderModel newRootNode) {
		rightTreeTable.setTreeData(newRootNode);
	}

	public void updateComparisonData(FolderModel originRootNode, FolderModel comparisonRootNode) {
		leftTreeTable.setTreeData(originRootNode);
		rightTreeTable.setTreeData(comparisonRootNode);
	}

	private void configureTreeTable(JXTreeTable treeTable) {
		if (treeTable == null) {
			logger.error("JXTreeTable is null. Skipping configuration.");
			return;
		}

		treeTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (SwingUtilities.isLeftMouseButton(e)) {
					if (e.getClickCount() == 1) {
						handleSingleClick(treeTable);
					} else if (e.getClickCount() == 2) {
						handleDoubleClick(treeTable, e);
					}
				}
			}
		});

		if (leftTreeTable != null && rightTreeTable != null) {
			JScrollPane leftScrollPane = (JScrollPane) leftTreeTable.getTreeTable().getParent().getParent();
			JScrollPane rightScrollPane = (JScrollPane) rightTreeTable.getTreeTable().getParent().getParent();
			syncScrollPanes(leftScrollPane, rightScrollPane);
		}
	}

	private void handleSingleClick(JXTreeTable treeTable) {
		if (treeTable == leftTreeTable.getTreeTable()) {
			clearSelectionWithDelay(rightTreeTable.getTreeTable());
		} else {
			clearSelectionWithDelay(leftTreeTable.getTreeTable());
		}
	}

	private void handleDoubleClick(JXTreeTable treeTable, MouseEvent e) {
		if (treeTable == leftTreeTable.getTreeTable()) {
			clearSelectionWithDelay(rightTreeTable.getTreeTable());
		} else {
			clearSelectionWithDelay(leftTreeTable.getTreeTable());
		}

		int row = treeTable.rowAtPoint(e.getPoint());
		TreePath path = treeTable.getPathForRow(row);
		if (treeTable.isExpanded(path)) {
			treeTable.collapsePath(path);
			Object selectedItem = path.getLastPathComponent();
			if (selectedItem instanceof FolderModel) {
				((FolderModel) selectedItem).setExpanded(false);
				collapsePathInAllTrees((FolderModel) selectedItem);
			}
		} else {
			treeTable.expandPath(path);
			Object selectedItem = path.getLastPathComponent();
			if (selectedItem instanceof FolderModel) {
				((FolderModel) selectedItem).setExpanded(true);
				expandPathInAllTrees((FolderModel) selectedItem);
			}
		}
	}

	private void clearSelectionWithDelay(JXTreeTable treeTable) {
		SwingUtilities.invokeLater(() -> {
			treeTable.getSelectionModel().clearSelection();
			treeTable.repaint();
		});
	}

	private void syncScrollPanes(JScrollPane leftScrollPane, JScrollPane rightScrollPane) {
		syncMouseWheelScroll(leftScrollPane, rightScrollPane);
		syncVerticalScroll(leftScrollPane, rightScrollPane);
	}

	private void syncMouseWheelScroll(JScrollPane leftScrollPane, JScrollPane rightScrollPane) {
		leftScrollPane.addMouseWheelListener(e -> {
			try {
				rightScrollPane.dispatchEvent(e);
			} catch (Exception err) {
				logger.error(err.getMessage());
			}
		});

		rightScrollPane.addMouseWheelListener(e -> {
			try {
				leftScrollPane.dispatchEvent(e);
			} catch (Exception err) {
				logger.error(err.getMessage());
			}
		});
	}

	private void syncVerticalScroll(JScrollPane leftScrollPane, JScrollPane rightScrollPane) {
		leftScrollPane.getVerticalScrollBar().addAdjustmentListener(e -> {
			if (e.getValueIsAdjusting()) {
				rightScrollPane.getVerticalScrollBar().setValue(e.getValue());
			}
		});

		leftScrollPane.addMouseWheelListener(e -> {
			rightScrollPane.getVerticalScrollBar()
					.setValue(leftScrollPane.getVerticalScrollBar().getValue() + e.getWheelRotation() * 16);
		});

		rightScrollPane.getVerticalScrollBar().addAdjustmentListener(e -> {
			if (e.getValueIsAdjusting()) {
				leftScrollPane.getVerticalScrollBar().setValue(e.getValue());
			}
		});

		rightScrollPane.addMouseWheelListener(e -> {
			leftScrollPane.getVerticalScrollBar()
					.setValue(rightScrollPane.getVerticalScrollBar().getValue() + e.getWheelRotation() * 16);
		});
	}

	private void expandPathInAllTrees(FolderModel folder) {
		expandPathInTree(leftTreeTable.getTreeTable(), folder);
		expandPathInTree(rightTreeTable.getTreeTable(), folder);
	}

	private void collapsePathInAllTrees(FolderModel folder) {
		collapsePathInTree(leftTreeTable.getTreeTable(), folder);
		collapsePathInTree(rightTreeTable.getTreeTable(), folder);
	}

	private void expandPathInTree(JXTreeTable treeTable, FolderModel folder) {
		int rowCount = treeTable.getRowCount();
		for (int i = 0; i < rowCount; i++) {
			TreePath path = treeTable.getPathForRow(i);
			Object node = path.getLastPathComponent();
			if (node instanceof FolderModel && ((FolderModel) node).getPosition() == folder.getPosition()) {
				expandPathIfNeeded(treeTable, path);
				break;
			}
		}
	}

	private void collapsePathInTree(JXTreeTable treeTable, FolderModel folder) {
		int rowCount = treeTable.getRowCount();
		for (int i = 0; i < rowCount; i++) {
			TreePath path = treeTable.getPathForRow(i);
			Object node = path.getLastPathComponent();
			if (node instanceof FolderModel && ((FolderModel) node).getPosition() == folder.getPosition()) {
				treeTable.collapsePath(path);
				break;
			}
		}
	}

	private void expandPathIfNeeded(JXTreeTable treeTable, TreePath path) {
		if (!treeTable.isExpanded(path)) {
			treeTable.expandPath(path);
		}
	}

	public void createBottomArea() {
		Label label = new Label(parent, SWT.BORDER);
		label.setText("Bottom");
		GridData gridData = new GridData(SWT.FILL, SWT.BOTTOM, true, false, 3, 1);
		gridData.heightHint = 50;
		label.setLayoutData(gridData);
	}
}
