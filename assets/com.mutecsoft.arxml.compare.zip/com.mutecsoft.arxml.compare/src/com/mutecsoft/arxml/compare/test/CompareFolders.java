package com.mutecsoft.arxml.compare.test;

import java.io.File;
import java.io.FileInputStream;
import java.security.MessageDigest;

import java.util.Arrays;

public class CompareFolders {

    public static void main(String[] args) {
        File folder1 = new File("C:\\dev\\new\\현대오토에버_전달파일");
        File folder2 = new File("C:\\dev\\new\\현대오토에버_전달파일 - 복사본");

        boolean areFoldersIdentical = compareFolders(folder1, folder2);
        System.out.println("폴더가 동일한가요? " + areFoldersIdentical);
    }

    public static boolean compareFolders(File folder1, File folder2) {
        if (!folder1.isDirectory() || !folder2.isDirectory()) {
            throw new IllegalArgumentException("두 경로 모두 디렉토리여야 합니다.");
        }

        File[] folder1Files = folder1.listFiles();
        File[] folder2Files = folder2.listFiles();

        Arrays.sort(folder1Files);
        Arrays.sort(folder2Files);

        boolean foldersIdentical = true;

        int i = 0, j = 0;
        while (i < folder1Files.length && j < folder2Files.length) {
            File file1 = folder1Files[i];
            File file2 = folder2Files[j];

            int comparison = file1.getName().compareTo(file2.getName());

            if (comparison == 0) {
                if (file1.isDirectory() && file2.isDirectory()) {
                    if (!compareFolders(file1, file2)) {
                        System.out.println("폴더가 다릅니다: " + file1.getPath() + " 와 " + file2.getPath());
                        foldersIdentical = false;
                    }
                } else if (file1.isFile() && file2.isFile()) {
                    if (!compareFiles(file1, file2)) {
                        System.out.println("파일이 다릅니다: " + file1.getPath() + " 와 " + file2.getPath());
                        foldersIdentical = false;
                    }
                } else {
                    System.out.println("파일과 폴더 타입이 일치하지 않습니다: " + file1.getPath() + " 와 " + file2.getPath());
                    foldersIdentical = false;
                }
                i++;
                j++;
            } else if (comparison < 0) {
                System.out.println("폴더1에만 있는 파일/폴더: " + file1.getPath());
                foldersIdentical = false;
                i++;
            } else {
                System.out.println("폴더2에만 있는 파일/폴더: " + file2.getPath());
                foldersIdentical = false;
                j++;
            }
        }

        while (i < folder1Files.length) {
            System.out.println("폴더1에만 있는 파일/폴더: " + folder1Files[i].getPath());
            foldersIdentical = false;
            i++;
        }

        while (j < folder2Files.length) {
            System.out.println("폴더2에만 있는 파일/폴더: " + folder2Files[j].getPath());
            foldersIdentical = false;
            j++;
        }

        return foldersIdentical;
    }

    private static boolean compareFiles(File file1, File file2) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");

            byte[] file1Digest = getFileChecksum(md, file1);
            byte[] file2Digest = getFileChecksum(md, file2);

            if (!Arrays.equals(file1Digest, file2Digest)) {
                System.out.println("파일 내용이 다릅니다: " + file1.getPath() + " 와 " + file2.getPath());
                return false;
            }

            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private static byte[] getFileChecksum(MessageDigest digest, File file) throws Exception {
        FileInputStream fis = new FileInputStream(file);
        byte[] byteArray = new byte[1024];
        int bytesCount;

        while ((bytesCount = fis.read(byteArray)) != -1) {
            digest.update(byteArray, 0, bytesCount);
        }

        fis.close();

        return digest.digest();
    }
}