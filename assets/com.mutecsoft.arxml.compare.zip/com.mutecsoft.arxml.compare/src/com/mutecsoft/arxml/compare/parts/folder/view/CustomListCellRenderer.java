package com.mutecsoft.arxml.compare.parts.folder.view;

import java.awt.Color;
import java.awt.Component;

import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;

import com.mutecsoft.arxml.compare.model.FileModel;
import com.mutecsoft.arxml.compare.model.FolderModel;

public class CustomListCellRenderer extends JLabel implements ListCellRenderer<Object> {

	private static final long serialVersionUID = 1L;

	@Override
	public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected,
			boolean cellHasFocus) {
		if (value instanceof String && ((String) value).startsWith("HEADER_")) {
			// 헤더 스타일 적용
//			setText(((String) value).substring(7));
			setBackground(Color.WHITE);
//			setForeground(Color.WHITE);
//			setFont(getFont().deriveFont(Font.BOLD));
			setText("");
		} else {
			if (value instanceof FolderModel) {
				FolderModel folder = (FolderModel) value;
				setText("");
//				setText(folder.isExpanded() + " | " + folder.getName());
//		            setText(FolderModel.showCreatedDate ? folder.getCreatedDate() : folder.getName());
			} else if (value instanceof FileModel) {
				FileModel file = (FileModel) value;
//				setText(file.getName());
				setText("");
//		            setText(FileModel.showCreatedDate ? file.getCreatedDate() : file.getName());
			}
			if (isSelected) {
				setBackground(list.getSelectionBackground());
				setForeground(list.getSelectionForeground());
			} else {
				setBackground(list.getBackground());
				setForeground(list.getForeground());
			}
		}

		setEnabled(list.isEnabled());
		setFont(list.getFont());
		setOpaque(true);
		return this;
	}
}