package com.mutecsoft.arxml.compare.parts.folder;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.eclipse.e4.ui.di.Focus;
import org.eclipse.e4.ui.di.Persist;
import org.eclipse.e4.ui.model.application.MApplication;
import org.eclipse.e4.ui.model.application.ui.basic.MPart;
import org.eclipse.e4.ui.workbench.modeling.EModelService;
import org.eclipse.e4.ui.workbench.modeling.EPartService;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import com.mutecsoft.arxml.compare.parts.folder.controller.ButtonAction;
import com.mutecsoft.arxml.compare.parts.folder.controller.FolderPartController;
import com.mutecsoft.arxml.compare.parts.folder.view.FolderPartView;

public class FolderPart {

	private static final Logger logger = LogManager.getLogger(FolderPart.class);

	@Inject
	private MPart part;

	@Inject
	private Shell shell;

	@Inject
	private Display display;

	@Inject
	private EPartService partService;

	@Inject
	private EModelService modelService;

	@Inject
	private MApplication application;

	private FolderPartController controller = new FolderPartController();

	@PostConstruct
	public void postConstruct(Composite parent) {
		ButtonAction buttonAction = new ButtonAction();
		FolderPartView view = new FolderPartView(parent);

		view.createTopArea();
		view.createLeftArea();
		view.createRightArea();
		view.createBottomArea();

		controller.setup(view, buttonAction, part, shell, display, partService, modelService, application);

		// 배경색 설정 (RGB 값: 빨강, 초록, 파랑)
//        Color backgroundColor = new Color(display, 255, 255, 0); // 노란색
//        parent.setBackground(backgroundColor);

		logger.info("FolderPart initialized");
	}

	@Focus
	public void setFocus() {
	}

	@Persist
	public void save() {
	}
}