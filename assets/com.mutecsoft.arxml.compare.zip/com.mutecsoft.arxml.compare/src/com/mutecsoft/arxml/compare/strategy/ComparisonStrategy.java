package com.mutecsoft.arxml.compare.strategy;

public interface ComparisonStrategy<T> {
//    CompareModelNode<T> compare(CompareModelNode<T> node1, CompareModelNode<T> node2);
}
