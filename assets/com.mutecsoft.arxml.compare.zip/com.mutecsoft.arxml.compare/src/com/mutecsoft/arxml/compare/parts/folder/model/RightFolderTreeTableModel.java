package com.mutecsoft.arxml.compare.parts.folder.model;

import org.jdesktop.swingx.treetable.AbstractTreeTableModel;

import com.mutecsoft.arxml.compare.model.FileModel;
import com.mutecsoft.arxml.compare.model.FolderModel;

public class RightFolderTreeTableModel extends AbstractTreeTableModel {

	private final String[] columnNames = { "Name", "Size", "Modified"};

	public RightFolderTreeTableModel(FolderModel root) {
		super(root);
	}

	@Override
	public int getColumnCount() {
		return columnNames.length;
	}

	@Override
	public String getColumnName(int column) {
		return columnNames[column];
	}

	@Override
	public Object getValueAt(Object node, int column) {
		if (node instanceof FolderModel) {
			FolderModel folderModel = (FolderModel) node;
			switch (column) {
			case 0:
				return folderModel.getName();
			case 1:
//				return folderModel.getSize();
				return "";
			case 2:
				return folderModel.getCreatedDate();
			default:
				return null;
			}
		} else if (node instanceof FileModel) {
			FileModel fileModel = (FileModel) node;
			switch (column) {
			case 0:
				return fileModel.getName();
			case 1:
				return fileModel.getSize();
			case 2:
				return fileModel.getCreatedDate();
			default:
				return null;
			}
		}
		return null;
	}

	@Override
	public Object getChild(Object parent, int index) {
		if (parent instanceof FolderModel) {
			FolderModel folderModel = (FolderModel) parent;
			int folderCount = folderModel.getSubFolders().size();
			if (index < folderCount) {
				return folderModel.getSubFolders().get(index);
			} else {
				return folderModel.getFiles().get(index - folderCount);
			}
		}
		return null;
	}

	@Override
	public int getChildCount(Object parent) {
		if (parent instanceof FolderModel) {
			FolderModel folderModel = (FolderModel) parent;
			return folderModel.getSubFolders().size() + folderModel.getFiles().size();
		}
		return 0;
	}

	@Override
	public int getIndexOfChild(Object parent, Object child) {
		if (parent instanceof FolderModel) {
			FolderModel folderModel = (FolderModel) parent;
			int folderIndex = folderModel.getSubFolders().indexOf(child);
			if (folderIndex != -1) {
				return folderIndex;
			} else {
				return folderModel.getFiles().indexOf(child) + folderModel.getSubFolders().size();
			}
		}
		return -1;
	}

	@Override
	public boolean isLeaf(Object node) {
		if (node instanceof FolderModel) {
			FolderModel folderModel = (FolderModel) node;
			return folderModel.getSubFolders().isEmpty() && folderModel.getFiles().isEmpty();
		} else if (node instanceof FileModel) {
			return true;
		}
		return false;
	}

	public void reload() {
		FolderModel root = (FolderModel) getRoot();
		fireTreeStructureChanged(this, new Object[] { root }, null, null);
	}

	public void setRoot(FolderModel root) {
		this.root = root;
		reload();
	}

	protected void fireTreeStructureChanged(Object source, Object[] path, int[] childIndices, Object[] children) {
		javax.swing.event.TreeModelEvent e = new javax.swing.event.TreeModelEvent(source, path, childIndices, children);
		for (javax.swing.event.TreeModelListener listener : getTreeModelListeners()) {
			listener.treeStructureChanged(e);
		}
	}

	public void removeNode(Object node) {
		FolderModel root = (FolderModel) getRoot();
		FolderModel parent = findParent(root, node);
		if (parent != null) {
			if (node instanceof FolderModel) {
				parent.getSubFolders().remove(node);
			} else if (node instanceof FileModel) {
				parent.getFiles().remove(node);
			}
			reload();
		}
	}

	private FolderModel findParent(FolderModel current, Object target) {
		for (FolderModel child : current.getSubFolders()) {
			if (child == target) {
				return current;
			}
			FolderModel parent = findParent(child, target);
			if (parent != null) {
				return parent;
			}
		}
		for (FileModel file : current.getFiles()) {
			if (file == target) {
				return current;
			}
		}
		return null;
	}
}
