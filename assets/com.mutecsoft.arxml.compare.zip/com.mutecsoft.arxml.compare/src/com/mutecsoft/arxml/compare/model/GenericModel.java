package com.mutecsoft.arxml.compare.model;

import java.util.ArrayList;
import java.util.List;

public class GenericModel<T> {
	private String name;
	private T data;
	private List<GenericModel<T>> children;
	private int position;
	private boolean isExpanded;

	public GenericModel(String name, T data, int position, boolean isExpanded) {
		this.name = name;
		this.data = data;
		this.position = position;
		this.isExpanded = isExpanded;
		this.children = new ArrayList<>();
	}

	public String getName() {
		return name;
	}

	public T getData() {
		return data;
	}

	public List<GenericModel<T>> getChildren() {
		return children;
	}

	public void addChild(GenericModel<T> child) {
		children.add(child);
	}

	public boolean hasChildren() {
		return !children.isEmpty();
	}

	public int getPosition() {
		return position;
	}

	public void setPosition(int position) {
		this.position = position;
	}

	public boolean isExpanded() {
		return isExpanded;
	}

	public void setExpanded(boolean isExpanded) {
		this.isExpanded = isExpanded;
	}
}
