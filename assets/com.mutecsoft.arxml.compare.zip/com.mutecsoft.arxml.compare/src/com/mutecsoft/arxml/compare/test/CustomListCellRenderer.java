package com.mutecsoft.arxml.compare.test;

import java.awt.Component;

import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;

import com.mutecsoft.arxml.compare.model.FileModel;
import com.mutecsoft.arxml.compare.model.FolderModel;

class CustomListCellRenderer extends JLabel implements ListCellRenderer<Object> {
	@Override
	public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected,
			boolean cellHasFocus) {
		if (value instanceof FolderModel) {
			FolderModel folder = (FolderModel) value;
			setText(folder.isExpanded() + " | " +  folder.getName());
//            setText(FolderModel.showCreatedDate ? folder.getCreatedDate() : folder.getName());
		} else if (value instanceof FileModel) {
			FileModel file = (FileModel) value;
			setText(file.getName());
//            setText(FileModel.showCreatedDate ? file.getCreatedDate() : file.getName());
		}
		if (isSelected) {
			setBackground(list.getSelectionBackground());
			setForeground(list.getSelectionForeground());
		} else {
			setBackground(list.getBackground());
			setForeground(list.getForeground());
		}
		setEnabled(list.isEnabled());
		setFont(list.getFont());
		setOpaque(true);
		return this;
	}
}