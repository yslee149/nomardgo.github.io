package com.mutecsoft.arxml.compare.test;

public class TreeTableExample {
//
//	private JXTreeTable treeTable;
//	private FolderTreeTableModel treeTableModel;
//	private FolderNode rootNode;
//
//	public static void main(String[] args) {
//		Display display = new Display();
//		Shell shell = new Shell(display);
//		shell.setSize(800, 600);
//		shell.setLayout(new FillLayout());
//
//		TreeTableExample example = new TreeTableExample();
//		example.addTree(shell);
//
//		shell.open();
//		while (!shell.isDisposed()) {
//			if (!display.readAndDispatch()) {
//				display.sleep();
//			}
//		}
//		display.dispose();
//	}
//
//	private void addTree(Composite parent) {
//		Composite swingComposite = new Composite(parent, SWT.EMBEDDED | SWT.NO_BACKGROUND);
//		swingComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
//		java.awt.Frame frame = SWT_AWT.new_Frame(swingComposite);
//
//		SwingUtilities.invokeLater(() -> {
//			try {
//				// Look and Feel을 Windows 스타일로 설정
//				UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
//			} catch (ClassNotFoundException | InstantiationException | IllegalAccessException
//					| UnsupportedLookAndFeelException e) {
//				e.printStackTrace();
//			}
//
//			JPanel panel = new JPanel(new java.awt.BorderLayout());
//			frame.add(panel);
//
//			// 초기 빈 모델로 트리 테이블 생성
//			rootNode = new FolderNode("Root", new Date(), 0);
//			String[] columnsNames = { "Name", "Size", "Modified" };
//			treeTableModel = new FolderTreeTableModel(rootNode);
//			treeTable = new JXTreeTable(treeTableModel);
//			treeTable.setRootVisible(true);
//
//			// 트리의 선 스타일 설정
//			treeTable.putClientProperty("JTree.lineStyle", "Angled");
//
//			// 더블 클릭 이벤트 추가
//			treeTable.addMouseListener(new MouseInputAdapter() {
//				@Override
//				public void mouseClicked(MouseEvent e) {
//					if (e.getClickCount() == 2) {
//						int row = treeTable.rowAtPoint(e.getPoint());
//						TreePath path = treeTable.getPathForRow(row);
//						if (treeTable.isExpanded(path)) {
//							treeTable.collapsePath(path);
//						} else {
//							treeTable.expandPath(path);
//						}
//					}
//				}
//			});
//			treeTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
//
//			JScrollPane scrollPane = new JScrollPane(treeTable);
//
//			// 짝수 열과 홀수 열 배경색 다르게 설정
//			Highlighter oddHighlighter = new ColorHighlighter((component, adapter) -> adapter.row % 2 != 0,
//					new Color(255, 255, 255, 255), Color.BLACK);
//			Highlighter evenHighlighter = new ColorHighlighter((component, adapter) -> adapter.row % 2 == 0,
//					new Color(248, 250, 249, 255), Color.BLACK);
//			treeTable.addHighlighter(oddHighlighter);
//			treeTable.addHighlighter(evenHighlighter);
//
//			// 셀 내용의 정렬 설정
//			DefaultTableCellRenderer leftRenderer = new DefaultTableCellRenderer();
//			leftRenderer.setHorizontalAlignment(DefaultTableCellRenderer.LEFT);
//			treeTable.getColumn(0).setCellRenderer(leftRenderer);
//
//			DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
//			rightRenderer.setHorizontalAlignment(DefaultTableCellRenderer.RIGHT);
//			for (int i = 1; i < treeTable.getColumnCount(); i++) {
//				treeTable.getColumn(i).setCellRenderer(rightRenderer);
//			}
//
//			// 특정 열의 넓이 고정
//			TableColumn column = treeTable.getColumnModel().getColumn(1);
//			column.setMinWidth(300);
//			column.setPreferredWidth(300);
//
//			column = treeTable.getColumnModel().getColumn(2);
//			column.setMinWidth(300);
//			column.setPreferredWidth(300);
//
//			panel.add(scrollPane, java.awt.BorderLayout.CENTER);
//		});
//
//		// 디렉토리 선택 버튼 추가
//		Button selectDirectoryButton = new Button(parent, SWT.PUSH);
//		selectDirectoryButton.setText("Select Directory");
//		selectDirectoryButton.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, true, false));
//		selectDirectoryButton.addListener(SWT.Selection, event -> {
//			String selectedDirectory = selectDirectory(parent.getShell());
//			if (selectedDirectory != null) {
//				setDirectoryData(selectedDirectory);
//			}
//		});
//
//		parent.layout();
//	}
//
//	private String selectDirectory(Shell shell) {
//		DirectoryDialog dialog = new DirectoryDialog(shell);
//		dialog.setMessage("Please select a folder");
//		return dialog.open();
//	}
//
//	private void setDirectoryData(String directoryPath) {
//		File rootDir = new File(directoryPath);
//		FolderNode newRootNode = createFolderNode(rootDir);
//		treeTableModel.setRoot(newRootNode);
//		treeTableModel.reload();
//	}
//
//	private FolderNode createFolderNode(File folder) {
//		long folderSize = 0;
//		List<FolderNode> childrenNodes = new ArrayList<>();
//		File[] files = folder.listFiles();
//
//		if (files != null) {
//			for (File file : files) {
//				if (file.isDirectory()) {
//					// 재귀적으로 하위 폴더를 탐색하여 .arxml 파일이 있는 폴더만 추가
//					FolderNode childNode = createFolderNode(file);
//					if (!childNode.getChildren().isEmpty() || containsArxmlFiles(file)) {
//						childrenNodes.add(childNode);
//						folderSize += childNode.getSize();
//					}
//				} else if (file.getName().toLowerCase().endsWith(".arxml")) {
//					// .arxml 파일만 추가
//					FolderNode childNode = new FolderNode(file.getName(), new Date(file.lastModified()), file.length());
//					childrenNodes.add(childNode);
//					folderSize += file.length();
//				}
//			}
//		}
//
//		FolderNode node = new FolderNode(folder.getName(), new Date(folder.lastModified()), folderSize);
//		for (FolderNode child : childrenNodes) {
//			node.add(child);
//		}
//		return node;
//	}
//
//	private boolean containsArxmlFiles(File folder) {
//		File[] files = folder.listFiles();
//		if (files != null) {
//			for (File file : files) {
//				if (file.isDirectory()) {
//					if (containsArxmlFiles(file)) {
//						return true;
//					}
//				} else if (file.getName().toLowerCase().endsWith(".arxml")) {
//					return true;
//				}
//			}
//		}
//		return false;
//	}
}