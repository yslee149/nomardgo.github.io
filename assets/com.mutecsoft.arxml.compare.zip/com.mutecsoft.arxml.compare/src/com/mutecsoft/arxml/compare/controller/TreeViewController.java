package com.mutecsoft.arxml.compare.controller;

import java.util.List;

import org.eclipse.jface.viewers.AbstractTreeViewer;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.ITreeViewerListener;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.TreeExpansionEvent;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.ScrollBar;

public class TreeViewController {
	private List<TreeViewer> treeViewers;
	private static boolean isSelecting = false;
	private static boolean isExpanding = false;
	private static boolean isScrolling = false;

	public TreeViewController(List<TreeViewer> treeViewers) {
		this.treeViewers = treeViewers;
	}

	public void synchronizeTreeViewers() {
		for (TreeViewer treeViewer : treeViewers) {
			synchronizeScrollBars(treeViewer);
			synchronizeSelections(treeViewer);
			synchronizeExpansions(treeViewer);
//			addFocusAndExpandCollapseHandlers(treeViewer);
		}
	}

	private void synchronizeScrollBars(TreeViewer source) {
		ScrollBar sourceVBar = source.getTree().getVerticalBar();
		ScrollBar sourceHBar = source.getTree().getHorizontalBar();

		sourceVBar.addListener(SWT.Selection, new Listener() {
			public void handleEvent(Event event) {
				if (!isScrolling) {
					isScrolling = true;
					for (TreeViewer target : treeViewers) {
						if (target != source) {
							int sourceSelection = sourceVBar.getSelection();
							target.getTree().getVerticalBar().setSelection(sourceSelection);
							target.getTree().setTopItem(source.getTree().getTopItem());
							target.getTree().redraw();
						}
					}
					isScrolling = false;
				}
			}
		});

		sourceHBar.addListener(SWT.Selection, new Listener() {
			public void handleEvent(Event event) {
				if (!isScrolling) {
					isScrolling = true;
					for (TreeViewer target : treeViewers) {
						if (target != source) {
							int sourceSelection = sourceHBar.getSelection();
							target.getTree().getHorizontalBar().setSelection(sourceSelection);
							target.getTree().redraw();
						}
					}
					isScrolling = false;
				}
			}
		});
	}

	private void synchronizeSelections(TreeViewer source) {
		source.addSelectionChangedListener(new ISelectionChangedListener() {
			@Override
			public void selectionChanged(SelectionChangedEvent event) {
				if (!isSelecting) {
					isSelecting = true;
					IStructuredSelection selection = (IStructuredSelection) event.getSelection();
					for (TreeViewer target : treeViewers) {
						if (target != source) {
							target.setSelection(selection);
						}
					}
					isSelecting = false;
				}
			}
		});
	}

	private void synchronizeExpansions(TreeViewer source) {
		source.addTreeListener(new ITreeViewerListener() {
			@Override
			public void treeCollapsed(TreeExpansionEvent event) {
				if (!isExpanding) {
					isExpanding = true;
					Object element = event.getElement();
					for (TreeViewer target : treeViewers) {
						if (target != source) {
							target.getControl().getDisplay().asyncExec(() -> {
								if (target.testFindItem(element) != null) {
									target.collapseToLevel(element, AbstractTreeViewer.ALL_LEVELS);
								}
							});
						}
					}
					isExpanding = false;
				}
			}

			@Override
			public void treeExpanded(TreeExpansionEvent event) {
				if (!isExpanding) {
					isExpanding = true;
					Object element = event.getElement();
					for (TreeViewer target : treeViewers) {
						if (target != source) {
							target.getControl().getDisplay().asyncExec(() -> {
								if (target.testFindItem(element) != null) {
									target.expandToLevel(element, 1);
								}
							});
						}
					}
					isExpanding = false;
				}
			}
		});
	}

//	private void addFocusAndExpandCollapseHandlers(TreeViewer source) {
//		source.getTree().addListener(SWT.DefaultSelection, new Listener() {
//			@Override
//			public void handleEvent(Event event) {
//				handleExpandCollapse(source);
//			}
//		});
//	}

//	private void handleExpandCollapse(TreeViewer source) {
//		IStructuredSelection selection = (IStructuredSelection) source.getSelection();
//		Object selectedElement = selection.getFirstElement();
//
//		if (selectedElement instanceof CompareModelNode) {
//			CompareModelNode<?> node = (CompareModelNode<?>) selectedElement;
//			if (node.hasChildren()) {
//				if (source.getExpandedState(node)) {
//					source.collapseToLevel(node, AbstractTreeViewer.ALL_LEVELS);
//					for (TreeViewer target : treeViewers) {
//						if (target != source) {
//							target.getControl().getDisplay().asyncExec(() -> {
//								if (target.testFindItem(node) != null) {
//									target.collapseToLevel(node, AbstractTreeViewer.ALL_LEVELS);
//								}
//							});
//						}
//					}
//				} else {
//					source.expandToLevel(node, 1);
//					for (TreeViewer target : treeViewers) {
//						if (target != source) {
//							target.getControl().getDisplay().asyncExec(() -> {
//								if (target.testFindItem(node) != null) {
//									target.expandToLevel(node, 1);
//								}
//							});
//						}
//					}
//				}
//			} else {
//				System.out.println("Selected file: " + node.getObject());
//			}
//		}
//	}

//	public void compareFolders(CompareModelNode<String> node1, CompareModelNode<String> node2) {
//		ComparisonStrategy<String> strategy = new FolderComparisonStrategy<>();
//		CompareModelNode<String> result = strategy.compare(node1, node2);
//		// ����� ó���ϴ� ���� �߰�
//		System.out.println("Comparison result: " + result.getObject());
//	}
}
