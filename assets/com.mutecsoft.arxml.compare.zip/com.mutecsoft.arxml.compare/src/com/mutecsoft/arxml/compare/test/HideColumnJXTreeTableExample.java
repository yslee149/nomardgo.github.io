package com.mutecsoft.arxml.compare.test;

import org.jdesktop.swingx.JXTreeTable;
import org.jdesktop.swingx.treetable.AbstractTreeTableModel;
import javax.swing.*;
import javax.swing.table.TableColumn;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import java.awt.*;

public class HideColumnJXTreeTableExample {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Hide Column JXTreeTable Example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // 트리 노드 생성
        DefaultMutableTreeNode root = new DefaultMutableTreeNode("Root");
        DefaultMutableTreeNode child1 = new DefaultMutableTreeNode("Child 1");
        DefaultMutableTreeNode child2 = new DefaultMutableTreeNode("Child 2");
        DefaultMutableTreeNode subChild1 = new DefaultMutableTreeNode("Sub Child 1");
        DefaultMutableTreeNode subChild2 = new DefaultMutableTreeNode("Sub Child 2");

        child1.add(subChild1);
        child2.add(subChild2);
        root.add(child1);
        root.add(child2);

        // 트리 테이블 모델 생성
        MyTreeTableModel treeTableModel = new MyTreeTableModel(root);

        // JXTreeTable 생성
        JXTreeTable treeTable = new JXTreeTable(treeTableModel);

        // 기본 아이콘 및 들여쓰기 제거를 위한 커스텀 렌더러 설정
        DefaultTreeCellRenderer treeCellRenderer = new DefaultTreeCellRenderer() {
            @Override
            public Component getTreeCellRendererComponent(JTree tree, Object value,
                                                          boolean sel, boolean expanded,
                                                          boolean leaf, int row,
                                                          boolean hasFocus) {
                JLabel label = (JLabel) super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);
                label.setIcon(null);  // 아이콘 제거
                label.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));  // 들여쓰기 제거
                return label;
            }
        };

        treeTable.setTreeCellRenderer(treeCellRenderer);
        treeTable.setRowHeight(20);  // 행 높이 설정

        // 첫 번째 컬럼 숨기기
        TableColumn column = treeTable.getColumnModel().getColumn(0);
//        column.setMinWidth(0);
//        column.setMaxWidth(0);
//        column.setPreferredWidth(0);
//        column.setResizable(false);

        // JScrollPane에 추가하여 표시
        frame.add(new JScrollPane(treeTable), BorderLayout.CENTER);
        frame.pack();
        frame.setVisible(true);
    }

    // 커스텀 TreeTableModel 클래스
    static class MyTreeTableModel extends AbstractTreeTableModel {
        private String[] columnNames = {"Column 1", "Column 2"};

        public MyTreeTableModel(Object root) {
            super(root);
        }

        @Override
        public int getColumnCount() {
            return columnNames.length;
        }

        @Override
        public String getColumnName(int column) {
            return columnNames[column];
        }

        @Override
        public Object getValueAt(Object node, int column) {
            if (node instanceof DefaultMutableTreeNode) {
                DefaultMutableTreeNode treeNode = (DefaultMutableTreeNode) node;
                switch (column) {
                    case 0:
                        return treeNode.getUserObject();
                    case 1:
                        return "Additional Data";
                }
            }
            return null;
        }

        @Override
        public Object getChild(Object parent, int index) {
            if (parent instanceof DefaultMutableTreeNode) {
                return ((DefaultMutableTreeNode) parent).getChildAt(index);
            }
            return null;
        }

        @Override
        public int getChildCount(Object parent) {
            if (parent instanceof DefaultMutableTreeNode) {
                return ((DefaultMutableTreeNode) parent).getChildCount();
            }
            return 0;
        }

        @Override
        public int getIndexOfChild(Object parent, Object child) {
            if (parent instanceof DefaultMutableTreeNode && child instanceof DefaultMutableTreeNode) {
                return ((DefaultMutableTreeNode) parent).getIndex((DefaultMutableTreeNode) child);
            }
            return -1;
        }

        @Override
        public boolean isLeaf(Object node) {
            if (node instanceof DefaultMutableTreeNode) {
                return ((DefaultMutableTreeNode) node).isLeaf();
            }
            return true;
        }
    }
}
