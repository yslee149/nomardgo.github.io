package com.mutecsoft.arxml.compare.test.compare;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import com.mutecsoft.arxml.compare.model.ComparisonStatus;
import com.mutecsoft.arxml.compare.model.FileModel;
import com.mutecsoft.arxml.compare.model.FolderModel;

public class CompareFolderTest {

    public static void main(String[] args) {
        String firstFolderPath = "C:\\dev\\new\\compare-test\\Configuration";
        String secondFolderPath = "C:\\dev\\new\\compare-test\\Configuration2";

        boolean compareFileNames = true;
        boolean compareSizes = true;
        boolean compareDates = true;
        boolean compareContents = true;
        boolean searchSubfolders = true;

        FolderModel[] result = compareFolders(firstFolderPath, secondFolderPath, compareFileNames, compareSizes, compareDates, compareContents,
                searchSubfolders);
        
        if (result != null) {
            printFolderModel(result[0], "First Folder");
            printFolderModel(result[1], "Second Folder");
        }
    }

    public static FolderModel[] compareFolders(String firstFolder, String secondFolder, boolean compareFileNames,
            boolean compareSizes, boolean compareDates, boolean compareContents, boolean searchSubfolders) {
        File folder1 = new File(firstFolder);
        File folder2 = new File(secondFolder);

        if (!folder1.exists() || !folder2.exists()) {
            System.out.println("One or both folders do not exist.");
            return null;
        }

        try {
            List<String> folder1Files = getFilesRecursively(folder1, searchSubfolders);
            List<String> folder2Files = getFilesRecursively(folder2, searchSubfolders);

            Collections.sort(folder1Files);
            Collections.sort(folder2Files);

            Set<String> allFiles = new TreeSet<>(folder1Files);
            allFiles.addAll(folder2Files);

            FolderModel folderModel1 = new FolderModel(firstFolder, 0, "", 0, "folder");
            FolderModel folderModel2 = new FolderModel(secondFolder, 0, "", 0, "folder");

            int position = 0;
            for (String filePath : allFiles) {
                File file1 = new File(folder1, filePath);
                File file2 = new File(folder2, filePath);

                if (file1.exists() && file2.exists()) {
                    ComparisonStatus status = ComparisonStatus.IDENTICAL;
                    // Compare sizes
                    if (compareSizes && file1.length() != file2.length()) {
                        status = ComparisonStatus.DIFFERENT;
                    }
                    // Compare dates
                    if (compareDates && file1.lastModified() != file2.lastModified()) {
                        status = ComparisonStatus.DIFFERENT;
                    }
                    // Compare contents (checksum)
                    if (compareContents) {
                        String checksum1 = getFileChecksum(file1);
                        String checksum2 = getFileChecksum(file2);
                        if (!checksum1.equals(checksum2)) {
                            status = ComparisonStatus.DIFFERENT;
                        }
                    }
                    folderModel1.addFile(createFileModel(file1, position, status));
                    folderModel2.addFile(createFileModel(file2, position, status));
                } else if (file1.exists()) {
                    folderModel1.addFile(createFileModel(file1, position, ComparisonStatus.ONLY_IN_ORIGINAL));
                    folderModel2.addFile(createEmptyFileModel(filePath, position, ComparisonStatus.ONLY_IN_ORIGINAL));
                } else {
                    folderModel1.addFile(createEmptyFileModel(filePath, position, ComparisonStatus.ONLY_IN_COMPARISON));
                    folderModel2.addFile(createFileModel(file2, position, ComparisonStatus.ONLY_IN_COMPARISON));
                }
                position++;
            }
            return new FolderModel[] { folderModel1, folderModel2 };
        } catch (IOException | NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    private static List<String> getFilesRecursively(File folder, boolean searchSubfolders) throws IOException {
        List<String> fileList = new ArrayList<>();
        if (searchSubfolders) {
            Files.walk(folder.toPath()).filter(Files::isRegularFile)
                .filter(path -> path.toString().endsWith(".arxml"))
                .forEach(path -> fileList.add(folder.toPath().relativize(path).toString()));
        } else {
            Files.list(folder.toPath()).filter(Files::isRegularFile)
                .filter(path -> path.toString().endsWith(".arxml"))
                .forEach(path -> fileList.add(folder.toPath().relativize(path).toString()));
        }
        return fileList;
    }

    private static String getFileChecksum(File file) throws IOException, NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance("MD5");
        try (InputStream fis = new FileInputStream(file)) {
            byte[] byteArray = new byte[1024];
            int bytesCount;
            while ((bytesCount = fis.read(byteArray)) != -1) {
                digest.update(byteArray, 0, bytesCount);
            }
        }
        byte[] bytes = digest.digest();
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }

    private static FileModel createFileModel(File file, int position, ComparisonStatus status) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String createdDate = sdf.format(file.lastModified());
        String size = String.valueOf(file.length());
        return new FileModel(file.getName(), position, createdDate, size, "file", status);
    }

    private static FileModel createEmptyFileModel(String fileName, int position, ComparisonStatus status) {
        return new FileModel(fileName, position, "", "0", "file", status);
    }

    private static void printFolderModel(FolderModel folderModel, String folderName) {
        System.out.println("Folder: " + folderName);
        for (FileModel file : folderModel.getFiles()) {
            System.out.println("  File: " + file.getName());
            System.out.println("    Position: " + file.getPosition());
            System.out.println("    Created Date: " + file.getCreatedDate());
            System.out.println("    Size: " + file.getSize());
            System.out.println("    Type: " + file.getType());
            System.out.println("    Comparison Status: " + file.getComparisonStatus());
        }
    }
}