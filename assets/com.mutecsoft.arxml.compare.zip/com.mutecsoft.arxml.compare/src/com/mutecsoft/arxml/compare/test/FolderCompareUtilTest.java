package com.mutecsoft.arxml.compare.test;

import java.io.IOException;

import com.mutecsoft.arxml.compare.model.ComparisonStatus;
import com.mutecsoft.arxml.compare.model.FileModel;
import com.mutecsoft.arxml.compare.utils.FolderCompareUtil;

public class FolderCompareUtilTest {

//	public static void main(String[] args) {
//		try {
//			// 비교할 두 폴더의 경로를 설정합니다.
//			String originalFolderPath = "C:\\dev\\new\\현대오토에버_전달파일";
//			String comparisonFolderPath = "C:\\dev\\new\\현대오토에버_전달파일 - 복사본";
//			String extension = ".arxml"; // 비교할 파일 확장자
//
//			// FolderCompareUtil 객체를 생성하고 폴더를 비교합니다.
//			FolderCompareUtil util = new FolderCompareUtil();
//			FolderCompareUtil.ComparisonResult result = util.compareFolders(originalFolderPath, comparisonFolderPath,
//					extension);
//
//			// 결과를 출력합니다.
//			printComparisonResult(result);
//
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//	}
//
//
//    private static void printComparisonResult(FolderCompareUtil.ComparisonResult result) {
//        System.out.println("Comparison Result:");
//        System.out.println("Original Folder: " + result.getOriginalFolder().getName());
//        System.out.println("Comparison Folder: " + result.getComparisonFolder().getName());
//
//        int identicalCount = 0;
//
//        System.out.println("\nDifferences:");
//        for (FileModel file : result.getOriginalFolder().getFiles()) {
//            if (file.getComparisonStatus() == ComparisonStatus.IDENTICAL) {
//                identicalCount++;
//            } else {
//                System.out.println(file.getName() + " - " + file.getComparisonStatus());
//            }
//        }
//
//        for (FileModel file : result.getComparisonFolder().getFiles()) {
//            if (file.getComparisonStatus() == ComparisonStatus.IDENTICAL) {
//                identicalCount++;
//            } else if (file.getComparisonStatus() == ComparisonStatus.ONLY_IN_COMPARISON) {
//                System.out.println(file.getName() + " - " + file.getComparisonStatus());
//            }
//        }
//
//        System.out.println("\nNumber of identical files: " + identicalCount);
//    }
}
