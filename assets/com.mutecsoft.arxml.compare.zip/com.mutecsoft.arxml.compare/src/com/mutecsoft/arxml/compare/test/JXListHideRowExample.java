package com.mutecsoft.arxml.compare.test;

import org.jdesktop.swingx.JXList;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class JXListHideRowExample {
    private static List<String> originalData = new ArrayList<>();
    private static DefaultListModel<String> listModel = new DefaultListModel<>();
    private static boolean isHidden = false;
    private static int hiddenIndex = 4;
    private static String hiddenItem;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("JXList Hide Row Example");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setLayout(new BorderLayout());

            // 원본 데이터
            for (int i = 1; i <= 20; i++) {
                originalData.add("Item " + i);
            }

            // JXList와 ListModel 생성
            JXList jxList = new JXList(listModel);
            JScrollPane scrollPane = new JScrollPane(jxList);

            // 원본 데이터를 ListModel에 추가
            for (String item : originalData) {
                listModel.addElement(item);
            }

            // 특정 조건에 따라 로우 숨기기/표시하기 버튼
            JButton toggleButton = new JButton("Toggle Item 5");
            toggleButton.addActionListener(e -> toggleItem());

            frame.add(scrollPane, BorderLayout.CENTER);
            frame.add(toggleButton, BorderLayout.SOUTH);
            frame.setSize(300, 400);
            frame.setVisible(true);
        });
    }

    private static void toggleItem() {
        if (isHidden) {
            // 숨겨진 아이템을 다시 추가
            listModel.add(hiddenIndex, hiddenItem);
        } else {
            // 아이템을 숨기기 위해 제거
            hiddenItem = listModel.get(hiddenIndex);
            listModel.remove(hiddenIndex);
        }
        isHidden = !isHidden;
    }
}
