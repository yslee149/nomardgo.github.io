package com.mutecsoft.arxml.compare.view.dialog;

import java.io.File;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;

public class NormalDialogManager {

	public static void warning(Shell shell, String title, String mesString, Runnable callback) {
		MessageBox messageBox = new MessageBox(shell, SWT.ICON_WARNING | SWT.OK);
		messageBox.setText(title);
		messageBox.setMessage(mesString);

		int response = messageBox.open();
		if (response == SWT.OK) {
			callback.run();
		}
	}

	public static void info(Shell shell, String title, String mesString, Runnable callback) {
		MessageBox messageBox = new MessageBox(shell, SWT.ICON_INFORMATION | SWT.OK);
		messageBox.setText(title);
		messageBox.setMessage(mesString);

		int response = messageBox.open();
		if (response == SWT.OK) {
			callback.run();
		}
	}

	public static File showFileDlg(Shell shell, String... fileExtensions) {
		FileDialog dialog = new FileDialog(shell, SWT.OPEN);
		dialog.setFilterExtensions(fileExtensions);
		String path = dialog.open();
		if (path != null) {
			File file = new File(path);
			return file;
		}

		return null;

	}

	public static String selectDirectory(Shell shell, String message) {
		DirectoryDialog dialog = new DirectoryDialog(shell);
		dialog.setMessage(message);
		return dialog.open();
	}

}
