package com.mutecsoft.arxml.compare.builder;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;

import com.mutecsoft.arxml.compare.Activator;
import com.mutecsoft.arxml.compare.MyConstant.FileType;
import com.mutecsoft.arxml.compare.MyConstant.FixedExtension;
import com.mutecsoft.arxml.compare.MyConstant.ProjectType;
import com.mutecsoft.arxml.compare.db.DatabaseHelper;
import com.mutecsoft.arxml.compare.db.QuerySet.ProjectQueryKey;
import com.mutecsoft.arxml.compare.model.ProjectData;

public class ProjectDataBuilder {

	private DatabaseHelper dbHelper;
	private Connection connection;
	private String projectName = "";

	public ProjectDataBuilder() {
		dbHelper = Activator.getDefault().getDb();
		connection = dbHelper.getConnection();
	}

	public Map<ProjectType, List<ProjectData>> processProjectsData(IProject project1, IProject project2)
			throws SQLException, CoreException {

		dbHelper.executeSQL(ProjectQueryKey.DELETE_ALL.name());
		insertProjectData(project1, project2);

		ResultSet rs = dbHelper.executeSelectQuery(ProjectQueryKey.SELECT_COMPARE_ALL.name());

		List<ProjectData> projectDataList1 = new ArrayList<>();
		List<ProjectData> projectDataList2 = new ArrayList<>();

		while (rs.next()) {
			ProjectData projectData1 = extractProjectData(rs, "project_1");
			ProjectData projectData2 = extractProjectData(rs, "project_2");

			int compareResult = rs.getInt("CompareType");
			projectData1.setCompare_result(compareResult);
			projectData2.setCompare_result(compareResult);

			projectDataList1.add(projectData1);
			projectDataList2.add(projectData2);
		}

		Map<ProjectType, List<ProjectData>> result = new HashMap<>();
		result.put(ProjectType.ORIGIN, projectDataList1);
		result.put(ProjectType.TARGET, projectDataList2);

		return result;
	}

	private ProjectData extractProjectData(ResultSet rs, String prefix) throws SQLException {
		ProjectData projectData = new ProjectData();
		projectData.setId(rs.getInt(prefix + "_id"));
		projectData.setProject_id(rs.getInt(prefix + "_project_id"));
		projectData.setParent_id(rs.getInt(prefix + "_parent_id"));
		projectData.setFile_name(rs.getString(prefix + "_file_name"));
		projectData.setFile_path(rs.getString(prefix + "_file_path"));
		projectData.setFile_full_path(rs.getString(prefix + "_file_full_path"));
		projectData.setFile_type(rs.getInt(prefix + "_file_type"));
		projectData.setFile_date(rs.getString(prefix + "_file_date"));
		projectData.setVersion(rs.getInt(prefix + "_version"));
		return projectData;
	}

	private void insertProjectData(IProject... projects) throws CoreException, SQLException {
		connection.setAutoCommit(false);
		String sql = dbHelper.getSqlQueries().get(ProjectQueryKey.INSERT_DATA.name());

		PreparedStatement pstmt = connection.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);

		IProject project1 = projects[0];
		insertResource(pstmt, project1, null, ProjectType.ORIGIN.getCode());

		IProject project2 = projects[1];
		insertResource(pstmt, project2, null, ProjectType.TARGET.getCode());

		connection.commit();
	}

	private void insertResource(PreparedStatement pstmt, IResource resource, Integer parentId, int projectId)
			throws SQLException, CoreException {
		int fileType;
		String fileDate = "";
		if (resource instanceof IProject) {
			fileType = FileType.PROJECT.getCode();

			projectName = "/" + resource.getName();

		} else if (resource instanceof IFolder) {
			fileType = FileType.FOLDER.getCode();
		} else if (resource instanceof IFile) {
			fileType = FileType.FILE.getCode();
			fileDate = getFileTime(resource);
		} else {
			return;
		}

		boolean isInsert = true;

		if (fileType == FileType.FILE.getCode()) {
			if (!isValidFile((IFile) resource)) {
				isInsert = false;
			}
		}

		if (isInsert) {
			pstmt.setInt(1, projectId);

			if (parentId != null) {
				pstmt.setInt(2, parentId);
			} else {
				pstmt.setNull(2, java.sql.Types.INTEGER);
			}

			pstmt.setString(3, resource.getName());

			pstmt.setString(4, resource.getFullPath().toString().replaceFirst("^" + projectName, ""));
			pstmt.setString(5, resource.getFullPath().toString());
			pstmt.setInt(6, fileType);
			pstmt.setString(7, fileDate);

			pstmt.executeUpdate();

			int currentId = getCurrentId(pstmt); // ��� ���Ե� ���ڵ��� ID ��������

			if (resource instanceof IContainer) {
				for (IResource member : ((IContainer) resource).members()) {
					insertResource(pstmt, member, currentId, projectId);
				}
			}
		}

	}

	private boolean isValidFile(IFile resource) {

		try {
			String extension = resource.getFileExtension().toLowerCase();
			for (FixedExtension ext : FixedExtension.values()) {
				if (ext.name().toLowerCase().equals(extension)) {
					return true;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

		return false;

	}

	private int getCurrentId(PreparedStatement pstmt) throws SQLException {
		try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
			if (generatedKeys.next()) {
				return generatedKeys.getInt(1);
			} else {
				throw new SQLException("Creating resource failed, no ID obtained.");
			}
		}
	}

	private String getFileTime(IResource resource) {

		String creationTimeString = "";

		try {
			File file = ((IFile) resource).getLocation().toFile();
			Path filePath = file.toPath();
			BasicFileAttributes attr;
			attr = Files.readAttributes(filePath, BasicFileAttributes.class);
			FileTime creationTime = attr.creationTime();

			// FileTime�� ISO 8601 ���ڿ��� ��ȯ
			creationTimeString = creationTime.toInstant().atZone(ZoneId.systemDefault())
					.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);

		} catch (IOException e) {
			e.printStackTrace();
		}

		return creationTimeString;

	}

}
