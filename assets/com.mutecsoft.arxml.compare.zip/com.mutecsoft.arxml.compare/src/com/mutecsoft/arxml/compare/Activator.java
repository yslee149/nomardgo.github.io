package com.mutecsoft.arxml.compare;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.config.Configurator;
import org.eclipse.core.runtime.FileLocator;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;

public class Activator implements BundleActivator {

	private static final Logger logger = LogManager.getLogger(Activator.class);
	private static BundleContext context;

	static BundleContext getContext() {
		return context;
	}

	@Override
	public void start(BundleContext bundleContext) throws Exception {
		Activator.context = bundleContext;
		initializeLogging(context);
		logger.info("Bundle started");
	}

	@Override
	public void stop(BundleContext bundleContext) throws Exception {
		logger.info("Bundle stopped");
		Activator.context = null;
	}

	private void initializeLogging(BundleContext context) {
		URL url = context.getBundle().getResource("log4j2.xml");
		if (url != null) {
			try {
				File file = new File(FileLocator.resolve(url).toURI());
				Configurator.initialize(null, file.getAbsolutePath());
				logger.info("Log4j2 initialized with configuration file: " + file.getAbsolutePath());
			} catch (URISyntaxException | IOException e) {
				logger.error("Failed to initialize Log4j2 with configuration file", e);
			}
		} else {
			logger.error("Log4j2 configuration file not found");
		}
	}
}