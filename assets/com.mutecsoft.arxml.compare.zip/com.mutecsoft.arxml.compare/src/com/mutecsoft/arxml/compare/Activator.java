package com.mutecsoft.arxml.compare;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;

import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.Platform;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;

import com.mutecsoft.arxml.compare.db.DatabaseHelper;

public class Activator extends AbstractUIPlugin {

	public static final String PLUGIN_ID = "com.mutecsoft.arxml.compare";

	private static Activator plugin;

	private DatabaseHelper dbHelper;

	public Activator() {

	}

	public void start(BundleContext context) throws Exception {
		super.start(context);
		plugin = this;
		dbHelper = new DatabaseHelper();
	}

	public void stop(BundleContext context) throws Exception {
		dbHelper.closeDatabase();
		plugin = null;
		super.stop(context);
	}

	public static Activator getDefault() {
		return plugin;
	}

	public static ImageDescriptor getImageDescriptor(String path) {
		return imageDescriptorFromPlugin(PLUGIN_ID, path);
	}

	public DatabaseHelper getDb() {
		return dbHelper;
	}

	public File getFileFromPlugin(String filePath) throws IOException, URISyntaxException {
		Bundle bundle = Platform.getBundle(PLUGIN_ID);
		URL fileURL = bundle.getEntry(filePath);
		URL resolvedFileURL = FileLocator.toFileURL(fileURL);
		return new File(resolvedFileURL.toURI());
	}
}
