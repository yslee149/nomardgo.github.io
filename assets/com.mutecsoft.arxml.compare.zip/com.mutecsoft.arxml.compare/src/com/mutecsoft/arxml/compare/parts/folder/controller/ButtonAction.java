package com.mutecsoft.arxml.compare.parts.folder.controller;

import java.io.File;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.eclipse.e4.ui.model.application.MApplication;
import org.eclipse.e4.ui.model.application.ui.basic.MPart;
import org.eclipse.e4.ui.model.application.ui.basic.MPartStack;
import org.eclipse.e4.ui.workbench.modeling.EModelService;
import org.eclipse.e4.ui.workbench.modeling.EPartService;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import com.mutecsoft.arxml.compare.global.MyApp;
import com.mutecsoft.arxml.compare.model.FolderModel;
import com.mutecsoft.arxml.compare.model.folder.FolderModelBuilder;
import com.mutecsoft.arxml.compare.parts.folder.view.FolderPartView;
import com.mutecsoft.arxml.compare.utils.FolderCompareUtil;
import com.mutecsoft.arxml.compare.utils.StringUtils;
import com.mutecsoft.arxml.compare.view.dialog.NormalDialogManager;

public class ButtonAction {

	private static final Logger logger = LogManager.getLogger(ButtonAction.class);

	public void expandAll(MPart part) {
//		part.setLabel("Expanded All");
	}

	public void collapseAll(MPart part) {
//		part.setLabel("Collapsed All");
	}

	public void compareFile(Shell shell, FolderPartView view, Display display, EPartService partService,
			EModelService modelService, MApplication application) {

		display.asyncExec(() -> {
			// 새로운 Part를 생성합니다.
			MPart part = modelService.createModelElement(MPart.class);
			part.setElementId("your.new.part.id");
			part.setContributionURI(
					"bundleclass://com.mutecsoft.arxml.compare/com.mutecsoft.arxml.compare.parts.folder.FolderPart");
			part.setLabel("New Part");
			part.setCloseable(true);

			MPartStack partStack = (MPartStack) modelService.find("com.mutecsoft.arxml.compare.partstack.sample", application);

			if (partStack != null) {
				partStack.getChildren().add(part);
				partService.showPart(part, EPartService.PartState.ACTIVATE);
			}
		});
	}

	public void logAction(String message) {
		logger.info(message);
	}

	public void openFolderLeft(Shell shell, FolderPartView view) {

		String folderPath = getSelectedFolderPath(shell);

		if (!StringUtils.isEmpty(folderPath)) {
			FolderModel model = getFolderModel(folderPath);
			if (model != null) {
				MyApp.ORIGINAL_FOLDER_PATH = folderPath;
				view.setLeftTreeData(model);
			} else {
				logger.info("FolderModel is null");
			}
		}

	}

	public void openFolderRight(Shell shell, FolderPartView view) {

		String folderPath = getSelectedFolderPath(shell);

		if (!StringUtils.isEmpty(folderPath)) {
			FolderModel model = getFolderModel(folderPath);
			if (model != null) {
				MyApp.COMPARISON_FOLDER_PATH = folderPath;
				view.setRightTreeData(model);
			} else {
				logger.info("FolderModel is null");
			}
		}

	}

	private String getSelectedFolderPath(Shell shell) {
		String selectedDirectory = NormalDialogManager.selectDirectory(shell, "Please select a folder");
		if (selectedDirectory == null) {
			return null;
		}

		return selectedDirectory;
	}

	private FolderModel getFolderModel(String selectedDirectory) {
		File rootDir = new File(selectedDirectory);
		return new FolderModelBuilder().create(rootDir);
	}

	public void startFolderCompare(Shell shell, FolderPartView view) {

		String original = MyApp.ORIGINAL_FOLDER_PATH;
		String comparison = MyApp.COMPARISON_FOLDER_PATH;

		// 비교를 한번도 하지 않는 경우
		if (StringUtils.isEmpty(original) || StringUtils.isEmpty(comparison)) {

			NormalDialogManager.warning(shell, "Compare", "비교할 폴더가 지정되지 않았습니다.", () -> {

			});
			return;
		}

		FolderModel[] folderModels = new FolderCompareUtil().start(original, comparison, FolderCompareUtil.FILTER_ALL);
		view.updateComparisonData(folderModels[0], folderModels[1]);

	}

}
