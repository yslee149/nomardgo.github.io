package com.mutecsoft.arxml.compare.model;

public class FileModel {
	private String name;
	private int position;
	private String createdDate;
	private String size;
	private String type;
	private boolean comparisonResult; // 추가된 필드
	private ComparisonStatus comparisonStatus; // 추가된 필드

	public FileModel(String name, int position, String createdDate, String size, String type) {
		this.name = name;
		this.position = position;
		this.createdDate = createdDate;
		this.size = size;
		this.type = type;
		this.comparisonResult = false; // 기본값
		this.comparisonStatus = ComparisonStatus.IDENTICAL; // 기본값

	}

	public FileModel(String name, int position, String createdDate, String size, String type, ComparisonStatus status) {
		this(name, position, createdDate, size, type);
		this.comparisonStatus = status;
	}

	public String getName() {
		return name;
	}

	public int getPosition() {
		return position;
	}

	public void setPosition(int position) {
		this.position = position;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public String getSize() {
		return size;
	}

	public String getType() {
		return type;
	}

	public boolean isComparisonResult() {
		return comparisonResult;
	}

	public void setComparisonResult(boolean comparisonResult) {
		this.comparisonResult = comparisonResult;
	}

	public ComparisonStatus getComparisonStatus() {
		return comparisonStatus;
	}

	public void setComparisonStatus(ComparisonStatus comparisonStatus) {
		this.comparisonStatus = comparisonStatus;
	}
}
