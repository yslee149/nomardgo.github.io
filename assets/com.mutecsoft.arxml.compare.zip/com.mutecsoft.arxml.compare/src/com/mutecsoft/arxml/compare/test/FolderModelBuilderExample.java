package com.mutecsoft.arxml.compare.test;

import java.awt.BorderLayout;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;

import org.jdesktop.swingx.JXList;
import org.jdesktop.swingx.JXTree;

import com.mutecsoft.arxml.compare.model.FileModel;
import com.mutecsoft.arxml.compare.model.FolderModel;
import com.mutecsoft.arxml.compare.model.folder.FolderModelBuilder;
public class FolderModelBuilderExample {
    private static DefaultListModel<Object> listModel = new DefaultListModel<>();
    private static FolderModel rootFolder;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("JXList FolderModel Example");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setLayout(new BorderLayout());

            // 폴더 모델 빌더로 루트 폴더 생성
            FolderModelBuilder builder = new FolderModelBuilder();
            rootFolder = builder.create(new File("C:\\dev\\new\\현대오토에버_전달파일"));

            // JXList와 ListModel 생성
            JXList jxList = new JXList(listModel);
            jxList.setCellRenderer(new CustomListCellRenderer());
            
            // JXTree의 기본 로우 높이 설정
//            JXTree tempTree = new JXTree();
//            int rowHeight = tempTree.getRowHeight();
            jxList.setFixedCellHeight(20);
            
            JScrollPane scrollPane = new JScrollPane(jxList);

            // 초기 데이터 설정
            addFolderContents(rootFolder, 0);

            // 폴더 확장/축소 기능 구현
            jxList.addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseClicked(java.awt.event.MouseEvent evt) {
                    int index = jxList.locationToIndex(evt.getPoint());
                    Object item = listModel.get(index);
                    if (item instanceof FolderModel) {
                        FolderModel folder = (FolderModel) item;
                        if (folder.isExpanded()) {
                            collapseFolder(folder, index + 1);
                        } else {
                            expandFolder(folder, index + 1);
                        }
                        folder.setExpanded(!folder.isExpanded());
                    }
                }
            });

            // 날짜 표시 토글 버튼
            JButton toggleButton = new JButton("Toggle Date Display");
            toggleButton.addActionListener(e -> {
//                boolean showCreatedDate = !FolderModel.isShowCreatedDate();
//                FolderModel.setShowCreatedDate(showCreatedDate);
//                FileModel.setShowCreatedDate(showCreatedDate);
                refreshList();
            });

            frame.add(scrollPane, BorderLayout.CENTER);
            frame.add(toggleButton, BorderLayout.SOUTH);
            frame.setSize(300, 400);
            frame.setVisible(true);
        });
    }

    private static void addFolderContents(FolderModel folder, int indent) {
        listModel.addElement(folder);
        if (folder.isExpanded()) {
            for (FolderModel subFolder : folder.getSubFolders()) {
                addFolderContents(subFolder, indent + 1);
            }
            for (FileModel file : folder.getFiles()) {
                listModel.addElement(file);
            }
        }
    }

    private static void expandFolder(FolderModel folder, int index) {
        List<Object> itemsToAdd = new ArrayList<>();
        for (FolderModel subFolder : folder.getSubFolders()) {
            itemsToAdd.add(subFolder);
            if (subFolder.isExpanded()) {
                addSubFolderContents(subFolder, itemsToAdd);
            }
        }
        for (FileModel file : folder.getFiles()) {
            itemsToAdd.add(file);
        }
        for (int i = 0; i < itemsToAdd.size(); i++) {
            listModel.add(index + i, itemsToAdd.get(i));
        }
    }

    private static void collapseFolder(FolderModel folder, int index) {
        List<Object> itemsToRemove = new ArrayList<>();
        for (int i = index; i < listModel.getSize(); i++) {
            Object item = listModel.get(i);
            if (item instanceof FolderModel) {
                FolderModel subFolder = (FolderModel) item;
                if (subFolder.getPosition() <= folder.getPosition()) {
                    break;
                }
                itemsToRemove.add(item);
                if (subFolder.isExpanded()) {
                    collectSubFolderContents(subFolder, itemsToRemove);
                }
            } else if (item instanceof FileModel) {
                itemsToRemove.add(item);
            }
        }
        for (Object item : itemsToRemove) {
            listModel.removeElement(item);
        }
    }

    private static void addSubFolderContents(FolderModel folder, List<Object> items) {
        for (FolderModel subFolder : folder.getSubFolders()) {
            items.add(subFolder);
            if (subFolder.isExpanded()) {
                addSubFolderContents(subFolder, items);
            }
        }
        for (FileModel file : folder.getFiles()) {
            items.add(file);
        }
    }

    private static void collectSubFolderContents(FolderModel folder, List<Object> items) {
        for (FolderModel subFolder : folder.getSubFolders()) {
            items.add(subFolder);
            if (subFolder.isExpanded()) {
                collectSubFolderContents(subFolder, items);
            }
        }
        for (FileModel file : folder.getFiles()) {
            items.add(file);
        }
    }

    private static void refreshList() {
        listModel.clear();
        addFolderContents(rootFolder, 0);
    }
}