package com.mutecsoft.arxml.compare.db;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Type;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mutecsoft.arxml.compare.Activator;
import com.mutecsoft.arxml.compare.db.QuerySet.ProjectQueryKey;
import com.mutecsoft.arxml.compare.util.ConsoleUtil;
import com.mutecsoft.arxml.compare.util.SimpleLogger;

public class DatabaseHelper {

	private Connection connection;
	private Map<String, String> sqlQueries;
	private static final String DATABASE_FILE_PATH = "compare.db";

	public DatabaseHelper() {
		sqlQueries = new HashMap<>();
		loadSQLQueries("/resources/sql/project_data_query.json");
		initializeDatabase();
	}

	private void initializeDatabase() {
		try {

			deleteDatabaseFile();

			Class.forName("org.sqlite.JDBC");
			connection = DriverManager.getConnection("jdbc:sqlite:" + DATABASE_FILE_PATH);
			File dbFile = new File(DATABASE_FILE_PATH);
			SimpleLogger.d("Database file location: " + dbFile.getAbsolutePath());

			// ���̺� �� �ε��� ���� ������ ����
			executeSQL(ProjectQueryKey.CREATE_TABLE_PROJECT_DATA.name());
			executeSQL(ProjectQueryKey.CREATE_INDEX_PROJECT_ID.name());
			executeSQL(ProjectQueryKey.CREATE_INDEX_FILE_PATH.name());
			executeSQL(ProjectQueryKey.CREATE_INDEX_PARENT_ID.name());
			executeSQL(ProjectQueryKey.DELETE_ALL.name());

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

	private void deleteDatabaseFile() {
		File dbFile = new File(DATABASE_FILE_PATH);
		if (dbFile.exists()) {
			if (dbFile.delete()) {
				SimpleLogger.d("Database file deleted successfully.");
			} else {
				SimpleLogger.d("Failed to delete the database file.");
			}
		}
	}

	private void loadSQLQueries(String filePath) {
		try {
			String content = readFile(filePath);
			Gson gson = new Gson();
			Type type = new TypeToken<Map<String, String>>() {
			}.getType();
			sqlQueries = gson.fromJson(content, type);

		} catch (IOException | URISyntaxException e) {
			e.printStackTrace();
		}
	}

	private String readFile(String filePath) throws IOException, URISyntaxException {
		File jsonFile = Activator.getDefault().getFileFromPlugin(filePath);
		return new String(Files.readAllBytes(jsonFile.toPath()));
	}

	public void executeSQL(String queryKey) {

		String sql = sqlQueries.get(queryKey);
		if (sql == null) {
			System.err.println("Query not found for key: " + queryKey);
			return;
		}

		try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void closeDatabase() {
		try {
			if (connection != null && !connection.isClosed()) {
				connection.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public Connection getConnection() {
		return connection;
	}

	public void executeUpdate(String queryKey, Object... params) {
		String sql = sqlQueries.get(queryKey);
		if (sql == null) {
			System.err.println("Query not found for key: " + queryKey);
			return;
		}

		try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
			for (int i = 0; i < params.length; i++) {
				pstmt.setObject(i + 1, params[i]);
			}
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public Map<String, String> getSqlQueries() {
		return sqlQueries;
	}

	public synchronized ResultSet executeSelectQuery(String queryKey) {
		String sql = sqlQueries.get(queryKey);
		if (sql == null) {
			System.err.println("Query not found for key: " + queryKey);
			return null;
		}

		try {
			PreparedStatement pstmt = connection.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			return rs;

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}

	public synchronized void executeSelectQuery(String queryKey, Object... params) {
		String sql = sqlQueries.get(queryKey);
		if (sql == null) {
			System.err.println("Query not found for key: " + queryKey);
			return;
		}

		try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
			for (int i = 0; i < params.length; i++) {
				pstmt.setObject(i + 1, params[i]);
			}
			try (ResultSet rs = pstmt.executeQuery()) {
				int columnCount = rs.getMetaData().getColumnCount();
				while (rs.next()) {
					for (int i = 1; i <= columnCount; i++) {
						System.out.print(rs.getString(i) + "\t");
					}
					SimpleLogger.d("\n");
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
