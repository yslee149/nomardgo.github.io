package com.mutecsoft.arxml.compare.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import com.mutecsoft.arxml.compare.model.ComparisonStatus;
import com.mutecsoft.arxml.compare.model.FileModel;
import com.mutecsoft.arxml.compare.model.FolderModel;

public class FolderCompareUtil {

	// 필터 상수 정의
	public static final String FILTER_ALL = "all";
	public static final String FILTER_IDENTICAL = "identical";
	public static final String FILTER_DIFFERENT = "different";

	private boolean compareFileNames = true;
	private boolean compareSizes = true;
	private boolean compareDates = true;
	private boolean compareContents = true;
	private boolean searchSubfolders = true;

	public FolderModel[] start(String originFolderPath, String compareFolderPath, String filter) {
		FolderModel[] comparisonResult = compareFolders(originFolderPath, compareFolderPath, compareFileNames,
				compareSizes, compareDates, compareContents, searchSubfolders);
		return filterComparisonResult(comparisonResult, filter);
	}

	private FolderModel[] filterComparisonResult(FolderModel[] comparisonResult, String filter) {
		if (comparisonResult == null) {
			return null;
		}

		FolderModel filteredFolder1 = filterFolder(comparisonResult[0], filter);
		FolderModel filteredFolder2 = filterFolder(comparisonResult[1], filter);

		return new FolderModel[] { filteredFolder1, filteredFolder2 };
	}

	private FolderModel filterFolder(FolderModel folder, String filter) {
		FolderModel filteredFolder = new FolderModel(folder.getName(), folder.getPosition(), folder.getCreatedDate(),
				folder.getSize(), folder.getType());

		for (FileModel file : folder.getFiles()) {
			if (FILTER_ALL.equalsIgnoreCase(filter)) {
				filteredFolder.addFile(file);
			} else if (FILTER_IDENTICAL.equalsIgnoreCase(filter)
					&& file.getComparisonStatus() == ComparisonStatus.IDENTICAL) {
				filteredFolder.addFile(file);
			} else if (FILTER_DIFFERENT.equalsIgnoreCase(filter)
					&& file.getComparisonStatus() != ComparisonStatus.IDENTICAL) {
				filteredFolder.addFile(file);
			}
		}

		for (FolderModel subFolder : folder.getSubFolders()) {
			FolderModel filteredSubFolder = filterFolder(subFolder, filter);
			if (!filteredSubFolder.getFiles().isEmpty() || !filteredSubFolder.getSubFolders().isEmpty()) {
				filteredFolder.addSubFolder(filteredSubFolder);
			}
		}

		return filteredFolder;
	}

	private FolderModel[] compareFolders(String firstFolder, String secondFolder, boolean compareFileNames,
			boolean compareSizes, boolean compareDates, boolean compareContents, boolean searchSubfolders) {
		File folder1 = new File(firstFolder);
		File folder2 = new File(secondFolder);

		if (!folder1.exists() || !folder2.exists()) {
			System.out.println("One or both folders do not exist.");
			return null;
		}

		FolderModel folderModel1 = new FolderModel(firstFolder, 0, "", 0, "folder");
		FolderModel folderModel2 = new FolderModel(secondFolder, 0, "", 0, "folder");

		compareFolderContents(folderModel1, folderModel2, folder1, folder2, compareFileNames, compareSizes,
				compareDates, compareContents, searchSubfolders);

		return new FolderModel[] { folderModel1, folderModel2 };
	}

	private void compareFolderContents(FolderModel folderModel1, FolderModel folderModel2, File folder1, File folder2,
			boolean compareFileNames, boolean compareSizes, boolean compareDates, boolean compareContents,
			boolean searchSubfolders) {
		try {
			List<String> folder1Files = getFilesRecursively(folder1, searchSubfolders);
			List<String> folder2Files = getFilesRecursively(folder2, searchSubfolders);

			Collections.sort(folder1Files);
			Collections.sort(folder2Files);

			Set<String> allFiles = new TreeSet<>(folder1Files);
			allFiles.addAll(folder2Files);

			int position = 0;
			boolean isDifferent = false;

			for (String filePath : allFiles) {
				File file1 = new File(folder1, filePath);
				File file2 = new File(folder2, filePath);

				if (file1.exists() && file2.exists()) {
					ComparisonStatus status = ComparisonStatus.IDENTICAL;
					// Compare sizes
					if (compareSizes && file1.length() != file2.length()) {
						status = ComparisonStatus.DIFFERENT;
					}
					// Compare dates
					if (compareDates && file1.lastModified() != file2.lastModified()) {
						status = ComparisonStatus.DIFFERENT;
					}
					// Compare contents (checksum)
					if (compareContents) {
						String checksum1 = getFileChecksum(file1);
						String checksum2 = getFileChecksum(file2);
						if (!checksum1.equals(checksum2)) {
							status = ComparisonStatus.DIFFERENT;
						}
					}
					if (status == ComparisonStatus.DIFFERENT) {
						isDifferent = true;
					}
					folderModel1.addFile(createFileModel(file1, position, status));
					folderModel2.addFile(createFileModel(file2, position, status));
				} else if (file1.exists()) {
					isDifferent = true;
					folderModel1.addFile(createFileModel(file1, position, ComparisonStatus.ONLY_IN_ORIGINAL));
					folderModel2.addFile(createEmptyFileModel(filePath, position, ComparisonStatus.ONLY_IN_COMPARISON));
				} else {
					isDifferent = true;
					folderModel1.addFile(createEmptyFileModel(filePath, position, ComparisonStatus.ONLY_IN_ORIGINAL));
					folderModel2.addFile(createFileModel(file2, position, ComparisonStatus.ONLY_IN_COMPARISON));
				}
				position++;
			}

			// Compare subfolders
			if (searchSubfolders) {
				List<File> subFolders1 = Arrays.asList(folder1.listFiles(File::isDirectory));
				List<File> subFolders2 = Arrays.asList(folder2.listFiles(File::isDirectory));

				Set<String> allSubFolders = new TreeSet<>();
				subFolders1.forEach(subFolder -> allSubFolders.add(subFolder.getName()));
				subFolders2.forEach(subFolder -> allSubFolders.add(subFolder.getName()));

				for (String subFolderName : allSubFolders) {
					File subFolder1 = new File(folder1, subFolderName);
					File subFolder2 = new File(folder2, subFolderName);

					FolderModel subFolderModel1 = new FolderModel(subFolderName, position, "", 0, "folder");
					FolderModel subFolderModel2 = new FolderModel(subFolderName, position, "", 0, "folder");

					if (subFolder1.exists() && subFolder2.exists()) {
						compareFolderContents(subFolderModel1, subFolderModel2, subFolder1, subFolder2,
								compareFileNames, compareSizes, compareDates, compareContents, searchSubfolders);
					} else if (subFolder1.exists()) {
						subFolderModel1.setComparisonStatus(ComparisonStatus.ONLY_IN_ORIGINAL);
						subFolderModel2.setComparisonStatus(ComparisonStatus.ONLY_IN_COMPARISON);
						addEmptySubFolders(subFolderModel2, subFolder1);
					} else {
						subFolderModel1.setComparisonStatus(ComparisonStatus.ONLY_IN_ORIGINAL);
						subFolderModel2.setComparisonStatus(ComparisonStatus.ONLY_IN_COMPARISON);
						addEmptySubFolders(subFolderModel1, subFolder2);
					}

					folderModel1.addSubFolder(subFolderModel1);
					folderModel2.addSubFolder(subFolderModel2);

					if (subFolderModel1.getComparisonStatus() != ComparisonStatus.IDENTICAL
							|| subFolderModel2.getComparisonStatus() != ComparisonStatus.IDENTICAL) {
						isDifferent = true;
					}
				}
			}

			if (isDifferent) {
				folderModel1.setComparisonStatus(ComparisonStatus.DIFFERENT);
				folderModel2.setComparisonStatus(ComparisonStatus.DIFFERENT);
			} else {
				folderModel1.setComparisonStatus(ComparisonStatus.IDENTICAL);
				folderModel2.setComparisonStatus(ComparisonStatus.IDENTICAL);
			}
		} catch (IOException | NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
	}

	private void addEmptySubFolders(FolderModel emptyFolderModel, File referenceFolder) {
		try {
			List<String> referenceFiles = getFilesRecursively(referenceFolder, true);
			int position = 0;
			for (String filePath : referenceFiles) {
				emptyFolderModel.addFile(createEmptyFileModel(filePath, position, ComparisonStatus.ONLY_IN_ORIGINAL));
				position++;
			}

			List<File> referenceSubFolders = Arrays.asList(referenceFolder.listFiles(File::isDirectory));
			for (File subFolder : referenceSubFolders) {
				FolderModel subFolderModel = new FolderModel(subFolder.getName(), position, "", 0, "folder");
				subFolderModel.setComparisonStatus(ComparisonStatus.ONLY_IN_ORIGINAL);
				emptyFolderModel.addSubFolder(subFolderModel);
				addEmptySubFolders(subFolderModel, subFolder);
				position++;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private List<String> getFilesRecursively(File folder, boolean searchSubfolders) throws IOException {
		List<String> fileList = new ArrayList<>();
		if (searchSubfolders) {
			Files.walk(folder.toPath()).filter(Files::isRegularFile).filter(path -> path.toString().endsWith(".arxml"))
					.forEach(path -> fileList.add(folder.toPath().relativize(path).toString()));
		} else {
			Files.list(folder.toPath()).filter(Files::isRegularFile).filter(path -> path.toString().endsWith(".arxml"))
					.forEach(path -> fileList.add(folder.toPath().relativize(path).toString()));
		}
		return fileList;
	}

	private String getFileChecksum(File file) throws IOException, NoSuchAlgorithmException {
		MessageDigest digest = MessageDigest.getInstance("MD5");
		try (InputStream fis = new FileInputStream(file)) {
			byte[] byteArray = new byte[1024];
			int bytesCount;
			while ((bytesCount = fis.read(byteArray)) != -1) {
				digest.update(byteArray, 0, bytesCount);
			}
		}
		byte[] bytes = digest.digest();
		StringBuilder sb = new StringBuilder();
		for (byte b : bytes) {
			sb.append(String.format("%02x", b));
		}
		return sb.toString();
	}

	private FileModel createFileModel(File file, int position, ComparisonStatus status) {
		String createdDate = DateFormatUtil.formatDate(new Date(file.lastModified()));
		String size = DateFormatUtil.formatSizeToKB(file.length());

		return new FileModel(file.getName(), position, createdDate, size, "file", status);
	}

	private FileModel createEmptyFileModel(String fileName, int position, ComparisonStatus status) {
		return new FileModel("", position, "", "0", "file", status);
	}

	private void printFolderModel(FolderModel folderModel, String folderName) {
		System.out.println("Folder: " + folderName);
		for (FileModel file : folderModel.getFiles()) {
			System.out.println("  File: " + file.getName());
			System.out.println("    Position: " + file.getPosition());
			System.out.println("    Created Date: " + file.getCreatedDate());
			System.out.println("    Size: " + file.getSize());
			System.out.println("    Type: " + file.getType());
			System.out.println("    Comparison Status: " + file.getComparisonStatus());
		}
	}
}
