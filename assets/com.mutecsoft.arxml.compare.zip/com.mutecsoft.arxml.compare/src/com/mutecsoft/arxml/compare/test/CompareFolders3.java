package com.mutecsoft.arxml.compare.test;

import java.io.File;
import java.io.FileInputStream;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import com.mutecsoft.arxml.compare.model.FileModel;
import com.mutecsoft.arxml.compare.model.FolderModel;

public class CompareFolders3 {

    public static void main(String[] args) {
        String path1 = "C:\\dev\\new\\현대오토에버_전달파일";
        String path2 = "C:\\dev\\new\\현대오토에버_전달파일 - 복사본";

        FolderModel folder1 = createFolderModel(new File(path1), 0);
        FolderModel folder2 = createFolderModel(new File(path2), 0);

        boolean areFoldersIdentical = compareFolderModels(folder1, folder2);
        System.out.println("폴더가 동일한가요? " + areFoldersIdentical);
    }

    public static FolderModel createFolderModel(File folder, int position) {
        if (!folder.isDirectory()) {
            throw new IllegalArgumentException("경로가 유효한 디렉토리가 아닙니다: " + folder.getPath());
        }

        String name = folder.getName();
        String createdDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date(folder.lastModified()));
        long size = getFolderSize(folder);
        String type = "Folder";

        FolderModel folderModel = new FolderModel(name, position, createdDate, size, type);

        File[] filesAndFolders = folder.listFiles();
        if (filesAndFolders != null) {
            int subPosition = 0;
            for (File file : filesAndFolders) {
                if (file.isDirectory()) {
                    FolderModel subFolderModel = createFolderModel(file, subPosition++);
                    folderModel.addSubFolder(subFolderModel);
                } else if (file.isFile()) {
                    String fileName = file.getName();
                    String fileCreatedDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date(file.lastModified()));
                    String fileSize = String.valueOf(file.length());
                    String fileType = getFileExtension(file);

                    FileModel fileModel = new FileModel(fileName, subPosition++, fileCreatedDate, fileSize, fileType);
                    folderModel.addFile(fileModel);
                }
            }
        }

        return folderModel;
    }

    private static long getFolderSize(File folder) {
        long size = 0;
        File[] files = folder.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isFile()) {
                    size += file.length();
                } else if (file.isDirectory()) {
                    size += getFolderSize(file);
                }
            }
        }
        return size;
    }

    private static String getFileExtension(File file) {
        String name = file.getName();
        int lastIndexOf = name.lastIndexOf(".");
        if (lastIndexOf == -1) {
            return ""; // 확장자가 없는 경우
        }
        return name.substring(lastIndexOf + 1);
    }

    public static boolean compareFolderModels(FolderModel folder1, FolderModel folder2) {
        if (!folder1.getName().equals(folder2.getName())) {
            System.out.println("폴더 이름이 다릅니다: " + folder1.getName() + " 와 " + folder2.getName());
            return false;
        }

        List<FolderModel> subFolders1 = folder1.getSubFolders();
        List<FolderModel> subFolders2 = folder2.getSubFolders();
        List<FileModel> files1 = folder1.getFiles();
        List<FileModel> files2 = folder2.getFiles();

        if (subFolders1.size() != subFolders2.size() || files1.size() != files2.size()) {
            System.out.println("폴더 내 항목 수가 다릅니다: " + folder1.getName() + " 와 " + folder2.getName());
            return false;
        }

        for (int i = 0; i < subFolders1.size(); i++) {
            FolderModel subFolder1 = subFolders1.get(i);
            FolderModel subFolder2 = subFolders2.get(i);
            if (!compareFolderModels(subFolder1, subFolder2)) {
                System.out.println("하위 폴더가 다릅니다: " + subFolder1.getName() + " 와 " + subFolder2.getName());
                return false;
            }
        }

        for (int i = 0; i < files1.size(); i++) {
            FileModel file1 = files1.get(i);
            FileModel file2 = files2.get(i);
            if (!compareFileModels(file1, file2)) {
                System.out.println("파일이 다릅니다: " + file1.getName() + " 와 " + file2.getName());
                return false;
            }
        }

        return true;
    }

    private static boolean compareFileModels(FileModel file1, FileModel file2) {
        if (!file1.getName().equals(file2.getName()) || !file1.getSize().equals(file2.getSize()) || !file1.getType().equals(file2.getType())) {
            System.out.println("파일 속성이 다릅니다: " + file1.getName() + " 와 " + file2.getName());
            return false;
        }
        return true;
    }

    public static boolean compareFolders(File folder1, File folder2) {
        if (!folder1.isDirectory() || !folder2.isDirectory()) {
            throw new IllegalArgumentException("두 경로 모두 디렉토리여야 합니다.");
        }

        File[] folder1Files = folder1.listFiles();
        File[] folder2Files = folder2.listFiles();

        Arrays.sort(folder1Files);
        Arrays.sort(folder2Files);

        boolean foldersIdentical = true;

        int i = 0, j = 0;
        while (i < folder1Files.length && j < folder2Files.length) {
            File file1 = folder1Files[i];
            File file2 = folder2Files[j];

            int comparison = file1.getName().compareTo(file2.getName());

            if (comparison == 0) {
                if (file1.isDirectory() && file2.isDirectory()) {
                    if (!compareFolders(file1, file2)) {
                        System.out.println("폴더가 다릅니다: " + file1.getPath() + " 와 " + file2.getPath());
                        foldersIdentical = false;
                    }
                } else if (file1.isFile() && file2.isFile()) {
                    if (!compareFiles(file1, file2)) {
                        System.out.println("파일이 다릅니다: " + file1.getPath() + " 와 " + file2.getPath());
                        foldersIdentical = false;
                    }
                } else {
                    System.out.println("파일과 폴더 타입이 일치하지 않습니다: " + file1.getPath() + " 와 " + file2.getPath());
                    foldersIdentical = false;
                }
                i++;
                j++;
            } else if (comparison < 0) {
                System.out.println("폴더1에만 있는 파일/폴더: " + file1.getPath());
                foldersIdentical = false;
                i++;
            } else {
                System.out.println("폴더2에만 있는 파일/폴더: " + file2.getPath());
                foldersIdentical = false;
                j++;
            }
        }

        while (i < folder1Files.length) {
            System.out.println("폴더1에만 있는 파일/폴더: " + folder1Files[i].getPath());
            foldersIdentical = false;
            i++;
        }

        while (j < folder2Files.length) {
            System.out.println("폴더2에만 있는 파일/폴더: " + folder2Files[j].getPath());
            foldersIdentical = false;
            j++;
        }

        return foldersIdentical;
    }

    private static boolean compareFiles(File file1, File file2) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");

            byte[] file1Digest = getFileChecksum(md, file1);
            byte[] file2Digest = getFileChecksum(md, file2);

            if (!Arrays.equals(file1Digest, file2Digest)) {
                System.out.println("파일 내용이 다릅니다: " + file1.getPath() + " 와 " + file2.getPath());
                return false;
            }

            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private static byte[] getFileChecksum(MessageDigest digest, File file) throws Exception {
        FileInputStream fis = new FileInputStream(file);
        byte[] byteArray = new byte[1024];
        int bytesCount;

        while ((bytesCount = fis.read(byteArray)) != -1) {
            digest.update(byteArray, 0, bytesCount);
        }

        fis.close();

        return digest.digest();
    }
}
