package com.mutecsoft.arxml.compare.test;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.HashSet;
import java.util.Set;

public class FolderComparisonNIO {
    public static void main(String[] args) throws IOException {
        Path folder1 = Paths.get("C:\\dev\\new\\현대오토에버_전달파일");
        Path folder2 = Paths.get("C:\\dev\\new\\현대오토에버_전달파일 - 복사본");
        String extension = ".arxml"; // 비교할 파일의 확장자

        Set<Path> files1 = new HashSet<>();
        Set<Path> files2 = new HashSet<>();

        Files.walkFileTree(folder1, new SimpleFileVisitor<Path>() {
            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                if (file.toString().endsWith(extension)) {
                    files1.add(folder1.relativize(file));
                }
                return FileVisitResult.CONTINUE;
            }
        });

        Files.walkFileTree(folder2, new SimpleFileVisitor<Path>() {
            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                if (file.toString().endsWith(extension)) {
                    files2.add(folder2.relativize(file));
                }
                return FileVisitResult.CONTINUE;
            }
        });

        for (Path relativePath : files1) {
            Path file1 = folder1.resolve(relativePath);
            Path file2 = folder2.resolve(relativePath);

            if (Files.exists(file2)) {
                boolean isEqual = compareFiles(file1, file2);
                System.out.println(file1 + " and " + file2 + " are " + (isEqual ? "identical" : "different"));
            } else {
                System.out.println(file2 + " does not exist in folder2");
            }
        }

        for (Path relativePath : files2) {
            Path file1 = folder1.resolve(relativePath);
            if (!Files.exists(file1)) {
                System.out.println(file1 + " does not exist in folder1");
            }
        }
    }

    private static boolean compareFiles(Path file1, Path file2) throws IOException {
        if (Files.size(file1) != Files.size(file2)) {
            return false;
        }
        byte[] file1Bytes = Files.readAllBytes(file1);
        byte[] file2Bytes = Files.readAllBytes(file2);
        for (int i = 0; i < file1Bytes.length; i++) {
            if (file1Bytes[i] != file2Bytes[i]) {
                return false;
            }
        }
        return true;
    }
}
