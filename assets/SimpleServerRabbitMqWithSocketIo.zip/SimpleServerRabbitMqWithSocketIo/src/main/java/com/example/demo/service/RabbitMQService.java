package com.example.demo.service;

import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.corundumstudio.socketio.SocketIOServer;
import com.rabbitmq.client.CancelCallback;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.DeliverCallback;

@Service
public class RabbitMQService {

	private Connection connection;
	private Channel channel;

	private final SocketIOServer socketIOServer;

	// Map of queueName to consumerTag
	private ConcurrentMap<String, String> queueConsumerTagMap = new ConcurrentHashMap<>();

	@Autowired
	public RabbitMQService(SocketIOServer socketIOServer) {
		this.socketIOServer = socketIOServer;
	}

	@PostConstruct
	public void init() {
		System.out.println("RabbitMQ 서비스 초기화");
		setupRabbitMqConnection();
	}

	@PreDestroy
	public void cleanup() {
		try {
			if (channel != null && channel.isOpen()) {
				channel.close();
			}

			if (connection != null && connection.isOpen()) {
				connection.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void setupRabbitMqConnection() {
		final String RABBITMQ_HOST = "chillaxmax.kr";
		final int RABBITMQ_PORT = 25672;
		final String RABBITMQ_USER_NAME = "rabbit";
		final String RABBITMQ_USER_PASSWORD = "rabbitpassword";

		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost(RABBITMQ_HOST);
		factory.setPort(RABBITMQ_PORT);
		factory.setUsername(RABBITMQ_USER_NAME);
		factory.setPassword(RABBITMQ_USER_PASSWORD);

		try {
			connection = factory.newConnection();
			channel = connection.createChannel();
			System.out.println("RabbitMQ 접속 성공: " + connection.getAddress());

			// 연결 종료 리스너
			connection.addShutdownListener(cause -> {
				System.out.println("RabbitMQ 연결 종료: " + cause.getMessage());
				// 재연결 로직 추가 가능
			});

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("RabbitMQ 연결 실패: " + e.getMessage());
		}
	}

	public void createConsumer(String queueName) {
		if (channel == null || !channel.isOpen()) {
			setupRabbitMqConnection();
		}

		try {
			channel.queueDeclare(queueName, false, false, true, null);
			System.out.println("RabbitMQ 큐 선언 성공: " + queueName);

			DeliverCallback deliverCallback = (consumerTag, delivery) -> {

				String myMessage = new String(delivery.getBody(), "UTF-8");
				System.out.println("단말 전달 메시지 : " + myMessage);
				socketIOServer.getBroadcastOperations().sendEvent("message", myMessage); // Socket.IO를 통해 메시지 전송

			};

			CancelCallback cancelCallback = consumerTag -> {
				System.out.println("RabbitMQ 소비 취소: " + consumerTag);
				queueConsumerTagMap.remove(queueName);
			};

			String consumerTag = channel.basicConsume(queueName, true, deliverCallback, cancelCallback);
			queueConsumerTagMap.put(queueName, consumerTag);
			System.out.println("RabbitMQ 소비자 등록 완료: " + queueName);

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("RabbitMQ 소비자 설정 실패: " + e.getMessage());
		}
	}

	public void removeConsumer(String queueName) {
		String consumerTag = queueConsumerTagMap.get(queueName);
		if (consumerTag != null) {
			try {
				channel.basicCancel(consumerTag);
				queueConsumerTagMap.remove(queueName);
				System.out.println("RabbitMQ 소비자 취소 완료: " + queueName);
			} catch (IOException e) {
				e.printStackTrace();
				System.out.println("RabbitMQ 소비자 취소 실패: " + e.getMessage());
			}
		}

		try {
			channel.queueDelete(queueName);
			System.out.println("RabbitMQ 큐 삭제 완료: " + queueName);
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("RabbitMQ 큐 삭제 실패: " + e.getMessage());
		}
	}
}
