package com.mutecsoft.arxml.compare.view.impl.project;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.tree.TreePath;

import org.eclipse.swt.awt.SWT_AWT;
import org.eclipse.swt.widgets.Composite;
import org.jdesktop.swingx.JXTreeTable;
import org.jdesktop.swingx.decorator.ColorHighlighter;
import org.jdesktop.swingx.decorator.Highlighter;

import com.mutecsoft.arxml.compare.view.impl.project.tree.CustomTableCellRenderer;
import com.mutecsoft.arxml.compare.view.impl.project.tree.TreeTableCellRenderer;
import com.mutecsoft.arxml.compare.view.impl.project.tree.TreeTableModel;

public class TreeTable {

	private ProjectTreeViewImpl view;
	private Composite swingComposite;
	private JXTreeTable treeTable;

	public TreeTable(ProjectTreeViewImpl view) {
		this.view = view;
		this.swingComposite = view.getViewPart().getSwingComposite();
	}

	public void crate() {
		java.awt.Frame frame = SWT_AWT.new_Frame(swingComposite);
		SwingUtilities.invokeLater(() -> {
			configureSwingComponents(frame);
		});
	}

	private void configureSwingComponents(java.awt.Frame frame) {
		try {
//			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");

		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException
				| UnsupportedLookAndFeelException e1) {
			e1.printStackTrace();
		}

		JPanel panel = new JPanel(new BorderLayout());
		frame.add(panel);

		TreeTableModel tableModel = new TreeTableModel(view.getProjectsDatas());

		treeTable = new JXTreeTable(tableModel);
		treeTable.setRootVisible(false);
//		treeTable.setShowsRootHandles(true);
//		treeTable.setShowGrid(true); // �׸��� ������ �����ݴϴ�.
//		treeTable.setGridColor(Color.BLACK); // �׸��� ������ ������ �����մϴ�.
//		treeTable.setIntercellSpacing(new Dimension(1, 1)); // �� ���� ������ �����Ͽ� �׸��� ������ ��Ÿ������ �մϴ�.

		setColumnCustom();

 
//        treeTable.putClientProperty("JTree.lineStyle", "Angled"); // ���ἱ ��Ÿ�� ���� (Angled, Horizontal, None)
//        treeTable.putClientProperty("JTree.timeFactor", 1000); // �巡�� �� ��� �ð� ���� ����
//        treeTable.putClientProperty("JTree.paintLines", Boolean.TRUE); // ���ἱ ������ ����
//        treeTable.putClientProperty("JTree.largeModel", Boolean.TRUE); // ū ���� ���� ����ȭ
//        treeTable.putClientProperty("JTree.scrollsOnExpand", Boolean.TRUE); // ��� Ȯ�� �� �ڵ� ��ũ��

        
        
//		treeTable.putClientProperty("JTree.lineStyle", "Angled");
		treeTable.setRowHeight(30);
//		treeTable.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
		
//		JTree tree = (JTree) treeTable.getCellRenderer(1, 0);
//        tree.putClientProperty("JTree.lineStyle", "Angled"); // ���ἱ ��Ÿ�� ���� (Angled, Horizontal, None)


		Highlighter oddHighlighter = new ColorHighlighter((component, adapter) -> adapter.row % 2 != 0, Color.WHITE,
				Color.BLACK);
		Highlighter evenHighlighter = new ColorHighlighter((component, adapter) -> adapter.row % 2 == 0,
				new Color(248, 250, 249), Color.BLACK);
		treeTable.addHighlighter(oddHighlighter);
		treeTable.addHighlighter(evenHighlighter);
		
//		treeTable.setShowGrid(false);

		treeTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int row = treeTable.rowAtPoint(e.getPoint());
				int column = treeTable.columnAtPoint(e.getPoint());

				if (row != -1 && column != -1) {
					String columnName = treeTable.getColumnName(column);
					Object cellValue = treeTable.getValueAt(row, column);
					System.out.println("Clicked Column: " + columnName + ", Value: " + cellValue);
				}

				if (row != -1 && e.getClickCount() == 2) {
					TreePath path = treeTable.getPathForRow(row);
					if (treeTable.isExpanded(path)) {
						treeTable.collapsePath(path);
					} else {
						treeTable.expandPath(path);
					}
				}
			}
		});

		JScrollPane scrollPane = new JScrollPane(treeTable);
//		scrollPane.setBorder(customBorder); // Set custom border
		scrollPane.getVerticalScrollBar().setPreferredSize(new Dimension(0, 0));
		scrollPane.getHorizontalScrollBar().setPreferredSize(new Dimension(0, 0));
		panel.add(scrollPane, BorderLayout.CENTER);
		frame.setVisible(true);
	}

	private void setColumnCustom() {

		TableColumnModel columnModel = treeTable.getColumnModel();

		// ���� �տ� Ʈ���÷� ���� ó��
		TableColumn hideColumn = columnModel.getColumn(0);
		hideColumn.setMinWidth(0);
		hideColumn.setMaxWidth(0);
		hideColumn.setPreferredWidth(0);

		// Ʈ�� ����
		TableColumn treeColumn1 = columnModel.getColumn(1);
		treeColumn1.setCellRenderer(new TreeTableCellRenderer(treeTable, 1));

		TableColumn treeColumn2 = columnModel.getColumn(5);
		treeColumn2.setCellRenderer(new TreeTableCellRenderer(treeTable, 5));

		// ���� ũ�� �÷�
		int fileSizeWidth = 100;
		TableColumn treeSize1 = columnModel.getColumn(2);
		treeSize1.setMinWidth(fileSizeWidth);
		treeSize1.setMaxWidth(fileSizeWidth);
		treeSize1.setPreferredWidth(fileSizeWidth);

		TableColumn treeSize2 = columnModel.getColumn(6);
		treeSize2.setMinWidth(fileSizeWidth);
		treeSize2.setMaxWidth(fileSizeWidth);
		treeSize2.setPreferredWidth(fileSizeWidth);

		// ���� ������
		int fileDataWidth = 200;
		TableColumn treeDate1 = columnModel.getColumn(3);
		treeDate1.setMinWidth(fileDataWidth);
		treeDate1.setMaxWidth(fileDataWidth);
		treeDate1.setPreferredWidth(fileDataWidth);

		TableColumn treeDate2 = columnModel.getColumn(7);
		treeDate2.setMinWidth(fileDataWidth);
		treeDate2.setMaxWidth(fileDataWidth);
		treeDate2.setPreferredWidth(fileDataWidth);

		// �񱳰��
		int fileDiffWidth = 50;
		TableColumn treeDiff = columnModel.getColumn(4);
		treeDiff.setMinWidth(fileDiffWidth);
		treeDiff.setMaxWidth(fileDiffWidth);
		treeDiff.setPreferredWidth(fileDiffWidth);
		
		DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
		centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
		treeDiff.setCellRenderer(new CustomTableCellRenderer());

	
	}

}
