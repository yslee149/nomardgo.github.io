package com.mutecsoft.arxml.compare.util;

import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import com.mutecsoft.arxml.compare.CompareConstant.ScreenSize;

public class ScreenUtil {

	public static void setScreenSize(Shell shell, ScreenSize screenSize) {

		if (screenSize == null) {
			SimpleLogger.e("ScreenSize must not be null.", new IllegalArgumentException());
		}

		Display display = shell.getDisplay();
		Rectangle screenSizeBounds = display.getPrimaryMonitor().getBounds();

		int newWidth = (int) (screenSizeBounds.width * screenSize.getRatio());
		int newHeight = (int) (screenSizeBounds.height * screenSize.getRatio());

		int newX = (screenSizeBounds.width - newWidth) / 2;
		int newY = (screenSizeBounds.height - newHeight) / 2;

		shell.setBounds(newX, newY, newWidth, newHeight);
	}

}
