package com.mutecsoft.arxml.compare.test.tree;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;

public class TreeWithImages {
    public static void main(String[] args) {
        Display display = new Display();
        Shell shell = new Shell(display);
        shell.setText("Tree with Images Example");

        Tree tree = new Tree(shell, SWT.BORDER | SWT.V_SCROLL | SWT.H_SCROLL);
        tree.setSize(300, 200);

        Image image = new Image(display, "C:\\dev\\autoever\\workspace\\com.mutecsoft.arxml.compare\\resources\\folder.png");

        TreeItem root = new TreeItem(tree, 0);
        root.setText("Root Item");
        root.setImage(image);

        TreeItem child1 = new TreeItem(root, 0);
        child1.setText("Child Item 1");
        child1.setImage(image);

        TreeItem child2 = new TreeItem(root, 0);
        child2.setText("Child Item 2");
        child2.setImage(image);

        root.setExpanded(true);

        shell.setSize(350, 250);
        shell.open();

        while (!shell.isDisposed()) {
            if (!display.readAndDispatch()) {
                display.sleep();
            }
        }
        display.dispose();
        image.dispose();
    }
}
