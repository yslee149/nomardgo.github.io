package com.mutecsoft.arxml.compare.test.jxtree;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class Example {

	private Composite parent;
	private Composite topComposite;
	private Display display;

	public Example(Display display, Composite parent) {
		this.display = display;
		this.parent = parent;
	}

	private void createComposite() {
		GridLayout gridLayout = new GridLayout(2, false);
		gridLayout.marginWidth = 0;
		gridLayout.marginHeight = 0;
		gridLayout.horizontalSpacing = 0;
		gridLayout.verticalSpacing = 0;
		parent.setLayout(gridLayout);
	}

	private void createTopArea() {
		topComposite = new Composite(parent, SWT.BORDER);
		topComposite.setLayout(new GridLayout(16, false));
		GridData gridData = new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1);
		gridData.heightHint = 50;
		topComposite.setLayoutData(gridData);

		// ���� ����
		Color topBackgroundColor = display.getSystemColor(SWT.COLOR_BLUE); // ���ϴ� �������� ����
		topComposite.setBackground(topBackgroundColor);
	}

	private void createBottomArea() {
		Composite bottomComposite = new Composite(parent, SWT.BORDER);
		bottomComposite.setLayout(new GridLayout(16, false));
		GridData gridData = new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1);
		gridData.heightHint = 100;
		bottomComposite.setLayoutData(gridData);

		// ���� ����
		Color bottomBackgroundColor = display.getSystemColor(SWT.COLOR_GREEN); // ���ϴ� �������� ����
		bottomComposite.setBackground(bottomBackgroundColor);
	}

	public static void main(String[] args) {
		Display display = new Display();
		Shell shell = new Shell(display);
		shell.setLayout(new GridLayout(1, false));

		Composite parent = new Composite(shell, SWT.NONE);
		parent.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));

		Example example = new Example(display, parent);
		example.createComposite();
		example.createTopArea();
		example.createBottomArea();

		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		display.dispose();
	}
}
