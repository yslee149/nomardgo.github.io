package com.mutecsoft.arxml.compare.view;

import java.util.List;

import com.mutecsoft.arxml.compare.model.ProjectCompareData;

public interface ProjectTreeView {

	void displayComparisonResult(List<ProjectCompareData> projectsDatas);

	void showView();

	void showError(String message);

	void showFileSelection();

}
