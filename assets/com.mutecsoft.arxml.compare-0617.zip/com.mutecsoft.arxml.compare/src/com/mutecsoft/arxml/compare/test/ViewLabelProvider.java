package com.mutecsoft.arxml.compare.test;

import java.io.File;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.jface.resource.LocalResourceManager;
import org.eclipse.jface.resource.ResourceManager;
import org.eclipse.jface.viewers.DelegatingStyledCellLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.StyledString;
import org.eclipse.swt.graphics.Image;

class ViewLabelProvider extends LabelProvider implements DelegatingStyledCellLabelProvider.IStyledLabelProvider {
    private ImageDescriptor directoryImage;
    private ResourceManager resourceManager;

    public ViewLabelProvider(ImageDescriptor directoryImage) {
        this.directoryImage = directoryImage;
    }

    @Override
    public StyledString getStyledText(Object element) {
        if(element instanceof File) {
            File file = (File) element;
            StyledString styledString = new StyledString(file.getName());
            String[] files = file.list();
            if (files != null) {
                styledString.append(" (" + files.length + ")", StyledString.COUNTER_STYLER);
            }
            return styledString;
        }
        return null;
    }

    @Override
    public Image getImage(Object element) {
        if(element instanceof File) {
            if(((File) element).isDirectory()) {
                return getResourceManager().createImage(directoryImage);
            }
        }
        return super.getImage(element);
    }

    protected ResourceManager getResourceManager() {
        if (resourceManager == null) {
            resourceManager = new LocalResourceManager(JFaceResources.getResources());
        }
        return resourceManager;
    }
}
