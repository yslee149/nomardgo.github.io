package com.mutecsoft.arxml.compare.db;

import java.sql.Connection;
import java.util.Map;

import com.mutecsoft.arxml.compare.CompareConstant.ProjectDataQueryKey;

public interface DBService {

	Connection getConnection();

	void closeDatabase();

	String getProjectDataQuery(ProjectDataQueryKey queryKey);
	
	Map<String, String> getSqlQueries();
}
