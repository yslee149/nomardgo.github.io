package com.mutecsoft.arxml.compare.test.jxtree;

import org.jdesktop.swingx.JXTreeTable;
import org.jdesktop.swingx.treetable.AbstractTreeTableModel;
import org.jdesktop.swingx.treetable.DefaultMutableTreeTableNode;

import javax.swing.*;
import javax.swing.table.TableCellRenderer;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.TreeCellRenderer;
import javax.swing.tree.TreePath;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

public class CustomJXTreeTable6 {

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
        	
        	try {
				UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
			} catch (ClassNotFoundException | InstantiationException | IllegalAccessException
					| UnsupportedLookAndFeelException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        	
            JFrame frame = new JFrame("Custom JXTreeTable");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(800, 600);

            // Create sample data
            String[] paths = {
                    "/folder1",
                    "/folder1/file1.txt",
                    "/folder1/file2.txt",
                    "/folder1/subfolder1",
                    "/folder1/subfolder1/file1.txt",
                    "/folder1/subfolder1/subsubfolder1",
                    "/folder1/subfolder1/subsubfolder1/file1.txt",
                    "/folder1/subfolder2",
                    "/folder1/subfolder2/file1.txt",
                    "/folder1/subfolder2/yslee-file.txt",
                    "/folder1/subfolder3",
                    "/folder1/subfolder3/file1.txt",
                    "/folder1/subfolder3/file2.txt",
                    "/folder1/subfolder3/subsubfolder3",
                    "/folder1/subfolder3/subsubfolder3/file1.txt"
            };

            // Create root node
            DefaultMutableTreeTableNode root = new DefaultMutableTreeTableNode("Root");
            Map<String, DefaultMutableTreeTableNode> pathMap = new HashMap<>();
            pathMap.put("", root);

            // Build tree structure
            for (String path : paths) {
                String[] parts = path.split("/");
                StringBuilder currentPath = new StringBuilder();
                DefaultMutableTreeTableNode parentNode = root;
                for (String part : parts) {
                    if (part.isEmpty()) continue;
                    currentPath.append("/").append(part);
                    String currentPathStr = currentPath.toString();
                    if (!pathMap.containsKey(currentPathStr)) {
                        DefaultMutableTreeTableNode newNode = new DefaultMutableTreeTableNode(part);
                        pathMap.put(currentPathStr, newNode);
                        parentNode.add(newNode);
                    }
                    parentNode = pathMap.get(currentPathStr);
                }
            }

            // Create JXTreeTable
            JXTreeTable treeTable = new JXTreeTable(new CustomTreeTableModel(root));
            treeTable.setRootVisible(false); // Hide root

            // Hide the first column
            treeTable.getColumnModel().getColumn(0).setMinWidth(0);
            treeTable.getColumnModel().getColumn(0).setMaxWidth(0);
            treeTable.getColumnModel().getColumn(0).setPreferredWidth(0);

            // Set custom renderer for the second column (index 1)
            treeTable.getColumnModel().getColumn(1).setCellRenderer(new CustomTreeCellRenderer(treeTable, 1));
            // Set custom renderer for the fifth column (index 4)
            treeTable.getColumnModel().getColumn(4).setCellRenderer(new CustomTreeCellRenderer(treeTable, 4));
            
            treeTable.expandAll();
//            final DefaultListSelectionModel defaultListSelectionModel = new DefaultListSelectionModel();
//            treeTable.setSelectionModel(defaultListSelectionModel);
            treeTable.setRowHeight(30);
            
            treeTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

            // Add mouse listener to handle expansion
            treeTable.addMouseListener(new java.awt.event.MouseAdapter() {
                @Override
                public void mouseClicked(java.awt.event.MouseEvent e) {
                    int row = treeTable.rowAtPoint(e.getPoint());
                    if (row != -1 && e.getClickCount() == 2) {
                        TreePath path = treeTable.getPathForRow(row);
                        if (treeTable.isExpanded(path)) {
                            treeTable.collapsePath(path);
                        } else {
                            treeTable.expandPath(path);
                        }
                    }
                }
            });

            frame.add(new JScrollPane(treeTable));
            frame.setVisible(true);
        });
    }

    // Custom TreeTableModel
    static class CustomTreeTableModel extends AbstractTreeTableModel {
        private final String[] columnNames = {"Hidden Tree Column", "Column 2 (Indented)", "Column 3", "Column 4", "Column 5 (Indented)", "Column 6", "Column 7"};

        public CustomTreeTableModel(DefaultMutableTreeTableNode root) {
            super(root);
        }

        @Override
        public int getColumnCount() {
            return columnNames.length;
        }

        @Override
        public Object getValueAt(Object node, int column) {
            if (node instanceof DefaultMutableTreeTableNode) {
                return ((DefaultMutableTreeTableNode) node).getUserObject();
            }
            return null;
        }

        @Override
        public String getColumnName(int column) {
            return columnNames[column];
        }

        @Override
        public Object getChild(Object parent, int index) {
            if (parent instanceof DefaultMutableTreeTableNode) {
                return ((DefaultMutableTreeTableNode) parent).getChildAt(index);
            }
            return null;
        }

        @Override
        public int getChildCount(Object parent) {
            if (parent instanceof DefaultMutableTreeTableNode) {
                return ((DefaultMutableTreeTableNode) parent).getChildCount();
            }
            return 0;
        }

        @Override
        public int getIndexOfChild(Object parent, Object child) {
            if (parent instanceof DefaultMutableTreeTableNode && child instanceof DefaultMutableTreeTableNode) {
                return ((DefaultMutableTreeTableNode) parent).getIndex((DefaultMutableTreeTableNode) child);
            }
            return -1;
        }
    }

    // Custom TreeCellRenderer to apply indent to specified columns
    static class CustomTreeCellRenderer extends JPanel implements TableCellRenderer {
        private final JXTreeTable treeTable;
        private final int targetColumn;

        public CustomTreeCellRenderer(JXTreeTable treeTable, int targetColumn) {
            this.treeTable = treeTable;
            this.targetColumn = targetColumn;
            setLayout(new BorderLayout());
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            JTree tree = (JTree) treeTable.getCellRenderer(0, 0); // Get the JTree renderer component from the first column
            TreeCellRenderer delegate = tree.getCellRenderer();

            TreePath path = treeTable.getPathForRow(row);
            int depth = path != null ? path.getPathCount() - 1 : 0;

            // Create a renderer component for the tree
//            Component component = delegate.getTreeCellRendererComponent(tree, value, isSelected, hasFocus, treeTable.isExpanded(path), true, false);
            Component component = delegate.getTreeCellRendererComponent(tree, value, isSelected, hasFocus, treeTable.isExpanded(path), row, false);

            // Customize the component for the specified column
            if (column == targetColumn) {
                removeAll();
                JLabel label = new JLabel(value.toString());
                label.setIcon(((JLabel) component).getIcon());
                label.setPreferredSize(new Dimension(table.getColumnModel().getColumn(column).getWidth(), label.getPreferredSize().height));
                add(label, BorderLayout.CENTER);
                setBorder(BorderFactory.createEmptyBorder(0, 20 * depth, 0, 0)); // Adjust indentation based on path depth

                // Set background and foreground colors for specific rows
                System.out.println("value.toString()  = " + value.toString());
//                if (value.toString().equals("file1.txt")) {
//                    label.setBackground(Color.YELLOW); // Change background color
//                    label.setForeground(Color.RED); // Change text color
////                    label.setOpaque(true); // Ensure background color is painted
//                } else if (isSelected) {
//                    setBackground(table.getSelectionBackground());
//                    label.setForeground(table.getSelectionForeground());
//                } else {
                    setBackground(table.getBackground());
//                    label.setForeground(table.getForeground());
//                }

                setOpaque(true); // Make sure the background is painted

                // Custom icon for non-folder nodes
                if (label instanceof DefaultTreeCellRenderer) {
                    DefaultTreeCellRenderer renderer = (DefaultTreeCellRenderer) label;
                    if (value.toString().contains("folder")) {
                        renderer.setClosedIcon(UIManager.getIcon("FileView.directoryIcon"));
                        renderer.setOpenIcon(UIManager.getIcon("FileView.directoryIcon"));
                    } else {
                        renderer.setLeafIcon(UIManager.getIcon("FileView.fileIcon"));
                    }
                }
            } else {
                component = table.getDefaultRenderer(String.class).getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            }

            return this;
        }
    }
}
