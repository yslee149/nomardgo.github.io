package com.mutecsoft.arxml.compare.db.impl;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Type;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.Platform;
import org.osgi.framework.Bundle;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mutecsoft.arxml.compare.Activator;
import com.mutecsoft.arxml.compare.CompareConstant.ProjectDataQueryKey;
import com.mutecsoft.arxml.compare.db.DBService;
import com.mutecsoft.arxml.compare.util.SimpleLogger;

public class DBServiceImpl implements DBService {

	private Connection connection;
	private Map<String, String> sqlQueries;
	private static final String DATABASE_FILE_PATH = "compare.db";
	private static final String PROJECT_QUERY_PATH = "/resources/sql/project_data_query.json";

	public DBServiceImpl() {
		initializeDatabase();
	}

	public void initializeDatabase() {
		sqlQueries = new HashMap<>();
		loadSQLQueries(PROJECT_QUERY_PATH);

		deleteDB();
		setConnection();

		executeSQL(ProjectDataQueryKey.CREATE_TABLE_PROJECT_DATA.name());
		executeSQL(ProjectDataQueryKey.CREATE_INDEX_PROJECT_ID.name());
		executeSQL(ProjectDataQueryKey.CREATE_INDEX_FILE_PATH.name());
		executeSQL(ProjectDataQueryKey.CREATE_INDEX_PARENT_ID.name());
		executeSQL(ProjectDataQueryKey.DELETE_ALL.name());
	}

	private void setConnection() {
		try {

			Class.forName("org.sqlite.JDBC");
			connection = DriverManager.getConnection("jdbc:sqlite:" + DATABASE_FILE_PATH);
			File dbFile = new File(DATABASE_FILE_PATH);
			SimpleLogger.d("Database file location: " + dbFile.getAbsolutePath());

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

	private void executeSQL(String queryKey) {

		String sql = sqlQueries.get(queryKey);
		if (sql == null) {
			System.err.println("Query not found for key: " + queryKey);
			return;
		}

		try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private void deleteDB() {
		File dbFile = new File(DATABASE_FILE_PATH);
		if (dbFile.exists()) {
			if (dbFile.delete()) {
				SimpleLogger.d("Database file deleted successfully.");
			} else {
				SimpleLogger.d("Failed to delete the database file.");
			}
		}
	}

	private void loadSQLQueries(String filePath) {

		try {
			String content = readFile(filePath);
			Gson gson = new Gson();
			Type type = new TypeToken<Map<String, String>>() {
			}.getType();
			sqlQueries = gson.fromJson(content, type);
		} catch (IOException | URISyntaxException e) {
			e.printStackTrace();
		}

	}

	private String readFile(String filePath) throws IOException, URISyntaxException {
		File jsonFile = getFileFromPlugin(filePath);
		return new String(Files.readAllBytes(jsonFile.toPath()));
	}

	private File getFileFromPlugin(String filePath) throws IOException, URISyntaxException {
		Bundle bundle = Platform.getBundle(Activator.PLUGIN_ID);
		URL fileURL = bundle.getEntry(filePath);
		URL resolvedFileURL = FileLocator.toFileURL(fileURL);
		return new File(resolvedFileURL.toURI());
	}

	@Override
	public Connection getConnection() {
		return connection;
	}

	@Override
	public void closeDatabase() {
		try {
			if (connection != null && !connection.isClosed()) {
				connection.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	@Override
	public String getProjectDataQuery(ProjectDataQueryKey queryKey) {
		return sqlQueries.get(queryKey.name());
	}

	@Override
	public Map<String, String> getSqlQueries() {
		return sqlQueries;
	}

}
