package com.mutecsoft.arxml.compare.test.jxtree;

import org.jdesktop.swingx.JXTreeTable;
import org.jdesktop.swingx.treetable.AbstractTreeTableModel;
import org.jdesktop.swingx.treetable.DefaultMutableTreeTableNode;

import javax.swing.*;
import javax.swing.table.TableCellRenderer;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.TreeCellRenderer;
import javax.swing.tree.TreePath;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CustomJXTreeTable12 {

    static class FolderData {
        String folderPath;
        String name;
        int folderType; // 1 : ���� , 2: ����

        public FolderData(String folderPath, String name, int folderType) {
            this.folderPath = folderPath;
            this.name = name;
            this.folderType = folderType;
        }
    }

    static class CustomMutableTreeTableNode extends DefaultMutableTreeTableNode {
        public CustomMutableTreeTableNode(Object userObject) {
            super(userObject);
        }

        public void removeAllChildren() {
            while (getChildCount() > 0) {
                remove(0);
            }
        }
    }

    static class CustomTreeTableModel extends AbstractTreeTableModel {
        private final String[] columnNames = {"Hidden Tree Column", "Column 2 (Indented)", "Column 3", "Column 4", "Column 5 (Indented)", "Column 6", "Column 7"};

        public CustomTreeTableModel(FolderData rootData) {
            super(convertToNode(rootData));
        }

        private static CustomMutableTreeTableNode convertToNode(FolderData rootData) {
            CustomMutableTreeTableNode rootNode = new CustomMutableTreeTableNode("Root");
            Map<String, CustomMutableTreeTableNode> pathMap = new HashMap<>();
            pathMap.put("", rootNode);

            // Sample data for constructing the tree
            List<FolderData> folderDatas = new ArrayList<>();
            folderDatas.add(new FolderData("/folder1", "", 1));
            folderDatas.add(new FolderData("/folder1/file1.txt", "", 2));
            folderDatas.add(new FolderData("/folder1/file2.txt", "", 2));
            folderDatas.add(new FolderData("/folder1/subfolder1", "", 1));
            folderDatas.add(new FolderData("/folder1/subfolder1/file1.txt", "", 2));
            folderDatas.add(new FolderData("/folder1/subfolder1/subsubfolder1", "", 1));
            folderDatas.add(new FolderData("/folder1/subfolder1/subsubfolder1/file1.txt", "", 2));
            folderDatas.add(new FolderData("/folder1/subfolder2", "", 1));
            folderDatas.add(new FolderData("/folder1/subfolder2/file1.txt", "", 2));
            folderDatas.add(new FolderData("/folder1/subfolder2/yslee-file.txt", "", 2));
            folderDatas.add(new FolderData("/folder1/subfolder3", "", 1));
            folderDatas.add(new FolderData("/folder1/subfolder3/file1.txt", "", 2));
            folderDatas.add(new FolderData("/folder1/subfolder3/file2.txt", "", 2));
            folderDatas.add(new FolderData("/folder1/subfolder3/subsubfolder3", "", 1));
            folderDatas.add(new FolderData("/folder1/subfolder3/subsubfolder3/file1.txt", "", 2));

            // Build tree structure
            for (FolderData folderData : folderDatas) {
                String[] parts = folderData.folderPath.split("/");
                StringBuilder currentPath = new StringBuilder();
                CustomMutableTreeTableNode parentNode = rootNode;
                for (String part : parts) {
                    if (part.isEmpty()) continue;
                    currentPath.append("/").append(part);
                    String currentPathStr = currentPath.toString();
                    if (!pathMap.containsKey(currentPathStr)) {
                        CustomMutableTreeTableNode newNode = new CustomMutableTreeTableNode(part);
                        pathMap.put(currentPathStr, newNode);
                        parentNode.add(newNode);
                    }
                    parentNode = pathMap.get(currentPathStr);
                }
            }

            return rootNode;
        }

        @Override
        public int getColumnCount() {
            return columnNames.length;
        }

        @Override
        public Object getValueAt(Object node, int column) {
            if (node instanceof DefaultMutableTreeTableNode) {
                return ((DefaultMutableTreeTableNode) node).getUserObject();
            }
            return null;
        }

        @Override
        public String getColumnName(int column) {
            return columnNames[column];
        }

        @Override
        public Object getChild(Object parent, int index) {
            if (parent instanceof DefaultMutableTreeTableNode) {
                return ((DefaultMutableTreeTableNode) parent).getChildAt(index);
            }
            return null;
        }

        @Override
        public int getChildCount(Object parent) {
            if (parent instanceof DefaultMutableTreeTableNode) {
                return ((DefaultMutableTreeTableNode) parent).getChildCount();
            }
            return 0;
        }

        @Override
        public int getIndexOfChild(Object parent, Object child) {
            if (parent instanceof DefaultMutableTreeTableNode && child instanceof DefaultMutableTreeTableNode) {
                return ((DefaultMutableTreeTableNode) parent).getIndex((DefaultMutableTreeTableNode) child);
            }
            return -1;
        }

        public void reload() {
            modelSupport.fireNewRoot();
        }
    }

    static class CustomTreeCellRenderer extends JPanel implements TableCellRenderer {
        private final JXTreeTable treeTable;
        private final int targetColumn;

        public CustomTreeCellRenderer(JXTreeTable treeTable, int targetColumn) {
            this.treeTable = treeTable;
            this.targetColumn = targetColumn;
            setLayout(new BorderLayout());
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            JTree tree = (JTree) treeTable.getCellRenderer(0, 0); // Get the JTree renderer component from the first column
            TreeCellRenderer delegate = tree.getCellRenderer();

            TreePath path = treeTable.getPathForRow(row);
            int depth = path != null ? path.getPathCount() - 1 : 0;

            Component component = delegate.getTreeCellRendererComponent(tree, value, isSelected, hasFocus, treeTable.isExpanded(path), row, false);

            if (column == targetColumn) {
                removeAll();
                JLabel label = new JLabel(value.toString());
                label.setIcon(((JLabel) component).getIcon());
                label.setPreferredSize(new Dimension(table.getColumnModel().getColumn(column).getWidth(), label.getPreferredSize().height));
                add(label, BorderLayout.CENTER);
                setBorder(BorderFactory.createEmptyBorder(0, 20 * depth, 0, 0));

                if (isSelected) {
                    setBackground(table.getSelectionBackground());
                    label.setForeground(table.getSelectionForeground());
                } else {
                    setBackground(Color.WHITE);
                }

                if (label instanceof DefaultTreeCellRenderer) {
                    DefaultTreeCellRenderer renderer = (DefaultTreeCellRenderer) label;
                    if (value.toString().contains("folder")) {
                        renderer.setClosedIcon(UIManager.getIcon("FileView.directoryIcon"));
                        renderer.setOpenIcon(UIManager.getIcon("FileView.directoryIcon"));
                    } else {
                        renderer.setLeafIcon(UIManager.getIcon("FileView.fileIcon"));
                    }

                }
            } else {
                component = table.getDefaultRenderer(String.class).getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            }

            return this;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {

            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (ClassNotFoundException | InstantiationException | IllegalAccessException
                    | UnsupportedLookAndFeelException e1) {
                e1.printStackTrace();
            }

            JFrame frame = new JFrame("Custom JXTreeTable");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(800, 600);

            // Create a panel for the button
            JPanel panel = new JPanel();
            panel.setLayout(new BorderLayout());

            // Create the button
            JButton button = new JButton("Update Data");
            button.setPreferredSize(new Dimension(frame.getWidth(), 40));
            panel.add(button, BorderLayout.NORTH);

            // Create sample data
            FolderData rootData = new FolderData("", "Root", 1);

            // Create JXTreeTable
            CustomTreeTableModel treeTableModel = new CustomTreeTableModel(rootData);
            JXTreeTable treeTable = new JXTreeTable(treeTableModel);
            treeTable.setRootVisible(false); // Hide root

            // Hide the first column
            treeTable.getColumnModel().getColumn(0).setMinWidth(0);
            treeTable.getColumnModel().getColumn(0).setMaxWidth(0);
            treeTable.getColumnModel().getColumn(0).setPreferredWidth(0);

            // Set custom renderer for the second column (index 1)
            treeTable.getColumnModel().getColumn(1).setCellRenderer(new CustomTreeCellRenderer(treeTable, 1));
            treeTable.getColumnModel().getColumn(4).setCellRenderer(new CustomTreeCellRenderer(treeTable, 4));

            treeTable.expandAll();
            treeTable.setRowHeight(40);

            treeTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

            treeTable.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    int row = treeTable.rowAtPoint(e.getPoint());
                    int column = treeTable.columnAtPoint(e.getPoint());

                    if (row != -1 && column != -1) {
                        String columnName = treeTable.getColumnName(column);
                        Object cellValue = treeTable.getValueAt(row, column);
                        System.out.println("Clicked Column: " + columnName + ", Value: " + cellValue);
                    }

                    if (row != -1 && e.getClickCount() == 2) {
                        TreePath path = treeTable.getPathForRow(row);
                        if (treeTable.isExpanded(path)) {
                            treeTable.collapsePath(path);
                        } else {
                            treeTable.expandPath(path);
                        }
                    }
                }
            });

            // Add button action listener to update data
            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Create new sample data
                    List<FolderData> newFolderDatas = new ArrayList<>();
                    newFolderDatas.add(new FolderData("/newFolder1", "", 1));
                    newFolderDatas.add(new FolderData("/newFolder1/newFile1.txt", "", 2));
                    newFolderDatas.add(new FolderData("/newFolder1/newFile2.txt", "", 2));
                    newFolderDatas.add(new FolderData("/newFolder1/newSubfolder1", "", 1));
                    newFolderDatas.add(new FolderData("/newFolder1/newSubfolder1/newFile1.txt", "", 2));
                    newFolderDatas.add(new FolderData("/newFolder2", "", 1));
                    newFolderDatas.add(new FolderData("/newFolder2/newFile1.txt", "", 2));

                    // Clear existing nodes
                    CustomMutableTreeTableNode root = (CustomMutableTreeTableNode) treeTableModel.getRoot();
                    while (root.getChildCount() > 0) {
                        root.remove(0);
                    }
                    Map<String, CustomMutableTreeTableNode> pathMap = new HashMap<>();
                    pathMap.put("", root);

                    // Build new tree structure
                    for (FolderData folderData : newFolderDatas) {
                        String[] parts = folderData.folderPath.split("/");
                        StringBuilder currentPath = new StringBuilder();
                        CustomMutableTreeTableNode parentNode = root;
                        for (String part : parts) {
                            if (part.isEmpty()) continue;
                            currentPath.append("/").append(part);
                            String currentPathStr = currentPath.toString();
                            if (!pathMap.containsKey(currentPathStr)) {
                                CustomMutableTreeTableNode newNode = new CustomMutableTreeTableNode(part);
                                pathMap.put(currentPathStr, newNode);
                                parentNode.add(newNode);
                            }
                            parentNode = pathMap.get(currentPathStr);
                        }
                    }

                    // Notify model about the data change
                    treeTableModel.reload();
                    treeTable.expandAll();
                }
            });

            // Add components to the frame
            panel.add(new JScrollPane(treeTable), BorderLayout.CENTER);
            frame.add(panel);
            frame.setVisible(true);
        });
    }
}
