package com.mutecsoft.arxml.compare.view.impl.project;

import java.util.List;

import org.eclipse.swt.widgets.Display;

import com.mutecsoft.arxml.compare.model.ProjectCompareData;
import com.mutecsoft.arxml.compare.util.DialogUtil;
import com.mutecsoft.arxml.compare.view.ProjectTreeView;
import com.mutecsoft.arxml.compare.view.impl.BaseViewImpl;

public class ProjectTreeViewImpl extends BaseViewImpl implements ProjectTreeView {

	private ViewPart viewPart;
	private TreeTable projectTree;
	private List<ProjectCompareData> projectsDatas;

	public ProjectTreeViewImpl(Display display) {
		super(display);
		viewPart = new ViewPart(this);
		projectTree = new TreeTable(this);
	}

	@Override
	public void displayComparisonResult(List<ProjectCompareData> projectsDatas) {
		this.projectsDatas = projectsDatas;
	}

	@Override
	public void showView() {

		projectTree.crate();

		super.open();
	}

	@Override
	public void showError(String message) {

		DialogUtil.showWarning(getShell(), message);

	}

	@Override
	public void showFileSelection() {

	}

	public ViewPart getViewPart() {
		return viewPart;
	}

	public List<ProjectCompareData> getProjectsDatas() {
		return projectsDatas;
	}

}
