package com.mutecsoft.arxml.compare;

public class CompareConstant {

	public enum ProjectType {
		ORIGIN(1), TARGET(2);
		int code;

		ProjectType(int code) {
			this.code = code;
		}

		public int getCode() {
			return code;
		}
	}

	public enum FileType {
		PROJECT(0), FOLDER(1), FILE(2);

		int code;

		FileType(int code) {
			this.code = code;
		}

		public int getCode() {
			return code;
		}
	}

	public enum FixedExtension {
		ARXML, BMD, TXT
	}

	public enum CompareType {
		SAME(0), DIFFERENT(1), ONLY_IN_TREE1(2), ONLY_IN_TREE2(3);

		int code;

		CompareType(int code) {
			this.code = code;
		}

		public int getCode() {
			return code;
		}

	}

	public enum ProjectDataQueryKey {
		CREATE_TABLE_PROJECT_DATA, CREATE_INDEX_PROJECT_ID, CREATE_INDEX_FILE_PATH, CREATE_INDEX_PARENT_ID, DELETE_ALL,
		DELETE_ONE, UPDATE_COMPARE_RESULT, INSERT_DATA, SELECT_COMPARE_ALL, SELECT_COMPARE_DIFFERENT,
		SELECT_COMPARE_SAME, SELECT_NORMAL, UPDATE_PARENT_TREE_STATUS, SELECT_PARENT_TREE
	}

	public enum ScreenSize {
		FULL_SCREEN(1.0), HALF_SCREEN(0.5), THIRD_SCREEN(1.0 / 3.0), QUARTER_SCREEN(0.25), EIGHTY_PERCENT_SCREEN(0.8),
		SEVEN_PERCENT_SCREEN(0.7);

		private final double ratio;

		ScreenSize(double ratio) {
			this.ratio = ratio;
		}

		public double getRatio() {
			return ratio;
		}
	}

}
