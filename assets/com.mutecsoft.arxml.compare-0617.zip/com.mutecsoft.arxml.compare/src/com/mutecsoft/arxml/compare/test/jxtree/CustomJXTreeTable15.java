package com.mutecsoft.arxml.compare.test.jxtree;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTree;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.table.TableCellRenderer;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.TreeCellRenderer;
import javax.swing.tree.TreePath;

import org.jdesktop.swingx.JXTreeTable;
import org.jdesktop.swingx.treetable.AbstractTreeTableModel;
import org.jdesktop.swingx.treetable.DefaultMutableTreeTableNode;

public class CustomJXTreeTable15{

    static class ProjectData {
        int id;
        int project_id;
        int parent_id;
        String file_name;
        String file_path;
        String file_full_path;
        int file_type;
        String file_date;
        int compare_result;
        int version;

        public ProjectData(int id, int project_id, int parent_id, String file_name, String file_path, String file_full_path, int file_type, String file_date, int compare_result, int version) {
            this.id = id;
            this.project_id = project_id;
            this.parent_id = parent_id;
            this.file_name = file_name;
            this.file_path = file_path;
            this.file_full_path = file_full_path;
            this.file_type = file_type;
            this.file_date = file_date;
            this.compare_result = compare_result;
            this.version = version;
        }

        public int getId() {
            return id;
        }

        public int getProjectId() {
            return project_id;
        }

        public int getParentId() {
            return parent_id;
        }

        public String getFileName() {
            return file_name;
        }

        public String getFilePath() {
            return file_path;
        }

        public String getFileFullPath() {
            return file_full_path;
        }

        public int getFileType() {
            return file_type;
        }

        public String getFileDate() {
            return file_date;
        }

        public int getCompareResult() {
            return compare_result;
        }

        public int getVersion() {
            return version;
        }
    }

    static class ProjectCompareData {
        private ProjectData projectData1;
        private ProjectData projectData2;

        public ProjectCompareData(ProjectData projectData1, ProjectData projectData2) {
            this.projectData1 = projectData1;
            this.projectData2 = projectData2;
        }

        public ProjectData getProjectData1() {
            return projectData1;
        }

        public ProjectData getProjectData2() {
            return projectData2;
        }
    }

    static class CustomMutableTreeTableNode extends DefaultMutableTreeTableNode {
        public CustomMutableTreeTableNode(Object userObject) {
            super(userObject);
        }

        public void removeAllChildren() {
            while (getChildCount() > 0) {
                remove(0);
            }
        }
    }

    static class CustomTreeTableModel extends AbstractTreeTableModel {
        private final String[] columnNames = {"Hidden Tree Column", "Name 1", "Type 1", "Date 1", "Compare Result", "Name 2", "Type 2", "Date 2"};

        public CustomTreeTableModel(List<ProjectCompareData> projectCompareDataList) {
            super(convertToNode(projectCompareDataList));
        }

        private static CustomMutableTreeTableNode convertToNode(List<ProjectCompareData> projectCompareDataList) {
            CustomMutableTreeTableNode rootNode = new CustomMutableTreeTableNode("Root");
            Map<Integer, CustomMutableTreeTableNode> nodeMap = new HashMap<>();
            nodeMap.put(0, rootNode);

            // Step 1: Create all nodes and add to nodeMap
            for (ProjectCompareData compareData : projectCompareDataList) {
                ProjectData data1 = compareData.getProjectData1();
                CustomMutableTreeTableNode newNode = new CustomMutableTreeTableNode(compareData);
                nodeMap.put(data1.getId(), newNode);
            }

            // Step 2: Add all nodes to their parent nodes
            for (ProjectCompareData compareData : projectCompareDataList) {
                ProjectData data1 = compareData.getProjectData1();
                int parentId = data1.getParentId();

                CustomMutableTreeTableNode parentNode = nodeMap.get(parentId);
                CustomMutableTreeTableNode newNode = nodeMap.get(data1.getId());

                if (parentNode != null) {
                    parentNode.add(newNode);
                    System.out.println("Added node: " + data1.getFileName() + " to parent: " + parentId);
                } else {
                    System.out.println("Parent node not found for: " + data1.getFileName());
                }
            }

            // Add top-level nodes to root node if they are not already added
            for (Map.Entry<Integer, CustomMutableTreeTableNode> entry : nodeMap.entrySet()) {
                CustomMutableTreeTableNode node = entry.getValue();
                if (node.getParent() == null && node != rootNode) {
                    rootNode.add(node);
                }
            }

            System.out.println("Root node child count: " + rootNode.getChildCount());
            return rootNode;
        }


        @Override
        public int getColumnCount() {
            return columnNames.length;
        }

        @Override
        public Object getValueAt(Object node, int column) {
        	System.out.println("#######################");
            if (node instanceof CustomMutableTreeTableNode) {
                Object userObject = ((CustomMutableTreeTableNode) node).getUserObject();
                if (userObject instanceof ProjectCompareData) {
                    ProjectCompareData data = (ProjectCompareData) userObject;
                    ProjectData data1 = data.getProjectData1();
                    ProjectData data2 = data.getProjectData2();

                    switch (column) {
                        case 0:
                            return data1.getFilePath();
                        case 1:
                            return data1.getFileName();
                        case 2:
                            return data1.getFileType() == 1 ? "Folder" : "File";
                        case 3:
                            return data1.getFileDate();
                        case 4:
                            return data1.getCompareResult();
                        case 5:
                            return data2 != null ? data2.getFileName() : "";
                        case 6:
                            return data2 != null ? (data2.getFileType() == 1 ? "Folder" : "File") : "";
                        case 7:
                            return data2 != null ? data2.getFileDate() : "";
                        default:
                            return null;
                    }
                }
            }
            return null;
        }

        @Override
        public String getColumnName(int column) {
            return columnNames[column];
        }

        @Override
        public Object getChild(Object parent, int index) {
            if (parent instanceof DefaultMutableTreeTableNode) {
                return ((DefaultMutableTreeTableNode) parent).getChildAt(index);
            }
            return null;
        }

        @Override
        public int getChildCount(Object parent) {
            if (parent instanceof DefaultMutableTreeTableNode) {
                return ((DefaultMutableTreeTableNode) parent).getChildCount();
            }
            return 0;
        }

        @Override
        public int getIndexOfChild(Object parent, Object child) {
            if (parent instanceof DefaultMutableTreeTableNode && child instanceof DefaultMutableTreeTableNode) {
                return ((DefaultMutableTreeTableNode) parent).getIndex((DefaultMutableTreeTableNode) child);
            }
            return -1;
        }

        public void reload() {
            modelSupport.fireNewRoot();
        }
    }

    static class CustomTreeCellRenderer extends JPanel implements TableCellRenderer {
        private final JXTreeTable treeTable;
        private final int targetColumn;

        public CustomTreeCellRenderer(JXTreeTable treeTable, int targetColumn) {
            this.treeTable = treeTable;
            this.targetColumn = targetColumn;
            setLayout(new BorderLayout());
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            JTree tree = (JTree) treeTable.getCellRenderer(0, 0); // Get the JTree renderer component from the first column
            TreeCellRenderer delegate = tree.getCellRenderer();

            TreePath path = treeTable.getPathForRow(row);
            int depth = path != null ? path.getPathCount() - 1 : 0;

            Component component = delegate.getTreeCellRendererComponent(tree, value, isSelected, hasFocus, treeTable.isExpanded(path), row, false);

            if (column == targetColumn) {
                removeAll();
//                JLabel label = new JLabel(value.toString());
                String text = value != null ? value.toString() : "";
                JLabel label = new JLabel(text);
                
                label.setIcon(((JLabel) component).getIcon());
                label.setPreferredSize(new Dimension(table.getColumnModel().getColumn(column).getWidth(), label.getPreferredSize().height));
                add(label, BorderLayout.CENTER);
                setBorder(BorderFactory.createEmptyBorder(0, 20 * depth, 0, 0));

                if (isSelected) {
                    setBackground(table.getSelectionBackground());
                    label.setForeground(table.getSelectionForeground());
                } else {
                    setBackground(Color.WHITE);
                }

                if (label instanceof DefaultTreeCellRenderer) {
                    DefaultTreeCellRenderer renderer = (DefaultTreeCellRenderer) label;
                    if (value.toString().contains("folder")) {
                        renderer.setClosedIcon(UIManager.getIcon("FileView.directoryIcon"));
                        renderer.setOpenIcon(UIManager.getIcon("FileView.directoryIcon"));
                    } else {
                        renderer.setLeafIcon(UIManager.getIcon("FileView.fileIcon"));
                    }

                }
            } else {
                component = table.getDefaultRenderer(String.class).getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            }

            return this;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {

            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (ClassNotFoundException | InstantiationException | IllegalAccessException
                    | UnsupportedLookAndFeelException e1) {
                e1.printStackTrace();
            }

            JFrame frame = new JFrame("Custom JXTreeTable");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(800, 600);

            // Create a panel for the button
            JPanel panel = new JPanel();
            panel.setLayout(new BorderLayout());

            // Create the button
            JButton button = new JButton("Update Data");
            button.setPreferredSize(new Dimension(frame.getWidth(), 40));
            panel.add(button, BorderLayout.NORTH);

            // Create sample data
            // Create sample data
            List<ProjectCompareData> projectCompareDataList = new ArrayList<>();
            projectCompareDataList.add(new ProjectCompareData(
                    new ProjectData(2, 1, 1, "folder1", "/folder1", "/Comp1/folder1", 1, "", 0, 0),
                    new ProjectData(2, 1, 1, "folder1", "/folder1", "/Comp1/folder1", 1, "", 0, 0)
            ));
            projectCompareDataList.add(new ProjectCompareData(
                    new ProjectData(3, 1, 2, "file1.txt", "/folder1/file1.txt", "/Comp1/folder1/file1.txt", 2, "2024-06-12T14:33:24.111538", 0, 0),
                    new ProjectData(3, 1, 2, "file1.txt", "/folder1/file1.txt", "/Comp1/folder1/file1.txt", 2, "2024-06-12T14:33:24.111538", 0, 0)
            ));
            projectCompareDataList.add(new ProjectCompareData(
                    new ProjectData(4, 1, 2, "file2.txt", "/folder1/file2.txt", "/Comp1/folder1/file2.txt", 2, "2024-06-12T14:33:24.112769", 0, 0),
                    new ProjectData(4, 1, 2, "file2.txt", "/folder1/file2.txt", "/Comp1/folder1/file2.txt", 2, "2024-06-12T14:33:24.112769", 0, 0)
            ));
            projectCompareDataList.add(new ProjectCompareData(
                    new ProjectData(5, 1, 2, "subfoler1", "/folder1/subfoler1", "/Comp1/folder1/subfoler1", 1, "", 0, 0),
                    new ProjectData(5, 1, 2, "subfoler1", "/folder1/subfoler1", "/Comp1/folder1/subfoler1", 1, "", 0, 0)
            ));
            projectCompareDataList.add(new ProjectCompareData(
                    new ProjectData(6, 1, 5, "file1.txt", "/folder1/subfoler1/file1.txt", "/Comp1/folder1/subfoler1/file1.txt", 2, "2024-06-12T14:33:24.113871", 0, 0),
                    new ProjectData(6, 1, 5, "file1.txt", "/folder1/subfoler1/file1.txt", "/Comp1/folder1/subfoler1/file1.txt", 2, "2024-06-12T14:33:24.113871", 0, 0)
            ));
            projectCompareDataList.add(new ProjectCompareData(
                    new ProjectData(7, 1, 5, "subsubfolder1", "/folder1/subfoler1/subsubfolder1", "/Comp1/folder1/subfoler1/subsubfolder1", 1, "", 0, 0),
                    new ProjectData(7, 1, 5, "subsubfolder1", "/folder1/subfoler1/subsubfolder1", "/Comp1/folder1/subfoler1/subsubfolder1", 1, "", 0, 0)
            ));
            projectCompareDataList.add(new ProjectCompareData(
                    new ProjectData(8, 1, 7, "file1.txt", "/folder1/subfoler1/subsubfolder1/file1.txt", "/Comp1/folder1/subfoler1/subsubfolder1/file1.txt", 2, "2024-06-12T14:33:24.115219", 0, 0),
                    new ProjectData(8, 1, 7, "file1.txt", "/folder1/subfoler1/subsubfolder1/file1.txt", "/Comp1/folder1/subfoler1/subsubfolder1/file1.txt", 2, "2024-06-12T14:33:24.115219", 0, 0)
            ));
            projectCompareDataList.add(new ProjectCompareData(
                    new ProjectData(9, 1, 2, "subfoler2", "/folder1/subfoler2", "/Comp1/folder1/subfoler2", 1, "", 0, 0),
                    new ProjectData(9, 1, 2, "subfoler2", "/folder1/subfoler2", "/Comp1/folder1/subfoler2", 1, "", 0, 0)
            ));
            projectCompareDataList.add(new ProjectCompareData(
                    new ProjectData(10, 1, 9, "file1.txt", "/folder1/subfoler2/file1.txt", "/Comp1/folder1/subfoler2/file1.txt", 2, "2024-06-12T14:33:24.116598", 0, 0),
                    new ProjectData(10, 1, 9, "file1.txt", "/folder1/subfoler2/file1.txt", "/Comp1/folder1/subfoler2/file1.txt", 2, "2024-06-12T14:33:24.116598", 0, 0)
            ));
            projectCompareDataList.add(new ProjectCompareData(
                    new ProjectData(11, 1, 9, "yslee-file.txt", "/folder1/subfoler2/yslee-file.txt", "/Comp1/folder1/subfoler2/yslee-file.txt", 2, "2024-06-12T14:37:06.714363", 2, 0),
                    new ProjectData(11, 1, 9, "yslee-file.txt", "/folder1/subfoler2/yslee-file.txt", "/Comp1/folder1/subfoler2/yslee-file.txt", 2, "2024-06-12T14:37:06.714363", 2, 0)
            ));
            projectCompareDataList.add(new ProjectCompareData(
                    new ProjectData(12, 1, 2, "subfoler3", "/folder1/subfoler3", "/Comp1/folder1/subfoler3", 1, "", 2, 0),
                    new ProjectData(12, 1, 2, "subfoler3", "/folder1/subfoler3", "/Comp1/folder1/subfoler3", 1, "", 2, 0)
            ));
            projectCompareDataList.add(new ProjectCompareData(
                    new ProjectData(13, 1, 12, "file1.txt", "/folder1/subfoler3/file1.txt", "/Comp1/folder1/subfoler3/file1.txt", 2, "2024-06-12T14:33:24.128906", 2, 0),
                    new ProjectData(13, 1, 12, "file1.txt", "/folder1/subfoler3/file1.txt", "/Comp1/folder1/subfoler3/file1.txt", 2, "2024-06-12T14:33:24.128906", 2, 0)
            ));
            projectCompareDataList.add(new ProjectCompareData(
                    new ProjectData(14, 1, 12, "file2.txt", "/folder1/subfoler3/file2.txt", "/Comp1/folder1/subfoler3/file2.txt", 2, "2024-06-12T14:33:24.128906", 2, 0),
                    new ProjectData(14, 1, 12, "file2.txt", "/folder1/subfoler3/file2.txt", "/Comp1/folder1/subfoler3/file2.txt", 2, "2024-06-12T14:33:24.128906", 2, 0)
            ));
            projectCompareDataList.add(new ProjectCompareData(
                    new ProjectData(15, 1, 12, "subsubfolder3", "/folder1/subfoler3/subsubfolder3", "/Comp1/folder1/subfoler3/subsubfolder3", 1, "", 2, 0),
                    new ProjectData(15, 1, 12, "subsubfolder3", "/folder1/subfoler3/subsubfolder3", "/Comp1/folder1/subfoler3/subsubfolder3", 1, "", 2, 0)
            ));
            projectCompareDataList.add(new ProjectCompareData(
                    new ProjectData(16, 1, 15, "file1.txt", "/folder1/subfoler3/subsubfolder3/file1.txt", "/Comp1/folder1/subfoler3/subsubfolder3/file1.txt", 2, "2024-06-12T14:33:24.129906", 2, 0),
                    new ProjectData(16, 1, 15, "file1.txt", "/folder1/subfoler3/subsubfolder3/file1.txt", "/Comp1/folder1/subsubfolder3/file1.txt", 2, "2024-06-12T14:33:24.129906", 2, 0)
            ));
            projectCompareDataList.add(new ProjectCompareData(
                    new ProjectData(23, 2, 21, "file2.txt", "/folder1/subfoler1/file2.txt", "/Comp2/folder1/subfoler1/file2.txt", 2, "2024-06-12T14:33:29.178521", 3, 0),
                    new ProjectData(23, 2, 21, "file2.txt", "/folder1/subfoler1/file2.txt", "/Comp2/folder1/subfoler1/file2.txt", 2, "2024-06-12T14:33:29.178521", 3, 0)
            ));
            projectCompareDataList.add(new ProjectCompareData(
                    new ProjectData(28, 2, 18, "subfoler4", "/folder1/subfoler4", "/Comp2/folder1/subfoler4", 1, "", 3, 0),
                    new ProjectData(28, 2, 18, "subfoler4", "/folder1/subfoler4", "/Comp2/folder1/subfoler4", 1, "", 3, 0)
            ));
            projectCompareDataList.add(new ProjectCompareData(
                    new ProjectData(29, 2, 28, "file1.txt", "/folder1/subfoler4/file1.txt", "/Comp2/folder1/subfoler4/file1.txt", 2, "2024-06-12T14:33:29.193844", 3, 0),
                    new ProjectData(29, 2, 28, "file1.txt", "/folder1/subfoler4/file1.txt", "/Comp2/folder1/subfoler4/file1.txt", 2, "2024-06-12T14:33:29.193844", 3, 0)
            ));
            projectCompareDataList.add(new ProjectCompareData(
                    new ProjectData(30, 2, 17, "folder2", "/folder2", "/Comp2/folder2", 1, "", 3, 0),
                    new ProjectData(30, 2, 17, "folder2", "/folder2", "/Comp2/folder2", 1, "", 3, 0)
            ));
            projectCompareDataList.add(new ProjectCompareData(
                    new ProjectData(31, 2, 30, "file1.txt", "/folder2/file1.txt", "/Comp2/folder2/file1.txt", 2, "2024-06-12T15:05:25.129532", 3, 0),
                    new ProjectData(31, 2, 30, "file1.txt", "/folder2/file1.txt", "/Comp2/folder2/file1.txt", 2, "2024-06-12T15:05:25.129532", 3, 0)
            ));
            projectCompareDataList.add(new ProjectCompareData(
                    new ProjectData(32, 2, 30, "subfoler1", "/folder2/subfoler1", "/Comp2/folder2/subfoler1", 1, "", 3, 0),
                    new ProjectData(32, 2, 30, "subfoler1", "/folder2/subfoler1", "/Comp2/folder2/subfoler1", 1, "", 3, 0)
            ));
            projectCompareDataList.add(new ProjectCompareData(
                    new ProjectData(33, 2, 32, "file1.txt", "/folder2/subfoler1/file1.txt", "/Comp2/folder2/subfoler1/file1.txt", 2, "2024-06-12T15:05:25.140742", 3, 0),
                    new ProjectData(33, 2, 32, "file1.txt", "/folder2/subfoler1/file1.txt", "/Comp2/folder2/subfoler1/file1.txt", 2, "2024-06-12T15:05:25.140742", 3, 0)
            ));
            // Add more sample data...

            // Create JXTreeTable
            CustomTreeTableModel treeTableModel = new CustomTreeTableModel(projectCompareDataList);
            JXTreeTable treeTable = new JXTreeTable(treeTableModel);
            treeTable.setRootVisible(false); // Hide root

            // Hide the first column
            treeTable.getColumnModel().getColumn(0).setMinWidth(0);
            treeTable.getColumnModel().getColumn(0).setMaxWidth(0);
            treeTable.getColumnModel().getColumn(0).setPreferredWidth(0);

            // Set custom renderer for the second column (index 1)
            treeTable.getColumnModel().getColumn(1).setCellRenderer(new CustomTreeCellRenderer(treeTable, 1));
            treeTable.getColumnModel().getColumn(5).setCellRenderer(new CustomTreeCellRenderer(treeTable, 5));

//            treeTable.expandAll();
            treeTable.setRowHeight(40);

            treeTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

            treeTable.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    int row = treeTable.rowAtPoint(e.getPoint());
                    int column = treeTable.columnAtPoint(e.getPoint());

                    if (row != -1 && column != -1) {
                        String columnName = treeTable.getColumnName(column);
                        Object cellValue = treeTable.getValueAt(row, column);
                        System.out.println("Clicked Column: " + columnName + ", Value: " + cellValue);
                    }

                    if (row != -1 && e.getClickCount() == 2) {
                        TreePath path = treeTable.getPathForRow(row);
                        if (treeTable.isExpanded(path)) {
                            treeTable.collapsePath(path);
                        } else {
                            treeTable.expandPath(path);
                        }
                    }
                }
            });

            // Add button action listener to update data
            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Create new sample data
                    List<ProjectCompareData> newProjectCompareDataList = new ArrayList<>();
                    ProjectData newProjectData1 = new ProjectData(3, 1, 0, "newFolder1", "/newFolder1", "/newFolder1", 1, "2024-01-01", 0, 1);
                    ProjectData newProjectData2 = new ProjectData(4, 1, 3, "newFile1.txt", "/newFolder1/newFile1.txt", "/newFolder1/newFile1.txt", 2, "2024-01-02", 0, 1);
                    newProjectCompareDataList.add(new ProjectCompareData(newProjectData1, newProjectData2));
                    // Add more new sample data...

                    // Clear existing nodes
                    CustomMutableTreeTableNode root = (CustomMutableTreeTableNode) treeTableModel.getRoot();
                    while (root.getChildCount() > 0) {
                        root.remove(0);
                    }
                    Map<Integer, CustomMutableTreeTableNode> nodeMap = new HashMap<>();
                    nodeMap.put(0, root);

                    // Build new tree structure
                    for (ProjectCompareData compareData : newProjectCompareDataList) {
                        ProjectData data1 = compareData.getProjectData1();
                        CustomMutableTreeTableNode newNode = new CustomMutableTreeTableNode(compareData);
                        nodeMap.put(data1.getId(), newNode);

                        CustomMutableTreeTableNode parentNode = nodeMap.get(data1.getParentId());
                        if (parentNode != null) {
                            parentNode.add(newNode);
                        }
                    }

                    // Notify model about the data change
                    treeTableModel.reload();
                    treeTable.expandAll();
                }
            });

            // Add components to the frame
            panel.add(new JScrollPane(treeTable), BorderLayout.CENTER);
            frame.add(panel);
            frame.setVisible(true);
        });
    }
}
