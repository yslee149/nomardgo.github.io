package com.mutecsoft.arxml.compare.test.treeviewer;

import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.TreeViewerColumn;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerCell;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeColumn;
import org.eclipse.swt.widgets.TreeItem;

public class TreeViewerExample {

    public static void main(String[] args) {
        Display display = new Display();
        Shell shell = new Shell(display);
        shell.setText("JFace TreeViewer Example");
        shell.setLayout(new FillLayout());

        TreeViewer treeViewer = new TreeViewer(shell, SWT.BORDER | SWT.FULL_SELECTION);
        Tree tree = treeViewer.getTree();
        tree.setHeaderVisible(true);
        tree.setLinesVisible(true);

        // Define columns using TreeViewerColumn
        String[] columnTitles = {"Column 1", "Column 2", "Column 3"};
        for (int i = 0; i < columnTitles.length; i++) {
            TreeViewerColumn viewerColumn = new TreeViewerColumn(treeViewer, SWT.NONE);
            TreeColumn column = viewerColumn.getColumn();
            column.setText(columnTitles[i]);
            column.setWidth(100);
            viewerColumn.setLabelProvider(new MyTreeLabelProvider(i));
        }

        // Set content provider
        treeViewer.setContentProvider(new MyTreeContentProvider());

        // Set input data
        treeViewer.setInput(createSampleData());

        // Add paint listener to change selection background color
        tree.addListener(SWT.EraseItem, new Listener() {
            @Override
            public void handleEvent(Event event) {
                event.detail &= ~SWT.SELECTED;
            }
        });

        tree.addListener(SWT.PaintItem, new Listener() {
            @Override
            public void handleEvent(Event event) {
                TreeItem item = (TreeItem) event.item;
                if ((event.detail & SWT.SELECTED) != 0) {
                    GC gc = event.gc;
                    Color background = item.getDisplay().getSystemColor(SWT.COLOR_LIST_BACKGROUND);
                    Color selectedColor = new Color(display, 0, 255, 0, 128); // Green with 50% transparency
                    gc.setBackground(mixColors(gc, background, selectedColor, 0.5f));
                    Rectangle bounds = item.getBounds(event.index);
                    gc.fillRectangle(bounds);
                    event.detail &= ~SWT.SELECTED;
                    selectedColor.dispose(); // Dispose the color to avoid resource leaks
                }
            }
        });

        shell.setSize(400, 300);
        shell.open();

        while (!shell.isDisposed()) {
            if (!display.readAndDispatch()) {
                display.sleep();
            }
        }
        display.dispose();
    }

    // Sample data model class
    static class MyModel {
        String column1;
        String column2;
        String column3;
        MyModel[] children;

        MyModel(String column1, String column2, String column3, MyModel[] children) {
            this.column1 = column1;
            this.column2 = column2;
            this.column3 = column3;
            this.children = children;
        }

        MyModel(String column1, String column2, String column3) {
            this(column1, column2, column3, new MyModel[0]);
        }

        boolean hasChildren() {
            return children != null && children.length > 0;
        }
    }

    // Sample data creation
    private static MyModel[] createSampleData() {
        MyModel child1 = new MyModel("Child 1-1", "Child 1-2", "Child 1-3");
        MyModel child2 = new MyModel("Child 2-1", "Child 2-2", "Child 2-3");
        MyModel root1 = new MyModel("Root 1-1", "Root 1-2", "Root 1-3", new MyModel[] { child1 });
        MyModel root2 = new MyModel("Root 2-1", "Root 2-2", "Root 2-3", new MyModel[] { child2 });
        return new MyModel[] { root1, root2 };
    }

    // Content provider class
    static class MyTreeContentProvider implements ITreeContentProvider {

        @Override
        public Object[] getElements(Object inputElement) {
            return (MyModel[]) inputElement;
        }

        @Override
        public Object[] getChildren(Object parentElement) {
            return ((MyModel) parentElement).children;
        }

        @Override
        public Object getParent(Object element) {
            return null; // Not needed in this example
        }

        @Override
        public boolean hasChildren(Object element) {
            return ((MyModel) element).hasChildren();
        }

        @Override
        public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
            // Do nothing
        }

        @Override
        public void dispose() {
            // Do nothing
        }
    }

    // Label provider class with background color for the second column
    static class MyTreeLabelProvider extends ColumnLabelProvider {
        private int columnIndex;

        public MyTreeLabelProvider(int columnIndex) {
            this.columnIndex = columnIndex;
        }

        @Override
        public String getText(Object element) {
            MyModel model = (MyModel) element;
            switch (columnIndex) {
                case 0: return model.column1;
                case 1: return model.column2;
                case 2: return model.column3;
                default: return "";
            }
        }

//        @Override
//        public Color getBackground(Object element) {
//            if (columnIndex == 1) {
//                return Display.getCurrent().getSystemColor(SWT.COLOR_YELLOW);
//            }
//            return super.getBackground(element);
//        }

        @Override
        public void update(ViewerCell cell) {
            super.update(cell);
            MyModel model = (MyModel) cell.getElement();
            if (columnIndex == 2) {
                cell.setText(model.column1);  // Show the hierarchy in the third column as well
            } else {
                cell.setText(getText(model));
            }
        }
    }

    private static Color mixColors(GC gc, Color color1, Color color2, float ratio) {
        int r = (int) (color1.getRed() * (1 - ratio) + color2.getRed() * ratio);
        int g = (int) (color1.getGreen() * (1 - ratio) + color2.getGreen() * ratio);
        int b = (int) (color1.getBlue() * (1 - ratio) + color2.getBlue() * ratio);
        return new Color(gc.getDevice(), r, g, b);
    }
}
