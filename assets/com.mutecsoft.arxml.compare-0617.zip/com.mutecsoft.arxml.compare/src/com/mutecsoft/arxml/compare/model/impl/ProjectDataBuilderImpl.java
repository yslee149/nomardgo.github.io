package com.mutecsoft.arxml.compare.model.impl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;

import com.mutecsoft.arxml.compare.Activator;
import com.mutecsoft.arxml.compare.CompareConstant.CompareType;
import com.mutecsoft.arxml.compare.CompareConstant.FileType;
import com.mutecsoft.arxml.compare.CompareConstant.FixedExtension;
import com.mutecsoft.arxml.compare.CompareConstant.ProjectDataQueryKey;
import com.mutecsoft.arxml.compare.CompareConstant.ProjectType;
import com.mutecsoft.arxml.compare.db.SQLService;
import com.mutecsoft.arxml.compare.model.ProjectCompareData;
import com.mutecsoft.arxml.compare.model.ProjectData;
import com.mutecsoft.arxml.compare.model.ProjectDataBuilder;

public class ProjectDataBuilderImpl implements ProjectDataBuilder {

	private static final String PROJECT_PREFIX = "project_";

	private SQLService sqlService;
	private String projectName = "";
	private Map<String, Integer> pathIdCache = new HashMap<>();
	private int nextId = 1; // Ű ���� �� ����� ID �� �ʱ�ȭ

	public ProjectDataBuilderImpl() {
		sqlService = Activator.getDefault().getSqlService();
	}

	@Override
	public List<ProjectData> getProjectData(ProjectType projectType, IProject project)
			throws SQLException, CoreException {
		int prjCode = projectType.getCode();

		sqlService.delete(ProjectDataQueryKey.DELETE_ONE.name(), prjCode);

		insertProjectDataInTransaction(project, prjCode);

		return getProjectDataList(ProjectDataQueryKey.SELECT_NORMAL.name(), prjCode, PROJECT_PREFIX + "1");
	}

	private List<ProjectData> getProjectDataList(String queryKey, int prjCode, String prefix) throws SQLException {
		List<ProjectData> projectDataList = new ArrayList<>();
		try (ResultSet rs = sqlService.select(queryKey, prjCode)) {
			while (rs.next()) {
				ProjectData projectData = extractProjectData(rs, prefix);
				projectData.setCompareResult(rs.getInt("CompareType"));
				projectDataList.add(projectData);
			}
		}
		return projectDataList;
	}

	@Override
	public Map<ProjectType, List<ProjectData>> getProjectDataCompareMap(IProject project1, IProject project2)
			throws SQLException, CoreException {
		sqlService.delete(ProjectDataQueryKey.DELETE_ALL.name());
		sqlService.resetId();

		insertProjectDataInTransaction(project1, ProjectType.ORIGIN.getCode(), project2, ProjectType.TARGET.getCode());

		List<ProjectData> projectDataList1 = new ArrayList<>();
		List<ProjectData> projectDataList2 = new ArrayList<>();

		try (ResultSet rs = sqlService.select(ProjectDataQueryKey.SELECT_COMPARE_ALL.name())) {
			while (rs.next()) {

				ProjectData projectData1 = extractProjectData(rs, PROJECT_PREFIX + "1");
				ProjectData projectData2 = extractProjectData(rs, PROJECT_PREFIX + "2");
				int compareResult = rs.getInt("CompareType");
				projectData1.setCompareResult(compareResult);
				projectData2.setCompareResult(compareResult);

				projectDataList1.add(projectData1);
				projectDataList2.add(projectData2);
			}
		}

		Map<ProjectType, List<ProjectData>> result = new HashMap<>();
		result.put(ProjectType.ORIGIN, projectDataList1);
		result.put(ProjectType.TARGET, projectDataList2);

		return result;
	}

	private HashMap<Integer, Set<Integer>> mapParentTreeId = new HashMap<Integer, Set<Integer>>();

	@Override
	public List<ProjectCompareData> getProjectDataCompareList(IProject project1, IProject project2)
			throws SQLException, CoreException {

		sqlService.delete(ProjectDataQueryKey.DELETE_ALL.name());
		sqlService.resetId();

		insertProjectDataInTransaction(project1, ProjectType.ORIGIN.getCode(), project2, ProjectType.TARGET.getCode());

		List<ProjectCompareData> projectDataList = new ArrayList<>();
		mapParentTreeId.clear();

		try (ResultSet rs = sqlService.select(ProjectDataQueryKey.SELECT_COMPARE_ALL.name())) {
			while (rs.next()) {

				ProjectData projectData1 = extractProjectData(rs, PROJECT_PREFIX + "1");
				ProjectData projectData2 = extractProjectData(rs, PROJECT_PREFIX + "2");
				int compareResult = rs.getInt("CompareType");
				projectData1.setCompareResult(compareResult);
				projectData2.setCompareResult(compareResult);

				if (compareResult != CompareType.SAME.getCode()) {

					int id1 = projectData1.getId();
					int id2 = projectData2.getId();

					int projectId = 0;
					int targetId = 0;

					if (id1 > 0) {
						targetId = id1;
						projectId = projectData1.getProjectId();
					} else if (id2 > 0) {
						targetId = id2;
						projectId = projectData2.getProjectId();
					}

					int parentId = getUpdateParentId(targetId);

					if (parentId > 0) {
						mapParentTreeId.computeIfAbsent(projectId, k -> new LinkedHashSet<>()).add(parentId);
					}

				}

				ProjectCompareData compareData = new ProjectCompareData(projectData1, projectData2);
				projectDataList.add(compareData);
			}
		}

		updateCompareResult(mapParentTreeId.get(ProjectType.ORIGIN.getCode()), projectDataList, true);
		updateCompareResult(mapParentTreeId.get(ProjectType.TARGET.getCode()), projectDataList, false);

		return projectDataList;
	}

	private int getUpdateParentId(int targetId) {

		try (ResultSet rs = sqlService.select(ProjectDataQueryKey.SELECT_PARENT_TREE.name(), targetId, targetId)) {
			while (rs.next()) {
				int id = rs.getInt("id");
				int parentId = rs.getInt("parent_id");
				int compareResult = rs.getInt("compare_result");

				// ������Ʈ ������ �ְ� ������ ������ ��츸
				if (parentId > 0 && compareResult == CompareType.SAME.getCode()) {
					return id;
				}

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return 0;
	}

	private static void updateCompareResult(Set<Integer> ids, List<ProjectCompareData> projectDataList,
			boolean isOrigin) {
		ids.forEach(id -> {
			projectDataList.forEach(wrapper -> {
				ProjectData data = isOrigin ? wrapper.getProjectData1() : wrapper.getProjectData2();
				if (id == data.getId()) {
					data.setCompareResult(CompareType.DIFFERENT.getCode());
				}
			});
		});
	}

	private ProjectData extractProjectData(ResultSet rs, String prefix) throws SQLException {
		ProjectData projectData = new ProjectData();
		projectData.setId(rs.getInt(prefix + "_id"));
		projectData.setProjectId(rs.getInt(prefix + "_project_id"));
		projectData.setParentId(rs.getInt(prefix + "_parent_id"));
		projectData.setFileName(rs.getString(prefix + "_file_name"));
		projectData.setFilePath(rs.getString(prefix + "_file_path"));
		projectData.setFileFullPath(rs.getString(prefix + "_file_full_path"));
		projectData.setFileType(rs.getInt(prefix + "_file_type"));
		projectData.setFileDate(rs.getString(prefix + "_file_date"));
		projectData.setVersion(rs.getInt(prefix + "_version"));
		return projectData;
	}

	private void insertProjectDataInTransaction(IProject project, int prjCode) throws SQLException, CoreException {
		insertProjectDataInTransaction(project, prjCode, null, 0);
	}

	private void insertProjectDataInTransaction(IProject project1, int prjCode1, IProject project2, int prjCode2)
			throws SQLException, CoreException {
		sqlService.setAutoCommit(false);
		try (PreparedStatement pstmt = sqlService.getPreparedStatement(ProjectDataQueryKey.INSERT_DATA.name(),
				PreparedStatement.RETURN_GENERATED_KEYS)) {
			insertResource(pstmt, project1, null, prjCode1);
			if (project2 != null) {
				insertResource(pstmt, project2, null, prjCode2);
			}
			sqlService.commit();
		} catch (SQLException | CoreException e) {
			sqlService.rollback();
			throw e;
		} finally {
			sqlService.setAutoCommit(true);
		}
	}

	private void insertResource(PreparedStatement pstmt, IResource resource, Integer parentId, int projectId)
			throws SQLException, CoreException {
		int fileType;
		String fileDate = "";

		if (resource instanceof IProject) {
			fileType = FileType.PROJECT.getCode();
			projectName = "/" + resource.getName();
		} else if (resource instanceof IFolder) {
			fileType = FileType.FOLDER.getCode();
		} else if (resource instanceof IFile) {
			fileType = FileType.FILE.getCode();
			fileDate = getFileTime(resource);
		} else {
			return;
		}

		if (fileType == FileType.FILE.getCode() && !isValidFile((IFile) resource)) {
			return;
		}

		int key = getNextId(); // �������� Ű ����

		// �θ� ��θ� ã�� ���� ��θ� �����ϰ� id�� ��ȸ
		String parentPath = resource.getFullPath().removeLastSegments(1).toString();
		Integer newParentId = getParentId(parentPath);

		// �� ���ҽ��� Map�� �߰�
		pathIdCache.put(resource.getFullPath().toString(), key);

		pstmt.setInt(1, key);
		pstmt.setInt(2, projectId);
		if (newParentId != null) {
			pstmt.setInt(3, newParentId);
		} else {
			pstmt.setNull(3, java.sql.Types.INTEGER);
		}
		pstmt.setString(4, resource.getName());
		pstmt.setString(5, resource.getFullPath().toString().replaceFirst("^" + projectName, ""));
		pstmt.setString(6, resource.getFullPath().toString());
		pstmt.setInt(7, fileType);
		pstmt.setString(8, fileDate);

		pstmt.executeUpdate();

		if (resource instanceof IContainer) {
			for (IResource member : ((IContainer) resource).members()) {
				insertResource(pstmt, member, key, projectId); // ���ο� Ű�� ����Ͽ� ��� ȣ��
			}
		}
	}

	private Integer getParentId(String parentPath) {
		return pathIdCache.get(parentPath);
	}

	private synchronized int getNextId() {
		return nextId++;
	}

	private boolean isValidFile(IFile resource) {
		try {
			String extension = resource.getFileExtension().toLowerCase();
			for (FixedExtension ext : FixedExtension.values()) {
				if (ext.name().toLowerCase().equals(extension)) {
					return true;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	private String getFileTime(IResource resource) {
		try {
			File file = ((IFile) resource).getLocation().toFile();
			Path filePath = file.toPath();
			BasicFileAttributes attr = Files.readAttributes(filePath, BasicFileAttributes.class);
			FileTime creationTime = attr.creationTime();

			// FileTime�� ISO 8601 ���ڿ��� ��ȯ
			return creationTime.toInstant().atZone(ZoneId.systemDefault())
					.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
		} catch (IOException e) {
			e.printStackTrace();
			return "";
		}
	}
}
