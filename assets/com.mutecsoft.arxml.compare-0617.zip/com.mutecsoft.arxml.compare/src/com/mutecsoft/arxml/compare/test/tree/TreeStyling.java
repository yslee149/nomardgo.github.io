package com.mutecsoft.arxml.compare.test.tree;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;

public class TreeStyling {
    public static void main(String[] args) {
        Display display = new Display();
        Shell shell = new Shell(display);
        shell.setText("Tree Styling Example");

        Tree tree = new Tree(shell, SWT.BORDER | SWT.V_SCROLL | SWT.H_SCROLL);
        tree.setSize(300, 200);

        TreeItem root = new TreeItem(tree, 0);
        root.setText("Root Item");

        TreeItem child1 = new TreeItem(root, 0);
        child1.setText("Child Item 1");

        TreeItem child2 = new TreeItem(root, 0);
        child2.setText("Child Item 2");

        Font boldFont = new Font(display, "Arial", 10, SWT.BOLD);
        Color redColor = new Color(display, 255, 0, 0);

        child1.setFont(boldFont);
        child2.setForeground(redColor);

        root.setExpanded(true);

        shell.setSize(350, 250);
        shell.open();

        while (!shell.isDisposed()) {
            if (!display.readAndDispatch()) {
                display.sleep();
            }
        }
        display.dispose();
        boldFont.dispose();
        redColor.dispose();
    }
}
