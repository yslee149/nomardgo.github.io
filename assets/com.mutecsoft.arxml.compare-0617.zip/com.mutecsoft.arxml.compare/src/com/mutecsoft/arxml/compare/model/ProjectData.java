package com.mutecsoft.arxml.compare.model;

public class ProjectData {

	int id;
	int project_id;
	int parent_id;
	String file_name;
	String file_path;
	String file_full_path;
	int file_type;
	String file_date;
	int compare_result;
	int version;

	public ProjectData() {}

	public ProjectData(int id, int project_id, int parent_id, String file_name, String file_path, String file_full_path,
			int file_type, String file_date, int compare_result, int version) {
		this.id = id;
		this.project_id = project_id;
		this.parent_id = parent_id;
		this.file_name = file_name;
		this.file_path = file_path;
		this.file_full_path = file_full_path;
		this.file_type = file_type;
		this.file_date = file_date;
		this.compare_result = compare_result;
		this.version = version;
	}

	public int getId() {
		return id;
	}

	public int getProjectId() {
		return project_id;
	}

	public int getParentId() {
		return parent_id;
	}

	public String getFileName() {
		return file_name;
	}

	public String getFilePath() {
		return file_path;
	}

	public String getFileFullPath() {
		return file_full_path;
	}

	public int getFileType() {
		return file_type;
	}

	public String getFileDate() {
		return file_date;
	}

	public int getCompareResult() {
		return compare_result;
	}

	public int getVersion() {
		return version;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setProjectId(int project_id) {
		this.project_id = project_id;
	}

	public void setParentId(int parent_id) {
		this.parent_id = parent_id;
	}

	public void setFileName(String file_name) {
		this.file_name = file_name;
	}

	public void setFilePath(String file_path) {
		this.file_path = file_path;
	}

	public void setFileFullPath(String file_full_path) {
		this.file_full_path = file_full_path;
	}

	public void setFileType(int file_type) {
		this.file_type = file_type;
	}

	public void setFileDate(String file_date) {
		this.file_date = file_date;
	}

	public void setCompareResult(int compare_result) {
		this.compare_result = compare_result;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	@Override
	public String toString() {
		return "ProjectData [id=" + id + ", project_id=" + project_id + ", parent_id=" + parent_id + ", file_name="
				+ file_name + ", file_path=" + file_path + ", file_full_path=" + file_full_path + ", file_type="
				+ file_type + ", file_date=" + file_date + ", compare_result=" + compare_result + ", version=" + version
				+ "]";
	}

}
