package com.mutecsoft.arxml.compare.view.impl.project.tree;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.tree.TreePath;

import org.jdesktop.swingx.treetable.AbstractTreeTableModel;
import org.jdesktop.swingx.treetable.DefaultMutableTreeTableNode;

import com.mutecsoft.arxml.compare.CompareConstant.CompareType;
import com.mutecsoft.arxml.compare.CompareConstant.FileType;
import com.mutecsoft.arxml.compare.model.ProjectCompareData;
import com.mutecsoft.arxml.compare.model.ProjectData;

public class TreeTableModel extends AbstractTreeTableModel {

	private final String[] columnNames = { "hide", "Name", "Size", "Modified", "", "Name", "Size", "Modified" };
	private DefaultMutableTreeTableNode root;

	public TreeTableModel(List<ProjectCompareData> projectCompareDataList) {
		root = new DefaultMutableTreeTableNode("Root");
		createTree(projectCompareDataList);
	}

	private void createTree(List<ProjectCompareData> projectCompareDataList) {
		Map<String, DefaultMutableTreeTableNode> pathNodeMap = new HashMap<>();

		for (ProjectCompareData projectCompareData : projectCompareDataList) {
			ProjectData data1 = projectCompareData.getProjectData1();
			ProjectData data2 = projectCompareData.getProjectData2();

			if (data1 != null && data1.getFilePath() != null) {
				String[] paths1 = data1.getFilePath().split("/");
				addToTree(root, paths1, projectCompareData, pathNodeMap);
			}

			if (data2 != null && data2.getFilePath() != null) {
				String[] paths2 = data2.getFilePath().split("/");
				addToTree(root, paths2, projectCompareData, pathNodeMap);
			}
		}
	}

	private void addToTree(DefaultMutableTreeTableNode parent, String[] paths, ProjectCompareData projectCompareData,
			Map<String, DefaultMutableTreeTableNode> pathNodeMap) {
		StringBuilder fullPath = new StringBuilder();

		for (String path : paths) {
			if (path.isEmpty())
				continue;
			fullPath.append("/").append(path);
			String fullPathStr = fullPath.toString();

			DefaultMutableTreeTableNode node = pathNodeMap.get(fullPathStr);
			if (node == null) {
				node = new DefaultMutableTreeTableNode(projectCompareData);
				parent.add(node);
				pathNodeMap.put(fullPathStr, node);
			}

			parent = node;
		}

		// Only set user object if it's not already set
		if (parent.getUserObject() == null) {
			parent.setUserObject(projectCompareData);
		}
	}

	@Override
	public int getColumnCount() {
		return columnNames.length;
	}

	@Override
	public String getColumnName(int column) {
		return columnNames[column];
	}

	@Override
	public Object getValueAt(Object node, int column) {

		if (node == null) {
			System.out.println("Node is null");
			return null;
		}

		if (node instanceof DefaultMutableTreeTableNode) {
			DefaultMutableTreeTableNode treeNode = (DefaultMutableTreeTableNode) node;
			Object userObject = treeNode.getUserObject();

			if (userObject instanceof ProjectCompareData) {
				ProjectCompareData projectCompareData = (ProjectCompareData) userObject;
				ProjectData data1 = projectCompareData.getProjectData1();
				ProjectData data2 = projectCompareData.getProjectData2();

				int fileType = data1.getFileType();
				int compareResult = data1.getCompareResult();

				switch (column) {
				case 0:
					return "";
				case 1:

					if (compareResult == CompareType.SAME.getCode()
							|| compareResult == CompareType.DIFFERENT.getCode()) {
						return data1.getFileName();
					} else if (compareResult == CompareType.ONLY_IN_TREE2.getCode()) {
						return data1.getFileName();
					} else {
						return "";
					}

				case 2:
//					if (fileType == FileType.FILE.getCode()) {
//						return "size";
//					} else {
//						return "";
//					}
					return data1.getCompareResult();
				case 3:
					return data1 != null ? data1.getFileDate() : null;
				case 4:

					int compareType = data1.getCompareResult();
					if (compareType == CompareType.DIFFERENT.getCode()) {
						return "!=";
					} else if (compareType == CompareType.ONLY_IN_TREE1.getCode()) {
						return "<";
					} else if (compareType == CompareType.ONLY_IN_TREE2.getCode()) {
						return ">";
					} else {
						return "=";
					}

				case 5:

					if (compareResult == CompareType.SAME.getCode()
							|| compareResult == CompareType.DIFFERENT.getCode()) {
						return data2.getFileName();
					} else if (compareResult == CompareType.ONLY_IN_TREE2.getCode()) {
						return data2.getFileName();
					}

					else {
						return "";
					}

				case 6:
//					if (fileType == FileType.FILE.getCode()) {
//						return "size";
//					} else {
//						return "";
//					}
					return data2.getCompareResult();
				case 7:
					return data2 != null ? data2.getFileDate() : null;
				default:
					return null;
				}
			} else {
				System.out.println("User object is not an instance of ProjectCompareData");
			}
		} else {
			System.out.println("Node is not an instance of DefaultMutableTreeTableNode");
		}
		return null;
	}

	@Override
	public Object getChild(Object parent, int index) {
		if (parent instanceof DefaultMutableTreeTableNode) {
			DefaultMutableTreeTableNode treeNode = (DefaultMutableTreeTableNode) parent;
			return treeNode.getChildAt(index);
		}
		return null;
	}

	@Override
	public int getChildCount(Object parent) {
		if (parent instanceof DefaultMutableTreeTableNode) {
			DefaultMutableTreeTableNode treeNode = (DefaultMutableTreeTableNode) parent;
			return treeNode.getChildCount();
		}
		return 0;
	}

	@Override
	public int getIndexOfChild(Object parent, Object child) {
		if (parent instanceof DefaultMutableTreeTableNode && child instanceof DefaultMutableTreeTableNode) {
			DefaultMutableTreeTableNode parentNode = (DefaultMutableTreeTableNode) parent;
			DefaultMutableTreeTableNode childNode = (DefaultMutableTreeTableNode) child;
			return parentNode.getIndex(childNode);
		}
		return -1;
	}

	@Override
	public Object getRoot() {
		return root;
	}

	@Override
	public boolean isLeaf(Object node) {
		if (node instanceof DefaultMutableTreeTableNode) {
			DefaultMutableTreeTableNode treeNode = (DefaultMutableTreeTableNode) node;
			return treeNode.getChildCount() == 0;
		}
		return true;
	}

	@Override
	public void valueForPathChanged(TreePath path, Object newValue) {
		// Implement if needed
	}
}
