package com.mutecsoft.arxml.compare.view.impl.project.tree;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTree;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.table.TableCellRenderer;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.TreePath;

import org.jdesktop.swingx.JXTreeTable;
import org.jdesktop.swingx.treetable.DefaultMutableTreeTableNode;

import com.mutecsoft.arxml.compare.CompareConstant.CompareType;
import com.mutecsoft.arxml.compare.CompareConstant.FileType;
import com.mutecsoft.arxml.compare.model.ProjectCompareData;
import com.mutecsoft.arxml.compare.model.ProjectData;

public class TreeTableCellRenderer extends JPanel implements TableCellRenderer {
	
	private static final long serialVersionUID = 1L;
	
	private final JXTreeTable treeTable;
	private final int targetColumn;
	private final DefaultTreeCellRenderer treeCellRenderer;
	private final Color oddRowColor = Color.WHITE;
	private final Color evenRowColor = new Color(248, 250, 249);

	public TreeTableCellRenderer(JXTreeTable treeTable, int targetColumn) {
		this.treeTable = treeTable;

		this.targetColumn = targetColumn;
		this.treeCellRenderer = new DefaultTreeCellRenderer();
		setLayout(new BorderLayout());

		treeTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		setLookAndFeel();

	}

	private void setLookAndFeel() {
		try {
			// Set the Look and Feel to the system's Look and Feel
//			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");

			
			// Update the component tree UI to apply the new Look and Feel
			SwingUtilities.updateComponentTreeUI(this);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
			int row, int column) {
		if (column == targetColumn) {
			return getTreeTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
		} else {
			return getDefaultTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
		}
	}

	private Component getTreeTableCellRendererComponent(JTable table, Object value, boolean isSelected,
			boolean hasFocus, int row, int column) {
		TreePath path = treeTable.getPathForRow(row);
		int depth = path != null ? path.getPathCount() - 1 : 0;

		removeAll();
		Component treeCellComponent = treeCellRenderer.getTreeCellRendererComponent(
				(JTree) treeTable.getCellRenderer(0, 0), value, isSelected, hasFocus, treeTable.isExpanded(path), row,
				false);

		if (treeCellComponent instanceof JLabel) {
			JLabel label = (JLabel) treeCellComponent;
			setupLabel(label, path, column);
			add(label, BorderLayout.CENTER);
		}

		setBorder(BorderFactory.createEmptyBorder(0, 20 * depth, 0, 0));
		setBackgroundAndForeground(isSelected, table, row);
		

		return this;
	}

	private void setupLabel(JLabel label, TreePath path, int column) {
		Object node = path.getLastPathComponent();
		if (node instanceof DefaultMutableTreeTableNode) {
			DefaultMutableTreeTableNode treeNode = (DefaultMutableTreeTableNode) node;
			Object userObject = treeNode.getUserObject();

			if (userObject instanceof ProjectCompareData) {
				ProjectCompareData compareData = (ProjectCompareData) userObject;
				setupLabelForCompareData(label, compareData, column);
			}
		}
	}

	private void setupLabelForCompareData(JLabel label, ProjectCompareData compareData, int column) {
		ProjectData data1 = compareData.getProjectData1();
		ProjectData data2 = compareData.getProjectData2();
		int compareResult = data1.getCompareResult();

		if (compareResult == CompareType.SAME.getCode() || compareResult == CompareType.DIFFERENT.getCode()) {
			setLabelIconAndText(label, data1.getFileType(), data1.getFileName());
		} else if (compareResult == CompareType.ONLY_IN_TREE1.getCode()) {
			setupLabelForOnlyInTree1(label, data1, column);
		} else if (compareResult == CompareType.ONLY_IN_TREE2.getCode()) {
			setupLabelForOnlyInTree2(label, data2, column);
		}
		
//		label.setBackground(row % 2 == 0 ? evenRowColor : oddRowColor);
//		label.setBackground(evenRowColor);
	}

	private void setupLabelForOnlyInTree1(JLabel label, ProjectData data1, int column) {
		if (column == 1) {
			setLabelIconAndText(label, data1.getFileType(), data1.getFileName());
			
		} else if (column == 5) {
			label.setIcon(null);
			label.setText("");
		}
	}

	private void setupLabelForOnlyInTree2(JLabel label, ProjectData data2, int column) {
		if (column == 1) {
			label.setIcon(null);
			label.setText("");
		} else if (column == 5) {
			setLabelIconAndText(label, data2.getFileType(), data2.getFileName());
		}
	}

	private void setLabelIconAndText(JLabel label, int fileType, String fileName) {
		if (fileType == FileType.FOLDER.getCode() || fileType == FileType.PROJECT.getCode()) {
			label.setIcon(UIManager.getIcon("FileView.directoryIcon"));
		} else if (fileType == FileType.FILE.getCode()) {
			label.setIcon(UIManager.getIcon("FileView.fileIcon"));
		}
		label.setText(fileName);
	}

	private Component getDefaultTableCellRendererComponent(JTable table, Object value, boolean isSelected,
			boolean hasFocus, int row, int column) {
		Component component = table.getDefaultRenderer(String.class).getTableCellRendererComponent(table, value,
				isSelected, hasFocus, row, column);
		add(component, BorderLayout.CENTER);
		return this;
	}

	private void setBackgroundAndForeground(boolean isSelected, JTable table, int row) {
		if (isSelected) {
			setBackground(table.getSelectionBackground());
			setForeground(table.getSelectionForeground());
		} else {
			setBackground(row % 2 == 0 ? evenRowColor : oddRowColor);
			setForeground(treeCellRenderer.getTextNonSelectionColor());
		}
	}
}