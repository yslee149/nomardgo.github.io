package com.mutecsoft.arxml.compare.view.impl.project.tree;

import org.jdesktop.swingx.treetable.DefaultMutableTreeTableNode;

public class MutableTreeTableNode extends DefaultMutableTreeTableNode {

	public MutableTreeTableNode(Object userObject) {
		super(userObject);
	}

	public void removeAllChildren() {
		while (getChildCount() > 0) {
			remove(0);
		}
	}
}
