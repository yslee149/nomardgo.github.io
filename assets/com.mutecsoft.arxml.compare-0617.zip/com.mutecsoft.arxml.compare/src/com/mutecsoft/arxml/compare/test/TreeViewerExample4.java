package com.mutecsoft.arxml.compare.test;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.TreeViewerColumn;
import org.eclipse.jface.viewers.ViewerCell;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TreeItem;

public class TreeViewerExample4 {

    public static void main(String[] args) {
        Display display = new Display();
        Shell shell = new Shell(display);
        shell.setText("TreeViewer Example");
        shell.setSize(400, 300);

        TreeViewer viewer = new TreeViewer(shell, SWT.BORDER | SWT.FULL_SELECTION);
        viewer.getTree().setLinesVisible(true);
        viewer.getTree().setHeaderVisible(true);
        viewer.getTree().setBounds(10, 10, 380, 250);

        // First column
        TreeViewerColumn column1 = new TreeViewerColumn(viewer, SWT.LEFT);
        column1.getColumn().setText("Column 1");
        column1.getColumn().setWidth(0);
        column1.setLabelProvider(new ColumnLabelProvider() {
            @Override
            public String getText(Object element) {
                TreeNode node = (TreeNode) element;
                return node.getText(0);
            }
        });
        
        // Second column
        TreeViewerColumn column2 = new TreeViewerColumn(viewer, SWT.LEFT);
        column2.getColumn().setText("Column 2");
        column2.getColumn().setWidth(100);
        column2.setLabelProvider(new CustomColumnLabelProvider(1, true)); // Center aligned

        // Third column
        TreeViewerColumn column3 = new TreeViewerColumn(viewer, SWT.LEFT);
        column3.getColumn().setText("Column 3");
        column3.getColumn().setWidth(100);
        column3.setLabelProvider(new CustomColumnLabelProvider(2, false)); // Left aligned

        viewer.setContentProvider(new ITreeContentProvider() {
            @Override
            public Object[] getElements(Object inputElement) {
                return ((MyModel) inputElement).getElements();
            }

            @Override
            public Object[] getChildren(Object parentElement) {
                return ((TreeNode) parentElement).getChildren();
            }

            @Override
            public Object getParent(Object element) {
                return ((TreeNode) element).getParent();
            }

            @Override
            public boolean hasChildren(Object element) {
                return ((TreeNode) element).hasChildren();
            }
        });

        viewer.setInput(new MyModel());

        shell.open();
        while (!shell.isDisposed()) {
            if (!display.readAndDispatch()) {
                display.sleep();
            }
        }
        display.dispose();
    }

    static class MyModel {
        public TreeNode[] getElements() {
            TreeNode root1 = new TreeNode("Root 1");
            TreeNode root2 = new TreeNode("Root 2");

            TreeNode child1 = new TreeNode("Child 1");
            TreeNode child2 = new TreeNode("Child 2");
            TreeNode child3 = new TreeNode("Child 3");

            root1.setChildren(new TreeNode[] { child1, child2 });
            root2.setChildren(new TreeNode[] { child3 });

            return new TreeNode[] { root1, root2 };
        }
    }

    static class TreeNode {
        private String name;
        private TreeNode parent;
        private TreeNode[] children;

        public TreeNode(String name) {
            this.name = name;
            this.children = new TreeNode[0];
        }

        public void setParent(TreeNode parent) {
            this.parent = parent;
        }

        public TreeNode getParent() {
            return parent;
        }

        public void setChildren(TreeNode[] children) {
            this.children = children;
            for (TreeNode child : children) {
                child.setParent(this);
            }
        }

        public TreeNode[] getChildren() {
            return children;
        }

        public boolean hasChildren() {
            return children.length > 0;
        }

        public String getText(int columnIndex) {
            return name + " - Column " + (columnIndex + 1);
        }
    }

    static class CustomColumnLabelProvider extends ColumnLabelProvider {
        private final int columnIndex;
        private final boolean isCenterAligned;

        public CustomColumnLabelProvider(int columnIndex, boolean isCenterAligned) {
            this.columnIndex = columnIndex;
            this.isCenterAligned = isCenterAligned;
        }

        @Override
        public void update(ViewerCell cell) {
            TreeNode node = (TreeNode) cell.getElement();
            cell.setText(node.getText(columnIndex));
            cell.setImage(getTreeIcon());

            if (isCenterAligned) {
                alignCenter(cell);
            } else {
                alignLeft(cell);
            }
        }

        private void alignCenter(ViewerCell cell) {
            TreeItem item = (TreeItem) cell.getItem();
            int cellWidth = item.getBounds(cell.getColumnIndex()).width;
            int textWidth = cell.getBounds().width;
            int imageWidth = (cell.getImage() != null) ? cell.getImage().getBounds().width : 0;
            int totalWidth = textWidth + imageWidth + 2;
            int xOffset = (cellWidth - totalWidth) / 2;
            
            item.setText(cell.getColumnIndex(), repeat(" ", xOffset / 10) + cell.getText());

        }
        
        private String repeat(String str, int times) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < times; i++) {
                sb.append(str);
            }
            return sb.toString();
        }
        
        private void alignLeft(ViewerCell cell) {
            // No need to do anything as default is left alignment
        }

        private Image getTreeIcon() {
            // Load your tree icon image here
            // For example, using ImageDescriptor:
            return ImageDescriptor.createFromFile(getClass(), "/path/to/treeicon.png").createImage();
        }
    }
}
