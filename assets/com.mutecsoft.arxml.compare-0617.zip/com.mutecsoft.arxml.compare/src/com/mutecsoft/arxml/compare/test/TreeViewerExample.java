package com.mutecsoft.arxml.compare.test;

import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;

public class TreeViewerExample {

    public static void main(String[] args) {
        Display display = new Display();
        Shell shell = new Shell(display);
        shell.setSize(400, 300);

        TreeViewer treeViewer = new TreeViewer(shell, SWT.BORDER | SWT.FULL_SELECTION);
        treeViewer.getTree().setBounds(10, 10, 360, 240);

        // Set content provider
        treeViewer.setContentProvider(new ITreeContentProvider() {
            @Override
            public Object[] getElements(Object inputElement) {
                return (Object[]) inputElement;
            }

            @Override
            public Object[] getChildren(Object parentElement) {
                if (parentElement instanceof String) {
                    return new String[] { parentElement + " - Child 1", parentElement + " - Child 2" };
                }
                return new Object[0];
            }

            @Override
            public Object getParent(Object element) {
                return null;
            }

            @Override
            public boolean hasChildren(Object element) {
                return element instanceof String;
            }

            @Override
            public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
            }

            @Override
            public void dispose() {
            }
        });

        treeViewer.setLabelProvider(new LabelProvider());
        treeViewer.setInput(new String[] { "Item 1", "Item 2", "Item 3" });

        // Set selection listener
        treeViewer.addSelectionChangedListener(event -> {
            StructuredSelection selection = (StructuredSelection) event.getSelection();
            if (!selection.isEmpty()) {
                Object selectedElement = selection.getFirstElement();
                Tree tree = treeViewer.getTree();
                TreeItem[] items = tree.getItems();

                for (TreeItem item : items) {
                    resetItemColors(item, display);
                    if (selectedElement.equals(item.getData())) {
                        highlightItem(item, display);
                    }
                    // Recursively process children
                    highlightSelectedChildren(item, selectedElement, display);
                }
            }
        });

        shell.open();
        while (!shell.isDisposed()) {
            if (!display.readAndDispatch()) {
                display.sleep();
            }
        }
        display.dispose();
    }

    private static void highlightSelectedChildren(TreeItem parentItem, Object selectedElement, Display display) {
        for (TreeItem child : parentItem.getItems()) {
            resetItemColors(child, display);
            if (selectedElement.equals(child.getData())) {
                highlightItem(child, display);
            }
            // Recursively process children
            highlightSelectedChildren(child, selectedElement, display);
        }
    }

    private static void resetItemColors(TreeItem item, Display display) {
        item.setBackground(display.getSystemColor(SWT.COLOR_WHITE));
        item.setForeground(display.getSystemColor(SWT.COLOR_BLACK));
    }

    private static void highlightItem(TreeItem item, Display display) {
        item.setBackground(display.getSystemColor(SWT.COLOR_DARK_GREEN));
        item.setForeground(display.getSystemColor(SWT.COLOR_WHITE));
    }
}
