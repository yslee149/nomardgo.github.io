package com.mutecsoft.arxml.compare.view.impl.project;

import javax.swing.SwingUtilities;

import org.eclipse.swt.SWT;
import org.eclipse.swt.awt.SWT_AWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Shell;

public class ViewPart {

	private ProjectTreeViewImpl mainView;
	private Shell shell;

	private Composite parent;

	private Composite swingComposite;

	public ViewPart(ProjectTreeViewImpl view) {
		mainView = view;
		shell = mainView.getShell();

		shell.setLayout(new GridLayout(1, false));

		parent = new Composite(shell, SWT.NONE);
		parent.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));

		createComposite();
		createTopArea();
		createTreeTable();
		createBottomArea();
	}

	private void createComposite() {
		GridLayout gridLayout = new GridLayout(1, false);
		gridLayout.marginWidth = 0;
		gridLayout.marginHeight = 0;
		gridLayout.horizontalSpacing = 0;
		gridLayout.verticalSpacing = 0;
		parent.setLayout(gridLayout);
	}

	private void createTopArea() {
		Composite c = new Composite(parent, SWT.BORDER);
		c.setLayout(new GridLayout(10, false));
		GridData gridData = new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1);
		gridData.heightHint = 50;
		c.setLayoutData(gridData);

		// ���� ����
		Color topBackgroundColor = mainView.getSystemColor(SWT.COLOR_YELLOW);
		c.setBackground(topBackgroundColor);
	}

	private void createTreeTable() {
		Composite c = new Composite(parent, SWT.NONE);
		GridData gridData = new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1);
		c.setLayoutData(gridData);

		GridLayout gridLayout = new GridLayout(1, false);
		gridLayout.marginHeight = 0;
		gridLayout.marginWidth = 0;
		gridLayout.horizontalSpacing = 0;
		gridLayout.verticalSpacing = 0;
		c.setLayout(gridLayout);

		swingComposite = new Composite(c, SWT.EMBEDDED | SWT.NO_BACKGROUND);
		swingComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));

	}

	private void createBottomArea() {
		Composite c = new Composite(parent, SWT.BORDER);
		c.setLayout(new GridLayout(16, false));
		GridData gridData = new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1);
		gridData.heightHint = 100;
		c.setLayoutData(gridData);

		// ���� ����
		Color bottomBackgroundColor = mainView.getSystemColor(SWT.COLOR_YELLOW);
		c.setBackground(bottomBackgroundColor);
	}
	
	public Composite getSwingComposite() {
		return swingComposite;
	}

}
