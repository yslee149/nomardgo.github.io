package com.mutecsoft.arxml.compare.test.jxtree;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTree;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.table.TableCellRenderer;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.TreeCellRenderer;
import javax.swing.tree.TreePath;

import org.jdesktop.swingx.JXTreeTable;
import org.jdesktop.swingx.treetable.AbstractTreeTableModel;
import org.jdesktop.swingx.treetable.DefaultMutableTreeTableNode;

public class CustomJXTreeTable13 {

    static class ProjectData {
        int id;
        int project_id;
        int parent_id;
        String file_name;
        String file_path;
        String file_full_path;
        int file_type;
        String file_date;
        int compare_result;
        int version;

        public ProjectData(int id, int project_id, int parent_id, String file_name, String file_path, String file_full_path, int file_type, String file_date, int compare_result, int version) {
            this.id = id;
            this.project_id = project_id;
            this.parent_id = parent_id;
            this.file_name = file_name;
            this.file_path = file_path;
            this.file_full_path = file_full_path;
            this.file_type = file_type;
            this.file_date = file_date;
            this.compare_result = compare_result;
            this.version = version;
        }

        public int getId() {
            return id;
        }

        public int getProjectId() {
            return project_id;
        }

        public int getParentId() {
            return parent_id;
        }

        public String getFileName() {
            return file_name;
        }

        public String getFilePath() {
            return file_path;
        }

        public String getFileFullPath() {
            return file_full_path;
        }

        public int getFileType() {
            return file_type;
        }

        public String getFileDate() {
            return file_date;
        }

        public int getCompareResult() {
            return compare_result;
        }

        public int getVersion() {
            return version;
        }
    }

    static class CustomMutableTreeTableNode extends DefaultMutableTreeTableNode {
        public CustomMutableTreeTableNode(Object userObject) {
            super(userObject);
        }

        public void removeAllChildren() {
            while (getChildCount() > 0) {
                remove(0);
            }
        }
    }

    static class CustomTreeTableModel extends AbstractTreeTableModel {
        private final String[] columnNames = {"Hidden Tree Column", "Name", "Type", "Date", "Compare Result"};

        public CustomTreeTableModel(List<ProjectData> projectDataList) {
            super(convertToNode(projectDataList));
        }

        private static CustomMutableTreeTableNode convertToNode(List<ProjectData> projectDataList) {
            CustomMutableTreeTableNode rootNode = new CustomMutableTreeTableNode("Root");
            Map<Integer, CustomMutableTreeTableNode> nodeMap = new HashMap<>();
            nodeMap.put(0, rootNode);

            System.out.println("step 1 ==========> " + projectDataList.size());
            for (ProjectData projectData : projectDataList) {
                CustomMutableTreeTableNode newNode = new CustomMutableTreeTableNode(projectData);
                nodeMap.put(projectData.getId(), newNode);

                CustomMutableTreeTableNode parentNode = nodeMap.get(projectData.getParentId());
                if (parentNode != null) {
                    parentNode.add(newNode);
                }
                
                System.out.println("step 2 ==========> " + parentNode.getChildCount());
            }
            
            System.out.println("step 3 ==========> " + nodeMap.size());
            
            System.out.println("convertToNode size ========= " + rootNode.getChildCount());
            return rootNode;
        }

        @Override
        public int getColumnCount() {
            return columnNames.length;
        }

        @Override
        public Object getValueAt(Object node, int column) {
            if (node instanceof CustomMutableTreeTableNode) {
                Object userObject = ((CustomMutableTreeTableNode) node).getUserObject();
                if (userObject instanceof ProjectData) {
                    ProjectData data = (ProjectData) userObject;

                    switch (column) {
                        case 0:
                            return data.getFilePath();
                        case 1:
                            return data.getFileName();
                        case 2:
                            return data.getFileType() == 1 ? "Folder" : "File";
                        case 3:
                            return data.getFileDate();
                        case 4:
                            return data.getCompareResult();
                        default:
                            return null;
                    }
                }
            }
            return null;
        }

        @Override
        public String getColumnName(int column) {
            return columnNames[column];
        }

        @Override
        public Object getChild(Object parent, int index) {
            if (parent instanceof DefaultMutableTreeTableNode) {
                return ((DefaultMutableTreeTableNode) parent).getChildAt(index);
            }
            return null;
        }

        @Override
        public int getChildCount(Object parent) {
            if (parent instanceof DefaultMutableTreeTableNode) {
                return ((DefaultMutableTreeTableNode) parent).getChildCount();
            }
            return 0;
        }

        @Override
        public int getIndexOfChild(Object parent, Object child) {
            if (parent instanceof DefaultMutableTreeTableNode && child instanceof DefaultMutableTreeTableNode) {
                return ((DefaultMutableTreeTableNode) parent).getIndex((DefaultMutableTreeTableNode) child);
            }
            return -1;
        }

        public void reload() {
            modelSupport.fireNewRoot();
        }
    }

    static class CustomTreeCellRenderer extends JPanel implements TableCellRenderer {
        private final JXTreeTable treeTable;
        private final int targetColumn;

        public CustomTreeCellRenderer(JXTreeTable treeTable, int targetColumn) {
            this.treeTable = treeTable;
            this.targetColumn = targetColumn;
            setLayout(new BorderLayout());
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            JTree tree = (JTree) treeTable.getCellRenderer(0, 0); // Get the JTree renderer component from the first column
            TreeCellRenderer delegate = tree.getCellRenderer();

            TreePath path = treeTable.getPathForRow(row);
            int depth = path != null ? path.getPathCount() - 1 : 0;

            Component component = delegate.getTreeCellRendererComponent(tree, value, isSelected, hasFocus, treeTable.isExpanded(path), row, false);

            if (column == targetColumn) {
                removeAll();
                JLabel label = new JLabel(value.toString());
                label.setIcon(((JLabel) component).getIcon());
                label.setPreferredSize(new Dimension(table.getColumnModel().getColumn(column).getWidth(), label.getPreferredSize().height));
                add(label, BorderLayout.CENTER);
                setBorder(BorderFactory.createEmptyBorder(0, 20 * depth, 0, 0));

                if (isSelected) {
                    setBackground(table.getSelectionBackground());
                    label.setForeground(table.getSelectionForeground());
                } else {
                    setBackground(Color.WHITE);
                }

                if (label instanceof DefaultTreeCellRenderer) {
                    DefaultTreeCellRenderer renderer = (DefaultTreeCellRenderer) label;
                    if (value.toString().contains("folder")) {
                        renderer.setClosedIcon(UIManager.getIcon("FileView.directoryIcon"));
                        renderer.setOpenIcon(UIManager.getIcon("FileView.directoryIcon"));
                    } else {
                        renderer.setLeafIcon(UIManager.getIcon("FileView.fileIcon"));
                    }

                }
            } else {
                component = table.getDefaultRenderer(String.class).getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            }

            return this;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {

            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (ClassNotFoundException | InstantiationException | IllegalAccessException
                    | UnsupportedLookAndFeelException e1) {
                e1.printStackTrace();
            }

            JFrame frame = new JFrame("Custom JXTreeTable");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(800, 600);

            // Create a panel for the button
            JPanel panel = new JPanel();
            panel.setLayout(new BorderLayout());

            // Create the button
            JButton button = new JButton("Update Data");
            button.setPreferredSize(new Dimension(frame.getWidth(), 40));
            panel.add(button, BorderLayout.NORTH);

            // Create sample data
            List<ProjectData> projectDataList = new ArrayList<>();
            projectDataList.add(new ProjectData(1, 1, 0, "folder1", "/folder1", "/folder1", 1, "2023-01-01", 0, 1));
            projectDataList.add(new ProjectData(2, 1, 1, "file1.txt", "/folder1/file1.txt", "/folder1/file1.txt", 2, "2023-01-02", 0, 1));
            projectDataList.add(new ProjectData(3, 1, 1, "file2.txt", "/folder1/file2.txt", "/folder1/file2.txt", 2, "2023-01-03", 0, 1));
            projectDataList.add(new ProjectData(4, 1, 1, "subfolder1", "/folder1/subfolder1", "/folder1/subfolder1", 1, "2023-01-04", 0, 1));
            projectDataList.add(new ProjectData(5, 1, 4, "file1.txt", "/folder1/subfolder1/file1.txt", "/folder1/subfolder1/file1.txt", 2, "2023-01-05", 0, 1));

            // Create JXTreeTable
            CustomTreeTableModel treeTableModel = new CustomTreeTableModel(projectDataList);
            JXTreeTable treeTable = new JXTreeTable(treeTableModel);
            treeTable.setRootVisible(false); // Hide root

            // Hide the first column
            treeTable.getColumnModel().getColumn(0).setMinWidth(0);
            treeTable.getColumnModel().getColumn(0).setMaxWidth(0);
            treeTable.getColumnModel().getColumn(0).setPreferredWidth(0);

            // Set custom renderer for the second column (index 1)
            treeTable.getColumnModel().getColumn(1).setCellRenderer(new CustomTreeCellRenderer(treeTable, 1));
            treeTable.getColumnModel().getColumn(2).setCellRenderer(new CustomTreeCellRenderer(treeTable, 2));

            treeTable.expandAll();
            treeTable.setRowHeight(40);

            treeTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

            treeTable.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    int row = treeTable.rowAtPoint(e.getPoint());
                    int column = treeTable.columnAtPoint(e.getPoint());

                    if (row != -1 && column != -1) {
                        String columnName = treeTable.getColumnName(column);
                        Object cellValue = treeTable.getValueAt(row, column);
                        System.out.println("Clicked Column: " + columnName + ", Value: " + cellValue);
                    }

                    if (row != -1 && e.getClickCount() == 2) {
                        TreePath path = treeTable.getPathForRow(row);
                        if (treeTable.isExpanded(path)) {
                            treeTable.collapsePath(path);
                        } else {
                            treeTable.expandPath(path);
                        }
                    }
                }
            });

            // Add button action listener to update data
            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Create new sample data
                    List<ProjectData> newProjectDataList = new ArrayList<>();
                    newProjectDataList.add(new ProjectData(1, 1, 0, "newFolder1", "/newFolder1", "/newFolder1", 1, "2024-01-01", 0, 1));
                    newProjectDataList.add(new ProjectData(2, 1, 1, "newFile1.txt", "/newFolder1/newFile1.txt", "/newFolder1/newFile1.txt", 2, "2024-01-02", 0, 1));
                    newProjectDataList.add(new ProjectData(3, 1, 1, "newFile2.txt", "/newFolder1/newFile2.txt", "/newFolder1/newFile2.txt", 2, "2024-01-03", 0, 1));
                    newProjectDataList.add(new ProjectData(4, 1, 1, "newSubfolder1", "/newFolder1/newSubfolder1", "/newFolder1/newSubfolder1", 1, "2024-01-04", 0, 1));
                    newProjectDataList.add(new ProjectData(5, 1, 4, "newFile1.txt", "/newFolder1/newSubfolder1/newFile1.txt", "/newFolder1/newSubfolder1/newFile1.txt", 2, "2024-01-05", 0, 1));

                    // Clear existing nodes
                    CustomMutableTreeTableNode root = (CustomMutableTreeTableNode) treeTableModel.getRoot();
                    while (root.getChildCount() > 0) {
                        root.remove(0);
                    }
                    Map<Integer, CustomMutableTreeTableNode> nodeMap = new HashMap<>();
                    nodeMap.put(0, root);

                    // Build new tree structure
                    for (ProjectData projectData : newProjectDataList) {
                        CustomMutableTreeTableNode newNode = new CustomMutableTreeTableNode(projectData);
                        nodeMap.put(projectData.getId(), newNode);

                        CustomMutableTreeTableNode parentNode = nodeMap.get(projectData.getParentId());
                        if (parentNode != null) {
                            parentNode.add(newNode);
                        }
                    }

                    // Notify model about the data change
                    treeTableModel.reload();
                    treeTable.expandAll();
                }
            });

            // Add components to the frame
            panel.add(new JScrollPane(treeTable), BorderLayout.CENTER);
            frame.add(panel);
            frame.setVisible(true);
        });
    }
}
