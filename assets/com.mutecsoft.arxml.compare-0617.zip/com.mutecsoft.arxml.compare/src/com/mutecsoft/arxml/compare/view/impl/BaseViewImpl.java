package com.mutecsoft.arxml.compare.view.impl;

import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import com.mutecsoft.arxml.compare.CompareConstant.ScreenSize;

public class BaseViewImpl {

	private Display mDisplay;
	private Shell mShell;

	public BaseViewImpl(Display display) {

		this.mDisplay = display;
		this.mShell = new Shell(mDisplay);

		setScreenShell();
	}

	private void setScreenShell() {

		ScreenSize screenSize = ScreenSize.EIGHTY_PERCENT_SCREEN;

		Rectangle screenSizeBounds = mDisplay.getPrimaryMonitor().getBounds();

		int newWidth = (int) (screenSizeBounds.width * screenSize.getRatio());
		int newHeight = (int) (screenSizeBounds.height * screenSize.getRatio());

		int newX = (screenSizeBounds.width - newWidth) / 2;
		int newY = (screenSizeBounds.height - newHeight) / 2;

		mShell.setBounds(newX, newY, newWidth, newHeight);
	}

	public void open() {
		mShell.open();

		while (!mShell.isDisposed()) {
			if (!mDisplay.readAndDispatch()) {
				mDisplay.sleep();
			}
		}
	}

	public Shell getShell() {
		return mShell;
	}

	public Color getSystemColor(int colorId) {
		return mDisplay.getSystemColor(colorId);
	}

}
