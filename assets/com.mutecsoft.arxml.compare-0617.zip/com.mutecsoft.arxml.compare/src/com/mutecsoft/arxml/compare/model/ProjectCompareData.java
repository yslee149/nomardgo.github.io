package com.mutecsoft.arxml.compare.model;

public class ProjectCompareData {
	
	private ProjectData projectData1;
	private ProjectData projectData2;

	public ProjectCompareData(ProjectData projectData1, ProjectData projectData2) {
		this.projectData1 = projectData1;
		this.projectData2 = projectData2;
	}

	public ProjectData getProjectData1() {
		return projectData1;
	}

	public ProjectData getProjectData2() {
		return projectData2;
	}

	@Override
	public String toString() {
		return "ProjectCompareData [projectData1=" + projectData1.toString() + ", projectData2="
				+ projectData2.toString() + "]";
	}

}
