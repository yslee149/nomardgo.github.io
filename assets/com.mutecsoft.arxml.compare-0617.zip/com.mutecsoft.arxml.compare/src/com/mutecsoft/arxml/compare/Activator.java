package com.mutecsoft.arxml.compare;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.osgi.framework.BundleContext;

import com.mutecsoft.arxml.compare.db.DBService;
import com.mutecsoft.arxml.compare.db.SQLService;
import com.mutecsoft.arxml.compare.db.impl.DBServiceImpl;
import com.mutecsoft.arxml.compare.db.impl.SQLServiceImpl;

public class Activator extends AbstractUIPlugin {

	public static final String PLUGIN_ID = "com.mutecsoft.arxml.compare";

	private static Activator plugin;

	private DBService dbService;
	private SQLService sqlService;

	public Activator() {

	}

	public void start(BundleContext context) throws Exception {
		super.start(context);
		plugin = this;

		dbService = new DBServiceImpl();
		sqlService = new SQLServiceImpl(dbService);
	}

	public void stop(BundleContext context) throws Exception {
		dbService.closeDatabase();
		plugin = null;
		super.stop(context);
	}

	public static Activator getDefault() {
		return plugin;
	}

	public static ImageDescriptor getImageDescriptor(String path) {
		return imageDescriptorFromPlugin(PLUGIN_ID, path);
	}

	public DBService getDbService() {
		return dbService;
	}

	public SQLService getSqlService() {
		return sqlService;
	}
}
