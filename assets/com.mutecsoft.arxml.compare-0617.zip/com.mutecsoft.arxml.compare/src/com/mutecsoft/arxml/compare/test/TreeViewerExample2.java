package com.mutecsoft.arxml.compare.test;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.TreeViewerColumn;
import org.eclipse.jface.viewers.ViewerCell;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class TreeViewerExample2 {

    public static void main(String[] args) {
        Display display = new Display();
        Shell shell = new Shell(display);
        shell.setText("TreeViewer Example");
        shell.setSize(400, 300);

        TreeViewer viewer = new TreeViewer(shell, SWT.BORDER | SWT.FULL_SELECTION);
        viewer.getTree().setLinesVisible(true);
        viewer.getTree().setHeaderVisible(true);
        viewer.getTree().setBounds(10, 10, 380, 250);

        // First column
        TreeViewerColumn column1 = new TreeViewerColumn(viewer, SWT.LEFT);
        column1.getColumn().setText("Column 1");
        column1.getColumn().setWidth(100);
        column1.setLabelProvider(new ColumnLabelProvider() {
            @Override
            public String getText(Object element) {
                TreeNode node = (TreeNode) element;
                return node.getText(0);
            }
        });
        
        // Second column
        TreeViewerColumn column2 = new TreeViewerColumn(viewer, SWT.LEFT);
        column2.getColumn().setText("Column 2");
        column2.getColumn().setWidth(100);
        column2.setLabelProvider(new IndentedColumnLabelProvider(1));

        // Third column
        TreeViewerColumn column3 = new TreeViewerColumn(viewer, SWT.LEFT);
        column3.getColumn().setText("Column 3");
        column3.getColumn().setWidth(100);
        column3.setLabelProvider(new IndentedColumnLabelProvider(2));

        viewer.setContentProvider(new ITreeContentProvider() {
            @Override
            public Object[] getElements(Object inputElement) {
                return ((MyModel) inputElement).getElements();
            }

            @Override
            public Object[] getChildren(Object parentElement) {
                return ((TreeNode) parentElement).getChildren();
            }

            @Override
            public Object getParent(Object element) {
                return ((TreeNode) element).getParent();
            }

            @Override
            public boolean hasChildren(Object element) {
                return ((TreeNode) element).hasChildren();
            }
        });

        viewer.setInput(new MyModel());

        shell.open();
        while (!shell.isDisposed()) {
            if (!display.readAndDispatch()) {
                display.sleep();
            }
        }
        display.dispose();
    }

    static class MyModel {
        public TreeNode[] getElements() {
            TreeNode root1 = new TreeNode("Root 1");
            TreeNode root2 = new TreeNode("Root 2");

            TreeNode child1 = new TreeNode("Child 1");
            TreeNode child2 = new TreeNode("Child 2");
            TreeNode child3 = new TreeNode("Child 3");

            root1.setChildren(new TreeNode[] { child1, child2 });
            root2.setChildren(new TreeNode[] { child3 });

            return new TreeNode[] { root1, root2 };
        }
    }

    static class TreeNode {
        private String name;
        private TreeNode parent;
        private TreeNode[] children;

        public TreeNode(String name) {
            this.name = name;
            this.children = new TreeNode[0];
        }

        public void setParent(TreeNode parent) {
            this.parent = parent;
        }

        public TreeNode getParent() {
            return parent;
        }

        public void setChildren(TreeNode[] children) {
            this.children = children;
            for (TreeNode child : children) {
                child.setParent(this);
            }
        }

        public TreeNode[] getChildren() {
            return children;
        }

        public boolean hasChildren() {
            return children.length > 0;
        }

        public String getText(int columnIndex) {
            return name + " - Column " + (columnIndex + 1);
        }
    }

    static class IndentedColumnLabelProvider extends ColumnLabelProvider {
        private final int columnIndex;

        public IndentedColumnLabelProvider(int columnIndex) {
            this.columnIndex = columnIndex;
        }

        @Override
        public String getText(Object element) {
            TreeNode node = (TreeNode) element;
            return node.getText(columnIndex);
        }

        @Override
        public void update(ViewerCell cell) {
            super.update(cell);
            TreeNode node = (TreeNode) cell.getElement();
            int indentation = getIndentation(node);
            cell.setText(repeat(" ", indentation) + cell.getText());
            cell.setImage(getTreeIcon());
        }

        private int getIndentation(TreeNode node) {
            int indentation = 0;
            TreeNode parent = node.getParent();
            while (parent != null) {
                indentation += 2; // Customize the amount of indentation as needed
                parent = parent.getParent();
            }
            return indentation;
        }

        private String repeat(String str, int times) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < times; i++) {
                sb.append(str);
            }
            return sb.toString();
        }

        private Image getTreeIcon() {
            // Load your tree icon image here
            // For example, using ImageDescriptor:
            return ImageDescriptor.createFromFile(getClass(), "/path/to/treeicon.png").createImage();
        }
    }
}
