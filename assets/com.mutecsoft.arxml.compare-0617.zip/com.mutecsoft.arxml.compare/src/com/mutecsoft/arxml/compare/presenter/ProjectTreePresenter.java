package com.mutecsoft.arxml.compare.presenter;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.CoreException;

import com.mutecsoft.arxml.compare.CompareConstant.CompareType;
import com.mutecsoft.arxml.compare.CompareConstant.FileType;
import com.mutecsoft.arxml.compare.model.ProjectCompareData;
import com.mutecsoft.arxml.compare.model.ProjectData;
import com.mutecsoft.arxml.compare.model.ProjectDataBuilder;
import com.mutecsoft.arxml.compare.model.impl.ProjectDataBuilderImpl;
import com.mutecsoft.arxml.compare.view.ProjectTreeView;

public class ProjectTreePresenter {

	private ProjectTreeView view;

	public ProjectTreePresenter(ProjectTreeView view) {
		this.view = view;
	}

	public List<ProjectCompareData> getComparisonList(IProject project1, IProject project2) {

		ProjectDataBuilder dataBuilder = new ProjectDataBuilderImpl();
		try {
			List<ProjectCompareData> projectsDatas = dataBuilder.getProjectDataCompareList(project1, project2);

			projectsDatas.forEach(data -> {

				ProjectData projectData1 = data.getProjectData1();
//				ProjectData projectData2 = data.getProjectData2();

				if (projectData1.getCompareResult() == CompareType.SAME.getCode()
						&& projectData1.getFileType() == FileType.FILE.getCode()) {

					// TODO ���⼭ ARXML ������ ���� ������Ʈ ģ�� �������� �Ѿ��.
//					Activator.getDefault().getSqlService().update(ProjectDataQueryKey.UPDATE_COMPARE_RESULT.name(), 9, projectData2.getId());

				}

			});

			return projectsDatas;

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (CoreException e) {
			e.printStackTrace();
		}

		return new ArrayList<ProjectCompareData>();
	}

	public void onComparisonComplete(List<ProjectCompareData> projectsDatas) {

		if (projectsDatas.isEmpty()) {
			view.showError("�� �����Ͱ� �׽��ϴ�.");
		} else {
			view.displayComparisonResult(projectsDatas);
			view.showView();
		}

	}

	public ProjectTreeView getView() {
		return view;
	}

}
