package com.mutecsoft.arxml.compare.test.jxtree;

import java.util.ArrayList;
import java.util.List;

public class test {

	class FolderData {
		String folderPath = "";
		String name;
		int folderType; // 1 : ���� , 2: ����

		public FolderData(String folderPath, String name, int folderType) {
			this.folderPath = folderPath;
			this.name = name;
			this.folderType = folderType;
		}

	}

	public List<FolderData> folderDatas = new ArrayList<test.FolderData>();

	public void addData(String folderPath, String name, int folderType) {
		FolderData folderData = new FolderData(folderPath, name, folderType);
		folderDatas.add(folderData);
	}

	public static void main(String[] args) {

		test t = new test();

		t.addData("/folder1", "", 1);
		t.addData("/folder1/file1.txt", "", 2);
		t.addData("/folder1/file2.txt", "", 2);
		t.addData("/folder1/subfoler1", "", 1);
		t.addData("/folder1/subfoler1/file1.txt", "", 2);
		t.addData("/folder1/subfoler1/subsubfolder1", "", 1);
		t.addData("/folder1/subfoler1/subsubfolder1/file1.txt", "", 2);
		t.addData("/folder1/subfoler2", "", 1);
		t.addData("/folder1/subfoler2/file1.txt", "", 2);
		t.addData("/folder1/subfoler2/yslee-file.txt", "", 2);
		t.addData("/folder1/subfoler3", "", 1);
		t.addData("/folder1/subfoler3/file1.txt", "", 2);
		t.addData("/folder1/subfoler3/file2.txt", "", 2);
		t.addData("/folder1/subfoler3/subsubfolder3", "", 1);
		t.addData("/folder1/subfoler3/subsubfolder3/file1.txt", "", 2);

	}

}
