package com.mutecsoft.arxml.compare.util;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;

public class DialogUtil {

	public static void showWarning(Shell shell, String message) {

		MessageBox messageBox = new MessageBox(shell, SWT.ICON_WARNING);

		messageBox.setText("Warning");
		messageBox.setMessage(message);
		int buttonID = messageBox.open();
		System.out.println(buttonID);
	}

}
