package com.mutecsoft.arxml.compare.util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class SimpleLogger {

	private static boolean IS_SHOW_TIME_STAMP = false;

	public static void d(String message) {
		log(message, null);
	}

	public static void e(String message, Exception e) {
		log(message, e);
	}

	private static void log(String message, Exception e) {

		String logMessage = "";
		if (IS_SHOW_TIME_STAMP) {
			String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date());
			logMessage = String.format("%s %s", timestamp, message);
		} else {

			logMessage = message;
		}

		if (e == null) {
			System.out.println(logMessage);
		} else {
			System.err.println(logMessage);
			e.printStackTrace();
		}

	}

}
