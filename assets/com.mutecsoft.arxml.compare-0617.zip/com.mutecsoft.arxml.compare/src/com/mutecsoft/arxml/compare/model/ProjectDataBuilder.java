package com.mutecsoft.arxml.compare.model;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.CoreException;

import com.mutecsoft.arxml.compare.CompareConstant.ProjectType;

public interface ProjectDataBuilder {

	List<ProjectData> getProjectData(ProjectType projectType, IProject project) throws SQLException, CoreException;

	Map<ProjectType, List<ProjectData>> getProjectDataCompareMap(IProject project1, IProject project2)
			throws SQLException, CoreException;

	List<ProjectCompareData> getProjectDataCompareList(IProject project1, IProject project2)
			throws SQLException, CoreException;
}
