package com.mutecsoft.arxml.compare.test.tree;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeColumn;
import org.eclipse.swt.widgets.TreeItem;

public class CustomTreeSelectionColor {
	private static TreeItem[] selectedItems = new TreeItem[0];

	public static void main(String[] args) {
		Display display = new Display();
		Shell shell = new Shell(display);
		shell.setText("Custom Tree Selection Color Example");

		Tree tree = new Tree(shell, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL | SWT.CHECK);
		tree.setHeaderVisible(true);
		tree.setLinesVisible(true);
		tree.setSize(400, 300);

		// �÷� ����
		TreeColumn column1 = new TreeColumn(tree, SWT.NONE);
		column1.setText("Column 1");
		column1.setWidth(100);

		TreeColumn column2 = new TreeColumn(tree, SWT.NONE);
		column2.setText("Column 2");
		column2.setWidth(100);

		TreeColumn column3 = new TreeColumn(tree, SWT.NONE);
		column3.setText("Column 3");
		column3.setWidth(100);

		// ��Ʈ �׸� ����
		TreeItem root = new TreeItem(tree, SWT.NONE);
		root.setText(new String[] { "Root Item", "Root Column 2", "Root Column 3" });

		// �ڽ� �׸� ����
		TreeItem child1 = new TreeItem(root, SWT.NONE);
		child1.setText(new String[] { "Child Item 1", "Child Column 2", "Child Column 3" });

		TreeItem child2 = new TreeItem(root, SWT.NONE);
		child2.setText(new String[] { "Child Item 2", "Child Column 2", "Child Column 3" });

		root.setExpanded(true);

		Color selectionBackgroundColor = new Color(display, 173, 216, 230); // ���õ� �׸��� ����
		Color selectionTextColor = display.getSystemColor(SWT.COLOR_WHITE); // ���õ� �׸��� �ؽ�Ʈ ��

		tree.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				selectedItems = tree.getSelection();
				tree.redraw();
			}
		});

//		tree.addPaintListener(new PaintListener() {
//			@Override
//			public void paintControl(PaintEvent e) {
//				for (TreeItem item : selectedItems) {
//					for (int i = 0; i < tree.getColumnCount(); i++) {
//						e.gc.setBackground(selectionBackgroundColor);
//						e.gc.fillRectangle(item.getBounds(i));
//						e.gc.setForeground(selectionTextColor);
//						e.gc.drawText(item.getText(i), item.getBounds(i).x, item.getBounds(i).y);
//					}
//				}
//			}
//		});

		shell.setSize(450, 350);
		shell.open();

		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}

		selectionBackgroundColor.dispose();
		display.dispose();
	}
}
