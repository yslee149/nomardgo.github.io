package com.mutecsoft.atalk.constant;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public enum EnumPushType {

	FCM("A"),
	FCM2("F"),
	APNS("I");
	
	/////////////////////////////////////////////
	
	private final String value;
	
	EnumPushType(final String newValue) {
		value = newValue;
	}
	
	public String getValue(){
		return value;
	}
}
