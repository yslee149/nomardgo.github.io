package com.mutecsoft.atalk.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.mutecsoft.atalk.common.model.MUser;
import com.mutecsoft.atalk.common.repository.MUserRepository;
import com.mutecsoft.atalk.config.AtalkConfig;
import com.mutecsoft.atalk.logic.model.user.SearchUserRequest;
import com.mutecsoft.atalk.logic.model.user.SearchUserResponse;
import com.mutecsoft.atalk.logic.model.user.UserInfo;
import com.mutecsoft.atalk.service.AtalkSearchServiceLogic;

import jakarta.servlet.ServletContext;
import lombok.extern.slf4j.Slf4j;

/**
 * 검색 서비스
 * 
 */
@Slf4j
@Service("atalkSearchServiceLogic")
public class AtalkSearchServiceLogicImpl implements AtalkSearchServiceLogic {

	@Autowired
	MUserRepository mUserRepository;
	
	@Autowired
	AtalkConfig atalkConfig;

	@Autowired
    private ServletContext servletContext;
	
	@Override
	public SearchUserResponse searchUser(MUser user, SearchUserRequest reqObj)
			throws Exception {
		String searchWord = reqObj.getSearchWord();
		if (searchWord.trim().isEmpty()) {
			return null;
		}
		List<MUser> mUserList = mUserRepository.findByUserNameContainingIgnoreCaseAndUseYnAndActiveYn(searchWord, "Y", "Y");
		List<UserInfo> userList = Lists.newArrayList();
		if (mUserList != null) {
			for (MUser muser : mUserList) {
				if (muser.getUserNo().equals(user.getUserNo())) continue;
				UserInfo u = new UserInfo();
				u.setUserName(muser.getUserName());
				u.setUserNo(muser.getUserNo());
				u.setStatusMessage(muser.getStatusMessage());

				u.setProfileBgThumbUrl("");
				u.setProfileBgUrl("");
				u.setProfileFgThumbUrl("");
				u.setProfileFgUrl("");
				if (muser.getProfileBgNo() != null && !muser.getProfileBgNo().equals(0L)) {
					String url = String.format("%s%s%s/%s/%d",
							atalkConfig.getChatConfig().getBaseAddress()
							, servletContext.getContextPath()
							, atalkConfig.getProfileConfig().getBaseUrl()
							, "thumb", muser.getProfileBgNo());
					u.setProfileBgThumbUrl(url);
					url = String.format("%s%s%s/%s/%d",
							atalkConfig.getChatConfig().getBaseAddress()
							, servletContext.getContextPath()
							, atalkConfig.getProfileConfig().getBaseUrl()
							, "view", muser.getProfileBgNo());
					u.setProfileBgUrl(url);
				}
				if (muser.getProfileFgNo() != null && !muser.getProfileFgNo().equals(0L)) {
					String url = String.format("%s%s%s/%s/%d",
							atalkConfig.getChatConfig().getBaseAddress()
							, servletContext.getContextPath()
							, atalkConfig.getProfileConfig().getBaseUrl()
							, "thumb", muser.getProfileFgNo());
					u.setProfileFgThumbUrl(url);
					url = String.format("%s%s%s/%s/%d",
							atalkConfig.getChatConfig().getBaseAddress()
							, servletContext.getContextPath()
							, atalkConfig.getProfileConfig().getBaseUrl()
							, "view", muser.getProfileFgNo());
					u.setProfileFgUrl(url);
				}
				userList.add(u);
			}
		}
		///////////////////////// RESPONSE /////////////////////////////////////////////////////
		SearchUserResponse respObj = new SearchUserResponse();
		respObj.setUserList(userList);
		return respObj;
	}

	@Override
	public SearchUserResponse searchUserNoAuth(SearchUserRequest reqObj) throws Exception {
		String searchWord = reqObj.getSearchWord();
		if (searchWord.trim().isEmpty()) {
			return null;
		}
		
		List<MUser> mUserList = mUserRepository.findByUserIdAndUseYnAndActiveYn(searchWord, "Y", "Y");
		List<UserInfo> userList = Lists.newArrayList();
		if (mUserList != null) {
			for (MUser muser : mUserList) {
				UserInfo u = new UserInfo();
				u.setUserName(muser.getUserName());
				u.setUserNo(muser.getUserNo());
				userList.add(u);
			}
		}
		
		///////////////////////// RESPONSE /////////////////////////////////////////////////////
		SearchUserResponse respObj = new SearchUserResponse();
		respObj.setUserList(userList);
		return respObj;
	}
}
