package com.mutecsoft.atalk.security.oauth2.model;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
/**
 * @PackageName com.cnu.cas.mdms.app.security.oauth2.model
 * @fileName	AuthToken.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description :
 * <pre>
 *  AuthToken
 * </pre>
 */
@Builder
@Slf4j
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL) // null 제외
public class AuthToken {
	private String userId;
	private Map<String, String> moreInfo;
	private String accessToken;
	private String refreshToken;
}
