package com.mutecsoft.atalk.logic.model;

import java.io.Serializable;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * @PackageName com.mutecsoft.atalk.logic.model
 * @fileName	AtalkDataModelAll.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description :
 * <pre>
 * 
 * </pre>
 */
@Builder
@Setter
@Getter
public class AtalkDataModelAll implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8794053335049561276L;
	private SecureDataModel secureModel;
	private AtalkPacketBase atalkPacketBase;
	private int httpStatusCode;

	public void setAtalkPacketBase(AtalkPacketBase atalkPacketBase, String packetKey) throws Exception {
		this.atalkPacketBase = atalkPacketBase;
		setSecureModel(this.atalkPacketBase.toFinalModel());
	}
}
