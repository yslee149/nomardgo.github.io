package com.mutecsoft.atalk.web.controller.secure;

import com.mutecsoft.atalk.service.AtalkCtrlService;

import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;

import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @PackageName com.mutecsoft.atalk.web.secure.secure
 * @fileName	AtalkServiceController.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description :
 * <pre>
 * 
 * </pre>
 */
@Slf4j
@Tag(name="Service controller", description="Service Controller")
@Controller
@RequestMapping(value = "/api/v1/svcctrl")
public class AtalkServiceController {
	
	@Autowired
	AtalkCtrlService atalkCtrlService;	
	
	@PostConstruct
	private void init() throws NoSuchAlgorithmException, NoSuchProviderException {
		
	}
	
	/**
	 * 리셋 ALL 서비스
	 * 
	 * @param secureReqModel
	 * @return
	 */
	@GetMapping("/resetAll")
	public ResponseEntity<?> resetAll() {
		try {
			atalkCtrlService.resetAll(null);
			return new ResponseEntity<>("ok", HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Uprocessable");
	}
}
