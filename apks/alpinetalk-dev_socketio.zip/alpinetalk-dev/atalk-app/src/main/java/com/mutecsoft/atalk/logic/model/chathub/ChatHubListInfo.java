package com.mutecsoft.atalk.logic.model.chathub;

import java.io.Serializable;
import java.util.List;

/**
 * @PackageName com.mutecsoft.atalk.logic.model.chathub
 * @fileName	ChatHubListInfo.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description : 대화방정보
 * <pre>
 * 
 * </pre>
 */
public class ChatHubListInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -245976247312274504L;

	private Long chathubNo;
	private String chathubName;
	private String chathubType;
	private String encChathubKey;
	// private Long userNo;
	private Long usersNum;
	private String joinYn;
	
	private List<ChatHubUser> userList;
	
	private ChatInfoLast  lastChat; 

	public ChatInfoLast getLastChat() {
		return lastChat;
	}
	public void setLastChat(ChatInfoLast lastChat) {
		this.lastChat = lastChat;
	}
	//////////
	public String getEncChathubKey() {
		return encChathubKey;
	}
	public void setEncChathubKey(String encChathubKey) {
		this.encChathubKey = encChathubKey;
	}
	public Long getChathubNo() {
		return chathubNo;
	}
	public void setChathubNo(Long chathubNo) {
		this.chathubNo = chathubNo;
	}
	public String getChathubType() {
		return chathubType;
	}
	public void setChathubType(String chathubType) {
		this.chathubType = chathubType;
	}
	public String getChathubName() {
		return chathubName;
	}
	public void setChathubName(String chathubName) {
		this.chathubName = chathubName;
	}
	public Long getUsersNum() {
		return usersNum;
	}
	public void setUsersNum(Long usersNum) {
		this.usersNum = usersNum;
	}
	public String getJoinYn() {
		return joinYn;
	}
	public void setJoinYn(String joinYn) {
		this.joinYn = joinYn;
	}
	public List<ChatHubUser> getUserList() {
		return userList;
	}
	public void setUserList(List<ChatHubUser> userList) {
		this.userList = userList;
	}
	
}
