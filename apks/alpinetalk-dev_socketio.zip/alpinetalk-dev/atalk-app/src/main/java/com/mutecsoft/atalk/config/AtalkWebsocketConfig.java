package com.mutecsoft.atalk.config;

import java.io.FileInputStream;
import java.io.InputStream;
import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.stereotype.Component;

import com.corundumstudio.socketio.AckRequest;
import com.corundumstudio.socketio.Configuration;
import com.corundumstudio.socketio.SocketIOClient;
import com.corundumstudio.socketio.SocketIOServer;
import com.corundumstudio.socketio.listener.DataListener;
import com.corundumstudio.socketio.listener.ExceptionListener;
import com.mutecsoft.atalk.common.model.MUser;
import com.mutecsoft.atalk.common.repository.MUserRepository;
import com.mutecsoft.atalk.logic.model.chathub.ChatHubListInfo;
import com.mutecsoft.atalk.logic.model.chathub.ListChathubRequest;
import com.mutecsoft.atalk.logic.model.chathub.ListChathubResponse;
import com.mutecsoft.atalk.service.AtalkChatHubServiceLogic;

import io.netty.channel.ChannelHandlerContext;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Component
@NoArgsConstructor
@AllArgsConstructor
@Slf4j
public class AtalkWebsocketConfig {
	@Autowired
	AtalkConfig atalkConfig;
	
	@Autowired
	JwtUtils jwtUtils;
	
	@Autowired
	@Qualifier("accessTokenDecoder1")
	private JwtDecoder accessTokenDecoder1;
	
	// circular error !!!!
	@Autowired
	AtalkChatHubServiceLogic atalkChatHubServiceLogic;

	
	@Autowired
	MUserRepository mUserRepository;
	
	static SocketIOServer ioServer = null;
	
	@PreDestroy
	public void stopServer() {
        if (ioServer != null) {
        	log.info("#### Stopping WebSocket server...");
            ioServer.stop();
            log.info("#### WebSocket server stopped and port unbound.");
        }
    }
	
	/**
	 * 
	 * @param groupName
	 * @param message
	 */
	public static void broadCastToTheJoinedChathub(String groupName, String message) {
		try {
			if (ioServer !=null) {
				log.info("########## BROAD CAST : {}, {}", groupName, message);
				ioServer.getRoomOperations(groupName)
					.sendEvent("message", message);
			}
		} catch (Exception e) {
			log.error("@@@@ e : {}", e);
		}

	}
	
//	public static boolean isTokenExpired(Claims claims) {
//		try {
//			Date expirationDate = claims.getExpiration();
//			return expirationDate.before(new Date()); // Returns true if expired
//		} catch (Exception e) {
//			return true; // If parsing fails, consider token as expired
//		}
//	}
//	
	@PostConstruct
	public void init() {
		com.corundumstudio.socketio.Configuration config = new Configuration();
		config.setHostname("0.0.0.0");
		config.setPort(atalkConfig.getRealTimeWebsocketConfig().getPort());

		config.setOrigin("*");
		// Enable SSL
		if (atalkConfig.getRealTimeWebsocketConfig().getUseSsl().equals("Y")) {
			// Set keystore input stream and password
			try {
				InputStream keystoreStream = new FileInputStream(atalkConfig.getRealTimeWebsocketConfig().getKeystoreCertPass());
			
				config.setKeyStore(keystoreStream);
				config.setKeyStorePassword(atalkConfig.getRealTimeWebsocketConfig().getKeystorePassword());
			} catch (Exception e) {
				log.error("@@@@ : {}", e);
				System.exit(-1);
			}
		}
		ioServer = new SocketIOServer(config);
		ioServer.addEventListener("message", String.class, new DataListener<String>() {
			@Override
            public void onData(SocketIOClient client, String message, AckRequest ackRequest) {
            	log.info("#### Received from client [{}]: {}", client.getSessionId(), message);
            	// ✅ Send a response back to the sender
                client.sendEvent("message", "Server received: " + message);
            }
        });
		
		ioServer.addConnectListener(client-> {
			log.info("##### Client connected: " + client.getSessionId());
			
			// Extract query parameters (for token authentication)
			Map<String, List<String>> params = client.getHandshakeData().getUrlParams();
			List<String> tokenList = params.get("token");
			List<String> userNoList = params.get("user_no");
			
			String tokenValue = "";
			Long userNo = 0L;
			
			if (tokenList == null || tokenList.isEmpty()) {
				log.info("#### Connection rejected: No token provided.");
				client.disconnect();
			} else {
				tokenValue = tokenList.get(0);
				log.info("#### Received token: " + tokenList.get(0));
			}
			if (userNoList == null || userNoList.isEmpty()) {
				log.info("#### Connection rejected: No userId provided.");
				client.disconnect();
			} else {
				log.info("#### Received userId: " + userNoList.get(0));
				userNo = Long.valueOf(userNoList.get(0));
			}
			if (userNo < 1L) {
				client.disconnect();
			} else {
				Jwt jwtObj = accessTokenDecoder1.decode(tokenValue);
				if (jwtObj != null) {
					Map<String, Object> claimInfoObj = jwtObj.getClaims();
					
					Instant expInst = jwtObj.getExpiresAt();
					Date dt = Date.from(expInst);  
					String userId = (String)claimInfoObj.get("sub");
					String imei = (String)claimInfoObj.get("imei");
					
					Boolean bExpired = dt.before(new Date());
					if (bExpired != Boolean.TRUE) {
						
						// OK!!! LOGICS BELOW
						
						try {
							Optional<MUser> userObjOp = mUserRepository.findById(userNo);
							
							ListChathubRequest reqObj = new ListChathubRequest();
							reqObj.setUpdateDt("2000-01-01 00:00:00");
							ListChathubResponse chatHubListResp = atalkChatHubServiceLogic.listChathub(userObjOp.get(), reqObj);
							
							if (chatHubListResp != null) {
								
								List<ChatHubListInfo> chathubList = chatHubListResp.getChatHubListInfo();
								if (chathubList !=null) {
									for (ChatHubListInfo chatHubObk : chathubList) {
										Long chatHubNo = chatHubObk.getChathubNo();
										// websocket grouping by chathub no
										client.joinRoom(String.format("chathub_%d",  chatHubNo));  
										log.info("#### client [{}] joined room : {}", 
												client.getSessionId()
												, String.format("chathub_%d",  chatHubNo));
									}
								}
							}
							
						} catch (Exception e) {
							log.error("@@@@ get listChatHub joinend error : userId : {}", userId);
							client.disconnect();
						}
						
						
						
						
					} else {
						client.disconnect();	
					}
				} else {
					client.disconnect();
				}
			}
			// {iss=CASAPP, sub=voyzer@gmail.com, imei=44441111, exp=2025-02-10T02:39:53Z, iat=2025-01-31T02:39:53Z}
			// client.sendEvent("message123", "aaaaaaaaaaaaaaaaaaaa");
		});
		ioServer.addDisconnectListener(client-> {
			log.info("##### Client disconnected: " + client.getSessionId());
		});
        // Catch "Connection reset" exceptions by modifying Netty pipeline
		ioServer.getConfiguration().getSocketConfig().setReuseAddress(true);
		ioServer.getConfiguration().getSocketConfig().setTcpKeepAlive(true);

        // Modify Netty pipeline to catch low-level connection errors
		ioServer.getConfiguration().setExceptionListener(new ExceptionListener() {
			@Override
			public void onPongException(Exception e, SocketIOClient client) {
				// TODO Auto-generated method stub
				
			}
			@Override
			public void onPingException(Exception e, SocketIOClient client) {
				// TODO Auto-generated method stub
				
			}
			@Override
			public void onEventException(Exception e, List<Object> args, SocketIOClient client) {
				// TODO Auto-generated method stub
				
			}
			@Override
			public void onDisconnectException(Exception e, SocketIOClient client) {
				// TODO Auto-generated method stub
				
			}
			@Override
			public void onConnectException(Exception e, SocketIOClient client) {
				// TODO Auto-generated method stub
				
			}
			@Override
			public void onAuthException(Throwable e, SocketIOClient client) {
				// TODO Auto-generated method stub
				
			}
			@Override
			public boolean exceptionCaught(ChannelHandlerContext ctx, Throwable e) throws Exception {
				// TODO Auto-generated method stub
				return false;
			}
		});
//		ioServer.getConfiguration().getExceptionListener().onEventException(
//				new RuntimeException()
//				, new ArrayList<Object>()
//				, new SocketIOClient() {
//					@Override
//					public void send(Packet packet) {
//						// TODO Auto-generated method stub
//					}
//
//					@Override
//					public void disconnect() {
//						// TODO Auto-generated method stub
//						
//					}
//
//					@Override
//					public void sendEvent(String name, Object... data) {
//						// TODO Auto-generated method stub
//						
//					}
//
//					@Override
//					public void set(String key, Object val) {
//						// TODO Auto-generated method stub
//						
//					}
//
//					@Override
//					public <T> T get(String key) {
//						// TODO Auto-generated method stub
//						return null;
//					}
//
//					@Override
//					public boolean has(String key) {
//						// TODO Auto-generated method stub
//						return false;
//					}
//
//					@Override
//					public void del(String key) {
//						// TODO Auto-generated method stub
//						
//					}
//
//					@Override
//					public HandshakeData getHandshakeData() {
//						// TODO Auto-generated method stub
//						return null;
//					}
//
//					@Override
//					public Transport getTransport() {
//						// TODO Auto-generated method stub
//						return null;
//					}
//
//					@Override
//					public EngineIOVersion getEngineIOVersion() {
//						// TODO Auto-generated method stub
//						return null;
//					}
//
//					@Override
//					public boolean isWritable() {
//						// TODO Auto-generated method stub
//						return false;
//					}
//
//					@Override
//					public void sendEvent(String name, AckCallback<?> ackCallback, Object... data) {
//						// TODO Auto-generated method stub
//						
//					}
//
//					@Override
//					public void send(Packet packet, AckCallback<?> ackCallback) {
//						// TODO Auto-generated method stub
//						
//					}
//
//					@Override
//					public SocketIONamespace getNamespace() {
//						// TODO Auto-generated method stub
//						return null;
//					}
//
//					@Override
//					public UUID getSessionId() {
//						// TODO Auto-generated method stub
//						return null;
//					}
//
//					@Override
//					public SocketAddress getRemoteAddress() {
//						// TODO Auto-generated method stub
//						return null;
//					}
//
//					@Override
//					public boolean isChannelOpen() {
//						// TODO Auto-generated method stub
//						return false;
//					}
//
//					@Override
//					public void joinRoom(String room) {
//						// TODO Auto-generated method stub
//						
//					}
//
//					@Override
//					public void joinRooms(Set<String> rooms) {
//						// TODO Auto-generated method stub
//						
//					}
//
//					@Override
//					public void leaveRoom(String room) {
//						// TODO Auto-generated method stub
//						
//					}
//
//					@Override
//					public void leaveRooms(Set<String> rooms) {
//						// TODO Auto-generated method stub
//						
//					}
//
//					@Override
//					public Set<String> getAllRooms() {
//						// TODO Auto-generated method stub
//						return null;
//					}
//
//					@Override
//					public int getCurrentRoomSize(String room) {
//						// TODO Auto-generated method stub
//						return 0;
//					}
//				});
		ioServer.start();
		// Keep the server running
		Runtime.getRuntime().addShutdownHook(new Thread(ioServer::stop));
	}
}
