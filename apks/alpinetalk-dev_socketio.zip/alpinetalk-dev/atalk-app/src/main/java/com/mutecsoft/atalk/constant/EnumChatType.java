package com.mutecsoft.atalk.constant;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public enum EnumChatType {

	MESSAGE_GENERAL_TYPE("C"),		// 일반 대화
	MESSAGE_EXT_GENERAL_TYPE("E"),	// 퇴장
	
	MESSAGE_FILE_TYPE("F"),		// 파일타입
	MESSAGE_CANCELED_TYPE("R"), // 회수된 메시지
	
	MESSAGE_INFO_TYPE("I");		// 인포

	/////////////////////////////////////////////
	
	private final String value;
	
	EnumChatType(final String newValue) {
		value = newValue;
	}
	
	public String getValue(){
		return value;
	}
	
}

