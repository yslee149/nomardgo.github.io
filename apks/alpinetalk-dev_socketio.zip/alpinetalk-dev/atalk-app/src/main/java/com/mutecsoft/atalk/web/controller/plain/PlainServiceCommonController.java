package com.mutecsoft.atalk.web.controller.plain;

import com.mutecsoft.atalk.common.model.MUser;
import com.mutecsoft.atalk.common.repository.MUserRepository;
import com.mutecsoft.atalk.component.PacketDecryptor;
import com.mutecsoft.atalk.config.AuthTokenGenerator;
import com.mutecsoft.atalk.config.CustomAuthenticationProvider;
import com.mutecsoft.atalk.logic.model.amigo.AddAmigoRequest;

import com.mutecsoft.atalk.logic.model.amigo.AmigoDetailResponse;
import com.mutecsoft.atalk.logic.model.amigo.AmigoListResponse;
import com.mutecsoft.atalk.logic.model.amigo.DeleteAmigoRequest;
import com.mutecsoft.atalk.logic.model.amigo.DeleteAmigoResponse;
import com.mutecsoft.atalk.logic.model.auth.UserResultResponse;
import com.mutecsoft.atalk.security.oauth2.model.CustomUserDetail;
import com.mutecsoft.atalk.service.AtalkAmigoServiceLogic;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;

import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationProvider;
import org.springframework.security.provisioning.UserDetailsManager;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * @PackageName com.mutecsoft.atalk.web.controller.plain
 * @fileName	PlainAmigoController.java.java
 * @author voyzer
 * @Date   2024. 12. 1.
 * @description :
 * <pre>
 * 
 * </pre>
 */
@Slf4j
@Tag(name="Authentication", description="Authentication API")
@Controller
@RequestMapping(value = "/api/plain/v1/common")
public class PlainServiceCommonController {
	@Autowired
	UserDetailsManager userDetailsManager;
	
	@Autowired
	AuthTokenGenerator authTokenGenerator;
	
	@Autowired
	@Qualifier("jwtRefreshTokenAuthProvider")
	JwtAuthenticationProvider refreshTokenAuthProvider;
	
	@Autowired
	CustomAuthenticationProvider customAuthenticationProvider;
	
	@Autowired
	AtalkAmigoServiceLogic atalkAmigoServiceLogic;
	
	@Autowired
	PacketDecryptor packetDecryptor;

	@Autowired
	MUserRepository mUserRepository;
	
	/**
	 * 친구그룹 조회
	 * 
	 * @param authUser
	 * @return
	 */
	@RequestMapping(value="/info", method = {RequestMethod.POST, RequestMethod.GET})
	public ResponseEntity<?> list(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			) {
		try {
			log.debug("################# LIST AMIGO");
			AmigoListResponse respObj = atalkAmigoServiceLogic.amigoList(
					authUser.getMUser());
			return new ResponseEntity<>(respObj, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
}

