package com.mutecsoft.atalk.service;

import java.util.List;
import java.util.Optional;

import com.mutecsoft.atalk.logic.model.AtalkDataModelAll;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.security.oauth2.model.CustomUserDetail;

public interface AtalkChatHubService {
	// Pair<MChathub, String> getChatHubInfo2(Long myNo, ChathubInfoRequest reqObj) throws JsonProcessingException;

	Optional<AtalkDataModelAll> openChathub(CustomUserDetail authUser, SecureDataModel secModel) throws Exception;
	Optional<AtalkDataModelAll> openChathubByAmigoSetNo(CustomUserDetail authUser, Long amigoSetNo) throws Exception;
	
	Optional<AtalkDataModelAll> listChathub(CustomUserDetail authUser, SecureDataModel secModel) throws Exception;
	Optional<AtalkDataModelAll> invite(CustomUserDetail authUser, SecureDataModel secModel) throws Exception;
	Optional<AtalkDataModelAll> forceExit(CustomUserDetail authUser, Long chatHubNo, List<Long> userList) throws Exception;
	
	Optional<AtalkDataModelAll> exit(CustomUserDetail authUser, Long chatHubNo, String exitQuietly) throws Exception;
	Optional<AtalkDataModelAll> openChathubWithTitle(CustomUserDetail authUser, SecureDataModel secModel) throws Exception;
	Optional<AtalkDataModelAll> info(CustomUserDetail authUser, SecureDataModel secModel) throws Exception;
}
