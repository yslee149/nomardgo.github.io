package com.mutecsoft.atalk.logic.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * APP REQUEST BASE
 * 
 */
@Getter
@Setter
@ToString
public abstract class ReqAppBase<T> {
	// public abstract List<ResStockInCheckResultError> checkValidate();
	public abstract T toVo();
	
}
