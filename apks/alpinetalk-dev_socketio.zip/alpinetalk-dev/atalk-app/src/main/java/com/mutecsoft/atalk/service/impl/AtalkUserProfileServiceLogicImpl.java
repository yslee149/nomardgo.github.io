package com.mutecsoft.atalk.service.impl;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.imageio.ImageIO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.mutecsoft.atalk.common.model.MUser;
import com.mutecsoft.atalk.common.model.MUserProfile;
import com.mutecsoft.atalk.common.repository.MUserProfileRepository;
import com.mutecsoft.atalk.common.repository.MUserRepository;
import com.mutecsoft.atalk.component.PacketDecryptor;
import com.mutecsoft.atalk.component.redis.RedisTaskBroker;
import com.mutecsoft.atalk.config.AtalkConfig;
import com.mutecsoft.atalk.config.AuthTokenGenerator;
import com.mutecsoft.atalk.config.CustomAuthenticationProvider;
import com.mutecsoft.atalk.constant.EnumProfileType;
import com.mutecsoft.atalk.logic.model.user.SearchUserResponse;
import com.mutecsoft.atalk.logic.model.user.UserInfo;
import com.mutecsoft.atalk.logic.util.AesEncDecComplex;
import com.mutecsoft.atalk.service.AtalkUserProfileServiceLogic;
import com.mutecsoft.atalk.service.UserAccountService;
import com.mutecsoft.atalk.util.ImageComplex;

import jakarta.annotation.PostConstruct;
import jakarta.servlet.ServletContext;
import lombok.extern.slf4j.Slf4j;

/**
 * 사용자 프로필 서비스
 * 
 */
@Slf4j
@Service("atalkUserProfileServiceLogic")
public class AtalkUserProfileServiceLogicImpl implements AtalkUserProfileServiceLogic {

	@Autowired
	MUserProfileRepository mUserProfileRepository;

	@Autowired
	MUserRepository mUserRepository;
	
	@Autowired
	UserAccountService userAccountService;
	
	@Autowired
	RedisTaskBroker redisTaskBroker;
	
	@Autowired
	PacketDecryptor packetDecryptor;
	
	@Autowired
	DaoAuthenticationProvider daoAuthenticationProvider;

	@Autowired
	AuthTokenGenerator authTokenGenerator;
	
	@Autowired
	CustomAuthenticationProvider customAuthenticationProvider;
	
	@Autowired
	AtalkConfig  atalkConfig;
	
	@Autowired
	ServletContext servletContext;

	SimpleDateFormat dateFormatter;

	SimpleDateFormat dateFormatterForFilePath;
	
	@PostConstruct
	private void init() {
		dateFormatter = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		dateFormatterForFilePath = new SimpleDateFormat("yyyy/MM/dd");
	}
	@Override
	public Optional<MUserProfile> registProfileForeground(MUser user, String decryptKey, MultipartFile file) throws Exception {
		byte [] decBuffer = null;
		if (decryptKey==null) { // no encrypt
			decBuffer = file.getBytes();
		} else {
			decBuffer = AesEncDecComplex.decryptAesWithIv(file.getBytes(), decryptKey);  // AES DECRYPT
		}
		String originalFileName = file.getOriginalFilename();
		if (ImageComplex.checkImage(originalFileName, decBuffer)) {
			
			MUserProfile profile = _uploadProfileImage(user, decBuffer, EnumProfileType.FOREGROUND);
			return Optional.of(profile);
		}
		return Optional.empty();
	}

	@Override
	public Optional<MUserProfile> registProfileBackground(MUser user, String decryptKey, MultipartFile file) throws Exception {
		byte [] decBuffer = null;
		if (decryptKey==null) { // no encrypt
			decBuffer = file.getBytes();
		} else {
			decBuffer = AesEncDecComplex.decryptAesWithIv(file.getBytes(), decryptKey);  // AES DECRYPT	
		}
		String originalFileName = file.getOriginalFilename();
		
		if (ImageComplex.checkImage(originalFileName, decBuffer)) {
			
			MUserProfile profile = _uploadProfileImage(user, decBuffer, EnumProfileType.BACKGROUND);
			return Optional.of(profile);
		}
		return Optional.empty();
	}
	
	private MUserProfile _uploadProfileImage(MUser user, byte [] byteArr, EnumProfileType profileType) throws IOException, FileNotFoundException {
		
		String datePath = "";
		if (profileType==EnumProfileType.FOREGROUND) {
			datePath = String.format("%s/%s", "fg", dateFormatterForFilePath.format(new Date()));
		} else {
			datePath = String.format("%s/%s", "bg", dateFormatterForFilePath.format(new Date()));
		}
		
		BufferedImage bi = ImageIO.read(new ByteArrayInputStream(byteArr));
		BufferedImage biThumb = null;
		
		if (profileType.equals(EnumProfileType.FOREGROUND)) {
			biThumb = ImageComplex.resizeImageWithAspectRatio(
					bi
					, atalkConfig.getProfileConfig().getFgResolutionThumbWidth()
					, atalkConfig.getProfileConfig().getFgResolutionThumbHeight());
		} else if (profileType.equals(EnumProfileType.BACKGROUND)) {
			biThumb = ImageComplex.resizeImageWithAspectRatio(
					bi
					, atalkConfig.getProfileConfig().getBgResolutionThumbWidth()
					, atalkConfig.getProfileConfig().getBgResolutionThumbHeight());
		}
		
		if (biThumb==null) {
			return null;
		}
		
		String fileName = String.format("pf_%d_%s.png",
				user.getUserNo()
				, dateFormatter.format(new Date()));

		String thumbFileName = String.format("pft_%d_%s.png",
				user.getUserNo()
				, dateFormatter.format(new Date()));
		
		Path uploadPath = Paths.get(atalkConfig.getProfileConfig().getGroundFilePath(), datePath);
		if (!Files.exists(uploadPath)) {
			Files.createDirectories(uploadPath);
		}
		// 1. write thumb
		Path thumbFilePath = uploadPath.resolve(thumbFileName);
		FileOutputStream fos = new FileOutputStream(thumbFilePath.toFile());
		ImageIO.write(biThumb, "png", fos);
		
		// 2. write original
		Path filePath = uploadPath.resolve(fileName);
		fos = new FileOutputStream(filePath.toFile());
		ImageIO.write(bi, "png", fos);
		
		MUserProfile mUserProfile = new MUserProfile();

		mUserProfile.setProfileType(profileType.getValue());
		mUserProfile.setUseYn("Y");
		mUserProfile.setRegDate(new Date());
		mUserProfile.setFileSize(Long.valueOf(byteArr.length));
		mUserProfile.setThumbnailPath(thumbFilePath.toString());
		mUserProfile.setFilePath(filePath.toString());
		mUserProfile.setFileName(fileName);
		
		mUserProfileRepository.save(mUserProfile);
		if (profileType.equals(EnumProfileType.FOREGROUND)) {
			user.setProfileFgNo(mUserProfile.getProfileNo());
		} else if (profileType.equals(EnumProfileType.BACKGROUND)) {
			user.setProfileBgNo(mUserProfile.getProfileNo());
		}
		mUserRepository.save(user);
		return mUserProfile;
	}

	@Override
	public SearchUserResponse updateProfileImage(MUser user
			, EnumProfileType profileType
			, MultipartFile file) throws Exception {
		///////////////////////// RESPONSE /////////////////////////////////////////////////////
		
		Optional<MUserProfile>  profileObjOp =  null;
		SearchUserResponse respObj = new SearchUserResponse();
		List<UserInfo> l = new ArrayList<UserInfo>();
		UserInfo obj = new UserInfo();
		
		String contextPath = servletContext.getContextPath();
		if (profileType.equals(EnumProfileType.BACKGROUND)) {
			profileObjOp = this.registProfileBackground(user, null, file);
			
			String url = String.format("%s%s%s/%s/%d",
					atalkConfig.getChatConfig().getBaseAddress()
					, contextPath
					, atalkConfig.getProfileConfig().getBaseUrl()
					, "thumb", profileObjOp.get().getProfileNo());
			obj.setProfileBgThumbUrl(url);
			url = String.format("%s%s%s/%s/%d",
					atalkConfig.getChatConfig().getBaseAddress()
					, contextPath
					, atalkConfig.getProfileConfig().getBaseUrl()
					, "view", profileObjOp.get().getProfileNo());
			obj.setProfileBgUrl(url);
		} else if (profileType.equals(EnumProfileType.FOREGROUND)) {
			profileObjOp = this.registProfileForeground(user, null, file);
			
			String url = String.format("%s%s%s/%s/%d",
					atalkConfig.getChatConfig().getBaseAddress()
					, contextPath
					, atalkConfig.getProfileConfig().getBaseUrl()
					, "thumb", profileObjOp.get().getProfileNo());
			obj.setProfileFgThumbUrl(url);
			url = String.format("%s%s%s/%s/%d",
					atalkConfig.getChatConfig().getBaseAddress()
					, contextPath 
					, atalkConfig.getProfileConfig().getBaseUrl()
					, "view", profileObjOp.get().getProfileNo());
			obj.setProfileFgUrl(url);
		}
		obj.setUserName(user.getUserName());
		obj.setUserNo(user.getUserNo());
		obj.setStatusMessage(user.getStatusMessage());
		l.add(obj);
		respObj.setUserList(l);
		return respObj;
	}
}
