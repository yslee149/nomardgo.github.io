package com.mutecsoft.atalk.config;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;

import java.time.Instant;
import java.util.Collections;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.authentication.AuthenticationProvider;

import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.security.provisioning.UserDetailsManager;
import org.springframework.stereotype.Component;

import com.mutecsoft.atalk.security.UserDetailsManageService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class CustomAuthenticationProvider implements AuthenticationProvider {

	@Autowired
	UserDetailsManager userDetailsManager;
	
	@Autowired
	UserDetailsManageService userDetailsService;
	
    @Autowired
    PasswordEncoder passwordEncoder;
	
	@Autowired
	@Qualifier("accessTokenDecoder1")
	private JwtDecoder accessTokenDecoder1;

	@Autowired
	@Qualifier("refreshTokenDecoder1")
	private JwtDecoder refreshTokenDecoder1;
	

//	public CustomAuthenticationProvider(UserDetailsService userDetailsService, PasswordEncoder passwordEncoder) {
//		this.userDetailsService = userDetailsService;
//		this.passwordEncoder = passwordEncoder;
//	}

	public CustomAuthenticationProvider() {
	}
	
	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		String username = authentication.getName();
		String password = (String) authentication.getCredentials();
		
		// Load user details from the database (or another source)
		UserDetails userDetails = userDetailsService.loadUserByUsername(username);
		
		if (userDetails == null) {
			throw new BadCredentialsException("User not found");
		}
		
//		if (userDetails instanceof CustomUserDetail) {
//			CustomUserDetail customUserDetail = (CustomUserDetail) userDetails;
//			if (StringUtils.isEmpty(customUserDetail.getTmpPassword())) {
//				// Compare passwords using the PasswordEncoder (BCrypt in this case)
//				if (!passwordEncoder.matches(password, userDetails.getPassword())) {
//					throw new BadCredentialsException("Invalid password");
//				}				
//			} else {
//				// check tmp_password one more
//				if (!passwordEncoder.matches(password, userDetails.getPassword())) {
//					if (!passwordEncoder.matches(password, customUserDetail.getTmpPassword())) {
//						throw new BadCredentialsException("Invalid password");
//					}
//				}
//			}
//		}
		// If everything is correct, return the authentication token
		return new UsernamePasswordAuthenticationToken(userDetails, password, userDetails.getAuthorities());
	}

	@Override
	public boolean supports(Class<?> authentication) {
		return UsernamePasswordAuthenticationToken.class.isAssignableFrom(authentication);
	}

	/**
	 * check validation for access token
	 * 
	 * @param accessToken
	 * @return
	 */
	public Boolean validateAccessToken(String accessToken) {

		Jwt jwt = accessTokenDecoder1.decode(accessToken);
		log.debug("#### jwt_expired(REFRESH) at : {}", jwt.getExpiresAt());
		Instant expiredInst = jwt.getExpiresAt();
		Instant now = Instant.now();

		return now.isBefore(expiredInst);
	}
	
	/**
	 * check validation for refresh token
	 * 
	 * @param refreshToken
	 * @return
	 */
	public Boolean validateRefreshToken(String refreshToken) {
		
		Jwt jwt = refreshTokenDecoder1.decode(refreshToken);
		log.debug("#### jwt_expired(REFRESH) at : {}", jwt.getExpiresAt());
		Instant expiredInst = jwt.getExpiresAt();
		Instant now = Instant.now();
		
		return now.isBefore(expiredInst);
	}

	@SuppressWarnings("unchecked")
	public Authentication getAuthenticationFromRefreshToken(String refreshToken) {
		Jwt jwt = refreshTokenDecoder1.decode(refreshToken);
		return new JwtAuthenticationToken(jwt, Collections.EMPTY_LIST);
		
//		String username = getUsernameFromRefreshToken(refreshToken);
//		UserDetails userDetails = userDetailsService.loadUserByUsername(username);
//		// Create the Authentication object (with authorities/roles from the user details)
//		return new UsernamePasswordAuthenticationToken(userDetails, "", userDetails.getAuthorities());
	}
	
	// Method to extract the username from the JWT token
	public String getUsernameFromRefreshToken(String token) {
		Jwt jwt = refreshTokenDecoder1.decode(token);
		log.debug("#### jwt_expired(REFRESH) at : {}", jwt.getExpiresAt());
		return jwt.getSubject();
	}
//
//    // Method to extract roles, expiration, etc. from the token
//    public Claims getClaims(String token) {
//        return Jwts.parser().setSigningKey(secretKey).parseClaimsJws(token).getBody();
//    }
//
//    // Method to check if the token is valid (signature and expiration)
//    public boolean validateToken(String token) {
//        try {
//            Jwts.parser().setSigningKey(secretKey).parseClaimsJws(token);
//            return true;
//        } catch (Exception e) {
//            return false;
//        }
//    }
}
