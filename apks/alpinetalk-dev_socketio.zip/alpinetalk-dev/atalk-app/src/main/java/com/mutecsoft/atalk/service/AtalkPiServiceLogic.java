package com.mutecsoft.atalk.service;

import com.mutecsoft.atalk.common.model.MUser;
import com.mutecsoft.atalk.logic.model.pi.PiAgreementResponse;
import com.mutecsoft.atalk.logic.model.response.AgreementResponse;

public interface AtalkPiServiceLogic {
	
	PiAgreementResponse getLatestPiAgreement() throws Exception;
	
	Long agree(MUser user, Long version) throws Exception;
//	
	AgreementResponse getHist(MUser user) throws Exception;
}

