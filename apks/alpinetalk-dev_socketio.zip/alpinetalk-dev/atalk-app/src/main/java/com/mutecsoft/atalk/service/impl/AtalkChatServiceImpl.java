package com.mutecsoft.atalk.service.impl;

import java.security.SecureRandom;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.mutecsoft.atalk.common.model.MUser;
import com.mutecsoft.atalk.component.PacketDecryptor;
import com.mutecsoft.atalk.component.redis.RedisTaskBroker;
import com.mutecsoft.atalk.constant.EnumChatSubType;
import com.mutecsoft.atalk.logic.model.AtalkDataModelAll;
import com.mutecsoft.atalk.logic.model.AtalkPacketBase;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.logic.model.chat.ChatInfoRequest;
import com.mutecsoft.atalk.logic.model.chat.ChatInfoResponse;
import com.mutecsoft.atalk.logic.model.chat.ChatResponse;
import com.mutecsoft.atalk.logic.model.chat.DeleteChatRequest;
import com.mutecsoft.atalk.logic.model.chat.DeleteChatResponse;
import com.mutecsoft.atalk.logic.model.chat.ExtChatResponse;
import com.mutecsoft.atalk.logic.model.chat.ReadChatRequest;
import com.mutecsoft.atalk.logic.model.chat.ReadChatResponse;
import com.mutecsoft.atalk.logic.model.chat.RetrieveChatRequest;
import com.mutecsoft.atalk.logic.model.chat.RetrieveChatResponse;
import com.mutecsoft.atalk.logic.model.chat.SendChatRequest;
import com.mutecsoft.atalk.logic.model.chat.SendChatResponse;
import com.mutecsoft.atalk.logic.model.chat.SendFileChatResponse;
import com.mutecsoft.atalk.logic.util.BufferComplex;
import com.mutecsoft.atalk.logic.util.RandomHexString;
import com.mutecsoft.atalk.secure.model.redis.RedisPacketKeySeed;
import com.mutecsoft.atalk.security.oauth2.model.CustomUserDetail;
import com.mutecsoft.atalk.service.AtalkChatService;
import com.mutecsoft.atalk.service.AtalkChatServiceLogic;
import com.mutecsoft.atalk.service.UserAccountService;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;

/**
 * 채팅방 관련 서비스
 * 
 */
@Slf4j
@Service("atalkChatService")
public class AtalkChatServiceImpl implements AtalkChatService {

	@Autowired
	UserAccountService userAccountService;
	
	@Autowired
	RedisTaskBroker redisTaskBroker;
	
	@Autowired
	PacketDecryptor packetDecryptor;
	
	@Autowired
    AtalkChatServiceLogic atalkChatServiceLogic;
    
	@PostConstruct
	private void init() {
	}

	@Override
	public Optional<AtalkDataModelAll> procMessage(CustomUserDetail authUser, SecureDataModel secModel)
			throws Exception {
		log.debug("################# SEND CHAT MESSAGE");
		MUser user = userAccountService.getUserByUserId(authUser.getUserId());
		if (user != null) {
			
			String [] decryptPacketData = packetDecryptor.packetStringFromModel(secModel);
			if (decryptPacketData == null || decryptPacketData[0].equals("")) {
				return Optional.ofNullable(null);
			}
			String objectJson = decryptPacketData[0];
			String packetKey = decryptPacketData[1];
			log.debug("#### request string : {}", objectJson);
			SendChatRequest reqObj = AtalkPacketBase.fromJson(objectJson, SendChatRequest.class);
			SendChatResponse respObj = atalkChatServiceLogic.procMessage(user, reqObj);
			if (respObj == null) {
				return Optional.ofNullable(null);
			}
			///////////////////////// RESPONSE /////////////////////////////////////////////////////
			AtalkDataModelAll resData = AtalkDataModelAll.builder()
					.httpStatusCode(200)
					.atalkPacketBase(respObj)
					.secureModel(respObj.toFinalModel(packetKey))
					.build();
			resData.getSecureModel().setTransactinId(secModel.getTransactinId());
			return Optional.of(resData);
			// return new ResponseEntity<>(resData.getSecureModel(), HttpStatus.OK);
		}
		return Optional.ofNullable(null);
	}
	
	@Override
	public Optional<AtalkDataModelAll> chatList(CustomUserDetail authUser, SecureDataModel secModel) throws Exception {
		log.debug("################# GET CHAT MESSAGE");
		MUser user = userAccountService.getUserByUserId(authUser.getUserId());
		if (user != null) {
			String [] decryptPacketData = packetDecryptor.packetStringFromModel(secModel);
			if (decryptPacketData == null || decryptPacketData[0].equals("")) {
				return Optional.ofNullable(null);
			}
			String objectJson = decryptPacketData[0];
			String packetKey = decryptPacketData[1];
			log.debug("#### request string : {}", objectJson);
			ChatInfoRequest reqObj = AtalkPacketBase.fromJson(objectJson, ChatInfoRequest.class);
			ChatInfoResponse respObj = atalkChatServiceLogic.chatList(user, reqObj);
			if (respObj == null) {
				return Optional.ofNullable(null);
			}			
			///////////////////////// RESPONSE /////////////////////////////////////////////////////
			AtalkDataModelAll resData = AtalkDataModelAll.builder()
					.httpStatusCode(200)
					.atalkPacketBase(respObj)
					.secureModel(respObj.toFinalModel(packetKey))
					.build();
			resData.getSecureModel().setTransactinId(secModel.getTransactinId());
			return Optional.of(resData);
			// return new ResponseEntity<>(resData.getSecureModel(), HttpStatus.OK);
		}
		return Optional.ofNullable(null);
	}
	
	@Override
	public Optional<AtalkDataModelAll> procFileMessage(
			CustomUserDetail authUser
			, Long chathubNo
			, String fileType
			, MultipartFile file)
			throws Exception {
		
		if (chathubNo == null || chathubNo <= 0L) {
			return Optional.ofNullable(null);
		}
		if (!fileType.equals(EnumChatSubType.MESSAGE_SUB_IMAGE_TYPE.getValue())
			&&
			!fileType.equals(EnumChatSubType.MESSAGE_SUB_MOVIE_TYPE.getValue())
			&&
			!fileType.equals(EnumChatSubType.MESSAGE_SUB_DECUMENT_TYPE.getValue())
			&&
			!fileType.equals(EnumChatSubType.MESSAGE_SUB_GENFILE_TYPE.getValue())) {
			log.error("@@@@ invalid file type : {}, chathub no : {}, userId : {}",
					fileType, chathubNo, authUser.getUserId());
			return Optional.ofNullable(null);
		}
		// String packetKey = packetDecryptor.packetKeyFromUserNo(user.getUserNo());
		// 0. get transaction id and seed value
		byte [] targetBuffer = file.getBytes();
		// targetBuffer.length
		// 60AD14753077B89D9A2B58AEE85FAFD2  16 byte : seed value
		// 2BE4A2C251E72DCD  8 byte   : transaction id
//			
		byte [] infoBuffer = BufferComplex.getLastNBytes(targetBuffer, 16 + 8);
		byte [] transactionBuffer = BufferComplex.getLastNBytes(infoBuffer, 8);
		byte [] packetSeedValBuffer = BufferComplex.getFrontBytes(infoBuffer, 16);

		String packetKey = packetDecryptor.getPacketKey(BufferComplex.bytesToHex(packetSeedValBuffer));
		MUser user = userAccountService.getUserByUserId(authUser.getUserId());
		if (user != null) {
			SendFileChatResponse respObj = atalkChatServiceLogic.procFileMessage(user, chathubNo, fileType, file);
			if (respObj == null) {
				return Optional.ofNullable(null);
			}
			///////////////////////// RESPONSE /////////////////////////////////////////////////////
			AtalkDataModelAll resData = AtalkDataModelAll.builder()
					.httpStatusCode(200)
					.atalkPacketBase(respObj)
					.secureModel(respObj.toFinalModel(packetKey))
					.build();
			resData.getSecureModel().setTransactinId(BufferComplex.bytesToHex(transactionBuffer));
			return Optional.of(resData);
		}
		return Optional.ofNullable(null);
	}

	@Override
	public Optional<AtalkDataModelAll> getExtChat(CustomUserDetail authUser, Long extChatNo) throws Exception {
		MUser user = userAccountService.getUserByUserId(authUser.getUserId());
		if (user != null) {
			RedisPacketKeySeed redisKeyObj = redisTaskBroker.findKeyObjectByUserNo(user.getUserNo());
			String packetKey = redisKeyObj.getPacketKey();
			
			ExtChatResponse respObj = atalkChatServiceLogic.getExtChat(user, extChatNo);
			if (respObj == null) {
				return Optional.ofNullable(null);
			}
			///////////////////////// RESPONSE /////////////////////////////////////////////////////
			AtalkDataModelAll resData = AtalkDataModelAll.builder()
					.httpStatusCode(200)
					.atalkPacketBase(respObj)
					.secureModel(respObj.toFinalModel(packetKey))
					.build();
			resData.getSecureModel().setTransactinId(RandomHexString.genSecureRandomHex(16));
			return Optional.of(resData);
		}
		return Optional.empty();
	}

	@Override
	public Optional<AtalkDataModelAll> deleteChatList(CustomUserDetail authUser, SecureDataModel secModel)
			throws Exception {
		log.debug("################# DELETE CHAT MESSAGE");
		MUser user = userAccountService.getUserByUserId(authUser.getUserId());
		if (user != null) {
			String [] decryptPacketData = packetDecryptor.packetStringFromModel(secModel);
			if (decryptPacketData == null || decryptPacketData[0].equals("")) {
				return Optional.ofNullable(null);
			}
			String objectJson = decryptPacketData[0];
			String packetKey = decryptPacketData[1];
			log.debug("#### request string : {}", objectJson);
			DeleteChatRequest reqObj = AtalkPacketBase.fromJson(objectJson, DeleteChatRequest.class);
			DeleteChatResponse respObj = atalkChatServiceLogic.deleteChatList(user, reqObj);
			if (respObj == null) {
				return Optional.ofNullable(null);
			}
			///////////////////////// RESPONSE /////////////////////////////////////////////////////
			respObj.setResult(Boolean.TRUE);
			AtalkDataModelAll resData = AtalkDataModelAll.builder()
					.httpStatusCode(200)
					.atalkPacketBase(respObj)
					.secureModel(respObj.toFinalModel(packetKey))
					.build();
			resData.getSecureModel().setTransactinId(secModel.getTransactinId());
			return Optional.of(resData);
		}
		return Optional.ofNullable(null);
	}

	@Override
	public Optional<AtalkDataModelAll> retrieveChatList(CustomUserDetail authUser, SecureDataModel secModel)
			throws Exception {
		log.debug("################# RETRIEVE CHAT MESSAGE");
		MUser user = userAccountService.getUserByUserId(authUser.getUserId());
		if (user != null) {
			String [] decryptPacketData = packetDecryptor.packetStringFromModel(secModel);
			if (decryptPacketData == null || decryptPacketData[0].equals("")) {
				return Optional.ofNullable(null);
			}
			String objectJson = decryptPacketData[0];
			String packetKey = decryptPacketData[1];
			log.debug("#### request string : {}", objectJson);
			RetrieveChatRequest reqObj = AtalkPacketBase.fromJson(objectJson, RetrieveChatRequest.class);
			RetrieveChatResponse respObj = atalkChatServiceLogic.retrieveChatList(user, reqObj);
			if (respObj == null) {
				return Optional.ofNullable(null);
			}
			///////////////////////// RESPONSE /////////////////////////////////////////////////////
			AtalkDataModelAll resData = AtalkDataModelAll.builder()
					.httpStatusCode(200)
					.atalkPacketBase(respObj)
					.secureModel(respObj.toFinalModel(packetKey))
					.build();
			resData.getSecureModel().setTransactinId(secModel.getTransactinId());
			return Optional.of(resData);
		}
		return Optional.ofNullable(null);
	}
	

	public String makeRandomPw(int len) {
	    // 소문자, 대문자, 숫자 
		final String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
		SecureRandom rm = new SecureRandom();
		StringBuffer sb = new StringBuffer();
		for (int i=0; i<len; i++) {
			int index = rm.nextInt(chars.length());
			//index의 위치한 랜덤값
			sb.append(chars.charAt(index));
		}
		return sb.toString();
	}

	@Override
	public Optional<AtalkDataModelAll> readChat(CustomUserDetail authUser, SecureDataModel secModel) throws Exception {

		MUser user = userAccountService.getUserByUserId(authUser.getUserId());
		if (user != null) {
			String [] decryptPacketData = packetDecryptor.packetStringFromModel(secModel);
			if (decryptPacketData == null || decryptPacketData[0].equals("")) {
				return Optional.ofNullable(null);
			}
			String objectJson = decryptPacketData[0];
			String packetKey = decryptPacketData[1];
			log.debug("#### request string : {}", objectJson);
			
			//////////////////////////////////////////////////////////////////////////
			ReadChatRequest reqObj = AtalkPacketBase.fromJson(objectJson, ReadChatRequest.class);
			ReadChatResponse respObj = atalkChatServiceLogic.readChat(user, reqObj);
			if (respObj == null) {
				return Optional.ofNullable(null);
			}
			///////////////////////// RESPONSE /////////////////////////////////////////////////////
			AtalkDataModelAll resData = AtalkDataModelAll.builder()
				.httpStatusCode(200)
				.atalkPacketBase(respObj)
				.secureModel(respObj.toFinalModel(packetKey))
				.build();
			resData.getSecureModel().setTransactinId(secModel.getTransactinId());
			return Optional.of(resData);
		}
		return Optional.ofNullable(null);
	}

	@Override
	public Optional<AtalkDataModelAll> get(CustomUserDetail authUser, Long chatHubNo, Long chatNo) throws Exception {
		MUser user = userAccountService.getUserByUserId(authUser.getUserId());
		if (user != null) {
			RedisPacketKeySeed redisKeyObj = redisTaskBroker.findKeyObjectByUserNo(user.getUserNo());
			String packetKey = redisKeyObj.getPacketKey();
			
			ChatResponse respObj = atalkChatServiceLogic.get(user.getUserNo(), chatHubNo, chatNo);
			
			if (respObj == null) {
				return Optional.ofNullable(null);
			}
			///////////////////////// RESPONSE /////////////////////////////////////////////////////
			AtalkDataModelAll resData = AtalkDataModelAll.builder()
					.httpStatusCode(200)
					.atalkPacketBase(respObj)
					.secureModel(respObj.toFinalModel(packetKey))
					.build();
			resData.getSecureModel().setTransactinId(RandomHexString.genSecureRandomHex(16));
			return Optional.of(resData);
		}
		return Optional.empty();
	}
}
