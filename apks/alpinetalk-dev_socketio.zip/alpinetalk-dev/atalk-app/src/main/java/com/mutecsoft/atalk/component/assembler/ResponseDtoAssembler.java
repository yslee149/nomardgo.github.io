package com.mutecsoft.atalk.component.assembler;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.hateoas.CollectionModel;
import org.springframework.stereotype.Component;

import com.mutecsoft.atalk.logic.model.response.ResPageInfo;
import com.mutecsoft.atalk.logic.model.response.ResResult;
import com.mutecsoft.atalk.model.presentation.ResponseDto;
import com.mutecsoft.atalk.model.presentation.ResponseOkDto;
import com.mutecsoft.atalk.model.presentation.ResponsePageDto;

import lombok.extern.slf4j.Slf4j;

/**
 * @PackageName com.cnu.cas.mdms.app.ia.component.assembler
 * @fileName	ResponseDtoAssembler.java
 * @author voyzer
 * @Date   2024. 9. 3.
 * @description :
 * <pre>
 * 
 * </pre>
 */
@Slf4j
@Component
public class ResponseDtoAssembler {
	
	@Autowired	
	private MessageSource messageSource;
	
	public <T> ResponseDto<?> toResouce(CollectionModel<T> data) {	
		log.debug("data : {} ", data);
		return toResouce(200, data.getContent());
	}

	public <T> ResponsePageDto<?> toResouce(CollectionModel<T> data, ResPageInfo pageInfo) {	
		log.debug("data : {} ", data);
		return toResouce(200, data.getContent(),pageInfo);
	}
	
	public <T> ResponseDto<?> toResouce(T data) {	
		log.debug("data : {} ", data);
		return toResouce(200, data);
	}
	
	public <T> ResponseOkDto<T> toResouceOk(ResResult data) {	
		log.debug("data : {} ", data);
		return toResouceOk( 
				data.getBoolVal().equals(Boolean.TRUE) ? 200 : 401, data);
	}
	
	public <T> ResponseOkDto<?> toResouceOkWithStatus(int statusCode, String data) {	
		log.debug("data : {} ", data);
		return toResouceOk(statusCode, data);
	}
	
	/**
	 * <pre>
	 *	메시지를 알리기 위해
	 * </pre>
	 * @param <T>
	 * @param data
	 * @param message
	 * @return
	 */
	public <T> ResponseDto<?> toResouceAndMessage(T data, String message){
		return ResponseDto.<T>builder()
//				.statusCode(200)
//				.errorMessage(message)
				.data((T) data)
				.build();
	}
	
	@SuppressWarnings("unchecked")
	public <T> ResponseDto<?> toResouceMap(Map<String,Object> data){
		
		int status = (int) data.getOrDefault("status", 200);
		String msg = (String) data.getOrDefault("msg", "00");
		if (status == 200) {			
			return toResouce(data);
		} else {
			return ResponseDto.<T>builder()
//					.statusCode(status)
//					.errorMessage(messageSource.getMessage(msg, null, "성공하였습니다", Locale.getDefault()))
					.data((T) data)
					.build();
		}
	}	
	
	@SuppressWarnings("unchecked")
	public <T> ResponseDto<?> toResouceResponse(Map<String,Object> response){
		
		int status = (int) response.getOrDefault("status", 200);
		String msg = (String) response.getOrDefault("msg", "");	
		
		log.debug("msg : {} ", msg);
		List<String> args = null;
		
		if (!StringUtils.isEmpty(msg)) {
			String [] msgArgs = msg.split(",");
			log.debug("msgArgs : {} ", msgArgs);
			msg = msgArgs[0];
			if(msgArgs.length > 1) {
				args = IntStream.range(0, msgArgs.length)
				         .filter(i -> i > 0)
				         .mapToObj(i -> msgArgs[i])
				         .collect(Collectors.toList());
				
			}
			return ResponseDto.<T>builder()
					//.statusCode(status)
					//.errorMessage(messageSource.getMessage(msg, (args ==  null)? null : args.toArray(new String[args.size()]), Locale.getDefault()))
					.data((T) response.get("data"))
					.build();
		} else {
			return ResponseDto.<T>builder()
//					.statusCode(status)
//					.errorMessage("")
					.data((T) response.get("data"))
					.build();
		}
	}	


	public <T> ResponseDto<?> toResouce(int status, T data) {	
		log.debug("Locale : {} ", Locale.getDefault());
		return ResponseDto.<T>builder()
//				.statusCode(status)
//				.errorMessage("")
				.data(data)
				.build();
	}
	
	public <T> ResponseOkDto<?> toResouceOk(int status, String errMessage) {	
		log.debug("Locale : {} ", Locale.getDefault());
		return ResponseOkDto.<T>builder()
				.statusCode(status)
				.errorMessage(errMessage)
				.build();
	}
	
	public <T> ResponseOkDto<T> toResouceOk(int status, ResResult data) {	
		log.debug("Locale : {} ", Locale.getDefault());
		return ResponseOkDto.<T>builder()
				.statusCode(status)
				.errorMessage("")
				.build();
	}

	public <T> ResponsePageDto<?> toResouce(int status, T data, ResPageInfo pageInfo) {	
		log.debug("Locale : {} ", Locale.getDefault());
		return ResponsePageDto.<T>builder()
				.statusCode(status)
				.errorMessage("")
				.pagination(pageInfo)
				.data(data)
				.build();
	}
}
