package com.mutecsoft.atalk.security.oauth2.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL) // null 제외
public class AuthUserInfo {

	private String userId;
	
	/**
	 * 유저 암호
	 */
	@Schema(name="password", description = "유저 암호")
	@JsonProperty("password")
    @Expose
    @SerializedName("password")
	private String password;
	
	/**
	 * 유저 현재 암호
	 */
	@Schema(name="currentPassword", description = "유저 현재 암호")
	@JsonProperty("currentPassword")
    @Expose
    @SerializedName("currentPassword")
	private String currentPassword;
	
	/**
	 * 유저 이름
	 */
	@Schema(name="userName", description = "유저 이름")
	@JsonProperty("userName")
    @Expose
    @SerializedName("userName")
	private String userName;
	
	/**
	 * email
	 */
	@Schema(name="email", description = "email")
	@JsonProperty("email")
    @Expose
    @SerializedName("email")
	private String email;
	
	/**
	 * PES ID
	 */
	@Schema(name="pesId", description = "PES ID")
	@JsonProperty("pesId")
    @Expose
    @SerializedName("pesId")
    private Integer pesId;

	/**
	 * PES Name
	 */
	@Schema(name="pesName", description = "PES Name")
	@JsonProperty("pesName")
    @Expose
    @SerializedName("pesName")
	private String pesName;
	
	/**
	 * RES ID
	 */
	@Schema(name="resId", description = "RES ID")
	@JsonProperty("resId")
    @Expose
    @SerializedName("resId")
    private Integer resId;

	/**
	 * RES Name
	 */
	@Schema(name="resName", description = "RES Name")
	@JsonProperty("resName")
    @Expose
    @SerializedName("resName")
	private String resName;
	
    /**
     * 부서 코드
     */
	@Schema(name="deptId", description = "부서 코드")
	@JsonProperty("deptId")
    @Expose
    @SerializedName("deptId")
    private Integer deptId;
	
    /**
     * 부서명
     */
	@Schema(name="deptName", description = "부서명")
	@JsonProperty("deptName")
    @Expose
    @SerializedName("deptName")
    private String deptName;
	
	/**
	 * 유저 최초 로그인 여부
	 * N - 최초 로그인 O
	 * Y - 최초 로그인 X
	 */
	@Schema(name="enabled", description = "유저 최초 로그인 여부")
	@JsonProperty("enabled")
    @Expose
    @SerializedName("enabled")
    private boolean enabled;
	
	/**
	 * 유저 임시 암호 발급 여부
	 * Y - 임시 암호 발급 O
	 * N - 임시 암호 발급 X
	 */
	@Schema(name="isAccountNonLocked", description = "유저 임시 암호 발급 여부")
	@JsonProperty("isAccountNonLocked")
    @Expose
    @SerializedName("isAccountNonLocked")
    private boolean isAccountNonLocked;
		
	/**
	 * 로그인 성공 후 이동 할 페이지 URL
	 */
	@Schema(name="landingPageUrl", description = "로그인 성공 후 이동 할 페이지 URL")
	@JsonProperty("landingPageUrl")
    @Expose
    @SerializedName("landingPageUrl")
	private String landingPageUrl;
	
	/**
	 * 최초로그인 암호 발급 여부
	 * Y - 임시 암호 발급 O
	 * N - 임시 암호 발급 X
	 */
	@Schema(name="isFirstLoginYn", description = "최초로그인 여부")
	@JsonProperty("isFirstLoginYn")
    @Expose
    @SerializedName("isFirstLoginYn")
    private String isFirstLoginYn;
	
	/**
	 * 유저 임시 암호 발급 여부
	 * Y - 임시 암호 발급 O
	 * N - 임시 암호 발급 X
	 */
	@Schema(name="temporaryPasswordYn", description = "임시 비밀번호 발급 여부")
	@JsonProperty("temporaryPasswordYn")
    @Expose
    @SerializedName("temporaryPasswordYn")
    private String temporaryPasswordYn;
}
