package com.mutecsoft.atalk.config;

import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;

import com.mutecsoft.atalk.security.oauth2.model.CustomUserDetail;

public class CustomDaoAuthenticationProvider extends DaoAuthenticationProvider{
	@Override
	protected void additionalAuthenticationChecks(UserDetails userDetails,
			UsernamePasswordAuthenticationToken authentication) throws AuthenticationException {
		if (authentication.getCredentials() == null) {
			this.logger.debug("Failed to authenticate since no credentials provided");
			throw new BadCredentialsException(this.messages
				.getMessage("AbstractUserDetailsAuthenticationProvider.badCredentials", "Bad credentials"));
		}
		String presentedPassword = authentication.getCredentials().toString();
		if (userDetails instanceof CustomUserDetail) {
			CustomUserDetail user = (CustomUserDetail) userDetails;
			
			String encPasswordValue = userDetails.getPassword();
			if (encPasswordValue.indexOf("::") > 0) {
				String [] passwordArr = encPasswordValue.split("::");
				if (!this.getPasswordEncoder().matches(presentedPassword, passwordArr[0])
						&&
					!this.getPasswordEncoder().matches(presentedPassword, passwordArr[1])) {
					throw new BadCredentialsException(this.messages
					.getMessage("AbstractUserDetailsAuthenticationProvider.badCredentials", "Bad credentials"));
				}
			} else {
				
				if (!this.getPasswordEncoder().matches(presentedPassword, encPasswordValue)) {
	//				if (!StringUtils.isEmpty(casUser.getTmpPassword())) {
	//					if (!this.getPasswordEncoder().matches(presentedPassword, casUser.getTmpPassword())) {
	//						this.logger.debug("Failed to authenticate since password does not match stored value");
	//						throw new BadCredentialsException(this.messages
	//							.getMessage("AbstractUserDetailsAuthenticationProvider.badCredentials", "Bad credentials"));
	//					}
	//				} else {
	//					this.logger.debug("Failed to authenticate since password does not match stored value");
	//					throw new BadCredentialsException(this.messages
	//						.getMessage("AbstractUserDetailsAuthenticationProvider.badCredentials", "Bad credentials"));
	//				}
					throw new BadCredentialsException(this.messages
					.getMessage("AbstractUserDetailsAuthenticationProvider.badCredentials", "Bad credentials"));
				}
			}
		} else {
			if (!this.getPasswordEncoder().matches(presentedPassword, userDetails.getPassword())) {
				this.logger.debug("Failed to authenticate since password does not match stored value");
				throw new BadCredentialsException(this.messages
					.getMessage("AbstractUserDetailsAuthenticationProvider.badCredentials", "Bad credentials"));
			}
		}
	}
}
