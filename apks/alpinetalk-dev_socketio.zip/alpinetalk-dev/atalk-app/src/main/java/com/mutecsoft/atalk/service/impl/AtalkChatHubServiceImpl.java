package com.mutecsoft.atalk.service.impl;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mutecsoft.atalk.common.model.MUser;
import com.mutecsoft.atalk.component.PacketDecryptor;
import com.mutecsoft.atalk.component.redis.RedisTaskBroker;
import com.mutecsoft.atalk.logic.model.AtalkDataModelAll;
import com.mutecsoft.atalk.logic.model.AtalkPacketBase;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.logic.model.chathub.ChathubInfoRequest;
import com.mutecsoft.atalk.logic.model.chathub.ExitChathubResponse;
import com.mutecsoft.atalk.logic.model.chathub.InviteChathubRequest;
import com.mutecsoft.atalk.logic.model.chathub.InviteChathubResponse;
import com.mutecsoft.atalk.logic.model.chathub.KickOutChathubResponse;
import com.mutecsoft.atalk.logic.model.chathub.ListChathubRequest;
import com.mutecsoft.atalk.logic.model.chathub.ListChathubResponse;
import com.mutecsoft.atalk.logic.model.chathub.OpenChathubRequest;
import com.mutecsoft.atalk.logic.model.chathub.OpenChathubResponse;
import com.mutecsoft.atalk.logic.model.chathub.OpenChathubWithTitleRequest;
import com.mutecsoft.atalk.logic.util.RandomHexString;
import com.mutecsoft.atalk.secure.model.redis.RedisPacketKeySeed;
import com.mutecsoft.atalk.security.oauth2.model.CustomUserDetail;
import com.mutecsoft.atalk.service.AtalkChatHubService;
import com.mutecsoft.atalk.service.AtalkChatHubServiceLogic;
import com.mutecsoft.atalk.service.UserAccountService;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;

/**
 * 채팅방 관련 서비스
 * 
 */
@Slf4j
@Service("atalkChatHubService")
public class AtalkChatHubServiceImpl implements AtalkChatHubService {

	@Autowired
	UserAccountService userAccountService;
	
	@Autowired
	RedisTaskBroker redisTaskBroker;
	
	@Autowired
	PacketDecryptor packetDecryptor;
	
	ObjectMapper objectMapper;
	
	SimpleDateFormat dateFormatter;
	
	@Autowired
	AtalkChatHubServiceLogic atalkChatHubServiceLogic;
	
	@PostConstruct
	private void init() {
		objectMapper = new ObjectMapper();
		dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	}

	/**
	 * 채팅방 오픈
	 * 
	 */
	@Override
	public Optional<AtalkDataModelAll> openChathub(CustomUserDetail authUser, SecureDataModel secModel)
			throws Exception {
		log.debug("################# OPEN CHATHUB");
		MUser user = userAccountService.getUserByUserId(authUser.getUserId());
		if (user != null) {
			log.debug("#### transactionId : {}", secModel.getTransactinId());
			log.debug("#### data : {}", secModel.getData());
			
			String [] decryptPacketData = packetDecryptor.packetStringFromModel(secModel);
			if (decryptPacketData == null || decryptPacketData[0].equals("")) {
				return Optional.ofNullable(null);
			}
			String objectJson = decryptPacketData[0];
			String packetKey = decryptPacketData[1];
			log.debug("#### request string : {}", objectJson);
			
			/////////////////////////////////////////////////////////			
			OpenChathubRequest reqObj = AtalkPacketBase.fromJson(objectJson, OpenChathubRequest.class);
			OpenChathubResponse respObj = atalkChatHubServiceLogic.openChathub(user, reqObj);
			if (respObj == null) {
				return Optional.ofNullable(null);
			}
			///////////////////////// RESPONSE /////////////////////////////////////////////////////
			AtalkDataModelAll resData = AtalkDataModelAll.builder()
					.httpStatusCode(200)
					.atalkPacketBase(respObj)
					.secureModel(respObj.toFinalModel(packetKey))
					.build();
			resData.getSecureModel().setTransactinId(secModel.getTransactinId());
			return Optional.of(resData);
		}
		return Optional.ofNullable(null);
	}

	/**
	 * 대화방 목록 요청
	 * 
	 */
	@Override
	public Optional<AtalkDataModelAll> listChathub(CustomUserDetail authUser, SecureDataModel secModel) throws Exception {
		MUser user = userAccountService.getUserByUserId(authUser.getUserId());
		if (user != null) {
			log.debug("#### transactionId : {}", secModel.getTransactinId());
			log.debug("#### data : {}", secModel.getData());
			
			String [] decryptPacketData = packetDecryptor.packetStringFromModel(secModel);
			if (decryptPacketData == null || decryptPacketData[0].equals("")) {
				return Optional.ofNullable(null);
			}
			String objectJson = decryptPacketData[0];
			String packetKey = decryptPacketData[1];
			log.debug("#### request string : {}", objectJson);
			
			/////////////////////////////////////////////////////////
			ListChathubRequest reqObj = AtalkPacketBase.fromJson(objectJson, ListChathubRequest.class);
			ListChathubResponse respObj = atalkChatHubServiceLogic.listChathub(user, reqObj);
			if (respObj == null) {
				return Optional.ofNullable(null);
			}
			///////////////////////// RESPONSE /////////////////////////////////////////////////////
			AtalkDataModelAll resData = AtalkDataModelAll.builder()
					.httpStatusCode(200)
					.atalkPacketBase(respObj)
					.secureModel(respObj.toFinalModel(packetKey))
					.build();
			resData.getSecureModel().setTransactinId(secModel.getTransactinId());
			return Optional.of(resData);
			
		}
		return Optional.ofNullable(null);
	}

	/**
	 * 대화방 초대
	 * 
	 */
	@Override
	public Optional<AtalkDataModelAll> invite(CustomUserDetail authUser, SecureDataModel secModel) throws Exception {

		MUser user = userAccountService.getUserByUserId(authUser.getUserId());
		if (user != null) {
			log.debug("#### transactionId : {}", secModel.getTransactinId());
			log.debug("#### data : {}", secModel.getData());
			String [] decryptPacketData = packetDecryptor.packetStringFromModel(secModel);
			if (decryptPacketData == null || decryptPacketData[0].equals("")) {
				return Optional.ofNullable(null);
			}
			String objectJson = decryptPacketData[0];
			String packetKey = decryptPacketData[1];
			log.debug("#### request string : {}", objectJson);
			
			/////////////////////////////////////////////////////////
			InviteChathubRequest reqObj = AtalkPacketBase.fromJson(objectJson, InviteChathubRequest.class);
			InviteChathubResponse respObj = atalkChatHubServiceLogic.invite(user, reqObj);
			if (respObj == null) {
				return Optional.ofNullable(null);
			}
			AtalkDataModelAll resData = AtalkDataModelAll.builder()
					.httpStatusCode(200)
					.atalkPacketBase(respObj)
					.secureModel(respObj.toFinalModel(packetKey))
					.build();
			resData.getSecureModel().setTransactinId(secModel.getTransactinId());
			return Optional.of(resData);
		}
		return Optional.ofNullable(null);
	}

	@Override
	public Optional<AtalkDataModelAll> forceExit(CustomUserDetail authUser, Long chatHubNo, List<Long> userList) throws Exception {
		log.debug("################# FORCE EXIT CHATHUB");
		MUser user = userAccountService.getUserByUserId(authUser.getUserId());
		if (user != null) {
			RedisPacketKeySeed redisKeyObj = redisTaskBroker.findKeyObjectByUserNo(user.getUserNo());
			String packetKey = redisKeyObj.getPacketKey();
			/////////////////////////////////////////////////////////			
			KickOutChathubResponse respObj = atalkChatHubServiceLogic.forceExit(user, chatHubNo, userList);
			if (respObj == null) {
				return Optional.ofNullable(null);
			}
			
			///////////////////////// RESPONSE /////////////////////////////////////////////////////
			AtalkDataModelAll resData = AtalkDataModelAll.builder()
					.httpStatusCode(200)
					.atalkPacketBase(respObj)
					.secureModel(respObj.toFinalModel(packetKey))
					.build();
			resData.getSecureModel().setTransactinId(RandomHexString.genSecureRandomHex(16));
			return Optional.of(resData);
		}
		return Optional.ofNullable(null);
	}

	@Override
	public Optional<AtalkDataModelAll> exit(CustomUserDetail authUser, Long chatHubNo, String exitQuietly) throws Exception {
		log.debug("################# OPEN CHATHUB by amigoset no");
		MUser user = userAccountService.getUserByUserId(authUser.getUserId());
		if (user != null) {
			RedisPacketKeySeed redisKeyObj = redisTaskBroker.findKeyObjectByUserNo(user.getUserNo());
			String packetKey = redisKeyObj.getPacketKey();
			///////////////////////// RESPONSE /////////////////////////////////////////////////////
			/////////////////////////////////////////////////////////
			ExitChathubResponse respObj = atalkChatHubServiceLogic.exit(user, chatHubNo, exitQuietly);
			if (respObj == null) {
				return Optional.ofNullable(null);
			}
			///////////////////////// RESPONSE /////////////////////////////////////////////////////
			AtalkDataModelAll resData = AtalkDataModelAll.builder()
					.httpStatusCode(200)
					.atalkPacketBase(respObj)
					.secureModel(respObj.toFinalModel(packetKey))
					.build();
			resData.getSecureModel().setTransactinId(RandomHexString.genSecureRandomHex(16));
			return Optional.of(resData);
		}
		return Optional.ofNullable(null);
	}

	@Override
	public Optional<AtalkDataModelAll> info(CustomUserDetail authUser, SecureDataModel secModel) throws Exception {
		log.debug("################# INFO CHATHUB");
		MUser user = userAccountService.getUserByUserId(authUser.getUserId());
		if (user != null) {
			log.debug("#### transactionId : {}", secModel.getTransactinId());
			log.debug("#### data : {}", secModel.getData());
			
			String [] decryptPacketData = packetDecryptor.packetStringFromModel(secModel);
			if (decryptPacketData == null || decryptPacketData[0].equals("")) {
				return Optional.ofNullable(null);
			}
			String objectJson = decryptPacketData[0];
			String packetKey = decryptPacketData[1];
			log.debug("#### request string : {}", objectJson);
			
			ChathubInfoRequest reqObj = AtalkPacketBase.fromJson(objectJson, ChathubInfoRequest.class);

			OpenChathubResponse respObj = atalkChatHubServiceLogic.info(user, reqObj);
			if (respObj == null) {
				return Optional.ofNullable(null);
			}
			///////////////////////// RESPONSE /////////////////////////////////////////////////////
			AtalkDataModelAll resData = AtalkDataModelAll.builder()
					.httpStatusCode(200)
					.atalkPacketBase(respObj)
					.secureModel(respObj.toFinalModel(packetKey))
					.build();
			resData.getSecureModel().setTransactinId(secModel.getTransactinId());
			return Optional.of(resData);
		}
		return Optional.ofNullable(null);
	}

	@Override
	public Optional<AtalkDataModelAll> openChathubWithTitle(CustomUserDetail authUser, SecureDataModel secModel)
			throws Exception {
		log.debug("################# OPEN CHATHUB WITH TITLE");
		MUser user = userAccountService.getUserByUserId(authUser.getUserId());
		if (user != null) {
			log.debug("#### transactionId : {}", secModel.getTransactinId());
			log.debug("#### data : {}", secModel.getData());
			
			String [] decryptPacketData = packetDecryptor.packetStringFromModel(secModel);
			if (decryptPacketData == null || decryptPacketData[0].equals("")) {
				return Optional.ofNullable(null);
			}
			String objectJson = decryptPacketData[0];
			String packetKey = decryptPacketData[1];
			log.debug("#### request string : {}", objectJson);
			
			/////////////////////////////////////////////////////////			
			OpenChathubWithTitleRequest reqObj = AtalkPacketBase.fromJson(objectJson, OpenChathubWithTitleRequest.class);
			OpenChathubResponse respObj = atalkChatHubServiceLogic.openChathubWithTitle(user, reqObj);
			if (respObj == null) {
				return Optional.ofNullable(null);
			}
			///////////////////////// RESPONSE /////////////////////////////////////////////////////
			AtalkDataModelAll resData = AtalkDataModelAll.builder()
					.httpStatusCode(200)
					.atalkPacketBase(respObj)
					.secureModel(respObj.toFinalModel(packetKey))
					.build();
			resData.getSecureModel().setTransactinId(secModel.getTransactinId());
			return Optional.of(resData);
		}
		return Optional.ofNullable(null);
	}

	@Override
	public Optional<AtalkDataModelAll> openChathubByAmigoSetNo(CustomUserDetail authUser, Long amigoSetNo)
			throws Exception {
		log.debug("################# OPEN CHATHUB by amigoset no");
		MUser user = userAccountService.getUserByUserId(authUser.getUserId());
		if (user != null) {
			RedisPacketKeySeed redisKeyObj = redisTaskBroker.findKeyObjectByUserNo(user.getUserNo());
			String packetKey = redisKeyObj.getPacketKey();
			/////////////////////////////////////////////////////////			
			OpenChathubResponse respObj = atalkChatHubServiceLogic.openChathubByAmigoSetNo(user, amigoSetNo);
			if (respObj == null) {
				return Optional.ofNullable(null);
			}
			///////////////////////// RESPONSE /////////////////////////////////////////////////////
			AtalkDataModelAll resData = AtalkDataModelAll.builder()
					.httpStatusCode(200)
					.atalkPacketBase(respObj)
					.secureModel(respObj.toFinalModel(packetKey))
					.build();
			resData.getSecureModel().setTransactinId(RandomHexString.genSecureRandomHex(16));
			return Optional.of(resData);
		}
		return Optional.ofNullable(null);
	}
}
