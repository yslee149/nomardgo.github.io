/*
 *  Copyright (c) 2024 CNU Global, Inc.
 *  All right reserved.
 *  This software is the confidential and proprietary information of DOUB
 *  , Inc. You shall not disclose such Confidential Information and
 *  shall use it only in accordance with the terms of the license agreement
 *  you entered into with CNU Global.
 *
 *  Revision History
 *  Date               Author         Description
 *  ------------------ -------------- ------------------
 *  2024. 8. 13.	       Hong Seok Woo  
 */
package com.mutecsoft.atalk.logic.model.response;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * 사용자 응답
 * @author "Hong Seok Woo"
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL) // null 제외
public class UserAccount {
	
	/**
	 * 유저 아이디
	 */
	@Schema(name="userId", description = "유저 이름")
	@JsonProperty("userId")
    @Expose
    @SerializedName("userId")
	private String userId;
	
	/**
	 * 유저 암호
	 */
	@Schema(name="password", description = "유저 암호")
	@JsonProperty("password")
    @Expose
    @SerializedName("password")
	private String password;
	
	/**
	 * 유저 이름
	 */
	@Schema(name="userName", description = "유저 이름")
	@JsonProperty("userName")
    @Expose
    @SerializedName("userName")
	private String userName;
	
	/**
	 * email
	 */
	@Schema(name="email", description = "email")
	@JsonProperty("email")
    @Expose
    @SerializedName("email")
	private String email;
	
	
	/**
	 * 유저 생성일자
	 */
	@Schema(name="crtDd", description = "유저 생성일자")
	@JsonProperty("crtDd")
    @Expose
    @SerializedName("crtDd")
	private LocalDate crtDd;
	
	/**
	 * 유저 수정일자
	 */
	@Schema(name="modDd", description = "유저 수정일자")
	@JsonProperty("modDd")
    @Expose
    @SerializedName("modDd")
	private LocalDate modDd;
	
}
