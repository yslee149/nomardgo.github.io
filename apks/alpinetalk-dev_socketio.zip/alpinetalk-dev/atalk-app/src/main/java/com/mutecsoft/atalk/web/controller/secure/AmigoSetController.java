package com.mutecsoft.atalk.web.controller.secure;

import com.mutecsoft.atalk.component.PacketDecryptor;
import com.mutecsoft.atalk.component.assembler.ResponseDtoAssembler;
import com.mutecsoft.atalk.config.AuthTokenGenerator;
import com.mutecsoft.atalk.config.CustomAuthenticationProvider;
import com.mutecsoft.atalk.logic.model.AtalkDataModelAll;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.security.oauth2.model.CustomUserDetail;
import com.mutecsoft.atalk.service.AtalkAmigoSetService;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;

import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationProvider;
import org.springframework.security.provisioning.UserDetailsManager;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @PackageName com.mutecsoft.atalk.web.controller.secure
 * @fileName	AmigoSetController.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description :
 * <pre>
 * 
 * </pre>
 */
@Slf4j
@Tag(name="Authentication", description="Authentication API")
@Controller
@RequestMapping(value = "/api/v1/amigoSet")
public class AmigoSetController {
	@Autowired
	UserDetailsManager userDetailsManager;
	
	@Autowired
	AuthTokenGenerator authTokenGenerator;
	
	
	@Autowired
	@Qualifier("jwtRefreshTokenAuthProvider")
	JwtAuthenticationProvider refreshTokenAuthProvider;
	
	@Autowired
	CustomAuthenticationProvider customAuthenticationProvider;

	@Autowired
	private ResponseDtoAssembler responseAssembler;
	
	@Autowired
	AtalkAmigoSetService atalkAmigoSetService;
	
	@Autowired
	PacketDecryptor packetDecryptor;

	/**
	 * 친구그룹 등록
	 * 
	 * @param authUser
	 * @param secureReqModel
	 * @return
	 */
	@PostMapping("/add")
	public ResponseEntity<?> addAmigoSet(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @RequestBody SecureDataModel secureReqModel) {
		try {
			log.debug("################# ADD AMIGO SET");
			Optional<AtalkDataModelAll> respOp = atalkAmigoSetService.addAmigoSet(authUser, secureReqModel);
			return new ResponseEntity<>(respOp.get().getSecureModel(), HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
	
	/**
	 * 친구그룹 수정
	 * 
	 * @param authUser
	 * @param secureReqModel
	 * @return
	 */
	@PostMapping("/rename")
	public ResponseEntity<?> rename(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @RequestBody SecureDataModel secureReqModel) {
		try {
			log.debug("################# RENAME AMIGO SET");
			Optional<AtalkDataModelAll> respOp = atalkAmigoSetService.renameAmigoSet(authUser, secureReqModel);
			return new ResponseEntity<>(respOp.get().getSecureModel(), HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
	
	/**
	 * 친구그룹 삭제
	 * 
	 * @param authUser
	 * @param secureReqModel
	 * @return
	 */
	@PostMapping("/delete")
	public ResponseEntity<?> delete(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @RequestBody SecureDataModel secureReqModel) {
		try {
			log.debug("################# DELETE AMIGO GROUP");
			Optional<AtalkDataModelAll> respOp = atalkAmigoSetService.deleteAmigoSet(authUser, secureReqModel);
			return new ResponseEntity<>(respOp.get().getSecureModel(), HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
	
	/**
	 * 친구그룹 조회
	 * 
	 * @param authUser
	 * @return
	 */
	@GetMapping("/list")
	public ResponseEntity<?> list(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			) {
		try {
			log.debug("################# LIST AMIGO GROUP");
			Optional<AtalkDataModelAll> respOp = atalkAmigoSetService.amigoSetList(authUser);
			return new ResponseEntity<>(respOp.get().getSecureModel(), HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
}
