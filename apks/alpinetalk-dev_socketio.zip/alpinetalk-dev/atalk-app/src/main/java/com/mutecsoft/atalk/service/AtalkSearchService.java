package com.mutecsoft.atalk.service;

import java.util.Optional;

import com.mutecsoft.atalk.logic.model.AtalkDataModelAll;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.security.oauth2.model.CustomUserDetail;

public interface AtalkSearchService {
	Optional<AtalkDataModelAll> searchUser(CustomUserDetail authUser, SecureDataModel secModel) throws Exception;
	Optional<AtalkDataModelAll> searchUserNoAuth(SecureDataModel secModel) throws Exception;
}
