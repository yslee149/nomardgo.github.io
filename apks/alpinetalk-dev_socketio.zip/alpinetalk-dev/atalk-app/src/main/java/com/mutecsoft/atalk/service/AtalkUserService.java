package com.mutecsoft.atalk.service;

import java.util.List;
import java.util.Optional;

import org.springframework.web.multipart.MultipartFile;

import com.mutecsoft.atalk.common.model.MUser;
import com.mutecsoft.atalk.logic.model.AtalkDataModelAll;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.logic.model.auth.UserResultResponse;
import com.mutecsoft.atalk.security.oauth2.model.CustomUserDetail;

public interface AtalkUserService {
	
	Optional<AtalkDataModelAll> checkDupAccount(SecureDataModel secModel) throws Exception;
	// Optional<AtalkDataModelAll> signup(SecureDataModel secModel) throws Exception;
	Optional<AtalkDataModelAll> signupMore(SecureDataModel secModel, List<MultipartFile> profileFiles) throws Exception;
	
	Optional<AtalkDataModelAll> login(SecureDataModel secModel) throws Exception;
	
	Optional<AtalkDataModelAll> refreshToken(SecureDataModel secModel) throws Exception;
	Optional<AtalkDataModelAll> changePassword(CustomUserDetail authUser, SecureDataModel secModel) throws Exception;
	Optional<AtalkDataModelAll> checkPassword(CustomUserDetail authUser, String encPassword) throws Exception;
	
	UserResultResponse issuePassword(String userId) throws Exception;
	UserResultResponse authEmail(String userEmail) throws Exception;

	UserResultResponse checkAuthToken(String userEmail, String tokenValue) throws Exception;
	
	UserResultResponse checkDupAccount(String userEmail) throws Exception;
	
	Optional<AtalkDataModelAll> deleteUser(SecureDataModel secModel) throws Exception;
	
	Optional<AtalkDataModelAll> resetAllForTest(SecureDataModel secModel) throws Exception;
	
	///////////
	void afterLogin(MUser userObj) throws Exception;
}
