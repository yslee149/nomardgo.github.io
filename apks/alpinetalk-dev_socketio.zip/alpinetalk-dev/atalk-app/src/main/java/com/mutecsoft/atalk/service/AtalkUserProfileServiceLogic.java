package com.mutecsoft.atalk.service;

import java.util.Optional;

import org.springframework.web.multipart.MultipartFile;

import com.mutecsoft.atalk.common.model.MUser;
import com.mutecsoft.atalk.common.model.MUserProfile;
import com.mutecsoft.atalk.constant.EnumProfileType;
import com.mutecsoft.atalk.logic.model.user.SearchUserResponse;

public interface AtalkUserProfileServiceLogic {
	
//	Optional<AtalkDataModelAll> checkDupAccount(SecureDataModel secModel) throws Exception;
//	Optional<AtalkDataModelAll> signup(SecureDataModel secModel) throws Exception;
//	
//	Optional<AtalkDataModelAll> signupMore(SecureDataModel secModel, List<MultipartFile> profileFiles) throws Exception;
//	
//	
//	Optional<AtalkDataModelAll> login(SecureDataModel secModel) throws Exception;
//	Optional<AtalkDataModelAll> refreshToken(SecureDataModel secModel) throws Exception;
//	Optional<AtalkDataModelAll> changePassword(CustomUserDetail authUser, SecureDataModel secModel) throws Exception;
	
	Optional<MUserProfile> registProfileForeground(MUser user, String decryptKey, MultipartFile file) throws Exception;
	Optional<MUserProfile> registProfileBackground(MUser user, String decryptKey, MultipartFile file) throws Exception;
	
	SearchUserResponse updateProfileImage(
			MUser user
			, EnumProfileType profileType
			, MultipartFile file) throws Exception;
}
