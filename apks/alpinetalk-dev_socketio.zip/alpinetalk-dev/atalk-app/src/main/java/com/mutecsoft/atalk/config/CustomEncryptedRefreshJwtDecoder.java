package com.mutecsoft.atalk.config;

import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtException;

import com.nimbusds.jose.JWEObject;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CustomEncryptedRefreshJwtDecoder implements JwtDecoder {

    private final JwtDecoder jwtDecoder;
    private final KeyUtils keyUtils;

    
	public CustomEncryptedRefreshJwtDecoder(JwtDecoder jwtDecoder, KeyUtils keyUtils) {
        this.jwtDecoder = jwtDecoder;
        this.keyUtils = keyUtils;
    }

    @Override
    public Jwt decode(String token) throws JwtException {
        try {
        	final String finalToken = token;
        	log.debug("#### TOKEN VALUE(REFRESH) : {}", finalToken);
            return jwtDecoder.decode(finalToken);

        } catch (Exception e) {
            throw new JwtException("Failed to decrypt and decode JWT", e);
        }
    }

    public Jwt convertToJwt(SignedJWT signedJWT) throws Exception {
    	JWTClaimsSet claims = signedJWT.getJWTClaimsSet();

	    return Jwt.withTokenValue(signedJWT.serialize())
	            .header("alg", signedJWT.getHeader().getAlgorithm().getName())
	            .claim("sub", claims.getSubject())
	            .claim("iss", claims.getIssuer())
	            .claim("exp", claims.getExpirationTime())
	            .claim("iat", claims.getIssueTime())
	            .claim("aud", claims.getAudience())
	            .claim("custom-claim", claims.getClaim("custom-claim"))  // Add any custom claims
	            .issuedAt(claims.getIssueTime().toInstant())
	            .expiresAt(claims.getExpirationTime().toInstant())
	            .build();
	}
    
    private Jwt decryptToken(String encryptedJwt) throws Exception {
    	JWEObject jweObject = JWEObject.parse(encryptedJwt);
        // Get the decrypted JWT as SignedJWT object
        SignedJWT signedJWT = jweObject.getPayload().toSignedJWT();
        JWTClaimsSet claimsSet = signedJWT.getJWTClaimsSet();
        return convertToJwt(signedJWT);
    	//return RsaComplex.decrypt(encryptedToken, keyUtils.getSecureTokenPrivateKey());
    }

}
