package com.mutecsoft.atalk.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mutecsoft.atalk.common.model.MUser;
import com.mutecsoft.atalk.common.repository.MUserRepository;
import com.mutecsoft.atalk.component.PacketDecryptor;
import com.mutecsoft.atalk.component.redis.RedisTaskBroker;
import com.mutecsoft.atalk.logic.model.AtalkDataModelAll;
import com.mutecsoft.atalk.logic.model.AtalkPacketBase;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.logic.model.amigo.AddAmigoRequest;
import com.mutecsoft.atalk.logic.model.amigo.AmigoDetailResponse;
import com.mutecsoft.atalk.logic.model.amigo.AmigoListResponse;
import com.mutecsoft.atalk.logic.model.amigo.DeleteAmigoRequest;
import com.mutecsoft.atalk.logic.model.amigo.DeleteAmigoResponse;
import com.mutecsoft.atalk.logic.util.RandomHexString;
import com.mutecsoft.atalk.secure.model.redis.RedisPacketKeySeed;
import com.mutecsoft.atalk.security.oauth2.model.CustomUserDetail;
import com.mutecsoft.atalk.service.AtalkAmigoService;
import com.mutecsoft.atalk.service.AtalkAmigoServiceLogic;
import com.mutecsoft.atalk.service.UserAccountService;

import lombok.extern.slf4j.Slf4j;

/**
 * 친구그룹 서비스
 * 
 */
@Slf4j
@Service("atalkAmigoService")
public class AtalkAmigoServiceImpl implements AtalkAmigoService {

	@Autowired
	UserAccountService userAccountService;
	
	@Autowired
	RedisTaskBroker redisTaskBroker;
	
	@Autowired
	PacketDecryptor packetDecryptor;
	
	@Autowired
	AtalkAmigoServiceLogic atalkAmigoServiceLogic;
	
	@Autowired
	MUserRepository mUserRepository;
	
	@Override
	public Optional<AtalkDataModelAll> addAmigo(CustomUserDetail authUser, SecureDataModel secModel) throws Exception {
		log.debug("################# ADD AMIGO");
		MUser user = userAccountService.getUserByUserId(authUser.getUserId());
		if (user != null) {
			log.debug("#### transactionId : {}", secModel.getTransactinId());
			log.debug("#### data : {}", secModel.getData());
			
			String [] decryptPacketData = packetDecryptor.packetStringFromModel(secModel);
			if (decryptPacketData == null || decryptPacketData[0].equals("")) {
				return Optional.ofNullable(null);
			}
			String objectJson = decryptPacketData[0];
			String packetKey = decryptPacketData[1];
			log.debug("#### request string : {}", objectJson);
			
			AddAmigoRequest reqObj = AtalkPacketBase.fromJson(objectJson, AddAmigoRequest.class);
			AmigoListResponse respObj = atalkAmigoServiceLogic.addAmigo(user, reqObj);

			///////////////////////// RESPONSE /////////////////////////////////////////////////////		
			if (respObj == null) {
				return Optional.ofNullable(null);
			}
			AtalkDataModelAll resData = AtalkDataModelAll.builder()
					.httpStatusCode(200)
					.atalkPacketBase(respObj)
					.secureModel(respObj.toFinalModel(packetKey))
					.build();
			resData.getSecureModel().setTransactinId(secModel.getTransactinId());
			return Optional.of(resData);
		}
		return Optional.ofNullable(null);
	}

	@Override
	public Optional<AtalkDataModelAll> deleteAmigo(CustomUserDetail authUser, SecureDataModel secModel)
			throws Exception {
		log.debug("################# ADD AMIGO");
		MUser user = userAccountService.getUserByUserId(authUser.getUserId());
		if (user != null) {
			log.debug("#### transactionId : {}", secModel.getTransactinId());
			log.debug("#### data : {}", secModel.getData());
			
			String [] decryptPacketData = packetDecryptor.packetStringFromModel(secModel);
			if (decryptPacketData == null || decryptPacketData[0].equals("")) {
				return Optional.ofNullable(null);
			}
			String objectJson = decryptPacketData[0];
			String packetKey = decryptPacketData[1];
			log.debug("#### request string : {}", objectJson);
			
			DeleteAmigoRequest reqObj = AtalkPacketBase.fromJson(objectJson, DeleteAmigoRequest.class);
			DeleteAmigoResponse respObj = atalkAmigoServiceLogic.deleteAmigo(user, reqObj);
			///////////////////////// RESPONSE /////////////////////////////////////////////////////		
			if (respObj == null) {
				return Optional.ofNullable(null);
			}
			respObj.setResult(Boolean.TRUE);
			AtalkDataModelAll resData = AtalkDataModelAll.builder()
					.httpStatusCode(200)
					.atalkPacketBase(respObj)
					.secureModel(respObj.toFinalModel(packetKey))
					.build();
			resData.getSecureModel().setTransactinId(secModel.getTransactinId());
			return Optional.of(resData);
		}
		return Optional.ofNullable(null);
	}

	@Override
	public Optional<AtalkDataModelAll> amigoList(CustomUserDetail authUser) throws Exception {
		log.debug("################# GET LIST AMIGO SET");
		MUser user = userAccountService.getUserByUserId(authUser.getUserId());
		if (user != null) {
			RedisPacketKeySeed redisKeyObj = redisTaskBroker.findKeyObjectByUserNo(user.getUserNo());
			String packetKey = redisKeyObj.getPacketKey();
			AmigoListResponse respObj = atalkAmigoServiceLogic.amigoList(user);
			///////////////////////// RESPONSE /////////////////////////////////////////////////////		
			if (respObj == null) {
				return Optional.ofNullable(null);
			}
			AtalkDataModelAll resData = AtalkDataModelAll.builder()
					.httpStatusCode(200)
					.atalkPacketBase(respObj)
					.secureModel(respObj.toFinalModel(packetKey))
					.build();
			resData.getSecureModel().setTransactinId(RandomHexString.genSecureRandomHex(16));
			return Optional.of(resData);
		}
		return Optional.ofNullable(null);
	}

	@Override
	public Optional<AtalkDataModelAll> detail(CustomUserDetail authUser, Long amigoUserNo) throws Exception {
		log.debug("################# GET LIST AMIGO SET");
		MUser user = userAccountService.getUserByUserId(authUser.getUserId());
		if (user != null) {
			RedisPacketKeySeed redisKeyObj = redisTaskBroker.findKeyObjectByUserNo(user.getUserNo());
			String packetKey = redisKeyObj.getPacketKey();
			AmigoDetailResponse respObj = atalkAmigoServiceLogic.detail(user, amigoUserNo);
			///////////////////////// RESPONSE /////////////////////////////////////////////////////		
			if (respObj == null) {
				return Optional.ofNullable(null);
			}
			AtalkDataModelAll resData = AtalkDataModelAll.builder()
					.httpStatusCode(200)
					.atalkPacketBase(respObj)
					.secureModel(respObj.toFinalModel(packetKey))
					.build();
			resData.getSecureModel().setTransactinId(RandomHexString.genSecureRandomHex(16));
			return Optional.of(resData);
		}
		return Optional.ofNullable(null);
	}

	@Override
	public Optional<AtalkDataModelAll> addAmigo(CustomUserDetail authUser, String userName, String userId)
			throws Exception {
		log.debug("################# ADD AMIGO");
		MUser user = userAccountService.getUserByUserId(authUser.getUserId());
		if (user != null) {
			RedisPacketKeySeed redisKeyObj = redisTaskBroker.findKeyObjectByUserNo(user.getUserNo());
			String packetKey = redisKeyObj.getPacketKey();

			/////////////////////////////////////////////////////////////
			Optional<MUser> userOp = mUserRepository.findByUserId(userId);
			if (!userOp.isPresent()) {
				return Optional.ofNullable(null);
			}
			AddAmigoRequest reqObj = new AddAmigoRequest();
			reqObj.setAmigoUserNoList(List.of(userOp.get().getUserNo()));
			AmigoListResponse respObj = atalkAmigoServiceLogic.addAmigo(authUser.getMUser(), reqObj);
			
			///////////////////////// RESPONSE /////////////////////////////////////////////////////		
			if (respObj == null) {
				return Optional.ofNullable(null);
			}
			AtalkDataModelAll resData = AtalkDataModelAll.builder()
					.httpStatusCode(200)
					.atalkPacketBase(respObj)
					.secureModel(respObj.toFinalModel(packetKey))
					.build();
			resData.getSecureModel().setTransactinId(RandomHexString.genSecureRandomHex(16));
			return Optional.of(resData);
		}
		return Optional.ofNullable(null);
	}
}
