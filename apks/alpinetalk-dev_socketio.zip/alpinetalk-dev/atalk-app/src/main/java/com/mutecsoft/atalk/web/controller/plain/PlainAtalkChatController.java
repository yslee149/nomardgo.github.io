package com.mutecsoft.atalk.web.controller.plain;

import com.mutecsoft.atalk.common.model.MChatFile;
import com.mutecsoft.atalk.common.repository.MChatFileRepository;
import com.mutecsoft.atalk.config.AtalkConfig;
import com.mutecsoft.atalk.logic.model.chat.ChatInfoRequest;
import com.mutecsoft.atalk.logic.model.chat.ChatInfoResponse;
import com.mutecsoft.atalk.logic.model.chat.ChatResponse;
import com.mutecsoft.atalk.logic.model.chat.DeleteChatRequest;
import com.mutecsoft.atalk.logic.model.chat.DeleteChatResponse;
import com.mutecsoft.atalk.logic.model.chat.ExtChatResponse;
import com.mutecsoft.atalk.logic.model.chat.ReadChatRequest;
import com.mutecsoft.atalk.logic.model.chat.ReadChatResponse;
import com.mutecsoft.atalk.logic.model.chat.RetrieveChatRequest;
import com.mutecsoft.atalk.logic.model.chat.RetrieveChatResponse;
import com.mutecsoft.atalk.logic.model.chat.SendChatRequest;
import com.mutecsoft.atalk.logic.model.chat.SendChatResponse;
import com.mutecsoft.atalk.logic.model.chat.SendFileChatResponse;
import com.mutecsoft.atalk.security.oauth2.model.CustomUserDetail;
import com.mutecsoft.atalk.service.AtalkChatServiceLogic;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

/**
 * @PackageName com.mutecsoft.atalk.web.controller.plain
 * @fileName	PlainAtalkChatController.java
 * @author voyzer
 * @Date   2024. 12. 1.
 * @description :
 * <pre>
 * 
 * </pre>
 */
@Slf4j
@Tag(name="Chat", description="Chat API(Plain)")
@Controller
@RequestMapping(value = "/api/plain/v1/chat")
public class PlainAtalkChatController {

	@Autowired
	AtalkChatServiceLogic atalkChatServiceLogic;
	
	@Autowired
	MChatFileRepository mChatFileRepository;
	
	@Autowired
	AtalkConfig atalkConfig;
	
	/**
	 * 일반대화
	 * 
	 * @param authUser
	 * @param reqObj
	 * @return
	 */
	@PostMapping("/send")
	public ResponseEntity<?> send(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @RequestBody SendChatRequest reqObj) {
		try {
			log.debug("################# SEND CHAT");
			SendChatResponse resp = atalkChatServiceLogic.procMessage(
					authUser.getMUser(), reqObj);
			return new ResponseEntity<>(resp, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
	
	/**
	 * 대화목록 조회
	 * 
	 * @param authUser
	 * @param reqObj
	 * @return
	 */
	@RequestMapping(value="/chatList/{chathubNo}/{lastChatNo}/{chatCount}", method = {RequestMethod.POST, RequestMethod.GET})
	public ResponseEntity<?> chatList(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @PathVariable("chathubNo") Long chathubNo
			, @PathVariable("lastChatNo") Long lastChatNo
			, @PathVariable("chatCount") Long chatCount) {
		try {
			log.debug("################# GET CHAT LIST");
			ChatInfoRequest reqObj = new ChatInfoRequest();
			reqObj.setChathubNo(chathubNo);
			reqObj.setLastChatNo(lastChatNo);
			if (chatCount == 0L) {
				chatCount = 10L;
			} else if (chatCount > 50L) {
				chatCount = 50L;
			}
			reqObj.setChatInqCount(chatCount.intValue());
			ChatInfoResponse respObj = atalkChatServiceLogic.chatList(
						authUser.getMUser(), reqObj);
			return new ResponseEntity<>(respObj, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}

	/**
	 * 파일 대화
	 * 
	 * @param authUser
	 * @param chathubNo
	 * @param fileType
	 * @param uploadDataFile
	 * @return
	 */
	@PostMapping(value = "/send/file/{chathubNo}/{fileType}")
	public ResponseEntity<?> sendFile(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @PathVariable("chathubNo") Long chathubNo
			, @PathVariable("fileType") String fileType
			, @RequestParam("file") MultipartFile uploadDataFile) {
		try {
			log.debug("################# SEND FILE CHAT");
			SendFileChatResponse respObj = atalkChatServiceLogic.procFileMessage(
					authUser.getMUser()
					, chathubNo
					, fileType
					, uploadDataFile);
			return new ResponseEntity<>(respObj, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
	
	private ByteArrayOutputStream toByteArrayOutputStream(Path filePath) {
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		try (FileInputStream fileInputStream = new FileInputStream(filePath.toFile())) {
			byte[] buffer = new byte[4096]; // Buffer size for reading chunks
			int bytesRead;
			while ((bytesRead = fileInputStream.read(buffer)) != -1) {
				byteArrayOutputStream.write(buffer, 0, bytesRead);
			}
		} catch (IOException e) {
			log.error("@@@@ : {}", e);
		}
		return byteArrayOutputStream;
	}
	
	/**
	 * 파일 다운로드
	 * 
	 * @param authUser
	 * @param chatFileNo
	 * @return
	 */
	@PostMapping(value = "/file/{chatFileNo}")
	public ResponseEntity<?> downloadFile(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @PathVariable("chatFileNo") Long chatFileNo) {
		
		Optional<MChatFile> chatFileOp = mChatFileRepository.findByUserNoAndChatFileNo(
				authUser.getMUser().getUserNo()
				, chatFileNo);
		if (chatFileOp.isEmpty()) {
			log.error("@@@@ : Not joind chathub-att file : {}, userNo : {}",
					chatFileNo, authUser.getMUser().getUserNo());
			return null;
		}
		Path uploadPath = Paths.get(
				atalkConfig.getChatConfig().getChatFilePath()
				, chatFileOp.get().getFilePath());
		if (!Files.exists(uploadPath)) {
			return null;
		}
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "attachment; filename="+chatFileOp.get().getDispName());
		ByteArrayResource resource = new ByteArrayResource(toByteArrayOutputStream(uploadPath).toByteArray());
        return ResponseEntity.status(HttpStatus.OK)
	            .header("Content-Type", "application/octet-stream")
	            .header("Content-Disposition", "attachment;filename="+chatFileOp.get().getDispName())
	            .header("Content-Length", String.valueOf(resource.getByteArray().length))
	            .body(resource);
	}
	
	/**
	 * 확장대화 요청
	 * 
	 * @param authUser
	 * @param chatExtNo
	 * @return
	 */
	@PostMapping(value = "/ext/{chatExtNo}")
	public ResponseEntity<?> getExtChatContent(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @PathVariable("chatExtNo") Long chatExtNo) {
		try {
			log.debug("################# GET EXT CAHT");
			ExtChatResponse respObj = atalkChatServiceLogic.getExtChat(
					authUser.getMUser()
					, chatExtNo);
			return new ResponseEntity<>(respObj, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}

	/**
	 * 대화 삭제 처리
	 * 
	 * @param authUser
	 * @param reqObj
	 * @return
	 */
	@PostMapping(value ="/delete", consumes = { MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<?> delete(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
            , @RequestBody DeleteChatRequest reqObj) {
		try {
			log.debug("################# DELETE CHAT LIST");
			DeleteChatResponse respObj = atalkChatServiceLogic.deleteChatList(
					authUser.getMUser(), reqObj);
			return new ResponseEntity<>(respObj, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}

	/**
	 * 대화 회수 처리
	 * 
	 * @param authUser
	 * @param reqObj
	 * @return
	 */
	@RequestMapping(value="/retrieve/{chathubNo}/{chatNo}", method = {RequestMethod.POST, RequestMethod.GET})
	public ResponseEntity<?> retrieve(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @PathVariable("chathubNo") Long chathubNo
			, @PathVariable("chatNo") Long chatNo) {
		try {
			log.debug("################# RETRIEVE CHAT LIST");
			RetrieveChatRequest reqObj = new RetrieveChatRequest();
			reqObj.setChathubNo(chathubNo);
			reqObj.setChtaNoList(List.of(chatNo));
					
			RetrieveChatResponse respOp = atalkChatServiceLogic.retrieveChatList(
					authUser.getMUser(), reqObj);
			return new ResponseEntity<>(respOp, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
	
	/**
	 * 읽음 확인
	 * 
	 * @param authUser
	 * @param reqObj
	 * @return
	 */
	@RequestMapping(value="/read/{chathubNo}", method = {RequestMethod.POST, RequestMethod.GET})
	public ResponseEntity<?> read(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @PathVariable("chathubNo") Long chathubNo) {
		try {
			log.debug("################# READ CHAT ");
			ReadChatRequest reqObj = new ReadChatRequest();
			reqObj.setChathubNo(chathubNo);
			ReadChatResponse respObj = atalkChatServiceLogic.readChat(
					authUser.getMUser(), reqObj);
			return new ResponseEntity<>(respObj, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
	
	/**
	 * 대화 상세정보
	 * 
	 * @param authUser
	 * @param reqObj
	 * @return
	 */
	@RequestMapping(value="/get/{userNo}/{chathubNo}/{chatNo}", method = {RequestMethod.POST, RequestMethod.GET})
	public ResponseEntity<?> get(
			@PathVariable("userNo") Long userNo
			, @PathVariable("chathubNo") Long chathubNo
			, @PathVariable("chatNo") Long chatNo) {
		try {
			log.debug("################# get CHAT");
			ChatResponse respObj = atalkChatServiceLogic.get(
					userNo, chathubNo, chatNo);
			return new ResponseEntity<>(respObj, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
}
