package com.mutecsoft.atalk.config;

import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtException;

import com.mutecsoft.atalk.component.PacketDecryptor;
import com.mutecsoft.atalk.logic.util.AesEncDecComplex;
import com.nimbusds.jose.JWEObject;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CustomEncryptedJwtDecoder implements JwtDecoder {

    private final JwtDecoder jwtDecoder;
    private final KeyUtils keyUtils;

    PacketDecryptor pktDecryptor;
    
	public CustomEncryptedJwtDecoder(JwtDecoder jwtDecoder, KeyUtils keyUtils) {
        this.jwtDecoder = jwtDecoder;
        this.keyUtils = keyUtils;
    }

    public PacketDecryptor getPktDecryptor() {
		return pktDecryptor;
	}

	public void setPktDecryptor(PacketDecryptor pktDecryptor) {
		this.pktDecryptor = pktDecryptor;
	}

    @Override
    public Jwt decode(String token) throws JwtException {
        try {
        	// just for development temporarily
        	/// decrypt token
        	String pktKeySeed = token.substring(token.length() - 32);
        	String encHexToken = token.substring(0, token.length() - 32);
        	String hexPacketKey = pktDecryptor.getPacketKey(pktKeySeed);
        	byte [] encHexTokenBuf = AesEncDecComplex.hexToBytes(encHexToken);
        	byte [] decBuffer =AesEncDecComplex.decryptAesCtrWithIv(encHexTokenBuf, hexPacketKey);
        	
        	final String finalToken = new String(decBuffer);
        	log.debug("#### TOKEN VALUE : {}", finalToken);
            // Step 1: Decrypt the encrypted JWT
            // String decryptedToken = decryptToken(token);
            // Jwt jwt = decryptToken(token);
            // Step 2: Parse and validate the decrypted JWT using the default JwtDecoder
            return jwtDecoder.decode(finalToken);

        } catch (Exception e) {
            throw new JwtException("Failed to decrypt and decode JWT", e);
        }
    }

    public Jwt convertToJwt(SignedJWT signedJWT) throws Exception {
    	JWTClaimsSet claims = signedJWT.getJWTClaimsSet();

	    return Jwt.withTokenValue(signedJWT.serialize())
	            .header("alg", signedJWT.getHeader().getAlgorithm().getName())
	            .claim("sub", claims.getSubject())
	            .claim("iss", claims.getIssuer())
	            .claim("exp", claims.getExpirationTime())
	            .claim("iat", claims.getIssueTime())
	            .claim("aud", claims.getAudience())
	            .claim("custom-claim", claims.getClaim("custom-claim"))  // Add any custom claims
	            .issuedAt(claims.getIssueTime().toInstant())
	            .expiresAt(claims.getExpirationTime().toInstant())
	            .build();
	}
    
    private Jwt decryptToken(String encryptedJwt) throws Exception {
    	JWEObject jweObject = JWEObject.parse(encryptedJwt);
        // Get the decrypted JWT as SignedJWT object
        SignedJWT signedJWT = jweObject.getPayload().toSignedJWT();
        JWTClaimsSet claimsSet = signedJWT.getJWTClaimsSet();
        return convertToJwt(signedJWT);
    	//return RsaComplex.decrypt(encryptedToken, keyUtils.getSecureTokenPrivateKey());
    }

}
