package com.mutecsoft.atalk.config;

import java.time.Instant;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;

import com.google.common.collect.Maps;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSSigner;
import com.nimbusds.jose.crypto.RSADecrypter;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jwt.EncryptedJWT;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.Claims;
import lombok.extern.slf4j.Slf4j;

import org.springframework.security.authentication.BadCredentialsException;

@Slf4j
public class CustomJwtAuthenticationProvider implements AuthenticationProvider {

    // private static final String SECRET_KEY = "your_secret_key"; // Replace with your actual key


//	@Autowired
//	@Qualifier("jwtAccessTokenDecoder")
//	JwtDecoder accessTokenDecoder;
//	
	private KeyUtils keyUtils;
	
	public CustomJwtAuthenticationProvider(KeyUtils keyUtils) {
		this.keyUtils = keyUtils;
	}
	
	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		String token = (String) authentication.getCredentials();
		try {
			// String decryptedJwt = decryptJwt(token);
			JWTClaimsSet claims = decryptJwt(token);
////            // Parse and validate the JWT (after decryption)
////            Claims claims = JwtClaimsSet.parser()
////                .setSigningKey(SECRET_KEY)  // Secret key for validation
////                .parseClaimsJws(decryptedJwt)  // Use the decrypted JWT
////                .getBody();
////            
//            // Perform custom validations on claims
//            // String username = claims.getSubject();
//            
//        	String userName = jwt.getSubject();
//        	if (userName == null || userName.isEmpty()) {
//                throw new BadCredentialsException("Invalid token");
//            }
//            return new JwtAuthenticationToken(jwt);
//            // Return a valid Authentication object (You can extend further for roles, etc.)
//            // return new JwtAuthenticationToken(userName, token, null); // Customize this according to your Authentication token class
			
			Jwt jwt = convertJwtClaimsSetToJwt(claims, token);
			return new JwtAuthenticationToken(jwt, Collections.EMPTY_LIST);
        } catch (Exception e) {
            throw new BadCredentialsException("Invalid JWT token", e);
        }
    }

    @Override
    public boolean supports(Class<?> authentication) {
        return JwtAuthenticationToken.class.isAssignableFrom(authentication);
    }
    
    // Method to convert JWTClaimsSet to Jwt
    public static Jwt convertJwtClaimsSetToJwt(JWTClaimsSet claimsSet, String tokenValue) {
        // Extract the claims from JWTClaimsSet
        Map<String, Object> claims = claimsSet.getClaims();

        // Define the headers (use empty headers or define your own)
        Map<String, Object> headers = Maps.newHashMap();
        headers.put("alg", "RS256"); // Example header

        // Extract standard claim values from the JWTClaimsSet
        Instant issuedAt = claimsSet.getIssueTime() != null ? claimsSet.getIssueTime().toInstant() : Instant.now();
        Instant expiresAt = claimsSet.getExpirationTime() != null ? claimsSet.getExpirationTime().toInstant() : Instant.now().plusSeconds(3600);

        // Step 2: Create the Jwt object
        return new Jwt(
                tokenValue,                // The original compact JWT string
                issuedAt,                  // Issued at time (iat)
                expiresAt,                 // Expiration time (exp)
                headers,                   // JWT headers (e.g., algorithm)
                claims                     // JWT claims
        );
    }

    private String resignStringDecryptJwt(String encryptedJwtString) throws Exception {
    	// Parse the encrypted JWT
    	EncryptedJWT encryptedJWT = EncryptedJWT.parse(encryptedJwtString);
        // Decrypt the JWT using RSA private key
    	RSADecrypter decrypter = new RSADecrypter(keyUtils.getSecureTokenPrivateKey());
    	encryptedJWT.decrypt(decrypter);
    	// Retrieve the decrypted claims
    	JWTClaimsSet claims = encryptedJWT.getJWTClaimsSet();
    	
    	return reSignJwt(claims);
    }
    
    private JWTClaimsSet decryptJwt(String encryptedJwtString) throws Exception {
    	if (encryptedJwtString==null) {
    		return null;
    	}
    	// Parse the encrypted JWT
    	EncryptedJWT encryptedJWT = EncryptedJWT.parse(encryptedJwtString);
        // Decrypt the JWT using RSA private key
    	RSADecrypter decrypter = new RSADecrypter(keyUtils.getSecureTokenPrivateKey());
    	encryptedJWT.decrypt(decrypter);
    	// Retrieve the decrypted claims
    	JWTClaimsSet claims = encryptedJWT.getJWTClaimsSet();
    	return claims;
    }
    
    // Re-sign the JWTClaimsSet and return a compact JWT string
    private String reSignJwt(JWTClaimsSet claims) throws Exception {
        JWSSigner signer = new RSASSASigner(keyUtils.getSecureTokenPrivateKey());
        // Create a new signed JWT with the decrypted claims
        SignedJWT signedJWT = new SignedJWT(
                new JWSHeader(JWSAlgorithm.RS256)
                , claims);

        // Sign the JWT
        signedJWT.sign(signer);

        // Return the compact JWT string
        return signedJWT.serialize();
    }
}
