package com.mutecsoft.atalk.component.redis;

import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mutecsoft.atalk.logic.util.RandomHexString;
import com.mutecsoft.atalk.secure.model.redis.RedisPacketKeySeed;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author voyzer
 *
 */
@Slf4j
@Component
@Getter
@Setter
public class RedisTaskBroker {

	@Autowired
	@Qualifier("redisTemplatePacketKeyDb")
	RedisTemplate<String, String> redisTemplatePacketKeyDb;
//	
//	@Autowired
//	@Qualifier("redisTemplateTransMutexDb")
//	RedisTemplate<String,Object> redisTemplateTransMutexDb;
	
	@Value("${spring.redis.expire-time-second}")
	private int expireTimeSeconds;
	
	@Value("${spring.redis.expire-time-millisecond-lock}")
	private int expireTimeMilliSecondsLockSeconds;
	
    @Autowired
    private ObjectMapper objectMapper;
    
	public RedisTaskBroker() {
		
	}
	
    /**
     * 
     * @param key
     * @param data
     */
	public void writeJsonToRedis(String key, Object data) {
		try {
			String jsonData = objectMapper.writeValueAsString(data);
			redisTemplatePacketKeyDb.opsForValue().set(key, jsonData);
		} catch (JsonProcessingException e) {
			log.error("@@@@ Err : {}", e);
		}
	}
	

    /**
     * 
	 * @param data
	 * @return
	 */
	public String getJsonValue(Object data) {
		try {
			String jsonData = objectMapper.writeValueAsString(data);
			return jsonData;
		} catch (JsonProcessingException e) {
			log.error("@@@@ Err : {}", e);
		}
		return null;
	}

	/**
	 * 
	 * @param seedValue
	 * @return
	 */
	@SuppressWarnings("finally")
	public int insertSeedValue(String seedValue) {
		int resData = 0;
		try {
			ValueOperations<String, String> vop = redisTemplatePacketKeyDb.opsForValue();
			String key = seedValue;
			
			RedisPacketKeySeed packetKeyObj = RedisPacketKeySeed.builder()
					.activeYn("N")
					.createdDt(new Date())
					.seed(seedValue)
					.packetKey(RandomHexString.genSecureRandomHex(64))  // 32 bytes buffer
					.build();
			log.debug("#### key : {}", key);
			redisTemplatePacketKeyDb.delete(key);
			String jsonValue = getJsonValue(packetKeyObj);
			log.debug("#### json value : {}", jsonValue);
			Boolean bRes = vop.setIfAbsent(key, jsonValue);
			log.info("#### redis key bRes : {}, seed value : {}",
					bRes, seedValue);
			if (bRes == null || bRes.equals(Boolean.FALSE)) {
				bRes = vop.setIfPresent(key, jsonValue);
				if (bRes == null || bRes.equals(Boolean.FALSE)) {
					log.debug("#### NOK UPDATE_1 : {}", key);
				} else {
					log.debug("## OK UPDATE_1 : {}", key);
				}
				log.debug("## OK UPDATE_2 : {}", key);
			}
			final Boolean expireRes = redisTemplatePacketKeyDb.expire(key, 
					 expireTimeSeconds, TimeUnit.SECONDS);
			log.info("#### redis insert:: key : {}, expire result : {}, exipreTime : {}",
					key, expireRes, expireTimeSeconds);
		} catch (Exception e) {
			log.error("@@@@ Err : {}", e);
		} finally {
			return resData;
		}
	}
	
	/**
	 * 
	 * 
	 * @param redisKey
	 * @param packetKeyObj
	 * @return
	 */
	@SuppressWarnings("finally")
	public int insertSeedObject(String redisKey, RedisPacketKeySeed packetKeyObj) {
		int resData = 0;
		try {
			ValueOperations<String, String> vop = redisTemplatePacketKeyDb.opsForValue();
			String key = redisKey;
			
			log.debug("#### key : {}", key);
			redisTemplatePacketKeyDb.delete(key);
			String jsonValue = getJsonValue(packetKeyObj);
			log.debug("#### json value : {}", jsonValue);
			
			Boolean exists = redisTemplatePacketKeyDb.hasKey(key);
			if (exists) {
				redisTemplatePacketKeyDb.delete(key);	
			}
			Boolean bRes = vop.setIfAbsent(key, jsonValue);
			if (bRes == null || bRes.equals(Boolean.FALSE)) {
				bRes = vop.setIfPresent(key, jsonValue);
				if (bRes == null || bRes.equals(Boolean.FALSE)) {
					log.debug("#### NOK UPDATE_1 : {}", key);
				} else {
					log.debug("## OK UPDATE_1 : {}", key);
				}
				log.debug("## OK UPDATE_2 : {}", key);
			}
			final Boolean expireRes = redisTemplatePacketKeyDb.expire(key, 
					 expireTimeSeconds, TimeUnit.SECONDS);
			log.info("#### redis insert:: key : {}, expire result : {}, exipreTime : {}",
					key, expireRes, expireTimeSeconds);
		} catch (Exception e) {
			log.error("@@@@ Err : {}", e);
		} finally {
			return resData;
		}
	}

	/**
	 * 
	 * @param seedValue
	 * @return
	 */
	@SuppressWarnings("finally")
	public int updateKeySeedObject(String key, RedisPacketKeySeed pktKeySeedObj) {
		int resData = 0;
		try {
			ValueOperations<String, String> vop = redisTemplatePacketKeyDb.opsForValue();
			String jsonValue = getJsonValue(pktKeySeedObj);
			log.debug("#### json value : {}", jsonValue);
			Boolean bRes = vop.setIfAbsent(key, jsonValue);
			if (bRes == null || bRes.equals(Boolean.FALSE)) {
				bRes = vop.setIfPresent(key, jsonValue);
				if (bRes == null || bRes.equals(Boolean.FALSE)) {
					log.debug("#### NOK UPDATE_1 : {}", key);
				} else {
					log.debug("## OK UPDATE_1 : {}", key);
				}
				log.debug("## OK UPDATE_2 : {}", key);
			}
			final Boolean expireRes = redisTemplatePacketKeyDb.expire(key, 
					 expireTimeSeconds, TimeUnit.SECONDS);
			log.info("#### redis insert:: key : {}, expire result : {}, exipreTime : {}",
					key, expireRes, expireTimeSeconds);
		} catch (Exception e) {
			log.error("@@@@ Err : {}", e);
		} finally {
			return resData;
		}
	}
	
	/**
	 * 패킷키 SEED 정보 반환
	 * 
	 * @param userNo
	 * @return
	 */
	public RedisPacketKeySeed findKeyObjectByUserNo(Long userNo) {
		ValueOperations<String, String> vop = redisTemplatePacketKeyDb.opsForValue();
		String seedValueKey = String.format("PKTKEY_%d", userNo);
		String packetKeySeedString = (String)vop.get(seedValueKey);
		RedisPacketKeySeed packetKeyObj = null;
		try {
			packetKeyObj = objectMapper.readValue(packetKeySeedString, RedisPacketKeySeed.class);
		} catch (Exception e) {
			log.error("@@@@ Err : {}", e);
		}
		return packetKeyObj;
	}
	
	/**
	 * 패킷키 SEED 정보 반환
	 * 
	 * @param seedValue
	 * @param vop
	 * @return
	 */
	public RedisPacketKeySeed findKeySeedData(String seedValue) {
		ValueOperations<String, String> vop = redisTemplatePacketKeyDb.opsForValue();
		String packetKeySeedString = (String)vop.get(seedValue);
		RedisPacketKeySeed packetKeyObj = null;
		try {
			packetKeyObj = objectMapper.readValue(packetKeySeedString, RedisPacketKeySeed.class);
		} catch (Exception e) {
			log.error("@@@@ Err : {}", e);
		}
		return packetKeyObj;
	}
	
	
	/**
	 * 패킷키 SEED 정보 반환 (사용자번호로)
	 * 
	 * @param seedValue
	 * @param vop
	 * @return
	 */
	public RedisPacketKeySeed findKeyUserNo(Long userNo) {
		ValueOperations<String, String> vop = redisTemplatePacketKeyDb.opsForValue();
		String redisKey = String.format("PKTKEY_%d", userNo);
		String packetKeySeedString = vop.get(redisKey);
		if (packetKeySeedString == null) {
			return null;
		}
		// String packetKeySeedString = (String)vop.get(redisKey);
		RedisPacketKeySeed packetKeyObj = null;
		try {
			packetKeyObj = objectMapper.readValue(packetKeySeedString, RedisPacketKeySeed.class);
		} catch (Exception e) {
			log.error("@@@@ Err : {}", e);
		}
		return packetKeyObj;
	}
}
