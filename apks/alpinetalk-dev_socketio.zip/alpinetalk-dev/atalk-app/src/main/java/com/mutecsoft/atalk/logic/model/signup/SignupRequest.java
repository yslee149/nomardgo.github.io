package com.mutecsoft.atalk.logic.model.signup;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.mutecsoft.atalk.logic.model.AtalkPacketBase;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.logic.util.AesEncDecComplex;

/**
 * @PackageName com.mutecsoft.atalk.logic.model.signup
 * @fileName	SignupRequest.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description :
 * <pre>
 * 
 * </pre>
 */

public class SignupRequest extends AtalkPacketBase {

    /**
	 * 
	 */
	private static final long serialVersionUID = -6286311744366868633L;
	
	private String signupToken;
	
	private String userId; // email
	private String password;
	
	private String userName;
	private String gender; // M, F
	
	private Long piAgreeVersion; // 동의약관 버전(개인정보)
	private Long siAgreeVersion; // 동의약관 버전(서비스)
	private Long pfAgreeVersion; // 동의약관 버전(프로필)
	
	private String birthDate;
	
	private String phoneNumber;
	private String statusMessage;
	
	private String lang;		// ko, js, jp, cn
	

	public Long getSiAgreeVersion() {
		return siAgreeVersion;
	}

	public void setSiAgreeVersion(Long siAgreeVersion) {
		this.siAgreeVersion = siAgreeVersion;
	}

	public Long getPfAgreeVersion() {
		return pfAgreeVersion;
	}

	public void setPfAgreeVersion(Long pfAgreeVersion) {
		this.pfAgreeVersion = pfAgreeVersion;
	}

	public Long getPiAgreeVersion() {
		return piAgreeVersion;
	}

	public void setPiAgreeVersion(Long piAgreeVersion) {
		this.piAgreeVersion = piAgreeVersion;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getStatusMessage() {
		return statusMessage;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

	public String getLang() {
		return lang;
	}

	public void setLang(String lang) {
		this.lang = lang;
	}

	public String getSignupToken() {
		return signupToken;
	}

	public void setSignupToken(String signupToken) {
		this.signupToken = signupToken;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	@Override
	public SecureDataModel toFinalModel() throws Exception {

		return null;
	}

	@Override
	public SecureDataModel toFinalModel(String seedValue, String packetKey) throws Exception {
		if (packetKey == null || packetKey.equals("")) {
			return null;
		}
		if (seedValue == null || seedValue.equals("")) {
			return null;
		}
		SecureDataModel secureModel = new SecureDataModel();
		secureModel.setTransactinId(this.getTransactinId());
		String jsonData = this.toJson();
		
		byte [] encBuffer = AesEncDecComplex.encryptAesCtrWithRandomIv(
				jsonData.getBytes(), packetKey);
		String hexEncString = AesEncDecComplex.bytesToHex(encBuffer);

		secureModel.setData(hexEncString);
		secureModel.setDataAfter(seedValue);
		
		return secureModel;
	}

	@Override
	public SecureDataModel toFinalModel(String packetKey) throws Exception {
		if (packetKey == null || packetKey.equals("")) {
			return null;
		}
		SecureDataModel secureModel = new SecureDataModel();
		secureModel.setTransactinId(this.getTransactinId());
		String jsonData = this.toJson();
		
		byte [] encBuffer = AesEncDecComplex.encryptAesCtrWithRandomIv(
				jsonData.getBytes(), packetKey);
		String hexEncString = AesEncDecComplex.bytesToHex(encBuffer);

		secureModel.setData(hexEncString);
		return secureModel;
	}

	@Override
	public String toJson() throws JsonProcessingException {
		return objectMapper.writeValueAsString(this);
	}
}
