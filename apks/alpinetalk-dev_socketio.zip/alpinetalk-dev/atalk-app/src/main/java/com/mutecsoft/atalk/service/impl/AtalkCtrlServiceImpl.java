package com.mutecsoft.atalk.service.impl;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.service.AtalkCtrlService;

import jakarta.annotation.PostConstruct;
import jakarta.persistence.EntityManager;
import jakarta.persistence.ParameterMode;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.StoredProcedureQuery;
import lombok.extern.slf4j.Slf4j;

/**
 * 서비스 컨트롤
 * 
 */
@Slf4j
@Service("atalkCtrlService")
public class AtalkCtrlServiceImpl implements AtalkCtrlService {

	@PersistenceContext
	EntityManager entityManager;

	ObjectMapper objectMapper;
	
	@PostConstruct
	private void init() {
		objectMapper = new ObjectMapper();
	}

	@Override
	public String resetAll(SecureDataModel secModel) throws Exception {
		StoredProcedureQuery query = entityManager.createStoredProcedureQuery("PROC_RESET_ALL");

		query.registerStoredProcedureParameter("OUT_RESULT", String.class, ParameterMode.OUT);
		query.execute();
		
		String outResult = (String) query.getOutputParameterValue("OUT_RESULT");
		
		log.debug("### OUT_RESULT RESULT :: outResult : {}",
				outResult);
		return outResult;
	}
}
