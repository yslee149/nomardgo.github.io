package com.mutecsoft.atalk.logic.model.digitalsign;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.mutecsoft.atalk.logic.model.AtalkPacketBase;
import com.mutecsoft.atalk.logic.model.SecureDataModel;

/**
 * @PackageName com.mutecsoft.atalk.logic.model.digitalsign
 * @fileName	PacketKeySeed.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description :
 * <pre>
 * 
 * </pre>
 */

public class PacketKeySeed extends AtalkPacketBase {

    /**
	 * 
	 */
	private static final long serialVersionUID = -6286311744366868633L;
	private String seedValue;
	
	public String getSeedValue() {
		return seedValue;
	}

	public void setSeedValue(String seedValue) {
		this.seedValue = seedValue;
	}

	@Override
	public SecureDataModel toFinalModel() {
		SecureDataModel secureModel = new SecureDataModel();
		secureModel.setTransactinId(this.getTransactinId());
		secureModel.setData(seedValue, "");
		return secureModel;
	}

	@Override
	public SecureDataModel toFinalModel(String seedValue, String packetKey) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SecureDataModel toFinalModel(String packetKey) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public String toJson() throws JsonProcessingException {
		// TODO Auto-generated method stub
		return null;
	}
}
