package com.mutecsoft.atalk.logic;

import freemarker.core.Environment;
import freemarker.template.*;

import java.io.IOException;
import java.io.Writer;
import java.net.URLDecoder;
import java.util.Map;

public class UriDecodeDirective implements TemplateDirectiveModel {

    public void execute(Environment environment, @SuppressWarnings("rawtypes") Map params, TemplateModel[] loopVars, TemplateDirectiveBody body)
            throws TemplateException, IOException {

        if (!params.isEmpty()) {
            throw new TemplateModelException(
                    "This directive doesn't allow parameters.");
        }
        if (loopVars.length != 0) {
            throw new TemplateModelException(
                    "This directive doesn't allow loop variables.");
        }
        if (body != null) {
            body.render(new UrlDecodeFilterWriter(environment.getOut()));
        } else {
            throw new RuntimeException("missing body");
        }
    }

    private static class UrlDecodeFilterWriter extends Writer {
        private final Writer out;
        UrlDecodeFilterWriter (Writer out) {
            this.out = out;
        }
        public void write(char[] cbuf, int off, int len)
                throws IOException {
            out.write(URLDecoder.decode(String.valueOf(cbuf), "UTF-8"));
        }
        public void flush() throws IOException {
            out.flush();
        }
        public void close() throws IOException {
            out.close();
        }
    }
}
