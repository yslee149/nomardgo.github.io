package com.mutecsoft.atalk.logic.model.digitalsign;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.mutecsoft.atalk.logic.model.AtalkPacketBase;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.logic.util.RsaComplex;

/**
 * @PackageName com.mutecsoft.atalk.logic.model.digitalsign
 * @fileName	PacketKeySeed.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description :
 * <pre>
 * 
 * </pre>
 */

public class PacketKeyResult extends AtalkPacketBase {

    /**
	 * 
	 */
	private static final long serialVersionUID = -6286311744366868633L;
	private String packetKeyData;
	
	// client publickey
	private String publicKey;
	
	public String getPacketKeyData() {
		return packetKeyData;
	}

	public String getPublicKey() {
		return publicKey;
	}

	public void setPublicKey(String publicKey) {
		this.publicKey = publicKey;
	}

	public void setPacketKeyData(String packetKeyData) {
		this.packetKeyData = packetKeyData;
	}

	@Override
	public SecureDataModel toFinalModel() {
		SecureDataModel secureModel = new SecureDataModel();
		secureModel.setTransactinId(this.getTransactinId());
		String encryptedKeyStr = RsaComplex.encrypt(packetKeyData, publicKey);
		secureModel.setData(encryptedKeyStr, "");
		return secureModel;
	}

	@Override
	public SecureDataModel toFinalModel(String seedValue, String packetKey) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SecureDataModel toFinalModel(String packetKey) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public String toJson() throws JsonProcessingException {
		// TODO Auto-generated method stub
		return null;
	}
}
