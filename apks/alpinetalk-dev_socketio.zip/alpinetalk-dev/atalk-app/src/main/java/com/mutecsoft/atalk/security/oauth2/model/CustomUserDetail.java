package com.mutecsoft.atalk.security.oauth2.model;

import java.util.Collection;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.mutecsoft.atalk.common.model.MUser;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @PackageName com.mutecsoft.thechat.app.security.oauth2.model
 * @fileName	CustomUserDetail.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description :
 * <pre>
 * </pre>
 */
@Builder
@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class CustomUserDetail implements UserDetails {
	private static final long serialVersionUID = -4711988522952516727L;
    private MUser mUser;
    
    private String userId;
    
    private String firstLogin;
    
    private Map<String, Object> moreInfo;
    
    public void setMoreInfo(Map<String, Object> moreInf) {
    	this.moreInfo=moreInf;
    }
    
    public Map<String, Object> getMoreInfo() {
    	return this.moreInfo;
    }
    
    public void setUserId(String userId) {
    	this.userId = userId;
//    	if (mUser==null) {
//    		mUser = new MUser();
//    		mUser.setUserId(userId);
//    	}
    }
    
	public String getUserId() {
		if (userId==null ) {
			return mUser.getUserId();
		} else {
			return userId;
		}
	}
	
	public String getFristLogin() {
		return mUser.getFirstLogin();
	}
	
	@Override
	public String getUsername() {
		return this.userId;
		// return mUser.getUserId();
	}
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getPassword() {
		if (StringUtils.isBlank(mUser.getUserPwTemp())) {
			return mUser.getUserPw();	
		}
		return mUser.getUserPw() + "::" + mUser.getUserPwTemp();	
	}
}
