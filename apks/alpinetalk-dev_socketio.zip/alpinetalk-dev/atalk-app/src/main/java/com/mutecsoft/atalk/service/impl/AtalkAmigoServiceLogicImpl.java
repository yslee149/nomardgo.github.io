package com.mutecsoft.atalk.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.mutecsoft.atalk.common.model.MAmigo;
import com.mutecsoft.atalk.common.model.MUser;
import com.mutecsoft.atalk.common.repository.MAmigoRepository;
import com.mutecsoft.atalk.common.repository.MAmigoSetRepository;
import com.mutecsoft.atalk.common.repository.MUserRepository;
import com.mutecsoft.atalk.config.AtalkConfig;
import com.mutecsoft.atalk.logic.model.amigo.AddAmigoRequest;
import com.mutecsoft.atalk.logic.model.amigo.Amigo;
import com.mutecsoft.atalk.logic.model.amigo.AmigoDetailResponse;
import com.mutecsoft.atalk.logic.model.amigo.AmigoListResponse;
import com.mutecsoft.atalk.logic.model.amigo.DeleteAmigoRequest;
import com.mutecsoft.atalk.logic.model.amigo.DeleteAmigoResponse;
import com.mutecsoft.atalk.service.AtalkAmigoServiceLogic;

import jakarta.servlet.ServletContext;
import lombok.extern.slf4j.Slf4j;

/**
 * 친구그룹 서비스
 * 
 */
@Slf4j
@Service("atalkAmigoServiceLogic")
public class AtalkAmigoServiceLogicImpl implements AtalkAmigoServiceLogic {

	@Autowired
	MUserRepository mUserRepository;
	
	@Autowired
	MAmigoSetRepository mAmigoSetRepository;

	@Autowired
	MAmigoRepository mAmigoRepository;
	
	@Autowired
	AtalkConfig atalkConfig;
	
	@Autowired
	ServletContext servletContext;
	
	@Override
	public AmigoListResponse addAmigo(MUser user, AddAmigoRequest reqObj) throws Exception {
		log.debug("################# ADD AMIGO");
		List<Long> amigoNoList = reqObj.getAmigoUserNoList();
		mAmigoRepository.deleteAmigos(user.getUserNo(), amigoNoList);
		mAmigoRepository.insertAmigos(user.getUserNo(), 0L, amigoNoList);

		///////////////////////// RESPONSE /////////////////////////////////////////////////////
		List<MAmigo> amigoList = mAmigoRepository.findByUserNoAndAmigoSetNoAndUseYnAndAmigoNoIn(user.getUserNo()
				, 0L
				, "Y"
				, amigoNoList);
		
		List<Amigo> amigoListObj = Lists.newArrayList();
		for (MAmigo amigo : amigoList) {
			Amigo o = new Amigo();
		//	o.setUserName(amigo.getuser);
			Optional<MUser> uOp= mUserRepository.findByUserNo(amigo.getAmigoNo());
			if (uOp.isEmpty()
					|| !uOp.get().getActiveYn().equals("Y")
					|| !uOp.get().getUseYn().equals("Y")) {
				continue;
			}
			o.setUserName(uOp.get().getUserName());
			o.setUserNo(uOp.get().getUserNo());
			o.setNickname(amigo.getNickname()==null ? "" : amigo.getNickname());
//
			o.setStatusMessage(uOp.get().getStatusMessage());

			List<String> profileUrlList = _getProfileInfo(uOp.get());
			o.setProfileFgThumbUrl(profileUrlList.get(0));
			o.setProfileFgUrl(profileUrlList.get(1));
			o.setProfileBgThumbUrl(profileUrlList.get(2));
			o.setProfileBgUrl(profileUrlList.get(3));
			
			amigoListObj.add(o);
		}
		///////////////////////// RESPONSE /////////////////////////////////////////////////////
		AmigoListResponse respObj = new AmigoListResponse();
		respObj.setAmigoList(amigoListObj);
		return respObj;
	}

	@Override
	public DeleteAmigoResponse deleteAmigo(MUser user, DeleteAmigoRequest reqObj)
			throws Exception {
		log.debug("################# ADD AMIGO");
		List<Long> amigoList = reqObj.getAmigoUserNoList();
		mAmigoRepository.deleteAmigos(user.getUserNo(), amigoList);

		///////////////////////// RESPONSE /////////////////////////////////////////////////////
		DeleteAmigoResponse respObj = new DeleteAmigoResponse();
		respObj.setResult(Boolean.TRUE);
		return respObj;
	}
	
	@Override
	public AmigoListResponse amigoList(MUser user) throws Exception {
		log.debug("################# GET LIST AMIGO SET");
//		List<MAmigoSet> mAmigoSetList = mAmigoSetRepository.findByUserNoAndUseYn(user.getUserNo(), "Y");
//		List<AmigoSet> amigoSetList = Lists.newArrayList();
//		List<MAmigo> amigoList = null;
//		
//		String contextPath = servletContext.getContextPath();
//		
//		String fgThumbnailPath, fgViewPath;
//		String bgThumbnailPath, bgViewPath;
//		
//		for (MAmigoSet amigoSetObj : mAmigoSetList) {
//			AmigoSet obj = new AmigoSet();
//			obj.setAmigoSetName(amigoSetObj.getAmigoSetName());
//			obj.setAmigoSetNo(amigoSetObj.getAmigoSetNo());
//			obj.setAmigoList(new ArrayList<Amigo>());
//			amigoList = mAmigoRepository.findByUserNoAndAmigoSetNoAndUseYn(
//					user.getUserNo()
//					, amigoSetObj.getAmigoSetNo()
//					, "Y");
//			for (MAmigo amigo : amigoList) {
//				Amigo o = new Amigo();
//			//	o.setUserName(amigo.getuser);
//				Optional<MUser> uOp= mUserRepository.findByUserNo(amigo.getAmigoNo());
//				if (uOp.isEmpty()
//						|| !uOp.get().getActiveYn().equals("Y")
//						|| !uOp.get().getUseYn().equals("Y")) {
//					continue;
//				}
//				o.setUserName(uOp.get().getUserName());
//				o.setUserNo(uOp.get().getUserNo());
//				o.setStatusMessage(uOp.get().getStatusMessage());
//
//				fgThumbnailPath="";
//				fgViewPath="";
//				bgThumbnailPath="";
//				bgViewPath="";
//				
//				if (uOp.get().getProfileFgNo()!=null) {
//					fgThumbnailPath = String.format("%s%s%s/%s/%d",
//							atalkConfig.getChatConfig().getBaseAddress()
//							, contextPath 
//							, atalkConfig.getProfileConfig().getBaseUrl()
//							, "thumb"
//							, uOp.get().getProfileFgNo());
//					fgViewPath = String.format("%s%s%s/%s/%d",
//							atalkConfig.getChatConfig().getBaseAddress()
//							, contextPath 
//							, atalkConfig.getProfileConfig().getBaseUrl()
//							, "view"
//							, uOp.get().getProfileFgNo());
//				}
//				if (uOp.get().getProfileFgNo()!=null) {
//					bgThumbnailPath = String.format("%s%s%s/%s/%d",
//							atalkConfig.getChatConfig().getBaseAddress()
//							, contextPath 
//							, atalkConfig.getProfileConfig().getBaseUrl()
//							, "thumb"
//							, uOp.get().getProfileBgNo());
//					bgViewPath = String.format("%s%s%s/%s/%d",
//							atalkConfig.getChatConfig().getBaseAddress()
//							, contextPath 
//							, atalkConfig.getProfileConfig().getBaseUrl()
//							, "view"
//							, uOp.get().getProfileBgNo());
//				}
//				o.setProfileFgThumbUrl(fgThumbnailPath);
//				o.setProfileFgUrl(fgViewPath);
//				o.setProfileBgThumbUrl(bgThumbnailPath);
//				o.setProfileBgUrl(bgViewPath);
//				obj.getAmigoList().add(o);
//			}
//			amigoSetList.add(obj);
//		}
		List<MAmigo> amigoList = mAmigoRepository.findByUserNoAndAmigoSetNoAndUseYn(user.getUserNo()
				, 0L
				, "Y");
		
		List<Amigo> amigoListObj = Lists.newArrayList();
		for (MAmigo amigo : amigoList) {
			Amigo o = new Amigo();
		//	o.setUserName(amigo.getuser);
			Optional<MUser> uOp= mUserRepository.findByUserNo(amigo.getAmigoNo());
			if (uOp.isEmpty()
					|| !uOp.get().getActiveYn().equals("Y")
					|| !uOp.get().getUseYn().equals("Y")) {
				continue;
			}
			o.setUserName(uOp.get().getUserName());
			o.setUserNo(uOp.get().getUserNo());
			o.setNickname(amigo.getNickname()==null ? "" : amigo.getNickname());
//
			o.setStatusMessage(uOp.get().getStatusMessage());

			List<String> profileUrlList = _getProfileInfo(uOp.get());
			o.setProfileFgThumbUrl(profileUrlList.get(0));
			o.setProfileFgUrl(profileUrlList.get(1));
			o.setProfileBgThumbUrl(profileUrlList.get(2));
			o.setProfileBgUrl(profileUrlList.get(3));
			
			amigoListObj.add(o);
		}
		///////////////////////// RESPONSE /////////////////////////////////////////////////////
		AmigoListResponse respObj = new AmigoListResponse();
		respObj.setAmigoList(amigoListObj);
		return respObj;
	}

	@Override
	public AmigoDetailResponse detail(MUser user, Long amigoUserNo) throws Exception {
		
		AmigoDetailResponse respObj = new AmigoDetailResponse();
		Amigo o = new Amigo();
		//	o.setUserName(amigo.getuser);
		Optional<MAmigo> amigoOp= mAmigoRepository.findByUserNoAndAmigoNo(user.getUserNo(), amigoUserNo);
		if (amigoOp.isEmpty()
				|| !amigoOp.get().getUseYn().equals("Y")) {
			return respObj;
		}
		Optional<MUser> uOp= mUserRepository.findByUserNo(amigoUserNo);
		if (uOp.isEmpty()
				|| !uOp.get().getActiveYn().equals("Y")
				|| !uOp.get().getUseYn().equals("Y")) {
			return respObj;
		}
		
		o.setUserName(uOp.get().getUserName());
		o.setUserNo(uOp.get().getUserNo());
		o.setNickname(amigoOp.get().getNickname()==null ? "" : amigoOp.get().getNickname());
		o.setStatusMessage(uOp.get().getStatusMessage());

		List<String> profileUrlList = _getProfileInfo(uOp.get());
		o.setProfileFgThumbUrl(profileUrlList.get(0));
		o.setProfileFgUrl(profileUrlList.get(1));
		o.setProfileBgThumbUrl(profileUrlList.get(2));
		o.setProfileBgUrl(profileUrlList.get(3));

		respObj.setAmigoInfo(o);
		
		return respObj;
	}
	
	/**
	 * 
	 * @param user
	 * @return
	 */
	private List<String> _getProfileInfo(MUser user) {
		List<String> profileList = Lists.newArrayList();
		String fgThumbnailPath = "";
		String fgViewPath = "";
		String bgThumbnailPath = "";
		String bgViewPath = "";
		String contextPath = servletContext.getContextPath();
		if (user.getProfileFgNo()!=null) {
			fgThumbnailPath = String.format("%s%s%s/%s/%d",
					atalkConfig.getChatConfig().getBaseAddress()
					, contextPath 
					, atalkConfig.getProfileConfig().getBaseUrl()
					, "thumb"
					, user.getProfileFgNo());
			fgViewPath = String.format("%s%s%s/%s/%d",
					atalkConfig.getChatConfig().getBaseAddress()
					, contextPath 
					, atalkConfig.getProfileConfig().getBaseUrl()
					, "view"
					, user.getProfileFgNo());
		}
		if (user.getProfileFgNo()!=null) {
			bgThumbnailPath = String.format("%s%s%s/%s/%d",
					atalkConfig.getChatConfig().getBaseAddress()
					, contextPath 
					, atalkConfig.getProfileConfig().getBaseUrl()
					, "thumb"
					, user.getProfileBgNo());
			bgViewPath = String.format("%s%s%s/%s/%d",
					atalkConfig.getChatConfig().getBaseAddress()
					, contextPath 
					, atalkConfig.getProfileConfig().getBaseUrl()
					, "view"
					, user.getProfileBgNo());
		}
		profileList.add(fgThumbnailPath);
		profileList.add(fgViewPath);
		profileList.add(bgThumbnailPath);
		profileList.add(bgViewPath);
		
		return profileList;
	}

	@Override
	public int updateNickName(MUser user, Long amigoNo, String nickName) throws Exception {
		mAmigoRepository.updateNickname(user.getUserNo(), nickName, amigoNo);
		return 1;
	}

	@Override
	public AmigoDetailResponse addAmigoOne(MUser user, Long amigoNo) throws Exception {
		log.debug("################# ADD AMIGO");
		List<Long> amigoNoList = List.of(amigoNo);
		mAmigoRepository.deleteAmigos(user.getUserNo(), amigoNoList);
		mAmigoRepository.insertAmigos(user.getUserNo(), 0L, amigoNoList);

		///////////////////////// RESPONSE /////////////////////////////////////////////////////
		Optional<MAmigo> amigoOp = mAmigoRepository.findByUserNoAndAmigoSetNoAndUseYnAndAmigoNo(user.getUserNo()
				, 0L
				, "Y"
				, amigoNo);
		if (!amigoOp.isPresent()) {
			return null;
		}
		MAmigo amigo = amigoOp.get();
		Amigo o = new Amigo();
	//	o.setUserName(amigo.getuser);
		Optional<MUser> uOp= mUserRepository.findByUserNo(amigo.getAmigoNo());
		if (uOp.isEmpty()
				|| !uOp.get().getActiveYn().equals("Y")
				|| !uOp.get().getUseYn().equals("Y")) {
			return null;
		}
		o.setUserName(uOp.get().getUserName());
		o.setUserNo(uOp.get().getUserNo());
		o.setNickname(amigo.getNickname()==null ? "" : amigo.getNickname());
//
		o.setStatusMessage(uOp.get().getStatusMessage());

		List<String> profileUrlList = _getProfileInfo(uOp.get());
		o.setProfileFgThumbUrl(profileUrlList.get(0));
		o.setProfileFgUrl(profileUrlList.get(1));
		o.setProfileBgThumbUrl(profileUrlList.get(2));
		o.setProfileBgUrl(profileUrlList.get(3));
		
		AmigoDetailResponse respObj = new AmigoDetailResponse();
		respObj.setAmigoInfo(o);
		return respObj;
	}
}
