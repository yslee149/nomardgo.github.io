package com.mutecsoft.atalk.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.security.authentication.dao.DaoAuthenticationProvider;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.google.common.collect.Lists;
import com.mutecsoft.atalk.common.model.MAgreementHist;
import com.mutecsoft.atalk.common.model.MAuthEmail;
import com.mutecsoft.atalk.common.model.MUser;
import com.mutecsoft.atalk.common.model.MUserProfile;
import com.mutecsoft.atalk.common.model.MUserSignuptoken;
import com.mutecsoft.atalk.common.repository.MAgreementHistRepository;
import com.mutecsoft.atalk.common.repository.MAuthEmailRepository;
import com.mutecsoft.atalk.common.repository.MUserRepository;
import com.mutecsoft.atalk.common.repository.MUserSignupTokenRepository;
import com.mutecsoft.atalk.component.PacketDecryptor;
import com.mutecsoft.atalk.component.redis.RedisTaskBroker;
import com.mutecsoft.atalk.config.AtalkConfig;
import com.mutecsoft.atalk.config.AuthTokenGenerator;
import com.mutecsoft.atalk.constant.EnumLangType;
import com.mutecsoft.atalk.logic.model.AtalkDataModelAll;
import com.mutecsoft.atalk.logic.model.AtalkPacketBase;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.logic.model.auth.UserAuthTokenRequest;
import com.mutecsoft.atalk.logic.model.auth.UserAuthTokenResponse;
import com.mutecsoft.atalk.logic.model.auth.UserLoginRequest;
import com.mutecsoft.atalk.logic.model.auth.UserLoginResponse;
import com.mutecsoft.atalk.logic.model.auth.UserPasswordRequest;
import com.mutecsoft.atalk.logic.model.auth.UserPasswordResponse;
import com.mutecsoft.atalk.logic.model.auth.UserResultResponse;
import com.mutecsoft.atalk.logic.model.chathub.ChatHubListInfo;
import com.mutecsoft.atalk.logic.model.signup.SignupRequest;
import com.mutecsoft.atalk.logic.model.signup.SignupResponse;
import com.mutecsoft.atalk.logic.model.user.DeleteUserRequest;
import com.mutecsoft.atalk.logic.model.user.DeleteUserResponse;
import com.mutecsoft.atalk.logic.util.AesEncDecComplex;
import com.mutecsoft.atalk.logic.util.HashComplex;
import com.mutecsoft.atalk.logic.util.RandomHexString;
import com.mutecsoft.atalk.secure.model.redis.RedisPacketKeySeed;
import com.mutecsoft.atalk.security.oauth2.model.CustomUserDetail;
import com.mutecsoft.atalk.service.AtalkChatHubServiceLogic;
import com.mutecsoft.atalk.service.AtalkUnreadCntService;
import com.mutecsoft.atalk.service.AtalkUserProfileServiceLogic;
import com.mutecsoft.atalk.service.AtalkUserService;
import com.mutecsoft.atalk.service.AtalkUserServiceLogic;
import com.mutecsoft.atalk.service.UserAccountService;

import jakarta.servlet.ServletContext;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;

/**
 * 사용자 서비스
 * 
 */
@Slf4j
@Service("atalkUserService")
public class AtalkUserServiceImpl implements AtalkUserService {

	@Autowired
	MUserSignupTokenRepository mUserSignupTokenRepository;
	
	@Autowired
	MAgreementHistRepository mAgreementHistRepository;

	@Autowired
	MAuthEmailRepository mAuthEmailRepository;

	
	@Autowired
	MUserRepository mUserRepository;
	
	@Autowired
	UserAccountService userAccountService;
	
	@Autowired
	RedisTaskBroker redisTaskBroker;
	
	@Autowired
	PacketDecryptor packetDecryptor;
	
	@Autowired
	DaoAuthenticationProvider daoAuthenticationProvider;

	@Autowired
	AuthTokenGenerator authTokenGenerator;
	
	@Autowired
	AtalkUserProfileServiceLogic atalkUserProfileServiceLogic;

	@Autowired
	AtalkConfig atalkConfig;

//	public String saveDigitalSigningSeed(String seedValue) {
//		int retval = redisTaskBroker.insertSeedValue(seedValue);
//		return seedValue;
//	}
	
	@Autowired
	AtalkUnreadCntService atalkUnreadCntService;
	
	@Autowired
	AtalkChatHubServiceLogic atalkChatHubServiceLogic;
	
	@Autowired
	ServletContext servletContext;
	
	
	@Autowired
	AtalkUserServiceLogic atalkUserServiceLogic;
//	
//	@Override
//	public Optional<AtalkDataModelAll> signup(SecureDataModel secModel) throws Exception {
//		String signatureDataAll = secModel.getData();
//		/////////////////////////////////
//		String secData = signatureDataAll.substring(
//				0,
//				signatureDataAll.length() - SecureDataModel.KEY_SEED_SIZE);
//		String packetKeySeedValue = signatureDataAll.substring(
//				signatureDataAll.length() - SecureDataModel.KEY_SEED_SIZE);
//		log.debug("#### packetKeySeedValue : {}", packetKeySeedValue);
//		/////////////////////////////////
//		
//		String encryptedSignupDataHex = secData;
//		RedisPacketKeySeed redisKeyObj = redisTaskBroker.findKeySeedData(packetKeySeedValue);
//		
//		if (!redisKeyObj.getActiveYn().equals("Y")) {
//			AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
//					.httpStatusCode(425)
//					.atalkPacketBase(null)
//					.secureModel(null)
//					.build();
//			return Optional.ofNullable(resultObj);
//		}
//		
//		////////////////////// GET PACKET KEY
//		log.debug("#### redisKeyObj : {}", redisKeyObj);
//		String packetKey = redisKeyObj.getPacketKey();
//
//		byte [] encBuffer = AesEncDecComplex.hexToBytes(encryptedSignupDataHex);
//		byte [] decBuffer = AesEncDecComplex.decryptAesWithIv(encBuffer, packetKey);  // AES DECRYPT
//		
//		String objectJson = new String(decBuffer);
//
//		int httpStatusCode = 200;
//		
//		SignupRequest signupRequest = AtalkPacketBase.fromJson(objectJson, SignupRequest.class);
//		
//		if (StringUtils.isBlank(signupRequest.getUserId())) {
//			AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
//					.httpStatusCode(423)
//					.atalkPacketBase(null)
//					.secureModel(null)
//					.build();
//			return Optional.ofNullable(resultObj);
//		}
//		
//		// 1. USER ID CHECK
//		if (StringUtils.isBlank(signupRequest.getUserId())) {
//			
//			AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
//					.httpStatusCode(423)
//					.atalkPacketBase(null)
//					.secureModel(null)
//					.build();
//			return Optional.ofNullable(resultObj);
//		}
//		Optional<MUser> userObjOp = mUserRepository.findByUserId(signupRequest.getUserId());
//		if (!userObjOp.isEmpty()) {
//			log.debug("@@@@@@@@@@@ ALREADY THE USER : {} exists", signupRequest.getUserId());
//			SignupResponse signupResponse = new SignupResponse();
//			signupResponse.setUserId(signupRequest.getUserId());
//			signupResponse.getError().setCode(1004L);
//			signupResponse.getError().setMessage(
//					String.format("Alreay user(%s) exists.",
//							signupRequest.getUserId()));
//			AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
//					.httpStatusCode(httpStatusCode)
//					.atalkPacketBase(signupResponse)
//					.secureModel(signupResponse.toFinalModel(packetKey))
//					.build();
//			return Optional.ofNullable(resultObj);
//		}
//		
//		// signup token 처리
//		MUserSignuptoken signupTokenObj = null;
//		if (!StringUtils.isBlank(signupRequest.getSignupToken())) {
//			Optional<MUserSignuptoken> signupTokenObjOp = mUserSignupTokenRepository.findBySignupKeyAndUseYn(signupRequest.getSignupToken(), "N");
//			if (signupTokenObjOp.isEmpty()) {
//				log.debug("@@@@@@@@@@@ No Valid signup token : {} exists", signupRequest.getSignupToken());
//				SignupResponse signupResponse = new SignupResponse();
//				signupResponse.setUserId(signupRequest.getUserId());
//				signupResponse.getError().setCode(1005L);
//				signupResponse.getError().setMessage(
//						String.format("Invalid signup token : %s",
//								signupRequest.getSignupToken()));
//				AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
//						.httpStatusCode(httpStatusCode)
//						.atalkPacketBase(signupResponse)
//						.secureModel(signupResponse.toFinalModel(packetKey))
//						.build();
//				return Optional.ofNullable(resultObj);
//			}
//			signupTokenObj = signupTokenObjOp.get();
//		} else {
//			if (!StringUtils.isBlank(signupRequest.getSignupEmailToken())) {
//				Optional<MAuthEmail> signupTokenObjOp = mAuthEmailRepository.findByEmail(signupRequest.getUserId());
//				if (signupTokenObjOp.isEmpty()) {
//					log.debug("@@@@@@@@@@@ No Valid email signup token : {}", signupRequest.getUserId());
//					SignupResponse signupResponse = new SignupResponse();
//					signupResponse.setUserId(signupRequest.getUserId());
//					signupResponse.getError().setCode(1005L);
//					signupResponse.getError().setMessage(
//							String.format("No Valid email signup token"));
//					AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
//							.httpStatusCode(httpStatusCode)
//							.atalkPacketBase(signupResponse)
//							.secureModel(signupResponse.toFinalModel(packetKey))
//							.build();
//					return Optional.ofNullable(resultObj);
//				}
//				
//				if (!signupRequest.getSignupEmailToken().equals(signupTokenObjOp.get().getAuthToken())) {
//					SignupResponse signupResponse = new SignupResponse();
//					signupResponse.setUserId(signupRequest.getUserId());
//					signupResponse.getError().setCode(1006L);
//					signupResponse.getError().setMessage(
//							String.format("No Valid email signup token"));
//					AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
//							.httpStatusCode(httpStatusCode)
//							.atalkPacketBase(signupResponse)
//							.secureModel(signupResponse.toFinalModel(packetKey))
//							.build();
//					return Optional.ofNullable(resultObj);
//				}
//				
//				Date date = new Date();
//				long differenceInMillis = date.getTime() - signupTokenObjOp.get().getRegDate().getTime();
//		        long differenceInSeconds = differenceInMillis / 1000;
//		        // 5분 간 유효함
//		        if (differenceInSeconds > 300L) {
//		        	SignupResponse signupResponse = new SignupResponse();
//					signupResponse.setUserId(signupRequest.getUserId());
//					signupResponse.getError().setCode(1009L);
//					signupResponse.getError().setMessage(
//							String.format("No Valid email signup token"));
//					AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
//							.httpStatusCode(httpStatusCode)
//							.atalkPacketBase(signupResponse)
//							.secureModel(signupResponse.toFinalModel(packetKey))
//							.build();
//					return Optional.ofNullable(resultObj);
//		        }
//			} else {
//				// 가입불가 
//				log.debug("@@@@@@@@@@@ No email auth token exists, email : {}", signupRequest.getUserId());
//				SignupResponse signupResponse = new SignupResponse();
//				signupResponse.setUserId(signupRequest.getUserId());
//				signupResponse.getError().setCode(1007L);
//				signupResponse.getError().setMessage("No auth email token");
//				AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
//						.httpStatusCode(httpStatusCode)
//						.atalkPacketBase(signupResponse)
//						.secureModel(signupResponse.toFinalModel(packetKey))
//						.build();
//				return Optional.ofNullable(resultObj);
//			}
//		}
//		MUser mUser = new MUser();
//		mUser.setActiveYn("Y");
//		mUser.setUseYn("Y");
//		mUser.setFirstLogin("Y");
//		mUser.setUserId(signupRequest.getUserId());
//		mUser.setUserName(signupRequest.getUserName());
//		mUser.setSignupKey(signupRequest.getSignupToken());
//		mUser.setEmail(signupRequest.getUserId());
//		mUser.setGender(signupRequest.getGender());
//		mUser.setUserPw(HashComplex.hashWithSha512(
//				signupRequest.getPassword(), 1
//		));
//		
//		// 3. LANGUAGE
//		if (!StringUtils.isBlank(signupRequest.getLang())) {
//			mUser.setLang(EnumLangType.KOREAN.getValue());
//		} else {
//			if (EnumLangType.checkValidation(signupRequest.getLang())) {
//				mUser.setLang(signupRequest.getLang());
//			} else {
//				SignupResponse signupResponse = new SignupResponse();
//				signupResponse.setUserId(mUser.getUserId());
//				signupResponse.getError().setCode(2000L);
//				signupResponse.getError().setMessage(
//						String.format("Invalid lang code : %s(%s)",
//								signupRequest.getLang()
//								, EnumLangType.langList()));
//				
//				AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
//						.httpStatusCode(httpStatusCode)
//						.atalkPacketBase(signupResponse)
//						.secureModel(signupResponse.toFinalModel(packetKey))
//						.build();
//				return Optional.ofNullable(resultObj);
//			}
//		}
//		// 4. birth date
//		if (!StringUtils.isBlank(signupRequest.getBirthDate())) {
//			SimpleDateFormat dateBirthFormatter = new SimpleDateFormat("yyyy-MM-dd");
//			mUser.setBirthDate(dateBirthFormatter.parse(
//					signupRequest.getBirthDate()));
//		}
//		// 5. phone number
//		if (!StringUtils.isBlank(signupRequest.getPhoneNumber())) {
//			mUser.setPhoneNumber(signupRequest.getPhoneNumber());
//		}
//		// 6. status message
//		if (!StringUtils.isBlank(signupRequest.getStatusMessage())) {
//			mUser.setStatusMessage(signupRequest.getStatusMessage());
//		}
//		
//		mUser.setRegDate(new Date());
//		mUser.setUpdDate(new Date());
//		
//		mUser = mUserRepository.save(mUser);
//		// 7. PROFILE 이미지 처리
//		
//		// signup token key
//		if (signupTokenObj != null) {
//			signupTokenObj.setUseYn("Y");
//			signupTokenObj.setUpdDate(new Date());
//			mUserSignupTokenRepository.save(signupTokenObj);
//		}
//		log.debug("#### mUser : {}", mUser.toString());
//		////////////////////////////////////////////////////////////////////////////////////
//
//		SignupResponse signupResponse = new SignupResponse();
//		signupResponse.setUserId(mUser.getUserId());
//		signupResponse.setUserNo(mUser.getUserNo());
//		
//		AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
//				.httpStatusCode(httpStatusCode)
//				.atalkPacketBase(signupResponse)
//				.secureModel(signupResponse.toFinalModel(packetKey))
//				.build();
//		// DigitalSignComplex.decryptSignature(signingMessageHashServer, extractClientPublicKey);
//		
//		return Optional.ofNullable(resultObj);
//		
//		
////		
////		String signatureDataAll = secModel.getData();
////		/////////////////////////////////
////		String secData = signatureDataAll.substring(
////				0,
////				signatureDataAll.length() - SecureDataModel.KEY_SEED_SIZE);
////		String packetKeySeedValue = signatureDataAll.substring(
////				signatureDataAll.length() - SecureDataModel.KEY_SEED_SIZE);
////		log.debug("#### packetKeySeedValue : {}", packetKeySeedValue);
////		/////////////////////////////////
////		
////		String encryptedSignupDataHex = secData;
////		RedisPacketKeySeed redisKeyObj = redisTaskBroker.findKeySeedData(packetKeySeedValue);
////		
////		if (!redisKeyObj.getActiveYn().equals("Y")) {
////			AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
////					.httpStatusCode(425)
////					.atalkPacketBase(null)
////					.secureModel(null)
////					.build();
////			return Optional.ofNullable(resultObj);
////		}
////		
////		////////////////////// GET PACKET KEY
////		log.debug("#### redisKeyObj : {}", redisKeyObj);
////		String packetKey = redisKeyObj.getPacketKey();
////
////		byte [] encBuffer = AesEncDecComplex.hexToBytes(encryptedSignupDataHex);
////		byte [] decBuffer = AesEncDecComplex.decryptAesWithIv(encBuffer, packetKey);  // AES DECRYPT
////		
////		String objectJson = new String(decBuffer);
////		
////		SignupRequest signupRequest = AtalkPacketBase.fromJson(objectJson, SignupRequest.class);
////		Optional<MUserSignuptoken> signupTokenObjOp = mUserSignupTokenRepository.findBySignupKeyAndUseYn(signupRequest.getSignupToken(), "N");
////		if (signupTokenObjOp.isEmpty()) {
////			AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
////					.httpStatusCode(423)
////					.atalkPacketBase(null)
////					.secureModel(null)
////					.build();
////			return Optional.ofNullable(resultObj);
////		}
////		MUserSignuptoken signupTokenObj = signupTokenObjOp.get();
////		int httpStatusCode = 200;
////		Optional<MUser> userObjOp = mUserRepository.findByUserId(signupRequest.getUserId());
////		if (!userObjOp.isEmpty()) {
////			log.debug("@@@@@@@@@@@ ALREADY THE USER : {} exists", signupRequest.getUserId());
////			AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
////					.httpStatusCode(424)
////					.atalkPacketBase(null)
////					.secureModel(null)
////					.build();
////			return Optional.ofNullable(resultObj);
////		}
////		MUser mUser = new MUser();
////		mUser.setActiveYn("Y");
////		mUser.setUseYn("Y");
////		mUser.setFirstLogin("Y");
////		mUser.setUserId(signupRequest.getUserId());
////		mUser.setUserName(signupRequest.getUserName());
////		mUser.setSignupKey(signupRequest.getSignupToken());
////		mUser.setUserPw(HashComplex.hashWithSha512(
////				signupRequest.getUserId(), 1
////				));
////		mUser.setRegDate(new Date());
////		mUser.setUpdDate(new Date());
////		mUser = mUserRepository.save(mUser);
////		
////		signupTokenObj.setUseYn("Y");
////		signupTokenObj.setUpdDate(new Date());
////		mUserSignupTokenRepository.save(signupTokenObj);
////		
////		log.debug("#### mUser 6 : {}", mUser.toString());
////		
////		////////////////////////////////////////////////////////////////////////////////////
////
////		SignupResponse signupResponse = new SignupResponse();
////		signupResponse.setUserId(mUser.getUserId());
////		AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
////				.httpStatusCode(httpStatusCode)
////				.atalkPacketBase(signupResponse)
////				.secureModel(signupResponse.toFinalModel(packetKey))
////				.build();
////		// DigitalSignComplex.decryptSignature(signingMessageHashServer, extractClientPublicKey);
////		
////		return Optional.ofNullable(resultObj);
////		
//	}

	@Override
	public Optional<AtalkDataModelAll> login(SecureDataModel secModel) throws Exception {
		try {
			log.debug("#### transactionId : {}", secModel.getTransactinId());
			log.debug("#### data : {}", secModel.getData());
			
			String [] decryptPacketData = packetDecryptor.packetStringFromModelFirst(secModel);
			
			if (decryptPacketData == null || decryptPacketData[0].equals("")) {
				return Optional.ofNullable(null);
			}
			String objectJson = decryptPacketData[0];
			String packetKey = decryptPacketData[1];
			
			String packetKeySeedValue = decryptPacketData[2];
			
			log.debug("#### request string : {}", objectJson);
			UserLoginRequest userLoginRequest = AtalkPacketBase.fromJson(objectJson, UserLoginRequest.class); 
			UserLoginResponse loginResp = atalkUserServiceLogic.login(packetKeySeedValue, userLoginRequest);
			if (loginResp == null) {
				return Optional.ofNullable(null);
			}
			AtalkDataModelAll resData = AtalkDataModelAll.builder()
					.httpStatusCode(200)
					.atalkPacketBase(loginResp)
					.secureModel(loginResp.toFinalModel(packetKey))
					.build();
			resData.getSecureModel().setTransactinId(secModel.getTransactinId());
			return Optional.of(resData);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return Optional.ofNullable(null);
	}

	@Override
	public Optional<AtalkDataModelAll> changePassword(CustomUserDetail authUser, SecureDataModel secModel) throws Exception {
		log.debug("################# CHANGE PASSWORD");
		MUser user = userAccountService.getUserByUserId(authUser.getUserId());
		if (user != null) {
			String dbHashedPassword = user.getUserPw();
			log.debug("#### transactionId : {}", secModel.getTransactinId());
			log.debug("#### data : {}", secModel.getData());
			
			String [] decryptPacketData = packetDecryptor.packetStringFromModel(secModel);
			if (decryptPacketData == null || decryptPacketData[0].equals("")) {
				return Optional.ofNullable(null);
			}
			String objectJson = decryptPacketData[0];
			String packetKey = decryptPacketData[1];
			log.debug("#### request string : {}", objectJson);
			UserPasswordRequest userPasswordRequest = AtalkPacketBase.fromJson(objectJson, UserPasswordRequest.class);
			UserPasswordResponse respObj =atalkUserServiceLogic.changePassword(user, userPasswordRequest);
			if (respObj == null) {
				return Optional.ofNullable(null);
			}
			AtalkDataModelAll resData = AtalkDataModelAll.builder()
					.httpStatusCode(200)
					.atalkPacketBase(respObj)
					.secureModel(respObj.toFinalModel(packetKey))
					.build();
			resData.getSecureModel().setTransactinId(secModel.getTransactinId());
			return Optional.of(resData);
		}
		return Optional.ofNullable(null);
	}

	@Override
	public Optional<AtalkDataModelAll> refreshToken(SecureDataModel secModel) throws Exception {
		try {
			log.debug("#### transactionId : {}", secModel.getTransactinId());
			log.debug("#### data : {}", secModel.getData());
			
			String [] decryptPacketData = packetDecryptor.packetStringFromModel(secModel);
			if (decryptPacketData == null || decryptPacketData[0].equals("")) {
				return Optional.ofNullable(null);
			}
			String objectJson = decryptPacketData[0];
			String packetKey = decryptPacketData[1];
			log.debug("#### request string : {}", objectJson);
			
			UserAuthTokenRequest reqObj = AtalkPacketBase.fromJson(objectJson, UserAuthTokenRequest.class);
			UserAuthTokenResponse resObj = atalkUserServiceLogic.refreshToken(reqObj);
			if (resObj == null) {
				return Optional.ofNullable(null); 
			}
			AtalkDataModelAll resData = AtalkDataModelAll.builder()
					.httpStatusCode(200)
					.atalkPacketBase(resObj)
					.secureModel(resObj.toFinalModel(packetKey))
					.build();
			resData.getSecureModel().setTransactinId(secModel.getTransactinId());
			return Optional.of(resData);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return Optional.ofNullable(null);
	}

	@Override
	public Optional<AtalkDataModelAll> checkDupAccount(SecureDataModel secModel) throws Exception {
		try {
//			log.debug("#### transactionId : {}", secModel.getTransactinId());
//			log.debug("#### data : {}", secModel.getData());
//			
//			String [] decryptPacketData = packetDecryptor.packetStringFromModelFirst(secModel);
//			
//			if (decryptPacketData == null || decryptPacketData[0].equals("")) {
//				return Optional.ofNullable(null);
//			}
//			String objectJson = decryptPacketData[0];
//			String packetKey = decryptPacketData[1];
//			
//			String packetKeySeedValue = decryptPacketData[2];
//			
//			log.debug("#### request string : {}", objectJson);
//			
//			UserDupCheckRequest userDupCheck = AtalkPacketBase.fromJson(objectJson, UserDupCheckRequest.class); 
//
//			////////////////// LOGIC BELOW
//			Optional<MUser> userObjOp = mUserRepository.findByUserId(userDupCheck.getUserId());
//			if (userObjOp.isEmpty()) {
//				AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
//						.httpStatusCode(423)
//						.atalkPacketBase(null)
//						.secureModel(null)
//						.build();
//				return Optional.ofNullable(resultObj);
//			}
//			MUserSignuptoken signupTokenObj = signupTokenObjOp.get();
//			int httpStatusCode = 200;
//			Optional<MUser> userObjOp = mUserRepository.findByUserId(signupRequest.getUserId());
//			if (!userObjOp.isEmpty()) {
//				log.debug("@@@@@@@@@@@ ALREADY THE USER : {} exists", signupRequest.getUserId());
//				AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
//						.httpStatusCode(424)
//						.atalkPacketBase(null)
//						.secureModel(null)
//						.build();
//				return Optional.ofNullable(resultObj);
//			}
//			MUser mUser = new MUser();
//			mUser.setActiveYn("Y");
//			mUser.setUseYn("Y");
//			mUser.setFirstLogin("Y");
//			mUser.setUserId(signupRequest.getUserId());
//			mUser.setUserName(signupRequest.getUserName());
//			mUser.setSignupKey(signupRequest.getSignupToken());
//			mUser.setUserPw(HashComplex.hashWithSha512(
//					signupRequest.getUserId(), 1
//					));
//			mUser.setRegDate(new Date());
//			mUser.setUpdDate(new Date());
//			mUser = mUserRepository.save(mUser);
//			
//			signupTokenObj.setUseYn("Y");
//			signupTokenObj.setUpdDate(new Date());
//			mUserSignupTokenRepository.save(signupTokenObj);
//			
//			log.debug("#### mUser 6 : {}", mUser.toString());
//			
//			////////////////////////////////////////////////////////////////////////////////////
//
//			SignupResponse signupResponse = new SignupResponse();
//			signupResponse.setUserId(mUser.getUserId());
//			AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
//					.httpStatusCode(httpStatusCode)
//					.atalkPacketBase(signupResponse)
//					.secureModel(signupResponse.toFinalModel(packetKey))
//					.build();
//			// DigitalSignComplex.decryptSignature(signingMessageHashServer, extractClientPublicKey);
//			
//			return Optional.ofNullable(resultObj);
			
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return Optional.ofNullable(null);
	}

	@Transactional
	@Override
	public Optional<AtalkDataModelAll> signupMore(SecureDataModel secModel, List<MultipartFile> profileFiles) throws Exception {
		String signatureDataAll = secModel.getData();
		/////////////////////////////////
		String secData = signatureDataAll.substring(
				0,
				signatureDataAll.length() - SecureDataModel.KEY_SEED_SIZE);
		String packetKeySeedValue = signatureDataAll.substring(
				signatureDataAll.length() - SecureDataModel.KEY_SEED_SIZE);
		log.debug("#### packetKeySeedValue : {}", packetKeySeedValue);
		/////////////////////////////////
		
		String encryptedSignupDataHex = secData;
		RedisPacketKeySeed redisKeyObj = redisTaskBroker.findKeySeedData(packetKeySeedValue);
		
		if (!redisKeyObj.getActiveYn().equals("Y")) {
			AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
					.httpStatusCode(425)
					.atalkPacketBase(null)
					.secureModel(null)
					.build();
			return Optional.ofNullable(resultObj);
		}
		
		////////////////////// GET PACKET KEY
		log.debug("#### redisKeyObj : {}", redisKeyObj);
		String packetKey = redisKeyObj.getPacketKey();

		byte [] encBuffer = AesEncDecComplex.hexToBytes(encryptedSignupDataHex);
		byte [] decBuffer = AesEncDecComplex.decryptAesWithIv(encBuffer, packetKey);  // AES DECRYPT
		
		String objectJson = new String(decBuffer);

		int httpStatusCode = 200;
		
		SignupRequest signupRequest = AtalkPacketBase.fromJson(objectJson, SignupRequest.class);
		if (signupRequest.getPiAgreeVersion()==null 
				|| signupRequest.getPiAgreeVersion() < 1
				|| signupRequest.getSiAgreeVersion()==null 
				|| signupRequest.getSiAgreeVersion() < 1) {
			AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
					.httpStatusCode(423)
					.atalkPacketBase(null)
					.secureModel(null)
					.build();
			return Optional.ofNullable(resultObj);
		}
		
		
		if (StringUtils.isBlank(signupRequest.getUserId())) {
			AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
					.httpStatusCode(423)
					.atalkPacketBase(null)
					.secureModel(null)
					.build();
			return Optional.ofNullable(resultObj);
		}
		
		// 1. USER ID CHECK
		if (StringUtils.isBlank(signupRequest.getUserId())) {
			
			AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
					.httpStatusCode(423)
					.atalkPacketBase(null)
					.secureModel(null)
					.build();
			return Optional.ofNullable(resultObj);
		}
		Optional<MUser> userObjOp = mUserRepository.findByUserId(signupRequest.getUserId());
		if (!userObjOp.isEmpty()) {
			log.debug("@@@@@@@@@@@ ALREADY THE USER : {} exists", signupRequest.getUserId());
			SignupResponse signupResponse = new SignupResponse();
			signupResponse.setUserId(signupRequest.getUserId());
			signupResponse.getError().setCode(1004L);
			signupResponse.getError().setMessage(
					String.format("Alreay user(%s) exists.",
							signupRequest.getUserId()));
			AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
					.httpStatusCode(httpStatusCode)
					.atalkPacketBase(signupResponse)
					.secureModel(signupResponse.toFinalModel(packetKey))
					.build();
			return Optional.ofNullable(resultObj);
		}
		
		// signup token 처리
		MUserSignuptoken signupTokenObj = null;
		if (!StringUtils.isBlank(signupRequest.getSignupToken())) {
			Optional<MUserSignuptoken> signupTokenObjOp = mUserSignupTokenRepository.findBySignupKeyAndUseYn(signupRequest.getSignupToken(), "N");
			if (signupTokenObjOp.isEmpty()) {
				log.debug("@@@@@@@@@@@ No Valid signup token : {} exists", signupRequest.getSignupToken());
				SignupResponse signupResponse = new SignupResponse();
				signupResponse.setUserId(signupRequest.getUserId());
				signupResponse.getError().setCode(1005L);
				signupResponse.getError().setMessage(
						String.format("Invalid signup token : %s",
								signupRequest.getSignupToken()));
				AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
						.httpStatusCode(httpStatusCode)
						.atalkPacketBase(signupResponse)
						.secureModel(signupResponse.toFinalModel(packetKey))
						.build();
				return Optional.ofNullable(resultObj);
			}
			signupTokenObj = signupTokenObjOp.get();
		} else {
			Optional<MAuthEmail> authEmailOp = mAuthEmailRepository.findByEmail(signupRequest.getUserId());
			if (authEmailOp.isPresent()) {
				if (!authEmailOp.get().getCheckYn().equals("Y")) {
					SignupResponse signupResponse = new SignupResponse();
					signupResponse.setUserId(signupRequest.getUserId());
					signupResponse.getError().setCode(1006L);
					signupResponse.getError().setMessage(
							String.format("Not checked email"));
					AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
							.httpStatusCode(httpStatusCode)
							.atalkPacketBase(signupResponse)
							.secureModel(signupResponse.toFinalModel(packetKey))
							.build();
					return Optional.ofNullable(resultObj);
				}
			} else {
				SignupResponse signupResponse = new SignupResponse();
				signupResponse.setUserId(signupRequest.getUserId());
				signupResponse.getError().setCode(1007L);
				signupResponse.getError().setMessage(
						String.format("No token for the email."));
				AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
						.httpStatusCode(httpStatusCode)
						.atalkPacketBase(signupResponse)
						.secureModel(signupResponse.toFinalModel(packetKey))
						.build();
				return Optional.ofNullable(resultObj);
			}
		}
		MUser mUser = new MUser();
		mUser.setActiveYn("Y");
		mUser.setUseYn("Y");
		mUser.setFirstLogin("Y");
		mUser.setLang(signupRequest.getLang());
		mUser.setUserId(signupRequest.getUserId());
		mUser.setUserName(signupRequest.getUserName());
		mUser.setSignupKey(signupRequest.getSignupToken());
		mUser.setEmail(signupRequest.getUserId());
		mUser.setGender(signupRequest.getGender());
		mUser.setUserPw(HashComplex.hashWithSha512(
				signupRequest.getPassword(), 1
		));
		
		// 3. LANGUAGE
		if (StringUtils.isBlank(signupRequest.getLang())) {
			mUser.setLang(EnumLangType.KOREAN.getValue());
		} else {
			if (EnumLangType.checkValidation(signupRequest.getLang())) {
				mUser.setLang(signupRequest.getLang());
			} else {
				SignupResponse signupResponse = new SignupResponse();
				signupResponse.setUserId(mUser.getUserId());
				signupResponse.getError().setCode(2000L);
				signupResponse.getError().setMessage(
						String.format("Invalid lang code : %s(%s)",
								signupRequest.getLang()
								, EnumLangType.langList()));
				
				AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
						.httpStatusCode(httpStatusCode)
						.atalkPacketBase(signupResponse)
						.secureModel(signupResponse.toFinalModel(packetKey))
						.build();
				return Optional.ofNullable(resultObj);
			}
		}
		// 4. birth date
		if (!StringUtils.isBlank(signupRequest.getBirthDate())) {
			SimpleDateFormat dateBirthFormatter = new SimpleDateFormat("yyyy-MM-dd");
			mUser.setBirthDate(dateBirthFormatter.parse(
					signupRequest.getBirthDate()));
		}
		// 5. phone number
		if (!StringUtils.isBlank(signupRequest.getPhoneNumber())) {
			mUser.setPhoneNumber(signupRequest.getPhoneNumber());
		}
		// 6. status message
		if (!StringUtils.isBlank(signupRequest.getStatusMessage())) {
			mUser.setStatusMessage(signupRequest.getStatusMessage());
		}
		
		mUser.setRegDate(new Date());
		mUser.setUpdDate(new Date());
		
		mUser.setPiAgreeVersion(signupRequest.getPiAgreeVersion());
		mUser.setSiAgreeVersion(signupRequest.getSiAgreeVersion());
		mUser.setPfAgreeVersion(signupRequest.getPfAgreeVersion());
		
		mUser = mUserRepository.save(mUser);

		if (signupRequest.getPiAgreeVersion()!=null && signupRequest.getPiAgreeVersion() > 0) {
			MAgreementHist agreeHistObj = new MAgreementHist();
			agreeHistObj.setCat("PI");
			agreeHistObj.setRegDate(new Date());
			agreeHistObj.setUserNo(mUser.getUserNo());
			agreeHistObj.setVersionNo(signupRequest.getPiAgreeVersion());
			agreeHistObj.setAgreeYn("Y");
			mAgreementHistRepository.save(agreeHistObj);
		}
		if (signupRequest.getSiAgreeVersion()!=null && signupRequest.getSiAgreeVersion() > 0) {
			MAgreementHist agreeHistObj = new MAgreementHist();
			agreeHistObj.setCat("SI");
			agreeHistObj.setRegDate(new Date());
			agreeHistObj.setUserNo(mUser.getUserNo());
			agreeHistObj.setVersionNo(signupRequest.getSiAgreeVersion());
			agreeHistObj.setAgreeYn("Y");
			mAgreementHistRepository.save(agreeHistObj);
		}
		
		
		// 선택약관
		if (signupRequest.getPfAgreeVersion()!=null && signupRequest.getPfAgreeVersion() > 0) {
			MAgreementHist agreeHistObj = new MAgreementHist();
			agreeHistObj.setCat("PF");
			agreeHistObj.setRegDate(new Date());
			agreeHistObj.setUserNo(mUser.getUserNo());
			agreeHistObj.setVersionNo(signupRequest.getPfAgreeVersion());
			agreeHistObj.setAgreeYn("Y");
			mAgreementHistRepository.save(agreeHistObj);
		} else {
			MAgreementHist agreeHistObj = new MAgreementHist();
			agreeHistObj.setCat("PF");
			agreeHistObj.setRegDate(new Date());
			agreeHistObj.setUserNo(mUser.getUserNo());
			agreeHistObj.setVersionNo(signupRequest.getPfAgreeVersion());
			agreeHistObj.setAgreeYn("N");
			mAgreementHistRepository.save(agreeHistObj);
		}
		
		// 7. PROFILE 이미지 처리
		if (profileFiles != null && profileFiles.size() > 0) {
			if (profileFiles.size() == 2) {
				Optional<MUserProfile> fp = atalkUserProfileServiceLogic.registProfileForeground(
						mUser
						, packetKey
						, profileFiles.get(0));
				Optional<MUserProfile> bp = atalkUserProfileServiceLogic.registProfileBackground(
						mUser
						, packetKey
						, profileFiles.get(1));
				
				mUser.setProfileBgNo(bp.get().getProfileNo());
				mUser.setProfileFgNo(fp.get().getProfileNo());

			} else if (profileFiles.size() == 1) {
				
				
				Optional<MUserProfile> fp = atalkUserProfileServiceLogic.registProfileForeground(
						mUser
						, packetKey
						, profileFiles.get(0));
				mUser.setProfileFgNo(fp.get().getProfileNo());
			}
		}
		
		// signup token key
		if (signupTokenObj != null) {
			signupTokenObj.setUseYn("Y");
			signupTokenObj.setUpdDate(new Date());
			mUserSignupTokenRepository.save(signupTokenObj);
		}
		log.debug("#### mUser : {}", mUser.toString());
		////////////////////////////////////////////////////////////////////////////////////

		SignupResponse signupResponse = new SignupResponse();
		signupResponse.setUserId(mUser.getUserId());
		signupResponse.setUserNo(mUser.getUserNo());
		
		AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
				.httpStatusCode(httpStatusCode)
				.atalkPacketBase(signupResponse)
				.secureModel(signupResponse.toFinalModel(packetKey))
				.build();
		// DigitalSignComplex.decryptSignature(signingMessageHashServer, extractClientPublicKey);
		
		return Optional.ofNullable(resultObj);
	}

	@Transactional
	@Override
	public Optional<AtalkDataModelAll> deleteUser(SecureDataModel secModel) throws Exception {
		String signatureDataAll = secModel.getData();
		/////////////////////////////////
		String secData = signatureDataAll.substring(
				0,
				signatureDataAll.length() - SecureDataModel.KEY_SEED_SIZE);
		String packetKeySeedValue = signatureDataAll.substring(
				signatureDataAll.length() - SecureDataModel.KEY_SEED_SIZE);
		log.debug("#### packetKeySeedValue : {}", packetKeySeedValue);
		/////////////////////////////////
		
		String encryptedSignupDataHex = secData;
		RedisPacketKeySeed redisKeyObj = redisTaskBroker.findKeySeedData(packetKeySeedValue);
		
		if (!redisKeyObj.getActiveYn().equals("Y")) {
			AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
					.httpStatusCode(425)
					.atalkPacketBase(null)
					.secureModel(null)
					.build();
			return Optional.ofNullable(resultObj);
		}
		
		////////////////////// GET PACKET KEY
		log.debug("#### redisKeyObj : {}", redisKeyObj);
		String packetKey = redisKeyObj.getPacketKey();

		byte [] encBuffer = AesEncDecComplex.hexToBytes(encryptedSignupDataHex);
		byte [] decBuffer = AesEncDecComplex.decryptAesWithIv(encBuffer, packetKey);  // AES DECRYPT
		
		String objectJson = new String(decBuffer);

		int httpStatusCode = 200;
		
		DeleteUserRequest deleteUserRequest = AtalkPacketBase.fromJson(objectJson, DeleteUserRequest.class);
		
		Long userNo = deleteUserRequest.getUserNo();
		
		MUser muser = new MUser();
		muser.setUserNo(userNo);
		mUserRepository.delete(muser);
		
		if (deleteUserRequest.getSignUptoken()!=null && !deleteUserRequest.getSignUptoken().isBlank()) {
			mUserSignupTokenRepository.updateSetUse(
					deleteUserRequest.getSignUptoken(), "N");
		}
		
		DeleteUserResponse deleteUserResponse = new DeleteUserResponse();
		deleteUserResponse.setUserNo(userNo);
		AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
				.httpStatusCode(200)
				.atalkPacketBase(deleteUserResponse)
				.secureModel(deleteUserResponse.toFinalModel(packetKey))
				.build();
		// DigitalSignComplex.decryptSignature(signingMessageHashServer, extractClientPublicKey);
		
		return Optional.ofNullable(resultObj);
	}

	@Override
	public Optional<AtalkDataModelAll> resetAllForTest(SecureDataModel secModel) throws Exception {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

	@Override
	public void afterLogin(MUser userObj) throws Exception {
		
		List<ChatHubListInfo> chatHubListInfo = Lists.newArrayList();
		atalkChatHubServiceLogic.retrieveChatHubList(userObj, "2000-01-01 00:00:00", chatHubListInfo);
		
		atalkUnreadCntService.deleteKey(userObj.getUserNo());
		
		chatHubListInfo.forEach(val -> {
			atalkUnreadCntService.setUnreadCount(userObj.getUserNo()
					, val.getChathubNo()
					, val.getLastChat().getUnreadCnt());
		});
	}

	@Override
	public Optional<AtalkDataModelAll> checkPassword(CustomUserDetail authUser, String encPassword) throws Exception {
		log.debug("################# OPEN CHATHUB by amigoset no");
		MUser user = userAccountService.getUserByUserId(authUser.getUserId());
		if (user != null) {
			RedisPacketKeySeed redisKeyObj = redisTaskBroker.findKeyObjectByUserNo(user.getUserNo());
			String packetKey = redisKeyObj.getPacketKey();
			/////////////////////////////////////////////////////////			
			UserResultResponse respObj = atalkUserServiceLogic.checkPassword(user, encPassword);
			if (respObj == null) {
				return Optional.ofNullable(null);
			}
			///////////////////////// RESPONSE /////////////////////////////////////////////////////
			AtalkDataModelAll resData = AtalkDataModelAll.builder()
					.httpStatusCode(200)
					.atalkPacketBase(respObj)
					.secureModel(respObj.toFinalModel(packetKey))
					.build();
			resData.getSecureModel().setTransactinId(RandomHexString.genSecureRandomHex(16));
			return Optional.of(resData);
		}
		return Optional.ofNullable(null);
	}

	@Override
	public UserResultResponse issuePassword(String userId) throws Exception {
		return atalkUserServiceLogic.issuePassword(userId);
	}

	@Override
	public UserResultResponse authEmail(String userEmail) throws Exception {
		return atalkUserServiceLogic.authEmail(userEmail);
	}

	@Override
	public UserResultResponse checkDupAccount(String userEmail) throws Exception {
		return atalkUserServiceLogic.checkDupAccount(userEmail);
	}

	@Override
	public UserResultResponse checkAuthToken(String userEmail, String tokenValue) throws Exception {
		return atalkUserServiceLogic.checkAuthToken(userEmail, tokenValue);
	}
}
