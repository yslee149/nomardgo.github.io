package com.mutecsoft.atalk.web.controller.plain;

import com.mutecsoft.atalk.logic.model.user.SearchUserRequest;
import com.mutecsoft.atalk.logic.model.user.SearchUserResponse;
import com.mutecsoft.atalk.security.oauth2.model.CustomUserDetail;
import com.mutecsoft.atalk.service.AtalkSearchServiceLogic;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @PackageName com.mutecsoft.atalk.web.controller.plain
 * @fileName	PlainAtalkSearchController.java
 * @author voyzer
 * @Date   2024. 12. 1.
 * @description :
 * <pre>
 * 
 * </pre>
 */
@Slf4j
@Tag(name="User Search", description="User Search API(Plain)")
@Controller
@RequestMapping(value = "/api/plain/v1/search")
public class PlainAtalkSearchController {
	
	@Autowired
	AtalkSearchServiceLogic atalkSearchServiceLogic;

	/**
	 * 사용자 검색
	 * 
	 * @param authUser
	 * @param reqObj
	 * @return
	 */
	@PostMapping("/user")
	public ResponseEntity<?> searchUser(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @RequestBody SearchUserRequest reqObj) {
		try {
			log.debug("################# SEARCH USER");
			SearchUserResponse resp = atalkSearchServiceLogic.searchUser(
					authUser.getMUser(), reqObj);
			return new ResponseEntity<>(resp, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
	
	/**
	 * 사용자 검색
	 * 
	 * @param authUser
	 * @param secureReqModel
	 * @return
	 */
	@PostMapping("/noauth/userId")
	public ResponseEntity<?> searchUserNoAuth(
			@RequestBody SearchUserRequest reqObj) {
		try {
			log.debug("################# SEARCH USER(no auth)");
			SearchUserResponse resp = atalkSearchServiceLogic.searchUserNoAuth(
					reqObj);
			return new ResponseEntity<>(resp, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
}
