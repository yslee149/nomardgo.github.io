package com.mutecsoft.atalk.constant;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public enum EnumLangType {

	KOREAN("ko"),
	JAPANES("jp"),
	SPANISH("es"),
	ENGLISH("en"),
	CHINESE("cn"),
	CHINESE_ZH("zh");

	/////////////////////////////////////////////
	
	private final String value;
	
	EnumLangType(final String newValue) {
		value = newValue;
	}
	
	public String getValue(){
		return value;
	}
	
	public static Boolean checkValidation(String val) {
		String checkString = "ko,jp,es,en,cn,zh";
		return (checkString.indexOf(val) >= 0 ? Boolean.TRUE : Boolean.FALSE);
	}
	
	public static String langList() {
		return "ko,jp,es,en,cn,zh";
	}
}

