package com.mutecsoft.atalk.service;

import java.util.Optional;

import com.mutecsoft.atalk.logic.model.AtalkDataModelAll;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.security.oauth2.model.CustomUserDetail;

public interface AtalkAmigoSetService {
	Optional<AtalkDataModelAll> addAmigoSet(CustomUserDetail authUser, SecureDataModel secModel) throws Exception;
	Optional<AtalkDataModelAll> renameAmigoSet(CustomUserDetail authUser, SecureDataModel secModel) throws Exception;
	Optional<AtalkDataModelAll> deleteAmigoSet(CustomUserDetail authUser, SecureDataModel secModel) throws Exception;
	Optional<AtalkDataModelAll> amigoSetList(CustomUserDetail authUser) throws Exception;
	
}
