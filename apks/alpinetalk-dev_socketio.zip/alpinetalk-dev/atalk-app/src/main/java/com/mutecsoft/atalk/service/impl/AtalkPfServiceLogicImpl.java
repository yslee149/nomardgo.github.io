package com.mutecsoft.atalk.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.mutecsoft.atalk.common.model.MAgreementHist;
import com.mutecsoft.atalk.common.model.MPfAgreement;
import com.mutecsoft.atalk.common.model.MUser;
import com.mutecsoft.atalk.common.repository.MAgreementHistRepository;
import com.mutecsoft.atalk.common.repository.MPfAgreementRepository;
import com.mutecsoft.atalk.common.repository.MUserRepository;
import com.mutecsoft.atalk.logic.model.pf.PfAgreementResponse;
import com.mutecsoft.atalk.logic.model.response.AgreementResponse;
import com.mutecsoft.atalk.service.AtalkPfServiceLogic;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;

/**
 * 프로필 이용약관 서비스
 * 
 */
@Slf4j
@Service("atalkPfServiceLogic")
public class AtalkPfServiceLogicImpl implements AtalkPfServiceLogic {

	@Autowired
	MPfAgreementRepository mPfAgreementRepository;
	
	@Autowired
	MAgreementHistRepository   mAgreementHistRepository;

	@Autowired
	MUserRepository mUserRepository;
	
	@Override
	public PfAgreementResponse getLatestPfAgreement() throws Exception {
		
		Optional<MPfAgreement> pfOp = mPfAgreementRepository.findByLatest();
		
		///////////////////////// RESPONSE /////////////////////////////////////////////////////
		PfAgreementResponse respObj = new PfAgreementResponse();
		respObj.setContent(pfOp.get().getPfContent());
		respObj.setPfVersion(pfOp.get().getPfNo());
		return respObj;
	}
	
	@Override
	public Long agree(MUser user, Long version) throws Exception {
		Optional<MPfAgreement> agreeOp = mPfAgreementRepository.findById(version);
		if (agreeOp.isPresent()) {
			user.setPfAgreeVersion(agreeOp.get().getPfNo());
			mUserRepository.save(user);
			
			MAgreementHist agreeHistObj = new MAgreementHist();
			agreeHistObj.setCat("PF");
			agreeHistObj.setRegDate(new Date());
			agreeHistObj.setUserNo(user.getUserNo());
			agreeHistObj.setVersionNo(version);
			agreeHistObj.setAgreeYn("Y");
			mAgreementHistRepository.save(agreeHistObj);
			
			return version;
		}
		return 0L;
	}

	@Override
	public Long disagree(MUser user, Long version) throws Exception {
		Optional<MPfAgreement> agreeOp = mPfAgreementRepository.findById(version);
		if (agreeOp.isPresent()) {
			user.setPfAgreeVersion(0L);
			mUserRepository.save(user);
			MAgreementHist agreeHistObj = new MAgreementHist();
			agreeHistObj.setCat("PF");
			agreeHistObj.setRegDate(new Date());
			agreeHistObj.setUserNo(user.getUserNo());
			agreeHistObj.setVersionNo(version);
			agreeHistObj.setAgreeYn("N");
			mAgreementHistRepository.save(agreeHistObj);
			return version;
		}
		return 0L;
	}
	

	SimpleDateFormat dateFormatter;
	
	@PostConstruct
	private void init() {
		dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	}

	@Override
	public AgreementResponse getHist(MUser user) throws Exception {
		Optional<MAgreementHist> agreementHistOp = mAgreementHistRepository.findByLatest(user.getUserNo(), "PF");
		
		///////////////////////// RESPONSE /////////////////////////////////////////////////////
		AgreementResponse respObj = new AgreementResponse();
		if (agreementHistOp.isPresent()) {
			respObj.setRegDt(dateFormatter.format(agreementHistOp.get().getRegDate()));
			respObj.setVersion(agreementHistOp.get().getVersionNo());
			respObj.setAgreeYn(agreementHistOp.get().getAgreeYn());
		} else {
			respObj.setRegDt(null);
			respObj.setVersion(0L);
			respObj.setAgreeYn("N");		
		}
		return respObj;
	}
}
