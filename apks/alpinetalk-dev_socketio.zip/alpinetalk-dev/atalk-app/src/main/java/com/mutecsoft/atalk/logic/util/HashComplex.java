package com.mutecsoft.atalk.logic.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * @PackageName 
 * @fileName	HashComplex.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description : 
 * <pre>
 * 
 * </pre>
 */
public class HashComplex {

	/**
	 * 
	 * @param inputStr
	 * @param iteration
	 * @return
	 */
	public static String hashWithSha512(String inputStr, int iteration) {
		try {
			MessageDigest md = MessageDigest.getInstance("SHA-512");
			
			byte [] hashedBytes = md.digest(inputStr.getBytes());
			
			return BufferComplex.bytesToHex(hashedBytes);
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException(e.getMessage());
		}
	}
	
	public static void main(String [] args) {
		System.out.println(HashComplex.hashWithSha512(
				RandomHexString.genSecureRandomHex(32)
				, 100));
	}
}
