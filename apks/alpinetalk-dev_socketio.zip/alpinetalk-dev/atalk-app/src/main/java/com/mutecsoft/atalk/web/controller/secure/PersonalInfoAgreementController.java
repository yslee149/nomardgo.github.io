package com.mutecsoft.atalk.web.controller.secure;

import com.mutecsoft.atalk.logic.model.AtalkDataModelAll;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.service.AtalkPiService;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @PackageName com.mutecsoft.atalk.web.controller.secure
 * @fileName	PersonalInfoAgreementController.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description :
 * <pre>
 * 
 * </pre>
 */
@Slf4j
@Tag(name="Personal Info agreement", description="Profile API")
@Controller
@RequestMapping(value = "/api/v1/pi")
public class PersonalInfoAgreementController {
	
	@Autowired
	AtalkPiService atalkPiService;

	/**
	 * 최근 버전 개인정보 이용약관
	 * 
	 * @param authUser
	 * @param secureReqModel
	 * @return
	 */
	@PostMapping(value = "/getLatest")
	public ResponseEntity<?> getLatest(
			@RequestBody SecureDataModel secureReqModel) {
		try {
			log.debug("################# GET Person Info usage agreement");
			Optional<AtalkDataModelAll> respOp = atalkPiService.getLatestPiAgreement(secureReqModel);
			return new ResponseEntity<>(respOp.get().getSecureModel(), HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
}
