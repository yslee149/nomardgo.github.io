package com.mutecsoft.atalk.service;

public interface AtalkEmailService {
	void sendMail(String to, String subject, String text);
}
