/*
 *  Copyright (c) 2024 CNU Global, Inc.
 *  All right reserved.
 *  This software is the confidential and proprietary information of DOUB
 *  , Inc. You shall not disclose such Confidential Information and
 *  shall use it only in accordance with the terms of the license agreement
 *  you entered into with CNU Global.
 *
 *  Revision History
 *  Date               Author         Description
 *  ------------------ -------------- ------------------
 *  2024. 8. 20.	       Hong Seok Woo  
 */
package com.mutecsoft.atalk.logic.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL) // null 제외
public class LogoutResponse  {
	
	/**
	 * login URL
	 */
	@Schema(name="logOutUrl", description = "login URL")
	@JsonProperty("logOutUrl")
    @Expose
    @SerializedName("logOutUrl")
	String logOutUrl = "/api/login";;
}
