/**
 * 
 */
package com.mutecsoft.atalk.model.presentation;

import com.mutecsoft.atalk.logic.model.response.ResPageInfo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author voyzer
 * @param <T>
 *
 */
@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class ResponsePageDto<T> {
	
	int statusCode;
	String errorMessage;
	ResPageInfo pagination;
	T data;
}
