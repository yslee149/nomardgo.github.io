/*
 *  Copyright (c) [2024] CNU Global, Inc.
 *  All right reserved.
 *  This software is the confidential and proprietary information of DOUB
 *  , Inc. You shall not disclose such Confidential Information and
 *  shall use it only in accordance with the terms of the license agreement
 *  you entered into with CNU Global.
 *
 *  Revision History
 *  Date               Author         Description
 *  ------------------ -------------- ------------------
 * 
 */
package com.mutecsoft.atalk.exception;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Exception handle
 */
@ControllerAdvice
@Order(Ordered.HIGHEST_PRECEDENCE)
public class RestExceptionHandler {

	private static final Logger log = LoggerFactory.getLogger(RestExceptionHandler.class);
	private static final Logger apilog = LoggerFactory.getLogger("API");
//	
//	@ExceptionHandler({BindException.class}) 
//	public ResponseEntity<CasResponse> handleBindException(HttpServletRequest request, BindException ex){ 	
//
//    	log.debug("BindException : {}", ex);		
//		String message = ex.getMessage();
//		BindingResult bindingResult = ex.getBindingResult();
//		List<FieldError> errors = bindingResult.getFieldErrors();
//		if (errors.size() > 0 && StringUtils.isNotBlank(errors.get(0).getDefaultMessage())) {
//			message = errors.get(0).getDefaultMessage();
//		}
//		apilog.info("{} {} {} {} {}", request.getRequestURI().substring(request.getRequestURI().lastIndexOf('/')), 
//				StringUtils.isNotBlank((String)request.getAttribute("userid"))?request.getAttribute("userid"):"-", 
//				HttpStatus.BAD_REQUEST, message);
//		
//		return new ResponseEntity<>(new CasResponse(HttpStatus.BAD_REQUEST.value(), message), 
//				HttpStatus.OK);
//    } 
//	
//	@ExceptionHandler({MethodArgumentNotValidException.class}) 
//	public ResponseEntity<CasResponse> handleMethodArgumentNotValidException(HttpServletRequest request, MethodArgumentNotValidException ex){ 	
//
//    	log.debug("MethodArgumentNotValidException : {}", ex);		
//		String message = ex.getMessage();
//    	log.error("message: {}", message);		
//		BindingResult bindingResult = ex.getBindingResult();
//		List<FieldError> errors = bindingResult.getFieldErrors();
//		if (errors.size() > 0 && StringUtils.isNotBlank(errors.get(0).getDefaultMessage())) {
//			message = errors.get(0).getDefaultMessage();
//	    	log.error("message: {}", message);		
//		}
//		apilog.info("{} {} {} {} {}", request.getRequestURI().substring(request.getRequestURI().lastIndexOf('/')), 
//				StringUtils.isNotBlank((String)request.getAttribute("userid"))?request.getAttribute("userid"):"-", 
//				HttpStatus.BAD_REQUEST, message);
//		
//		return new ResponseEntity<>(new CasResponse(HttpStatus.BAD_REQUEST.value(), message), 
//				HttpStatus.OK);
//    } 
//	
//	@ExceptionHandler({CasException.class}) 
//	public ResponseEntity<CasResponse> handleTaException(HttpServletRequest request, CasException ex){ 
//
//    	log.error("GatewayException : {}", ex.getMessage());		
//    	log.debug("GatewayException : {}", ex);		
//    	apilog.info("{} {} {} {} {}", request.getRequestURI().substring(request.getRequestURI().lastIndexOf('/')), 
//				StringUtils.isNotBlank((String)request.getAttribute("userid"))?request.getAttribute("userid"):"-", 
//				ex.getCode(), ex.getMessage());
//		return new ResponseEntity<>(new CasResponse(ex.getCode(), ex.getMessage()), 
//				HttpStatus.OK);
//    }
//
//	@ExceptionHandler(Exception.class)
//    public ResponseEntity<CasResponse> handleOtherException(HttpServletRequest request, Exception ex){
//    	
//    	log.error("Exception : {}", ex.getMessage());		
//    	log.debug("Exception : {}", ex);		
//    	apilog.info("{} {} {} {} {}", request.getRequestURI().substring(request.getRequestURI().lastIndexOf('/')), 
//				StringUtils.isNotBlank((String)request.getAttribute("userid"))?request.getAttribute("userid"):"-", 
//				HttpStatus.INTERNAL_SERVER_ERROR, ex.getMessage());
//		return new ResponseEntity<>(new CasResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), 
//				ex.getMessage()), HttpStatus.OK);
//    }  

}