package com.mutecsoft.atalk.constant;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public enum EnumProfileType {

	FOREGROUND("F"),
	BACKGROUND("B");
	/////////////////////////////////////////////
	
	private final String value;
	
	EnumProfileType(final String newValue) {
		value = newValue;
	}
	
	public String getValue(){
		return value;
	}
	
}

