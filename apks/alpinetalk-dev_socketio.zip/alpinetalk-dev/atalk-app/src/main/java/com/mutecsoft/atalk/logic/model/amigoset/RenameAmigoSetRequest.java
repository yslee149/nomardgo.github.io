package com.mutecsoft.atalk.logic.model.amigoset;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.mutecsoft.atalk.logic.model.AtalkPacketBase;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.logic.util.AesEncDecComplex;

/**
 * @PackageName com.mutecsoft.atalk.logic.model.auth
 * @fileName	RenameAmigoSetRequest.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description :  친구 그룹 수정
 * <pre>
 * 
 * </pre>
 */
public class RenameAmigoSetRequest extends AtalkPacketBase {

	/**
	 * 
	 */
	private static final long serialVersionUID = -245976247312274504L;
    
	private Long amigoSetNo;
	private String amigoSetName;
    
	public Long getAmigoSetNo() {
		return amigoSetNo;
	}
	public void setAmigoSetNo(Long amigoSetNo) {
		this.amigoSetNo = amigoSetNo;
	}
	public String getAmigoSetName() {
		return amigoSetName;
	}
	public void setAmigoSetName(String amigoSetName) {
		this.amigoSetName = amigoSetName;
	}
	@Override
	public String toJson() throws JsonProcessingException {
		return objectMapper.writeValueAsString(this);
	}
	@Override
	public SecureDataModel toFinalModel() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public SecureDataModel toFinalModel(String packetKey) throws Exception {
		if (packetKey == null || packetKey.equals("")) {
			return null;
		}
		SecureDataModel secureModel = new SecureDataModel();
		secureModel.setTransactinId(this.getTransactinId());
		String jsonData = this.toJson();
		
		byte [] encBuffer = AesEncDecComplex.encryptAesWithRandomIv(
				jsonData.getBytes(), packetKey);
		String hexEncString = AesEncDecComplex.bytesToHex(encBuffer);

		secureModel.setData(hexEncString);
		return secureModel;
	}

	@Override
	public SecureDataModel toFinalModel(String seedValue, String packetKey) throws Exception {
		if (packetKey == null || packetKey.equals("")) {
			return null;
		}
		if (seedValue == null || seedValue.equals("")) {
			return null;
		}
		SecureDataModel secureModel = new SecureDataModel();
		secureModel.setTransactinId(this.getTransactinId());
		String jsonData = this.toJson();
		
		byte [] encBuffer = AesEncDecComplex.encryptAesWithRandomIv(
				jsonData.getBytes(), packetKey);
		String hexEncString = AesEncDecComplex.bytesToHex(encBuffer);

		secureModel.setData(hexEncString);
		secureModel.setDataAfter(seedValue);
		
		return secureModel;
	}
}
