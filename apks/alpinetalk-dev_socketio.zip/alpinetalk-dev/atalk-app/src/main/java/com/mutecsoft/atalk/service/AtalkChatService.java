package com.mutecsoft.atalk.service;

import org.springframework.web.multipart.MultipartFile;

import java.util.Optional;

import com.mutecsoft.atalk.logic.model.AtalkDataModelAll;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.security.oauth2.model.CustomUserDetail;

public interface AtalkChatService {
	
	Optional<AtalkDataModelAll> procMessage(CustomUserDetail authUser, SecureDataModel secModel) throws Exception;
	Optional<AtalkDataModelAll> procFileMessage(
			CustomUserDetail authUser
			, Long chathubNo
			, String fileType
			, MultipartFile file) throws Exception;
	Optional<AtalkDataModelAll> chatList(CustomUserDetail authUser, SecureDataModel secModel) throws Exception;
	Optional<AtalkDataModelAll> getExtChat(CustomUserDetail authUser, Long extChatNo) throws Exception;
	Optional<AtalkDataModelAll> deleteChatList(CustomUserDetail authUser, SecureDataModel secModel) throws Exception;
	Optional<AtalkDataModelAll> retrieveChatList(CustomUserDetail authUser, SecureDataModel secModel) throws Exception;
	Optional<AtalkDataModelAll> readChat(CustomUserDetail authUser, SecureDataModel secModel) throws Exception;

	Optional<AtalkDataModelAll> get(CustomUserDetail authUser, Long chatHubNo, Long chatNo) throws Exception;
}

