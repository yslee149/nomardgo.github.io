package com.mutecsoft.atalk.web.controller.secure;

import com.mutecsoft.atalk.common.model.MChatFile;
import com.mutecsoft.atalk.common.repository.MChatFileRepository;
import com.mutecsoft.atalk.config.AtalkConfig;
import com.mutecsoft.atalk.logic.model.AtalkDataModelAll;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.logic.model.chat.ChatResponse;
import com.mutecsoft.atalk.security.oauth2.model.CustomUserDetail;
import com.mutecsoft.atalk.service.AtalkChatService;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

/**
 * @PackageName com.mutecsoft.atalk.web.controller.secure
 * @fileName	ChatController.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description :
 * <pre>
 * 
 * </pre>
 */
@Slf4j
@Tag(name="Chat", description="Chat API")
@Controller
@RequestMapping(value = "/api/v1/chat")
public class ChatController {
	
	@Autowired
	AtalkChatService atalkChatService;
	
	@Autowired
	MChatFileRepository mChatFileRepository;
	
	@Autowired
	AtalkConfig atalkConfig;
	
	/**
	 * 일반대화
	 * 
	 * @param authUser
	 * @param secureReqModel
	 * @return
	 */
	@PostMapping("/send")
	public ResponseEntity<?> send(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @RequestBody SecureDataModel secureReqModel) {
		try {
			log.debug("################# SEND CHAT");
			Optional<AtalkDataModelAll> respOp = atalkChatService.procMessage(authUser, secureReqModel);
			return new ResponseEntity<>(respOp.get().getSecureModel(), HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
	
	/**
	 * 대화목록 조회
	 * 
	 * @param authUser
	 * @param secureReqModel
	 * @return
	 */
	@PostMapping(value ="/chatList", consumes = { MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<?> chatList(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
            , @RequestBody SecureDataModel secureReqModel) {
		try {
			log.debug("################# GET CHAT LIST");
			Optional<AtalkDataModelAll> respOp = atalkChatService.chatList(authUser, secureReqModel);
			return new ResponseEntity<>(respOp.get().getSecureModel(), HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}

	/**
	 * 파일 대화
	 * 
	 * @param authUser
	 * @param secureReqModel
	 * @return
	 */
	@PostMapping(value = "/send/file/{chathubNo}/{fileType}")
	public ResponseEntity<?> sendFile(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @PathVariable("chathubNo") Long chathubNo
			, @PathVariable("fileType") String fileType
			, @RequestParam("file") MultipartFile uploadDataFile) {
		try {
			log.debug("################# SEND FILE CHAT");
			Optional<AtalkDataModelAll> respOp = atalkChatService.procFileMessage(
					authUser
					, chathubNo
					, fileType
					, uploadDataFile);
			return new ResponseEntity<>(respOp.get().getSecureModel(), HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
	
	private ByteArrayOutputStream toByteArrayOutputStream(Path filePath) {
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		try (FileInputStream fileInputStream = new FileInputStream(filePath.toFile())) {
			byte[] buffer = new byte[4096]; // Buffer size for reading chunks
			int bytesRead;
			while ((bytesRead = fileInputStream.read(buffer)) != -1) {
				byteArrayOutputStream.write(buffer, 0, bytesRead);
			}
		} catch (IOException e) {
			log.error("@@@@ : {}", e);
		}
		return byteArrayOutputStream;
	}
	
	/**
	 * 파일 다운로드
	 * 
	 * @param authUser
	 * @param secureReqModel
	 * @return
	 */
	@RequestMapping(value="/file/{chatFileNo}", method = {RequestMethod.POST, RequestMethod.GET})
	public ResponseEntity<?> downloadFile(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @PathVariable("chatFileNo") Long chatFileNo) {
		
		Optional<MChatFile> chatFileOp = mChatFileRepository.findByUserNoAndChatFileNo(
				authUser.getMUser().getUserNo()
				, chatFileNo);
		if (chatFileOp.isEmpty()) {
			log.error("@@@@ : Not joind chathub-att file : {}, userNo : {}",
					chatFileNo, authUser.getMUser().getUserNo());
			return null;
		}
		Path uploadPath = Paths.get(
				atalkConfig.getChatConfig().getChatFilePath()
				, chatFileOp.get().getFilePath());
		if (!Files.exists(uploadPath)) {
			return null;
		}
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "attachment; filename="+chatFileOp.get().getDispName());
		ByteArrayResource resource = new ByteArrayResource(toByteArrayOutputStream(uploadPath).toByteArray());
        return ResponseEntity.status(HttpStatus.OK)
	            .header("Content-Type", "application/octet-stream")
	            .header("Content-Disposition", "attachment;filename="+chatFileOp.get().getDispName())
	            .header("Content-Length", String.valueOf(resource.getByteArray().length))
	            .body(resource);
	}
	
	/**
	 * 확장대화 요청
	 * 
	 * @param authUser
	 * @param secureReqModel
	 * @return
	 */
	@RequestMapping(value="/ext/{chatExtNo}", method = {RequestMethod.POST, RequestMethod.GET})
	public ResponseEntity<?> getExtChatContent(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @RequestBody SecureDataModel secureReqModel
			, @PathVariable("chatExtNo") Long chatExtNo) {
		try {
			log.debug("################# GET EXT CAHT");
			Optional<AtalkDataModelAll> respOp = atalkChatService.getExtChat(authUser
					, chatExtNo);
			return new ResponseEntity<>(respOp.get().getSecureModel(), HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}

	/**
	 * 대화 삭제 처리
	 * 
	 * @param authUser
	 * @param secureReqModel
	 * @return
	 */
	@PostMapping(value ="/delete", consumes = { MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<?> delete(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
            , @RequestBody SecureDataModel secureReqModel) {
		try {
			log.debug("################# DELETE CHAT LIST");
			Optional<AtalkDataModelAll> respOp = atalkChatService.deleteChatList(authUser, secureReqModel);
			return new ResponseEntity<>(respOp.get().getSecureModel(), HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
	

	/**
	 * 대화 회수 처리
	 * 
	 * @param authUser
	 * @param secureReqModel
	 * @return
	 */
	@PostMapping(value ="/retrieve", consumes = { MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<?> retrieve(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
            , @RequestBody SecureDataModel secureReqModel) {
		try {
			log.debug("################# RETRIEVE CHAT LIST");
			Optional<AtalkDataModelAll> respOp = atalkChatService.retrieveChatList(authUser, secureReqModel);
			return new ResponseEntity<>(respOp.get().getSecureModel(), HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
	
	/**
	 * 읽음 확인
	 * 
	 * @param authUser
	 * @param secureReqModel
	 * @return
	 */
	@PostMapping(value ="/read", consumes = { MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<?> read(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
            , @RequestBody SecureDataModel secureReqModel) {
		try {
			log.debug("################# READ CHAT ");
			Optional<AtalkDataModelAll> respOp = atalkChatService.readChat(authUser, secureReqModel);
			return new ResponseEntity<>(respOp.get().getSecureModel(), HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
	
	///////// test
	/**
	 * 파일 다운로드
	 * 
	 * @param authUser
	 * @param secureReqModel
	 * @return
	 */
	@RequestMapping(value="/fileNoAuth/{chatFileNo}/{userNo}", method = {RequestMethod.POST, RequestMethod.GET})
	public ResponseEntity<?> downloadFile(
			@PathVariable("userNo") Long userNo
			, @PathVariable("chatFileNo") Long chatFileNo) {
		
		Optional<MChatFile> chatFileOp = mChatFileRepository.findByUserNoAndChatFileNo(
				userNo
				, chatFileNo);
		if (chatFileOp.isEmpty()) {
			log.error("@@@@ : Not joind chathub-att file : {}, userNo : {}",
					chatFileNo, userNo);
			return null;
		}
		Path uploadPath = Paths.get(
				atalkConfig.getChatConfig().getChatFilePath()
				, chatFileOp.get().getFilePath());
		if (!Files.exists(uploadPath)) {
			return null;
		}
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "attachment; filename="+chatFileOp.get().getDispName());
		ByteArrayResource resource = new ByteArrayResource(toByteArrayOutputStream(uploadPath).toByteArray());
        return ResponseEntity.status(HttpStatus.OK)
	            .header("Content-Type", "application/octet-stream")
	            .header("Content-Disposition", "attachment;filename="+chatFileOp.get().getDispName())
	            .header("Content-Length", String.valueOf(resource.getByteArray().length))
	            .body(resource);
	}
	
	/**
	 * 대화 상세정보
	 * 
	 * @param authUser
	 * @param reqObj
	 * @return
	 */
	@RequestMapping(value="/get/{chathubNo}/{chatNo}", method = {RequestMethod.POST, RequestMethod.GET})
	public ResponseEntity<?> get(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @PathVariable("chathubNo") Long chathubNo
			, @PathVariable("chatNo") Long chatNo) {
		try {
			log.debug("################# get CHAT");
			Optional<AtalkDataModelAll> respOp = atalkChatService.get(
					authUser, chathubNo, chatNo);
			return new ResponseEntity<>(respOp.get().getSecureModel(), HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
}

