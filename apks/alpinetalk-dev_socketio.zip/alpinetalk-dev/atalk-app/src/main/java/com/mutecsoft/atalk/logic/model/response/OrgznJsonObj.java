/*
 *  Copyright (c) 2024 CNU Global, Inc.
 *  All right reserved.
 *  This software is the confidential and proprietary information of DOUB
 *  , Inc. You shall not disclose such Confidential Information and
 *  shall use it only in accordance with the terms of the license agreement
 *  you entered into with CNU Global.
 *
 *  Revision History
 *  Date               Author         Description
 *  ------------------ -------------- ------------------
 *  2024. 8. 13.	   Hong Seok Woo  
 */
package com.mutecsoft.atalk.logic.model.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

/**
 * 조직 Tree 구조 Json 생성 시 필요한 객체
 * @author "Hong Seok Woo"
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL) // null 제외
public class OrgznJsonObj {
	/**
	 * 조직 아이디
	 */
    private int orgznId;
    
    /**
     * 조직명
     */
    private String label;
    
    /**
     * 조직의 자식요소
     */
    private List<OrgznJsonObj> nodes;

    public OrgznJsonObj(int orgznId, String label) {
        this.orgznId = orgznId;
        this.label = label;
    }
}
