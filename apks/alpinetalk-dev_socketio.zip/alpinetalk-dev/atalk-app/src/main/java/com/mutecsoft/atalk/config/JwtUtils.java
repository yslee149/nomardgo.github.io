package com.mutecsoft.atalk.config;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.stereotype.Component;

import com.mutecsoft.atalk.security.oauth2.model.TokenKeysProperty;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.*;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.EncodedKeySpec;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Arrays;
import java.util.Objects;

/**
 * @PackageName com.cnu.cas.mdms.app.config
 * @fileName	JwtUtils.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description :
 * <pre>
 *  WebSecurity  설정
 * </pre>
 */
@Slf4j
@Component
public class JwtUtils {
	@Autowired
	private KeyUtils keyUtils;
	
	@Autowired
	JwtDecoder decoder;

	private String extractUsername(String jwtToken) {
		if (Objects.isNull(jwtToken)) {
			return null;
		}
		return null;
	}
}
