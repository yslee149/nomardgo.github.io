package com.mutecsoft.atalk.service;

import java.util.Optional;

import com.mutecsoft.atalk.logic.model.AtalkDataModelAll;
import com.mutecsoft.atalk.logic.model.SecureDataModel;

public interface DigitalSigningServiceLogic {
	String saveDigitalSigningSeed(String seedValue);
	Optional<AtalkDataModelAll> doSign(SecureDataModel secModel) throws Exception ;
}
