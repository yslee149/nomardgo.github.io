
package com.mutecsoft.atalk.security;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.UserDetailsManager;
import org.springframework.stereotype.Service;

import com.mutecsoft.atalk.common.model.MUser;
import com.mutecsoft.atalk.common.repository.MUserRepository;
import com.mutecsoft.atalk.security.oauth2.model.CustomUserDetail;

import lombok.extern.slf4j.Slf4j;

/**
 * @PackageName com.mutecsoft.thechat.app.security.oauth2.service
 * @fileName	UserDetailsManageService.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description :
 * <pre>
 *  spring security UserDetailsManager  구현체
 * </pre>
 */
@Slf4j
@Service("userDetailsManager")
public class UserDetailsManageService implements UserDetailsManager {

	@Autowired
	MUserRepository mUserRepository;
	
	@Autowired
	PasswordEncoder passwordEncoder;

	@Override
	public void createUser(UserDetails user) {
	       
//	    ((User) user).setPassword(passwordEncoder.encode(user.getPassword()));
//	    // Save the user in the repository
//	    userRepository.save((User) user);
	}

	@Override
	public void updateUser(UserDetails user) {
	    // You can implement this method to update user details if needed
	    // For example, updating roles or other user information
	}

	@Override
	public void deleteUser(String username) {
	    // You can implement this method to delete a user by username
	    // Typically used when a user wants to delete their account
	}

	@Override
	public void changePassword(String oldPassword, String newPassword) {
	    // You can implement this method to change the user's password
	    // For example, when a user wants to change their password
	}

	@Override
	public boolean userExists(String username) {
	    
	    return false;
	}

	@Override
	public UserDetails loadUserByUsername(String userId) throws UsernameNotFoundException {
		Optional<MUser> userObjOp = mUserRepository.findByUserId(userId);
		if (userObjOp.isEmpty()) {
			throw new UsernameNotFoundException("login.account.notfound");
        }
		MUser mUser = userObjOp.get();
		CustomUserDetail loginUser = CustomUserDetail.builder()
				.mUser(mUser).build();
		return loginUser;
	}
}
