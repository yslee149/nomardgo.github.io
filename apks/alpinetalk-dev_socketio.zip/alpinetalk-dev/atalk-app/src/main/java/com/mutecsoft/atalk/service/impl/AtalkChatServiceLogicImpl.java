package com.mutecsoft.atalk.service.impl;

import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import com.mutecsoft.atalk.common.model.MChat;
import com.mutecsoft.atalk.common.model.MChatDel;
import com.mutecsoft.atalk.common.model.MChatExt;
import com.mutecsoft.atalk.common.model.MChatFile;
import com.mutecsoft.atalk.common.model.MChathub;
import com.mutecsoft.atalk.common.model.MChathubUser;
import com.mutecsoft.atalk.common.model.MUser;
import com.mutecsoft.atalk.common.repository.MChatDeleteRepository;
import com.mutecsoft.atalk.common.repository.MChatExtRepository;
import com.mutecsoft.atalk.common.repository.MChatFileRepository;
import com.mutecsoft.atalk.common.repository.MChatRepository;
import com.mutecsoft.atalk.common.repository.MChathubRepository;
import com.mutecsoft.atalk.common.repository.MChathubUserRepository;
import com.mutecsoft.atalk.common.repository.MUserRepository;
import com.mutecsoft.atalk.component.redis.RedisTaskBroker;
import com.mutecsoft.atalk.config.AtalkConfig;
import com.mutecsoft.atalk.config.AtalkMqSender;
import com.mutecsoft.atalk.constant.AtalkConstant;
import com.mutecsoft.atalk.constant.EnumChatSubType;
import com.mutecsoft.atalk.constant.EnumChatType;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.logic.model.chat.Chat;
import com.mutecsoft.atalk.logic.model.chat.ChatExt;
import com.mutecsoft.atalk.logic.model.chat.ChatFile;
import com.mutecsoft.atalk.logic.model.chat.ChatInfoRequest;
import com.mutecsoft.atalk.logic.model.chat.ChatInfoResponse;
import com.mutecsoft.atalk.logic.model.chat.ChatResponse;
import com.mutecsoft.atalk.logic.model.chat.DeleteChatRequest;
import com.mutecsoft.atalk.logic.model.chat.DeleteChatResponse;
import com.mutecsoft.atalk.logic.model.chat.ExtChatResponse;
import com.mutecsoft.atalk.logic.model.chat.ReadChatRequest;
import com.mutecsoft.atalk.logic.model.chat.ReadChatResponse;
import com.mutecsoft.atalk.logic.model.chat.RetrieveChatRequest;
import com.mutecsoft.atalk.logic.model.chat.RetrieveChatResponse;
import com.mutecsoft.atalk.logic.model.chat.SendChatRequest;
import com.mutecsoft.atalk.logic.model.chat.SendChatResponse;
import com.mutecsoft.atalk.logic.model.chat.SendFileChatResponse;
import com.mutecsoft.atalk.logic.model.chathub.ChatHubInfo;
import com.mutecsoft.atalk.logic.model.noti.ChatDataNoti;
import com.mutecsoft.atalk.logic.model.noti.ReadChatNoti;
import com.mutecsoft.atalk.logic.model.noti.RetrieveChatNoti;
import com.mutecsoft.atalk.logic.util.BufferComplex;
import com.mutecsoft.atalk.secure.model.redis.RedisPacketKeySeed;
import com.mutecsoft.atalk.service.AtalkChatServiceLogic;
import com.mutecsoft.atalk.service.AtalkUnreadCntService;

import jakarta.annotation.PostConstruct;
import jakarta.persistence.EntityManager;
import jakarta.persistence.ParameterMode;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.StoredProcedureQuery;
import lombok.extern.slf4j.Slf4j;

/**
 * 채팅방 관련 서비스
 * 
 */
@Slf4j
@Service("atalkChatServiceLogic")
public class AtalkChatServiceLogicImpl implements AtalkChatServiceLogic {

	@Autowired
	MUserRepository mUserRepository;
	
	@Autowired
	MChathubRepository mChathubRepository;

	@Autowired
	MChathubUserRepository mChathubUserRepository;
	
	@Autowired
	RedisTaskBroker redisTaskBroker;
	
	@PersistenceContext
	EntityManager entityManager;

	ObjectMapper objectMapper;
	
	@Autowired
	MChatRepository mChatRepository;
	
	@Autowired
	MChatFileRepository mChatFileRepository;

	@Autowired
	MChatExtRepository mChatExtRepository;
	
	@Autowired
	MChatDeleteRepository mChatDeleteRepository; 
	
	@Autowired
	AtalkConfig atalkConfig;
	
	SimpleDateFormat dateFormatter;
	
	SimpleDateFormat dateFormatterForFilePath;
	
	SimpleDateFormat dateFormatterForFileName;
	
//	@Autowired
//	private RabbitTemplate rabbitTemplate;
//
//	@Autowired
//	private RabbitAdmin rabbitAdmin;
	
	@Autowired
	AtalkUnreadCntService atalkUnreadCntService;
	
	@Autowired
	private AtalkMqSender atalkMqSender;
	
    Map<String, Object> rabbitMqConf;
	@PostConstruct
	private void init() {
		objectMapper = new ObjectMapper();
		dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		dateFormatterForFilePath = new SimpleDateFormat("yyyy/MM/dd");
		dateFormatterForFileName = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		rabbitMqConf = new HashMap<>();
		rabbitMqConf.put("x-expires", 60000); // Set TTL for queue to 60 seconds
	}

	@Override
	public SendChatResponse procMessage(MUser user, SendChatRequest reqObj)
			throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		
		String shortMsg = reqObj.getShortMessage();
		Chat messageObj = null;
		String chatContent = reqObj.getMessage();
		
		if (chatContent.isBlank()) {
			return null;
		}
		if (shortMsg == null || shortMsg.isBlank()) {
			messageObj = this.sendMessage(user.getUserNo()
					, reqObj.getChathubNo()
					, reqObj.getMessage()
					, EnumChatType.MESSAGE_GENERAL_TYPE
					, EnumChatSubType.MESSAGE_SUB_GENERAL_TYPE);
			messageObj.setChatExtUrl("");
			messageObj.setChatFileInfo(null);
		} else {
			/// 
			MChatExt mChatExt = new MChatExt();
			mChatExt.setExtChat(chatContent);
			mChatExt.setRegDate(new Date());
			mChatExtRepository.save(mChatExt);
			
			messageObj = this.sendMessage(user.getUserNo()
					, reqObj.getChathubNo()
					, reqObj.getShortMessage()
					, EnumChatType.MESSAGE_EXT_GENERAL_TYPE
					, EnumChatSubType.MESSAGE_SUB_GENERAL_TYPE);
			
			mChatExt.setChathubNo(messageObj.getChathubNo());
			mChatExt.setChatNo(messageObj.getChatNo());
			mChatExtRepository.save(mChatExt);
			
			String extChatUrl = String.format("%s/%d",
					atalkConfig.getChatConfig().getChatExtChatUrl()
					, mChatExt.getChatExtNo());
			
			messageObj.setChatExtUrl(extChatUrl);
			messageObj.setChatFileInfo(null);
			
			// mChatExtRepository.save(mChatExt);
		}
		messageObj.setUserName(user.getUserName());

		mChathubUserRepository.updateRead(user.getUserNo(), messageObj.getChathubNo());
		atalkUnreadCntService.resetUnreadCount(user.getUserNo(), messageObj.getChathubNo());
		
		////////////////////////// NOTI ///////////////////////
		List<MChathubUser> chathubUserList = mChathubUserRepository.findByChathubNoAndJoinYn(messageObj.getChathubNo(), "Y");
		
		RedisPacketKeySeed pktSeedObj = null;
		String seedValue = null;
		String packetKeyOther = null;
		ChatDataNoti chatDataNoti = new ChatDataNoti();
		chatDataNoti.setChatData(messageObj);
		
		SecureDataModel model = null;
		String notiCode = null;
		String message = null;
		String queueName = null;
		Optional<MUser> uOp = null;

		int unreadCntSum = 0;
		
		
		notiCode = String.format("%02x", AtalkConstant.MSG_CODE_CHAT_NOTI).toUpperCase();
		message = String.format("%s%s",
				chatDataNoti.toJson(), notiCode);
		
		atalkMqSender.publishMessageWithTTLThruWebSocket(
				chatDataNoti.getChatData().getChathubNo()
				, message);
		
		for (MChathubUser o : chathubUserList) {
			if (!user.getUserNo().equals(o.getUserNo())) {
				uOp = mUserRepository.findByUserNo(o.getUserNo());
				// pktSeedObj = redisTaskBroker.findKeyUserNo(o.getUserNo()); 
				
				atalkUnreadCntService.incrementUnreadCount(uOp.get().getUserNo()
						, o.getChathubNo());
				
//				if (pktSeedObj != null) {
//					queueName = String.format("Q_%s_%d",
//							uOp.get().getImei()
//							, o.getUserNo());
//					
//					seedValue = pktSeedObj.getSeed();
//					packetKeyOther = pktSeedObj.getPacketKey();
//					
//					model = chatDataNoti.toFinalModel(packetKeyOther);
//					log.debug("#### noti data : {}",model.toJson());
//					notiCode = String.format("%02x", AtalkConstant.MSG_CODE_CHAT_NOTI).toUpperCase();
//					message = String.format("%s%s%s",
//							model.toJson(), notiCode, seedValue);
//					// mq noti 처리
//					atalkMqSender.publishMessageWithTTL(
//							""
//							, queueName
//							, message
//							, 60 * 1000L);
//				}
				unreadCntSum = atalkUnreadCntService.getTotalUnreadCount(o.getUserNo());
				
				map.put("TYPE", messageObj.getChatType());
				map.put("KEY_ID", messageObj.getChathubNo().toString());
				map.put("CHAT_NO", messageObj.getChatNo().toString());
				map.put("SENDER_NO", user.getUserNo().toString());
				map.put("SENDER_NAME", user.getUserName());
				map.put("TITLE", "new message");
				map.put("UNREAD_CNT", String.valueOf(unreadCntSum));
				map.put("REG_DATE", messageObj.getRegDt());
				map.put("MESSAGE", "new message");
				map.put("collapse_key", makeRandomPw(8));
				map.put("token", uOp.get().getMobileToken());
				
				atalkMqSender.sendPush(uOp.get(), map);
			}
		}
		//////////////////////////NOTI ///////////////////////
		
		///////////////////////// RESPONSE /////////////////////////////////////////////////////
		SendChatResponse respObj = new SendChatResponse();
		respObj.setChatData(messageObj);
		return respObj;
	}
	
	// 대화 입력
	@Override
	public Chat sendMessage(
			Long userNo
			, Long chatHubNo
			, String message
			, EnumChatType chatType
			, EnumChatSubType chatSubType) {
		if (message == null || message.isBlank()) {
			return null;
		}
		if (chatSubType == null || chatType == null) {
			return null;
		}
		StoredProcedureQuery query = entityManager.createStoredProcedureQuery("PROC_CHAT");
		log.debug("#### CHAT DATA INFO :: chatType : {}, chatSubType : {}, userNo : {}, chatHubNo : {}, message {}",
				chatType.getValue(), chatSubType.getValue(), userNo, chatHubNo, message
				);
		query.registerStoredProcedureParameter("IN_CHATHUB_NO", 		Long.class, 	ParameterMode.IN);
		query.registerStoredProcedureParameter("IN_USER_NO", 			Long.class, 	ParameterMode.IN);
		query.registerStoredProcedureParameter("IN_CHAT_TYPE", 			String.class, 	ParameterMode.IN);
		query.registerStoredProcedureParameter("IN_CHAT_SUB_TYPE", 		String.class, 	ParameterMode.IN);
		query.registerStoredProcedureParameter("IN_CHAT", 				String.class, 	ParameterMode.IN);
		query.registerStoredProcedureParameter("OUT_REGDATE", 			Date.class, 	ParameterMode.OUT);
		query.registerStoredProcedureParameter("OUT_USERCOUNT", 		Long.class, 	ParameterMode.OUT);
		query.registerStoredProcedureParameter("OUT_MAX_CHAT_NO", 		Long.class, 	ParameterMode.OUT);
		
		query.setParameter("IN_CHATHUB_NO", chatHubNo);
		query.setParameter("IN_USER_NO", userNo);

		// C : 일반대화, E: 확장대화, F : 파일 대화, I : 인포
		// query.setParameter("IN_CHAT_TYPE", EnumChatType.MESSAGE_GENERAL_TYPE.getValue());
		query.setParameter("IN_CHAT_TYPE", chatType.getValue());
		query.setParameter("IN_CHAT_SUB_TYPE", chatSubType.getValue());
		
		query.setParameter("IN_CHAT", message);
		query.execute();

		Date outRegDt = (Date) query.getOutputParameterValue("OUT_REGDATE");
		Long outUserCount = (Long) query.getOutputParameterValue("OUT_USERCOUNT");
		Long outMaxChatNo = (Long) query.getOutputParameterValue("OUT_MAX_CHAT_NO");
		
		log.debug("### PROC_CHAT RESULT :: outRegDt : {}, outUserCount : {}, outMaxChatNo : {}",
				outRegDt, outUserCount, outMaxChatNo);

		Chat chatObj = new Chat();
		
		chatObj.setChathubNo(chatHubNo);
		chatObj.setChatNo(outMaxChatNo);
		chatObj.setUserNo(userNo);
		chatObj.setChatType(chatType.getValue());
		chatObj.setChatSubType(chatSubType.getValue());
		
		chatObj.setAlarmYn("Y");
		chatObj.setExtChat("");
		chatObj.setChatMessage(message);
		chatObj.setRegDt(dateFormatter.format(outRegDt));
		
		chatObj.setUnreadCnt(0L);
		chatObj.setUserCount(outUserCount);
		
		return chatObj;
	}

	@Override
	public Chat sendFileMessage(Long userNo, Long chatHubNo, String fileName, byte[] fileBuffer) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Chat sendInfoMessage(String subType, Long userNo, Long chatHubNo, String message) {
		if (message == null || message.isBlank()) {
			return null;
		}
		StoredProcedureQuery query = entityManager.createStoredProcedureQuery("PROC_CHAT");

		log.debug("#### CHAT DATA INFO : subType : {}, userNo : {}, chatHubNo : {}, message {}",
				subType, userNo, chatHubNo, message
				);
		query.registerStoredProcedureParameter("IN_CHATHUB_NO", 		Long.class, 	ParameterMode.IN);
		query.registerStoredProcedureParameter("IN_USER_NO", 			Long.class, 	ParameterMode.IN);
		query.registerStoredProcedureParameter("IN_CHAT_TYPE", 			String.class, 	ParameterMode.IN);
		query.registerStoredProcedureParameter("IN_CHAT_SUB_TYPE", 		String.class, 	ParameterMode.IN);
		query.registerStoredProcedureParameter("IN_CHAT", 				String.class, 	ParameterMode.IN);
		query.registerStoredProcedureParameter("OUT_REGDATE", 			Date.class, 	ParameterMode.OUT);
		query.registerStoredProcedureParameter("OUT_USERCOUNT", 		Integer.class, 	ParameterMode.OUT);
		query.registerStoredProcedureParameter("OUT_MAX_CHAT_NO", 		Long.class, 	ParameterMode.OUT);
		
		query.setParameter("IN_CHATHUB_NO", chatHubNo);
		query.setParameter("IN_USER_NO", userNo);

		// C : 일반대화, E: 확장대화, F : 파일 대화, I : 인포
		query.setParameter("IN_CHAT_TYPE", EnumChatType.MESSAGE_INFO_TYPE.getValue());
		query.setParameter("IN_CHAT_SUB_TYPE", subType);
		
		query.setParameter("IN_CHAT", message);
		query.execute();

		Date outRegDt = (Date) query.getOutputParameterValue("OUT_REGDATE");
		Integer outUserCount = (Integer) query.getOutputParameterValue("OUT_USERCOUNT");
		Long outMaxChatNo = (Long) query.getOutputParameterValue("OUT_MAX_CHAT_NO");
		
		log.debug("### PROC_CHAT RESULT :: outRegDt : {}, outUserCount : {}, outMaxChatNo : {}",
				outRegDt, outUserCount, outMaxChatNo);

		Chat chatObj = new Chat();
		
		chatObj.setChathubNo(chatHubNo);
		chatObj.setChatNo(outMaxChatNo);
		chatObj.setUserNo(userNo);
		chatObj.setChatType(EnumChatType.MESSAGE_INFO_TYPE.getValue());
		
		// 에러는 찾아야 겠지
//		if (outRegDt == null) {
//			outRegDt = new Date();
//		}
		
		
		chatObj.setRegDt(dateFormatter.format(outRegDt));
		
		return chatObj;
	}

	@Override
	public Pair<List<Chat>, Long> getMessageList(Long chatHubNo, Long baseChatNo, int chatCount) {
		Integer reqCount = chatCount > atalkConfig.getChatConfig().getChatInqDefaultMaxCount() ?
				atalkConfig.getChatConfig().getChatInqDefaultMaxCount() : chatCount;
		if (reqCount < 0) {
			reqCount = atalkConfig.getChatConfig().getChatInqDefaultMaxCount();
		}
		List<Object []> chatList = mChatRepository.findByChathubAndBaseChatNotWithCount(
				chatHubNo
				, baseChatNo
				, reqCount);

		List<Chat> retChatList = Lists.newArrayList();
		Long lastChatNo = baseChatNo;
		if (chatList != null) {
			for (Object[] row : chatList) {
				Chat obj = new Chat();
				int i =0;
				obj.setChathubNo(chatHubNo);
				obj.setChatNo((Long)row[i++]);
				obj.setChatType(String.valueOf((Character)row[i++]));
				obj.setChatSubType(String.valueOf((Character)row[i++]));
				obj.setUserNo((Long)row[i++]);
				obj.setUserName((String)row[i++]);
				obj.setUnreadCnt((Long)row[i++]);
				
				obj.setUserCount((Long)row[i++]);
				obj.setChatMessage((String)row[i++]);
				obj.setRegDt(dateFormatter.format((Date)row[i++]));
				obj.setExtChat((String)row[i++]);
				
				Long chatFileNo = (Long)row[i++];
				Long parentChatFileNo = (Long)row[i++];
				String fileType = (String.valueOf((Character)row[i++]));
				String displayName = (String)row[i++];
				Long fileSize = (Long)row[i++];
				
				if (chatFileNo > 0L) {
					ChatFile fileChat = new ChatFile();
					fileChat.setChatFileNo(chatFileNo);
					fileChat.setParentChatFileNo(parentChatFileNo);
					fileChat.setFileType(fileType);
					fileChat.setDispFileName(displayName);
					fileChat.setFileSize(fileSize);
					String fileChatUrl = String.format("%s/%d", 
							atalkConfig.getChatConfig().getChatFileChatUrl()
							, chatFileNo
							);
					fileChat.setDownloadPath(fileChatUrl);
					obj.setChatFileInfo(fileChat);
				}
				if (!obj.getExtChat().isBlank()) {
					String extChatUrl = String.format("%s/%d/%d", 
							atalkConfig.getChatConfig().getChatExtChatUrl()
							, chatHubNo
							, obj.getChatNo()
							);
					obj.setChatExtUrl(extChatUrl);
				}
				if (lastChatNo > obj.getChatNo()) {
					lastChatNo = obj.getChatNo();
				}
				if (obj.getChatExtUrl()==null) {
					obj.setChatExtUrl("");
				}
				obj.setAlarmYn("Y");
				retChatList.add(obj);
			}
		}
		return Pair.of(retChatList, lastChatNo);
	}
	
	@Override
	public Pair<List<Chat>, Long> getMessageLatestList(Long chatHubNo, int chatCount) {
		Integer reqCount = chatCount > atalkConfig.getChatConfig().getChatInqDefaultMaxCount() ?
				atalkConfig.getChatConfig().getChatInqDefaultMaxCount() : chatCount;
		if (reqCount < 0) {
			reqCount = atalkConfig.getChatConfig().getChatInqDefaultMaxCount();
		}
		List<Object []> chatList = mChatRepository.findByChathubLatestWithCount(
				chatHubNo, reqCount);
		
		List<Chat> retChatList = Lists.newArrayList();
		Long lastChatNo = 0L;// Long.MAX_VALUE;
		if (chatList != null) {
			if (chatList.size() > 0) {
				lastChatNo = Long.MAX_VALUE;
			}
			for (Object[] row : chatList) {
				int i=0;
				Chat obj = new Chat();
				
				obj.setChathubNo(chatHubNo);
				obj.setChatNo((Long)row[i++]);
				obj.setChatType(String.valueOf((Character)row[i++]));
				obj.setChatSubType(String.valueOf((Character)row[i++]));
				obj.setUserNo((Long)row[i++]);
				obj.setUserName((String)row[i++]);
				obj.setUnreadCnt((Long)row[i++]);
				
				obj.setUserCount((Long)row[i++]);
				obj.setChatMessage((String)row[i++]);
				obj.setRegDt(dateFormatter.format((Date)row[i++]));
				obj.setExtChat((String)row[i++]);
				
				Long chatFileNo = (Long)row[i++];
				Long parentChatFileNo = (Long)row[i++];
				String fileType = String.valueOf((Character)row[i++]);
				String displayName = (String)row[i++];
				
				Long fileSize = (Long)row[i++];
				
				
				if (chatFileNo > 0L) {
					ChatFile fileChat = new ChatFile();
					fileChat.setChatFileNo(chatFileNo);
					fileChat.setParentChatFileNo(parentChatFileNo);
					fileChat.setFileType(fileType);
					fileChat.setDispFileName(displayName);
					fileChat.setFileSize(fileSize);
					String fileChatUrl = String.format("%s/%d", 
							atalkConfig.getChatConfig().getChatFileChatUrl()
							, chatFileNo
							);
					fileChat.setDownloadPath(fileChatUrl);
					obj.setChatFileInfo(fileChat);
				}
				if (!obj.getExtChat().isBlank()) {
					String extChatUrl = String.format("%s/%d/%d", 
							atalkConfig.getChatConfig().getChatExtChatUrl()
							, chatHubNo
							, obj.getChatNo()
							);
					obj.setChatExtUrl(extChatUrl);
				}
				if (lastChatNo > obj.getChatNo()) {
					lastChatNo = obj.getChatNo();
				}
				if (obj.getChatExtUrl()==null) {
					obj.setChatExtUrl("");
				}
				obj.setAlarmYn("Y");
				retChatList.add(obj);
			}
		}
		return Pair.of(retChatList, lastChatNo);
	}

	@Override
	public ChatInfoResponse chatList(MUser user, ChatInfoRequest reqObj) throws Exception {
		log.debug("################# GET CHAT MESSAGE");
		
		Long chathubNo = reqObj.getChathubNo();
		Long lastChatNo = reqObj.getLastChatNo();
		int chatCount = reqObj.getChatInqCount();
		
		List<Chat> chatList = null;
		if (lastChatNo.equals(0L)) {
			Pair<List<Chat>, Long> chatListOp = this.getMessageLatestList(chathubNo, chatCount);
			chatList = chatListOp.getLeft();
			lastChatNo = chatListOp.getRight();
		} else {
			Pair<List<Chat>, Long> chatListOp = this.getMessageList(
					chathubNo
					, lastChatNo
					, chatCount);
			chatList = chatListOp.getLeft();
			lastChatNo = chatListOp.getRight();
		}
		///////////////////////// RESPONSE /////////////////////////////////////////////////////
		ChatInfoResponse respObj = new ChatInfoResponse();
		Optional<MChathub> chatHubObjOp = mChathubRepository.findByChathubNoAndUseYn(chathubNo, "Y");
		MChathub mchathubObj = chatHubObjOp.get();
		ChatHubInfo retChatHubObj = new ChatHubInfo();
		retChatHubObj.setChathubNo(mchathubObj.getChathubNo());
		retChatHubObj.setChathubType(mchathubObj.getChathubType());
		retChatHubObj.setUserNo(mchathubObj.getUserNo());
		retChatHubObj.setUsersNum(mchathubObj.getUsersNum());
		retChatHubObj.setUseYn(mchathubObj.getUseYn());
		
		Optional<MChathubUser> myChathubUserOp = mChathubUserRepository.findByChathubNoAndUserNoAndJoinYn(
				chathubNo, user.getUserNo(), "Y");
		retChatHubObj.setEncChathubKey(myChathubUserOp.get().getEncryptChatKey());
		
		respObj.setChatHubInfo(retChatHubObj);
		respObj.setChatList(chatList);
		respObj.setLastChatNo(lastChatNo);
		return respObj;
	}
	

	private static final int BUFFER_SIZE = 1024 * 1024; // 1 MB buffer size
    
	/**
	 * 
	 * 
	 * @param chathubNo
	 * @param userNo
	 * @param byteBuffer
	 * @param start
	 * @param length
	 * @return
	 */
	@SuppressWarnings("finally")
	private String [] _uploadFile(Long chathubNo, Long userNo, byte [] byteBuffer, int start, long length) {
		// 1. file upload
		FileOutputStream fos =null;
		String fileName = null;
		String datePath = dateFormatterForFilePath.format(new Date());
		Boolean bRes = Boolean.FALSE;
		try {
			fileName = String.format("a_%d_%d_%s", 
					chathubNo
					, userNo
					, dateFormatterForFileName.format(new Date()));
			Path uploadPath = Paths.get(atalkConfig.getChatConfig().getChatFilePath(), datePath);
			if (!Files.exists(uploadPath)) {
				Files.createDirectories(uploadPath);
			}
			Path filePath = uploadPath.resolve(fileName);
			fos = new FileOutputStream(filePath.toFile());
			long bytesRemaining = length;
			int offset = (int) start;
			while (bytesRemaining > 0) {
				int bytesToWrite = (int) Math.min(BUFFER_SIZE, bytesRemaining);
				fos.write(byteBuffer, offset, bytesToWrite);
				offset += bytesToWrite;
				bytesRemaining -= bytesToWrite;
			}
			bRes = Boolean.TRUE;
		} catch (IOException e) {
			log.error("@@@@ : {}", e);
		} finally {
		    if (fos != null) {
		        try {
		            fos.close();
		        } catch (IOException ex) {
		        	log.error("@@@@ : {}", ex);
		        }
		    }
		    if (bRes.equals(Boolean.TRUE)) {
				return new String [] {
						fileName
						, String.format("%s/%s", datePath, fileName)
				};
		    } else {
		    	return null;
		    }
		}
	}

	@Override
	public SendFileChatResponse procFileMessage(
			MUser user
			, Long chathubNo
			, String fileType
			, MultipartFile file)
			throws Exception {
		if (chathubNo == null || chathubNo <= 0L) {
			return null;
		}
		if (!fileType.equals(EnumChatSubType.MESSAGE_SUB_IMAGE_TYPE.getValue())
			&&
			!fileType.equals(EnumChatSubType.MESSAGE_SUB_MOVIE_TYPE.getValue())
			&&
			!fileType.equals(EnumChatSubType.MESSAGE_SUB_DECUMENT_TYPE.getValue())
			&&
			!fileType.equals(EnumChatSubType.MESSAGE_SUB_GENFILE_TYPE.getValue())) {
			log.error("@@@@ invalid file type : {}, chathub no : {}, userId : {}",
					fileType, chathubNo, user.getUserId());
			return null;
		}
		// String packetKey = packetDecryptor.packetKeyFromUserNo(user.getUserNo());
		
		// 0. get transaction id and seed value
		byte [] targetBuffer = file.getBytes();
		long bufferSize = (file.getSize() - 16L - 8L);
		String [] uploadInfoArr = _uploadFile(
				chathubNo
				, user.getUserNo()
				, targetBuffer
				, 0
				, bufferSize);
//			if (uploadInfoArr == null) {
//				return Optional.ofNullable(null);	
//			}
		
		// check file type one more
		
		if (file.getOriginalFilename().toUpperCase().endsWith("MP4")
			|| file.getOriginalFilename().toUpperCase().endsWith("AVI")
			|| file.getOriginalFilename().toUpperCase().endsWith("MOV")
			|| file.getOriginalFilename().toUpperCase().endsWith("WMV")
			|| file.getOriginalFilename().toUpperCase().endsWith("FLV")) {
		
			fileType = EnumChatSubType.MESSAGE_SUB_MOVIE_TYPE.getValue();
		}
		if (file.getOriginalFilename().toUpperCase().endsWith("GIF")
				|| file.getOriginalFilename().toUpperCase().endsWith("PNG")
				|| file.getOriginalFilename().toUpperCase().endsWith("JPG")
				|| file.getOriginalFilename().toUpperCase().endsWith("JPEG")
				|| file.getOriginalFilename().toUpperCase().endsWith("TIFF")
				|| file.getOriginalFilename().toUpperCase().endsWith("BMP")) {
			fileType = EnumChatSubType.MESSAGE_SUB_IMAGE_TYPE.getValue();
		}
		
		MChatFile chatFile = new MChatFile();
		chatFile.setFileType(fileType);
		chatFile.setFileName(uploadInfoArr[0]);
		chatFile.setDispName(file.getOriginalFilename());
		chatFile.setFilePath(uploadInfoArr[1]);
		chatFile.setFileSize(file.getSize());
		chatFile.setUseYn("N");
		chatFile.setRegDate(new Date());
		
		String message = String.format("%s(%s)",
				file.getOriginalFilename()
				, BufferComplex.convertBytesToReadableSize(file.getSize()));
		
		mChatFileRepository.save(chatFile);
		log.debug("#### file info : {}", chatFile);
		
		Chat messageObj = this.sendMessage(
				user.getUserNo()
				, chathubNo
				, message
				, EnumChatType.MESSAGE_FILE_TYPE
				, EnumChatSubType.fromSubValue(fileType));
		
		chatFile.setChathubNo(chathubNo);
		chatFile.setChatNo(messageObj.getChatNo());
		chatFile.setUseYn("Y");
		mChatFileRepository.save(chatFile);
		
		ChatFile chatFileObj = new ChatFile();
		chatFileObj.setChatFileNo(chatFile.getChatFileNo());
		chatFileObj.setParentChatFileNo(0L);
		
		chatFileObj.setFileType(fileType);
		chatFileObj.setDispFileName(chatFile.getDispName());
		chatFileObj.setFileSize(chatFile.getFileSize());
		chatFileObj.setDownloadPath(
				String.format("%s/%s", 
						atalkConfig.getChatConfig().getChatFileChatUrl()
						,chatFileObj.getChatFileNo()));
		
		chatFileObj.setFileSize(chatFile.getFileSize());
		
		messageObj.setUserName(user.getUserName());
		messageObj.setChatExtUrl("");
		messageObj.setChatFileInfo(chatFileObj);
		
		//////////////////////////NOTI ///////////////////////
		List<MChathubUser> chathubUserList = mChathubUserRepository.findByChathubNoAndJoinYn(messageObj.getChathubNo(), "Y");
		RedisPacketKeySeed pktSeedObj = null;
		String seedValue = null;
		String packetKeyOther = null;
		ChatDataNoti chatDataNoti = new ChatDataNoti();
		chatDataNoti.setChatData(messageObj);
		Optional<MUser> uOp = null;
		String queueName = null;
		
		Map<String, String> map = new HashMap<String, String>();

		int unreadCntSum = 0;
		
		
		String notiCode = String.format("%02x", AtalkConstant.MSG_CODE_CHAT_NOTI).toUpperCase();
		message = String.format("%s%s",
				chatDataNoti.toJson(), notiCode);
		
		atalkMqSender.publishMessageWithTTLThruWebSocket(
				chatDataNoti.getChatData().getChathubNo()
				, message);
		
		for (MChathubUser o : chathubUserList) {
			if (!user.getUserNo().equals(o.getUserNo())) {
				uOp = mUserRepository.findByUserNo(o.getUserNo());
//				pktSeedObj = redisTaskBroker.findKeyUserNo(o.getUserNo()); 
//				if (pktSeedObj != null) {
//					queueName = String.format("Q_%s_%d",
//							uOp.get().getImei()
//							, o.getUserNo());
//					
//					seedValue = pktSeedObj.getSeed();
//					packetKeyOther = pktSeedObj.getPacketKey();
//					
//					SecureDataModel model = chatDataNoti.toFinalModel(packetKeyOther);
//					log.debug("#### noti data : {}",model.toJson());
//					 notiCode = String.format("%02x", AtalkConstant.MSG_CODE_CHAT_NOTI).toUpperCase();
//					String tmessage = String.format("%s%s%s",
//							model.toJson(), notiCode, seedValue);
//					atalkMqSender.publishMessageWithTTL("", queueName, tmessage, 60 * 1000L);
//				}
				unreadCntSum = atalkUnreadCntService.getTotalUnreadCount(o.getUserNo());
				
				map.put("TYPE", messageObj.getChatType());
				map.put("KEY_ID", messageObj.getChathubNo().toString());
				map.put("CHAT_NO", messageObj.getChatNo().toString());
				map.put("SENDER_NO", user.getUserNo().toString());
				map.put("SENDER_NAME", user.getUserName());
				map.put("TITLE", "new message");
				map.put("UNREAD_CNT", String.valueOf(unreadCntSum));
				map.put("REG_DATE", messageObj.getRegDt());
				map.put("MESSAGE", "new message");
				map.put("collapse_key", makeRandomPw(8));
				map.put("token", uOp.get().getMobileToken());
				
				atalkMqSender.sendPush(uOp.get(), map);
			}
		}
		//////////////////////////NOTI ///////////////////////
		
		///////////////////////// RESPONSE /////////////////////////////////////////////////////
		SendFileChatResponse respObj = new SendFileChatResponse();
		respObj.setChatData(messageObj);
		return respObj;
	}

	@Override
	public ExtChatResponse getExtChat(MUser user, Long extChatNo) throws Exception {

		Optional<MChatExt> chatExtOp = mChatExtRepository.findByUserNoAndChatExtNo(
				user.getUserNo()
				, extChatNo);
		if (chatExtOp.isEmpty()) {
			log.error("@@@@ : Not joind chathub-ext no : {}, userNo : {}",
					extChatNo, user.getUserNo());
			return null;
		}
		///////////////////////// RESPONSE /////////////////////////////////////////////////////
		ChatExt chatData = new ChatExt();
		chatData.setChatContent(chatExtOp.get().getExtChat());
		
		ExtChatResponse respObj = new ExtChatResponse();
		respObj.setChatData(chatData);
		return respObj;
	}

	@Override
	public DeleteChatResponse deleteChatList(MUser user, DeleteChatRequest reqObj)
			throws Exception {
		Long chathubNo = reqObj.getChathubNo();
		List<Long> chatNoList = reqObj.getChtaNoList();
		if (chatNoList != null) {
			MChatDel chatDelObj = null;
			for (Long chatNo : chatNoList) {
				chatDelObj = new MChatDel();
				
				chatDelObj.setChathubNo(chathubNo);
				chatDelObj.setUserNo(user.getUserNo());
				chatDelObj.setChatNo(chatNo);
				chatDelObj.setRegDate(new Date());
				
				mChatDeleteRepository.save(chatDelObj);
			}
		}
		///////////////////////// RESPONSE /////////////////////////////////////////////////////
		DeleteChatResponse respObj = new DeleteChatResponse();
		respObj.setResult(Boolean.TRUE);
		return respObj;
	}

	@Override
	public RetrieveChatResponse retrieveChatList(MUser user, RetrieveChatRequest reqObj)
			throws Exception {
	
		Long chathubNo = reqObj.getChathubNo();
		List<Long> chatNoList = reqObj.getChtaNoList();
		
		Long lchatNo = 0L;
		if (chatNoList != null) {
			for (Long chatNo : chatNoList) {
				mChatRepository.retriveChat(chathubNo, chatNo);
				lchatNo = chatNo;
			}
		}
		mChathubUserRepository.updateDate(chathubNo);
		
        String resultNoti = chatNoList.stream()
                .map(String::valueOf) // Convert each Long to String
                .collect(Collectors.joining(","));
		////////////////////////// NOTI ///////////////////////
		List<MChathubUser> chathubUserList = mChathubUserRepository.findByChathubNoAndJoinYn(chathubNo, "Y");
		
		RedisPacketKeySeed pktSeedObj = null;
		String seedValue = null;
		String notiCode = null;
		String message = null;
		String queueName = null;
		Optional<MUser> uOp = null;
		

		Map<String, String> map = new HashMap<String, String>();
		
		
		int unreadCntSum = 0;
		
		RetrieveChatNoti notiMsg = new RetrieveChatNoti();
		notiMsg.setUserNo(user.getUserNo());
		notiMsg.setChatNo(lchatNo);
		notiMsg.setChathubNo(chathubNo);
		
		notiCode = String.format("%02x", AtalkConstant.MSG_CODE_RETREIVE_CHAT_NOTI).toUpperCase();
		message = String.format("%s%s",
				notiMsg, notiCode);
		
		atalkMqSender.publishMessageWithTTLThruWebSocket(
				chathubNo
				, message);
		
		for (MChathubUser o : chathubUserList) {
			if (!user.getUserNo().equals(o.getUserNo())) {
				uOp = mUserRepository.findByUserNo(o.getUserNo());
//				pktSeedObj = redisTaskBroker.findKeyUserNo(o.getUserNo());
//				
//				if (pktSeedObj != null) {
//					queueName = String.format("Q_%s_%d",
//							uOp.get().getImei()
//							, o.getUserNo());
//					notiCode = String.format("%02x", AtalkConstant.MSG_CODE_RETREIVE_CHAT_NOTI).toUpperCase();
//					message = String.format("%s%s%s",
//							resultNoti
//							, notiCode, seedValue);
//					// mq noti 처리
//					atalkMqSender.publishMessageWithTTL(
//							""
//							, queueName
//							, message
//							, 60 * 1000L);
//				}
				unreadCntSum = atalkUnreadCntService.getTotalUnreadCount(o.getUserNo());
				
				map.put("TYPE", "I");
				map.put("KEY_ID", String.valueOf(chathubNo));
				map.put("CHAT_NO", lchatNo.toString());
				map.put("SENDER_NO", user.getUserNo().toString());
				map.put("SENDER_NAME", user.getUserName());
				
				map.put("TITLE", resultNoti);
				map.put("UNREAD_CNT", String.valueOf(unreadCntSum));
				map.put("REG_DATE", "");
				map.put("MESSAGE", resultNoti);
				map.put("collapse_key", makeRandomPw(8));
				map.put("token", uOp.get().getMobileToken());
				
				atalkMqSender.sendPush(uOp.get(), map);
			}
		}
		//////////////////////////NOTI ///////////////////////
		
		
		///////////////////////// RESPONSE /////////////////////////////////////////////////////
		RetrieveChatResponse respObj = new RetrieveChatResponse();
		respObj.setResult(Boolean.TRUE);
		return respObj;
	}
	
//	/**
//	 * noti 메시지 처리
//	 * 
//	 * @param exchange
//	 * @param queueName
//	 * @param message
//	 * @param ttl
//	 * @param user
//	 * @param pushData
//	 */
//	private void publishMessageWithTTL(String exchange, String queueName, String message, long ttl) {
//		MessagePostProcessor messagePostProcessor = msg -> {
//			msg.getMessageProperties().setExpiration(String.valueOf(ttl));
//			return msg;
//		};
//		// message = "ffff";
//		// rabbitAdmin.declareQueue(new Queue(queueName, false, false, true));
//		// rabbitAdmin.declareQueue(new Queue(queueName, false, false, true, rabbitMqConf));
//		rabbitAdmin.declareQueue(new Queue(queueName, false, false, true, null));
//		// durable = true => system reboot exists
//		// exclusive = false => only one connection
//		// autoDelete = true => q get deleted unused.
//		log.info("### exchange : {}, queueName: {}, message : {}, ttl : {}", exchange, queueName, message, ttl);
//		rabbitTemplate.convertAndSend(exchange, queueName, message, messagePostProcessor);
//		// System.out.println("Published message with TTL: " + ttl + " ms");
//	}
	
	/**
	 * push 메시지 처리
	 * 
	 * @param user
	 * @param pushData
	 */
//	@Deprecated
//	private void sendPush(MUser user, Map<String, String> pushData) {
//		if (user.getDeviceType()!=null
//				&&
//			user.getDeviceType().equals("A")
//				&&
//				!StringUtils.isBlank(user.getMobileToken())) {
//			try {
//				AtalkPacketUtil.requestAtalkMessage(pushData
//						, atalkConfig.getPushAgentUrl());
//			} catch (Exception e) {
//				log.error("@@@@ : {}", e);
//			}
//		}
//	}

	public String makeRandomPw(int len) {
	    // 소문자, 대문자, 숫자 
		final String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
		SecureRandom rm = new SecureRandom();
		StringBuffer sb = new StringBuffer();
		for (int i=0; i<len; i++) {
			int index = rm.nextInt(chars.length());
			//index의 위치한 랜덤값
			sb.append(chars.charAt(index));
		}
		return sb.toString();
	}

	@Override
	public Chat getLastMessage(Long chatHubNo) {
		MChat mchat = mChatRepository.getLastMessage(chatHubNo);
		
		Chat chatObj = new Chat();
			
		chatObj.setChathubNo(chatHubNo);
		chatObj.setChatNo(mchat.getChatNo());
		chatObj.setUserNo(mchat.getUserNo());
		chatObj.setChatType(mchat.getChatType());
		chatObj.setChatSubType(mchat.getChatSubType());
		
		chatObj.setAlarmYn("Y");
		chatObj.setExtChat("");
		chatObj.setChatMessage(mchat.getChat());
		chatObj.setRegDt(dateFormatter.format(mchat.getRegDate()));
		
		chatObj.setUnreadCnt(0L);
		chatObj.setUserCount(mchat.getUsersNum());
		
		return chatObj;
	}

	@Override
	public ReadChatResponse readChat(MUser user, ReadChatRequest reqObj) throws Exception {
		mChathubUserRepository.updateRead(user.getUserNo(), reqObj.getChathubNo());
		Long maxChatNo = mChatRepository.getMaxChatNo(reqObj.getChathubNo());
		
		// 읽음 확인
		atalkUnreadCntService.resetUnreadCount(user.getUserNo(), reqObj.getChathubNo());
		
		ReadChatNoti notiObj = new ReadChatNoti();
		notiObj.setChathubNo(reqObj.getChathubNo());
		notiObj.setLastReadChatNo(maxChatNo);
		notiObj.setUserNo(user.getUserNo());
		
		//////////////////////////NOTI ///////////////////////
		
		List<MChathubUser> chathubUserList = mChathubUserRepository.findByChathubNoAndJoinYn(reqObj.getChathubNo(), "Y");
		RedisPacketKeySeed pktSeedObj = null;
		String seedValue = null;
		String packetKeyOther = null;
		
		Date dt = new Date();
		
		Map<String, String> map = new HashMap<String, String>();
		int unreadCntSum = 0;
		
		String notiCode = String.format("%02x", AtalkConstant.MSG_CODE_READ_NOTI).toUpperCase();
		String message = String.format("%s%s",
				notiObj, notiCode);
		
		atalkMqSender.publishMessageWithTTLThruWebSocket(
				reqObj.getChathubNo()
				, message);
		
		for (MChathubUser o : chathubUserList) {
			if (!user.getUserNo().equals(o.getUserNo())) {
				// unread count 증가
				// atalkUnreadCntService.incrementUnreadCount(o.getUserNo(), reqObj.getChathubNo());
				Optional<MUser> uOp = mUserRepository.findByUserNo(o.getUserNo());
//				String queueName = String.format("Q_%s_%d",
//						uOp.get().getImei()
//						, o.getUserNo());
//				pktSeedObj = redisTaskBroker.findKeyUserNo(o.getUserNo()); 
//				if (pktSeedObj != null) {
//					seedValue = pktSeedObj.getSeed();
//					packetKeyOther = pktSeedObj.getPacketKey();
//					SecureDataModel model = notiObj.toFinalModel(packetKeyOther);
//					log.debug("#### noti data : {}",model.toJson());
//					notiCode = String.format("%02x", AtalkConstant.MSG_CODE_READ_NOTI).toUpperCase();
//					message = String.format("%s%s%s",
//							model.toJson(), notiCode, seedValue);
//					
//					atalkMqSender.publishMessageWithTTL(
//							""
//							, queueName
//							, message
//							, 60 * 1000L);
//				}
				
//				ReadChatNoti notiObj = new ReadChatNoti();
//				notiObj.setChathubNo(reqObj.getChathubNo());
//				notiObj.setLastReadChatNo(maxChatNo);
//				notiObj.setUserNo(user.getUserNo());
				
				// NO NEED TO SEND PUSH
				unreadCntSum = atalkUnreadCntService.getTotalUnreadCount(o.getUserNo());
				map.put("TYPE", "RR");
				map.put("KEY_ID", notiObj.getChathubNo().toString());
				map.put("CHAT_NO", notiObj.getLastReadChatNo().toString());
				map.put("SENDER_NO", user.getUserNo().toString());
				map.put("SENDER_NAME", user.getUserName());
				map.put("TITLE", "read message");
				map.put("UNREAD_CNT", String.valueOf(unreadCntSum));
				map.put("REG_DATE", dateFormatter.format(dt));
				map.put("MESSAGE", "info message");
				map.put("collapse_key", atalkMqSender.makeRandomPw(8));
				map.put("token", uOp.get().getMobileToken());
				
				atalkMqSender.sendPush(uOp.get(), map);
			}
		}
		
		///////////////////////// RESPONSE /////////////////////////////////////////////////////
		ReadChatResponse respObj = new ReadChatResponse();
		respObj.setChathubNo(reqObj.getChathubNo());
		respObj.setLastReadChatNo(maxChatNo);
		respObj.setUserNo(user.getUserNo());
		return respObj;
	}

	@Override
	public ChatResponse get(Long userNo, Long chatHubNo, Long chatNo) throws Exception {
		Optional<MChat>  chatObjOp	= mChatRepository.findByChathubNoAndChatNo(chatHubNo, chatNo);
		
		ChatResponse respObj = new ChatResponse();
		if (chatObjOp.isPresent()) {
			respObj.setChathubNo(chatHubNo);
			respObj.setChatNo(chatNo);
			respObj.setChatMessage(chatObjOp.get().getChat());
			respObj.setChatType(chatObjOp.get().getChatType());
			respObj.setChatSubType(chatObjOp.get().getChatSubType());
			respObj.setUserName("");
			Optional<MUser> senderUserOp = mUserRepository.findByUserNo(chatObjOp.get().getUserNo());
			if (senderUserOp.isPresent()) {
				respObj.setUserName(senderUserOp.get().getUserName());
			}

			Optional<MChathubUser> chathubUserOp = mChathubUserRepository.findByChathubNoAndUserNoAndJoinYn(
					chatHubNo, userNo, "Y"
					);
			if (chathubUserOp.isPresent()) {
				respObj.setEncChatKey(chathubUserOp.get().getEncryptChatKey());
			}
			respObj.setUserNo(chatObjOp.get().getUserNo());
		} else {
		}
		return respObj;
	}
}
