package com.mutecsoft.atalk.web.controller.plain;

import com.mutecsoft.atalk.logic.model.auth.UserAuthTokenRequest;
import com.mutecsoft.atalk.logic.model.auth.UserAuthTokenResponse;
import com.mutecsoft.atalk.logic.model.auth.UserLoginRequest;
import com.mutecsoft.atalk.logic.model.auth.UserLoginResponse;
import com.mutecsoft.atalk.logic.model.auth.UserPasswordRequest;
import com.mutecsoft.atalk.logic.model.auth.UserPasswordResponse;
import com.mutecsoft.atalk.logic.model.auth.UserResultResponse;
import com.mutecsoft.atalk.security.oauth2.model.CustomUserDetail;
import com.mutecsoft.atalk.service.AtalkUserServiceLogic;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * @PackageName com.mutecsoft.atalk.web.controller.plain
 * @fileName	PlainAuthController.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description :
 * <pre>
 * 
 * </pre>
 */
@Slf4j
@Tag(name="Authentication(Plain)", description="Authentication API(Plain)")
@Controller
@RequestMapping(value = "/api/plain/v1/auth")
public class PlainAuthController {
	
	@Autowired
	AtalkUserServiceLogic atalkUserServiceLogic;	
	
	/**
	 * 로그인
	 * 
	 * @param secureReqModel
	 * @return
	 */
	@PostMapping("/login/{packetKeySeedValue}")
	public ResponseEntity<?> login(
			@PathVariable("packetKeySeedValue") String packetKeySeedValue
			, @RequestBody UserLoginRequest reqObj) {
		try {
			log.debug("################# LOGIN");
			UserLoginResponse resp = atalkUserServiceLogic.login(packetKeySeedValue, reqObj);
			return new ResponseEntity<>(resp, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("@@@@ Unauthorized");
	}
	
	/**
	 * refresh token 
	 * 
	 * @param reqObj
	 * @return
	 */
	@PostMapping("/refresh")
	public ResponseEntity<?> refreshToken(
			@RequestBody UserAuthTokenRequest reqObj) {
		try {
			log.debug("################# REFRESH TOKEN");
			UserAuthTokenResponse respOp = atalkUserServiceLogic.refreshToken(reqObj);
			return new ResponseEntity<>(respOp, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("@@@@ Unauthorized");
	}
//
	/**
	 * 임시 비밀번호 발급
	 * 
	 * @param userInf
	 * @return
	 * @throws Exception 
	 */
	@PostMapping("/changePassword")
	public ResponseEntity<?> changePassword(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @RequestBody UserPasswordRequest reqObj) {
		try {
			log.debug("################# CHANGE PASSWORD");
			UserPasswordResponse respOp = atalkUserServiceLogic.changePassword(authUser.getMUser(), reqObj);
			return new ResponseEntity<>(respOp, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
	
	/**
	 * 비밀번호 체크
	 * 
	 * @param authUser
	 * @param encPassword
	 * @return
	 */
	@PostMapping("/checkPassword/{encPassword}")
	public ResponseEntity<?> checkPassword(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @PathVariable("encPassword") String encPassword) {
		try {
			log.debug("################# CHECK PASSWORD");
			UserResultResponse respObj = atalkUserServiceLogic.checkPassword(authUser.getMUser(), encPassword);
			return new ResponseEntity<>(respObj, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
	

	/**
	 * 비밀번호 임시 발급
	 * 
	 * @param authUser
	 * @param encPassword
	 * @return
	 */
	@RequestMapping(value="/issueTempPassword/{userEmail}", method = {RequestMethod.POST, RequestMethod.GET})
	public ResponseEntity<?> issueTempPassword(
			@PathVariable("userEmail") String userEmail) {
		try {
			log.debug("################# CHECK PASSWORD");
			UserResultResponse respObj = atalkUserServiceLogic.issuePassword(userEmail);
			return new ResponseEntity<>(respObj, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
	
	/**
	 * 비밀번호 임시 발급
	 * 
	 * @param authUser
	 * @param encPassword
	 * @return
	 */
	@RequestMapping(value="/issueToken/{userEmail}", method = {RequestMethod.POST, RequestMethod.GET})
	public ResponseEntity<?> issueToken(
			@PathVariable("userEmail") String userEmail) {
		try {
			log.debug("################# AUTH EMAIL");
			UserResultResponse respObj = atalkUserServiceLogic.authEmail(userEmail);
			return new ResponseEntity<>(respObj, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}

	/**
	 * 인증 토큰 확인
	 * 
	 * @param userEmail
	 * @param tokenValue
	 * @return
	 */
	@RequestMapping(value="/checkIssueToken/{userEmail}/{tokenValue}", method = {RequestMethod.POST, RequestMethod.GET})
	public ResponseEntity<?> checkIssueToken(
			@PathVariable("userEmail") String userEmail
			, @PathVariable("tokenValue") String tokenValue) {
		try {
			log.debug("################# AUTH TOKEN (VERIFY)");
			UserResultResponse respObj = atalkUserServiceLogic.checkAuthToken(userEmail, tokenValue);
			return new ResponseEntity<>(respObj, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		UserResultResponse respObj = new UserResultResponse();
		respObj.setResult("FAIL");
		return new ResponseEntity<>(respObj, HttpStatus.OK);
	}

	/**
	 * 언어설정
	 * 
	 * @param userInf
	 * @return
	 * @throws Exception 
	 */
	@PostMapping("/logout")
	public ResponseEntity<?> logout(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser) {
		try {
			log.debug("################# CHANGE PASSWORD");
			UserResultResponse respOp = atalkUserServiceLogic.logout(authUser.getMUser());
			return new ResponseEntity<>(respOp, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
	
	/**
	 * 회원탈퇴
	 * 
	 * @param userInf
	 * @return
	 * @throws Exception 
	 */
	@PostMapping("/deactivate")
	public ResponseEntity<?> deactivate(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser) {
		try {
			log.debug("################# CHANGE PASSWORD");
			UserResultResponse respOp = atalkUserServiceLogic.deactivate(authUser.getMUser());
			return new ResponseEntity<>(respOp, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("@@@@ Unauthorized");
	}
}
