package com.mutecsoft.atalk.util;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.springframework.web.multipart.MultipartFile;

/**
 * @PackageName 
 * @fileName	ImageComplex.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description : 
 * <pre>
 * 
 * </pre>
 */
public class ImageComplex {

	/**
	 * 이미지 확장자 체크
	 * 
	 * @param file
	 * @return
	 */
	public static boolean isImageByExtension(MultipartFile file) {
		String fileName = file.getOriginalFilename().toLowerCase();
		if (fileName != null) {
			return fileName.endsWith(".jpg") || fileName.endsWith(".jpeg") ||
					fileName.endsWith(".png") || fileName.endsWith(".gif") ||
					fileName.endsWith(".bmp") || fileName.endsWith(".webp");
		}
		return false;
	}

	/**
	 * 이미지 확장자 체크
	 * 
	 * @param paramfileName
	 * @return
	 */
	public static boolean isImageByExtension(String paramfileName) {
		String fileName = paramfileName.toLowerCase();
		if (fileName != null) {
			return fileName.endsWith(".jpg") || fileName.endsWith(".jpeg") ||
					fileName.endsWith(".png") || fileName.endsWith(".gif") ||
					fileName.endsWith(".bmp") || fileName.endsWith(".webp");
		}
		return false;
	}
	
	/**
	 * 버퍼 체크
	 * 
	 * @param file
	 * @return
	 */
	public static boolean isImageByContent(MultipartFile file) {
		try {
			BufferedImage image = ImageIO.read(file.getInputStream());
			return image != null;
		} catch (IOException e) {
			return false;
		}
	}
	

	/**
	 * 버퍼 체크
	 * 
	 * @param file
	 * @return
	 */
	public static boolean isImageByContent(byte [] byteArr) {
		try {
			BufferedImage image = ImageIO.read(new ByteArrayInputStream(byteArr));
			return image != null;
		} catch (IOException e) {
			return false;
		}
	}

	/**
	 * 
	 * @param inputStr
	 * @param iteration
	 * @return
	 */
	public static boolean checkImage(MultipartFile file) {
		return ImageComplex.isImageByExtension(file) && ImageComplex.isImageByContent(file);
	}

	/**
	 * 
	 * @param inputStr
	 * @param iteration
	 * @return
	 */
	public static boolean checkImage(String fileName, byte [] byteArr) {
		return ImageComplex.isImageByExtension(fileName) && ImageComplex.isImageByContent(byteArr);
	}

	/**
	 * 
	 * @param originalImage
	 * @param targetWidth
	 * @param targetHeight
	 * @return
	 */
	public static BufferedImage resizeImageWithAspectRatio(BufferedImage originalImage, int targetWidth, int targetHeight) {
		int originalWidth = originalImage.getWidth();
		int originalHeight = originalImage.getHeight();

		// Calculate the scale factor to preserve the aspect ratio
		double scale = Math.min((double) targetWidth / originalWidth, (double) targetHeight / originalHeight);
		
		int newWidth = (int) (originalWidth * scale);
		int newHeight = (int) (originalHeight * scale);
		
		// Create a new BufferedImage with the target size and draw the scaled image onto it
		BufferedImage resizedImage = new BufferedImage(targetWidth, targetHeight, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g2d = resizedImage.createGraphics();
		
		// Optional: Set rendering hints for better image quality
		g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
		g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		
		// Calculate the x and y coordinates to center the scaled image
		int x = (targetWidth - newWidth) / 2;
		int y = (targetHeight - newHeight) / 2;
		
		// Draw the scaled image onto the new BufferedImage
		g2d.drawImage(originalImage.getScaledInstance(newWidth, newHeight, 
				Image.SCALE_SMOOTH), x, y, null);
		g2d.dispose();
		
		return resizedImage;
    }

	public static void main(String[] args) {
		try {
			// Load the original image
			BufferedImage originalImage = ImageIO.read(new File("D:\\temp\\test\\9070.jpg"));
			
			// Define the target dimensions for the profile image
			int targetWidth = 200;  // For example, a square profile image of 200x200 pixels
			int targetHeight = 200;
			
			// Resize the image
			BufferedImage profileImage = resizeImageWithAspectRatio(originalImage, targetWidth, targetHeight);
			
			// Save the resized image as a new file
			ImageIO.write(profileImage, "png", new File("D:\\temp\\test\\9070_gen.jpg"));
			System.out.println("Profile image created successfully!");
		} catch (IOException e) {
		    e.printStackTrace();
		}
	}
	
}
