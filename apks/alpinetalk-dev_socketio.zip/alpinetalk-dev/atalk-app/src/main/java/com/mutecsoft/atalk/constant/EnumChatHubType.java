package com.mutecsoft.atalk.constant;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public enum EnumChatHubType {

	ONE_TO_ONE("P"),		// 일대일 대화
	MULTI_USER("G");		// 멀티 대화방
	
	/////////////////////////////////////////////
	
	private final String value;
	
	EnumChatHubType(final String newValue) {
		value = newValue;
	}
	
	public String getValue(){
		return value;
	}
}
