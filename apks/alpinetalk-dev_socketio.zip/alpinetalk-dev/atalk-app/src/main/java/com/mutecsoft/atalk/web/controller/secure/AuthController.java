package com.mutecsoft.atalk.web.controller.secure;

import com.mutecsoft.atalk.logic.model.AtalkDataModelAll;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.logic.model.auth.UserResultResponse;
import com.mutecsoft.atalk.security.oauth2.model.CustomUserDetail;
import com.mutecsoft.atalk.service.AtalkUserService;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.JwtEncodingException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * @PackageName com.mutecsoft.atalk.web.controller.secure
 * @fileName	AuthController.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description :
 * <pre>
 * 
 * </pre>
 */
@Slf4j
@Tag(name="Authentication", description="Authentication API")
@Controller
@RequestMapping(value = "/api/v1/auth")
public class AuthController {
	
	@Autowired
	AtalkUserService atalkUserService;	
	
	/**
	 * 로그인
	 * 
	 * @param secureReqModel
	 * @return
	 */
	@PostMapping("/login")
	public ResponseEntity<?> login(
			@RequestBody SecureDataModel secureReqModel) {
		try {
			log.debug("################# LOGIN");
			Optional<AtalkDataModelAll> respOp = atalkUserService.login(secureReqModel);
			return new ResponseEntity<>(respOp.get().getSecureModel(), HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("@@@@ Unauthorized");
	}
	
	/**
	 * refresh token 
	 * 
	 * @param authToken
	 * @return
	 * @throws JwtEncodingException
	 * @throws Exception
	 */
	@PostMapping("/refresh")
	public ResponseEntity<?> refreshToken(
			@RequestBody SecureDataModel secureReqModel) {
		try {
			log.debug("################# LOGIN");
			Optional<AtalkDataModelAll> respOp = atalkUserService.refreshToken(secureReqModel);
			return new ResponseEntity<>(respOp.get().getSecureModel(), HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("@@@@ Unauthorized");
	}

	/**
	 * 임시 비밀번호 변경
	 * 
	 * @param userInf
	 * @return
	 * @throws Exception 
	 */
	@PostMapping("/changePassword")
	public ResponseEntity<?> changePassword(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @RequestBody SecureDataModel secureReqModel) {
		try {
			log.debug("################# CHANGE PASSWORD");
			Optional<AtalkDataModelAll> respOp = atalkUserService.changePassword(authUser, secureReqModel);
			return new ResponseEntity<>(respOp.get().getSecureModel(), HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("@@@@ Unauthorized");
	}
	
	/**
	 * 비밀번호 체크
	 * 
	 * @param authUser
	 * @param encPassword
	 * @param secureReqModel
	 * @return
	 */
	@PostMapping("/checkPassword/{encPassword}")
	public ResponseEntity<?> checkPassword(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @PathVariable("encPassword") String encPassword) {
		try {
			log.debug("################# CHECK PASSWORD");
			Optional<AtalkDataModelAll> respOp = atalkUserService.checkPassword(authUser, encPassword);
			return new ResponseEntity<>(respOp.get().getSecureModel(), HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("@@@@ Unauthorized");
	}

	/**
	 * 비밀번호 임시 발급
	 * 
	 * @param authUser
	 * @param encPassword
	 * @param secureReqModel
	 * @return
	 */
	@RequestMapping(value="/issueTempPassword/{userEmail}", method = {RequestMethod.POST, RequestMethod.GET})
	public ResponseEntity<?> issueTempPassword(
			@PathVariable("userEmail") String userEmail) {
		try {
			log.debug("################# CHECK PASSWORD");
			UserResultResponse respObj = atalkUserService.issuePassword(userEmail);
			return new ResponseEntity<>(respObj, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		UserResultResponse respObj = new UserResultResponse();
		respObj.setResult("FAIL");
		return new ResponseEntity<>(respObj, HttpStatus.OK);
	}
	
	/**
	 * 인증 이메일
	 * 
	 * @param userEmail
	 * @return
	 */
	@RequestMapping(value="/issueToken/{userEmail}", method = {RequestMethod.POST, RequestMethod.GET})
	public ResponseEntity<?> issueToken(
			@PathVariable("userEmail") String userEmail) {
		try {
			log.debug("################# AUTH EMAIL");
			UserResultResponse respObj = atalkUserService.authEmail(userEmail);
			return new ResponseEntity<>(respObj, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		UserResultResponse respObj = new UserResultResponse();
		respObj.setResult("FAIL");
		return new ResponseEntity<>(respObj, HttpStatus.OK);
	}
	
	/**
	 * 인증 토큰 확인
	 * 
	 * @param userEmail
	 * @param tokenValue
	 * @return
	 */
	@RequestMapping(value="/checkIssueToken/{userEmail}/{tokenValue}", method = {RequestMethod.POST, RequestMethod.GET})
	public ResponseEntity<?> checkIssueToken(
			@PathVariable("userEmail") String userEmail
			, @PathVariable("tokenValue") String tokenValue) {
		try {
			log.debug("################# AUTH TOKEN (VERIFY)");
			UserResultResponse respObj = atalkUserService.checkAuthToken(userEmail, tokenValue);
			return new ResponseEntity<>(respObj, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		UserResultResponse respObj = new UserResultResponse();
		respObj.setResult("FAIL");
		return new ResponseEntity<>(respObj, HttpStatus.OK);
	}
}

