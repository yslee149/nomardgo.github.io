package com.mutecsoft.atalk.service;

import com.mutecsoft.atalk.common.model.MUser;
import com.mutecsoft.atalk.logic.model.pf.PfAgreementResponse;
import com.mutecsoft.atalk.logic.model.response.AgreementResponse;

public interface AtalkPfServiceLogic {
	
	PfAgreementResponse getLatestPfAgreement() throws Exception;

	Long agree(MUser user, Long version) throws Exception;
	
	Long disagree(MUser user, Long version) throws Exception;
	
	AgreementResponse getHist(MUser user) throws Exception;
}

