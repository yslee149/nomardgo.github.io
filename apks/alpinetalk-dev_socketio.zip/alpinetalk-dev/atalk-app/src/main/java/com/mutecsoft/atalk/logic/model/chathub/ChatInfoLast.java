package com.mutecsoft.atalk.logic.model.chathub;

import java.io.Serializable;

/**
 * @PackageName com.mutecsoft.atalk.logic.model.chathub
 * @fileName	ChatInfoLast.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description : 마지막 대화 정보
 * <pre>
 * 
 * </pre>
 */
public class ChatInfoLast implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -245976247312274504L;

	private Long chatNo;	// 대화번호
	private String chatType;	// 대화타입
	private String chatSubType;	// 대화SUB타입
	
	private Long userNo;	// 작성자 번호
	private String userName;	// 작성자
	
	private Long unreadCnt; // 
	private Long userCount;	// 참여자명수
	
	private String regDt;	// 등록일시
	private String chatMessage;  // 대화방 목록 정보에 표시될 마지막 메시지
	public Long getChatNo() {
		return chatNo;
	}
	public void setChatNo(Long chatNo) {
		this.chatNo = chatNo;
	}
	public String getChatType() {
		return chatType;
	}
	public void setChatType(String chatType) {
		this.chatType = chatType;
	}
	public String getChatSubType() {
		return chatSubType;
	}
	public void setChatSubType(String chatSubType) {
		this.chatSubType = chatSubType;
	}
	public Long getUserNo() {
		return userNo;
	}
	public void setUserNo(Long userNo) {
		this.userNo = userNo;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Long getUnreadCnt() {
		return unreadCnt;
	}
	public void setUnreadCnt(Long unreadCnt) {
		this.unreadCnt = unreadCnt;
	}
	public Long getUserCount() {
		return userCount;
	}
	public void setUserCount(Long userCount) {
		this.userCount = userCount;
	}
	public String getRegDt() {
		return regDt;
	}
	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}
	public String getChatMessage() {
		return chatMessage;
	}
	public void setChatMessage(String chatMessage) {
		this.chatMessage = chatMessage;
	}
	
}

