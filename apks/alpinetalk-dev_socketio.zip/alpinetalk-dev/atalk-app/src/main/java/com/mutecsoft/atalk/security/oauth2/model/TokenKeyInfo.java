package com.mutecsoft.atalk.security.oauth2.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TokenKeyInfo {
	private Long jwtDurationMinutes;
	private String privateKeyPath;
	private String publicKeyPath;
}
