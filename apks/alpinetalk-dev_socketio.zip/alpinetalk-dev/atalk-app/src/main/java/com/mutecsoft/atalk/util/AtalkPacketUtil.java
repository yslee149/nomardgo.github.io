package com.mutecsoft.atalk.util;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mutecsoft.atalk.logic.model.AtalkPacketBase;

import lombok.extern.slf4j.Slf4j;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

@Slf4j
public class AtalkPacketUtil {
	
	static ObjectMapper objMapper = new ObjectMapper();

	/**
	 * invoke request
	 * 
	 * @param reqObj
	 * @return
	 * @throws Exception
	 */
	public static String
	requestAtalkMessage(Map<String, String> reqObj, String url) throws Exception {
		String url1 =	url;
		String responseJson = "";
		OkHttpClient client = new OkHttpClient().newBuilder()
				.connectTimeout(40, TimeUnit.SECONDS)  // Connection timeout
	            .readTimeout(40, TimeUnit.SECONDS)     // Read timeout
	            .writeTimeout(40, TimeUnit.SECONDS)    // Write timeout
	            .build();
		String json = objMapper.writeValueAsString(reqObj);
		MediaType jsonMediaType = MediaType.get("application/json; charset=utf-8");
		RequestBody body = RequestBody.Companion.create(json, jsonMediaType);
		
		Request request = new Request.Builder()
				.url(url1)
				.post(body)
				.build();
		try (Response response = client.newCall(request).execute()) {
			if (response.isSuccessful()) {
				responseJson = response.body().string();
			} else {
				log.error("Error: {}", response.code());
				log.error("@@@@@@@@@ ERR CASE 1");
			}
		} catch (Exception e) {
			log.error("@@@@@@@@@ ERR CASE 2 : {}", e);
		}
		return responseJson;
	}
	

	/**
	 * invoke request 인증없ㄴ이 요청
	 * 
	 * @param reqObj
	 * @return
	 * @throws Exception
	 */
	public static <R extends AtalkPacketBase> R
	requestAtalkMessageNoAuth(Class<R> retClass, String url) throws Exception {
		R responseData = null;
		String url1 =	url;
		log.info("############# 1. client -> server : send message");
		OkHttpClient client = new OkHttpClient().newBuilder()
				.connectTimeout(40, TimeUnit.SECONDS)  // Connection timeout
	            .readTimeout(40, TimeUnit.SECONDS)     // Read timeout
	            .writeTimeout(40, TimeUnit.SECONDS)    // Write timeout
	            .build();
		RequestBody emptyBody = RequestBody.create(new byte[0]);
		////////// ENCRYPT ACCESS TOKEN
		Request request = new Request.Builder()
				.url(url1)
				.post(emptyBody)
				.build();
		try (Response response = client.newCall(request).execute()) {
			if (response.isSuccessful()) {
				String responseJson = response.body().string();
				log.info("Response: http code : {}, value : {}", 
						response.code()
						, responseJson);
				log.info("### RESP DATA : {}",
						AtalkPacketBase.printAllFields(responseData));
				log.info("#### RESP JSON : {}", responseData.toJson());
				
			} else {
				log.error("Error: {}", response.code());
				log.error("@@@@@@@@@ ERR CASE 1");
			}
		} catch (Exception e) {
			log.error("@@@@@@@@@ ERR CASE 2 : {}", e);
		}
		return responseData;
	}
	}
