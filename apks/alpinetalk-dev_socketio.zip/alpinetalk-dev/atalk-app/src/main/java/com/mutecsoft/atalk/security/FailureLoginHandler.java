/*
 *  Copyright (c) [2024] CNU Global, Inc.
 *  All right reserved.
 *  This software is the confidential and proprietary information of DOUB
 *  , Inc. You shall not disclose such Confidential Information and
 *  shall use it only in accordance with the terms of the license agreement
 *  you entered into with CNU Global.
 *
 *  Revision History
 *  Date               Author         Description
 *  ------------------ -------------- ------------------
 * 
 */
package com.mutecsoft.atalk.security;

import java.io.IOException;

import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.CredentialsExpiredException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.InternalAuthenticationServiceException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mutecsoft.atalk.logic.model.response.LoginResponse;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;

/**
 * The type Failure login handler.
 */
@Slf4j
public class FailureLoginHandler implements AuthenticationFailureHandler {

    /**
     * On authentication failure.
     *
     * @param request  the request
     * @param response the response
     * @param e        the e
     * @throws IOException      the io exception
     * @throws ServletException the servlet exception
     */
    @Override
    public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response,
            AuthenticationException e) throws IOException, ServletException {

    	LoginResponse loginResponse = new LoginResponse();
		String remoteIp = request.getHeader("X-FORWARDED-FOR");
		if ( StringUtils.isBlank(remoteIp) ) { remoteIp = request.getRemoteAddr(); }
        
		//계정 암호가 틀렸을 때
		if(e instanceof BadCredentialsException) {
			log.debug("암호 틀림!");
//			loginResponse.setResultCode(CasError.NOT_FOUND_ERROR.getCode());
//			loginResponse.setResultMsg("message.incorrect.userInfo");
		} 
		//계정을 찾을 수 없을 때
		else if(e instanceof UsernameNotFoundException) {
			log.debug("계정 없음!");
//			loginResponse.setResultCode(CasError.NOT_FOUND_ERROR.getCode());
//			loginResponse.setResultMsg("message.incorrect.userInfo");
		} 
		//계정이 잠겼을 때
		else if(e instanceof LockedException) {
			log.debug("계정 잠김!");
		} 
		//계정이 비활성화 될 때
		else if(e instanceof DisabledException) {
			log.debug("계정 비활성화!");
		} 
		//인증 프로세스나 사용자 세부 정보 서비스에 내부 문제
		else if(e instanceof InternalAuthenticationServiceException) {
			log.debug("시스템 문제로 내부 인증 관련 처리 요청을 할 수 없습니다.");
		} 
		//사용자의 자격 증명(비밀번호)이 만료
		else if(e instanceof CredentialsExpiredException) {
			log.debug("인증 거부: 비밀번호 유효 기간 만료");
		} 
		
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonResponse = objectMapper.writeValueAsString(loginResponse);
        
        response.setStatus(HttpStatus.OK.value());
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(jsonResponse);
        response.getWriter().flush();
        response.getWriter().close();
    }
}
