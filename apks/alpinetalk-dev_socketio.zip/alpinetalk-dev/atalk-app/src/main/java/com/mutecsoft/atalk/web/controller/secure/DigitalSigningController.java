package com.mutecsoft.atalk.web.controller.secure;

import com.mutecsoft.atalk.logic.model.AtalkDataModelAll;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.logic.model.response.ResResult;
import com.mutecsoft.atalk.logic.util.RsaComplex;
import com.mutecsoft.atalk.service.DigitalSigningService;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;

import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.util.HashMap;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @PackageName com.mutecsoft.atalk.web.secure.secure
 * @fileName	DigitalSigningController.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description :
 * <pre>
 * 
 * </pre>
 */
@Slf4j
@Tag(name="Digital Signing", description="Digital Signing API(Packet Key determination)")
@Controller
@RequestMapping(value = "/api/v1/digitalSign")
public class DigitalSigningController {
	
	@Autowired
	DigitalSigningService digitalSigningService;
	
	HashMap<String, Object>	_keyMap = null;
	
	@PostConstruct
	private void init() throws NoSuchAlgorithmException, NoSuchProviderException {
		_keyMap = RsaComplex.getKeys(4096);
	}
	
	/**
	 * step 1. client -> server seed 값 전달
	 * 
	 * @param secureReqModel
	 * @return
	 */
	@PostMapping("/seedvalue")
	public ResponseEntity<?> seedvalue(
			@RequestBody SecureDataModel secureReqModel) {
		
		log.debug("#### transactionId : {}", secureReqModel.getTransactinId());
		log.debug("#### data : {}", secureReqModel.getData());
		String signingSeedValue = secureReqModel.getData();
		
		digitalSigningService.saveDigitalSigningSeed(signingSeedValue);
		ResResult res = ResResult.builder()
							.boolVal(Boolean.TRUE).build();
		return new ResponseEntity<>(res
				, HttpStatus.OK);
	}
	
	/**
	 * step 2. client -> server sign 요청 전달
	 * 
	 * @param secureReqModel
	 * @return
	 * @throws Exception 
	 */
	@PostMapping("/doSign")
	public ResponseEntity<?> doSign(
			@RequestBody SecureDataModel secureReqModel) throws Exception {
		log.debug("#### transactionId : {}", secureReqModel.getTransactinId());
		log.debug("#### data : {}", secureReqModel.getData());
		
		Optional<AtalkDataModelAll> resDataOp = digitalSigningService.doSign(secureReqModel);
		
		AtalkDataModelAll resData = resDataOp.orElseGet(() -> null);
		if (resData == null) {
			return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Uprocessable");
		}
		resData.getSecureModel().setTransactinId(secureReqModel.getTransactinId());
		return new ResponseEntity<>(resData.getSecureModel(), HttpStatus.OK);
	}
}
