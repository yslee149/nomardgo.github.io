package com.mutecsoft.atalk.security.oauth2.model;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;

/**
 * @PackageName com.cnu.cas.mdms.app.security.oauth2.model
 * @fileName	TokenKeysProperty.java
 * @author voyzer
 * @Date   2024. 10. 1
 * @description : token key 암복호화 키 정보
 * <pre>
 * 
 * </pre>
 */
@Getter
@Setter
@Configuration
@ConfigurationProperties("token-key")
public class TokenKeysProperty {
	private TokenKeyInfo accessToken;
	private TokenKeyInfo refreshToken;
	
	private TokenKeyInfo secureJwtToken;
}
