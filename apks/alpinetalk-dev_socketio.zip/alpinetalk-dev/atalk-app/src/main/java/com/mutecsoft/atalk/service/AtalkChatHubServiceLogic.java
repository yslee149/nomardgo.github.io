package com.mutecsoft.atalk.service;

import java.text.ParseException;
import java.util.List;

import org.apache.commons.lang3.tuple.Pair;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.mutecsoft.atalk.common.model.MChathub;
import com.mutecsoft.atalk.common.model.MUser;
import com.mutecsoft.atalk.logic.model.chathub.InviteChathubRequest;
import com.mutecsoft.atalk.logic.model.chathub.InviteChathubResponse;
import com.mutecsoft.atalk.logic.model.chathub.KickOutChathubResponse;
import com.mutecsoft.atalk.logic.model.chathub.ListChathubRequest;
import com.mutecsoft.atalk.logic.model.chathub.ListChathubResponse;
import com.mutecsoft.atalk.logic.model.chathub.OpenChathubRequest;
import com.mutecsoft.atalk.logic.model.chathub.OpenChathubResponse;
import com.mutecsoft.atalk.logic.model.chathub.OpenChathubWithTitleRequest;
import com.mutecsoft.atalk.logic.model.chathub.ChatHubListInfo;
import com.mutecsoft.atalk.logic.model.chathub.ChathubInfoRequest;
import com.mutecsoft.atalk.logic.model.chathub.ExitChathubResponse;

public interface AtalkChatHubServiceLogic {
	
	OpenChathubResponse openChathub(MUser user, OpenChathubRequest reqObj) throws Exception;
	OpenChathubResponse openChathubByAmigoSetNo(MUser user, Long amigoSetNo) throws Exception;
	
	ListChathubResponse listChathub(MUser user, ListChathubRequest reqObj) throws Exception;
	InviteChathubResponse invite(MUser user, InviteChathubRequest reqObj) throws Exception;
	KickOutChathubResponse forceExit(MUser user, Long chatHubNo, List<Long> userList) throws Exception;
	ExitChathubResponse exit(MUser user, Long chatHubN, String quietyYn) throws Exception;
	OpenChathubResponse info(MUser user, ChathubInfoRequest reqObj) throws Exception;
	OpenChathubResponse openChathubWithTitle(MUser user, OpenChathubWithTitleRequest reqObj) throws Exception;
	
	////////////////////////////
	
	String retrieveChatHubList(MUser user, String updateDt, List<ChatHubListInfo> chatHubListInfo)
			throws ParseException;
	
	Pair<MChathub, String> getChatHubInfo(Long myNo, List<Long> userNoList) throws JsonProcessingException;
	Pair<MChathub, String> getChatHubInfo2(Long myNo, ChathubInfoRequest reqObj) throws JsonProcessingException;
	MChathub inviteChatHub(Long myNo, InviteChathubRequest reqObj, String userNameList) throws JsonProcessingException;

}
