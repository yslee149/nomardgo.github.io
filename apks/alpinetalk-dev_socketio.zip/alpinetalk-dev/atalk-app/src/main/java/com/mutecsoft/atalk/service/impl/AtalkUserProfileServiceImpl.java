package com.mutecsoft.atalk.service.impl;

import java.text.SimpleDateFormat;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.mutecsoft.atalk.common.model.MUser;
import com.mutecsoft.atalk.common.repository.MUserProfileRepository;
import com.mutecsoft.atalk.common.repository.MUserRepository;
import com.mutecsoft.atalk.component.PacketDecryptor;
import com.mutecsoft.atalk.component.redis.RedisTaskBroker;
import com.mutecsoft.atalk.config.AtalkConfig;
import com.mutecsoft.atalk.config.AuthTokenGenerator;
import com.mutecsoft.atalk.config.CustomAuthenticationProvider;
import com.mutecsoft.atalk.constant.EnumProfileType;
import com.mutecsoft.atalk.logic.model.AtalkDataModelAll;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.logic.model.user.SearchUserResponse;
import com.mutecsoft.atalk.logic.util.RandomHexString;
import com.mutecsoft.atalk.secure.model.redis.RedisPacketKeySeed;
import com.mutecsoft.atalk.security.oauth2.model.CustomUserDetail;
import com.mutecsoft.atalk.service.AtalkUserProfileService;
import com.mutecsoft.atalk.service.AtalkUserProfileServiceLogic;
import com.mutecsoft.atalk.service.UserAccountService;

import jakarta.annotation.PostConstruct;
import jakarta.servlet.ServletContext;
import lombok.extern.slf4j.Slf4j;

/**
 * 사용자 프로필 서비스
 * 
 */
@Slf4j
@Service("atalkUserProfileService")
public class AtalkUserProfileServiceImpl implements AtalkUserProfileService {

	@Autowired
	MUserProfileRepository mUserProfileRepository;

	@Autowired
	MUserRepository mUserRepository;
	
	@Autowired
	UserAccountService userAccountService;
	
	@Autowired
	RedisTaskBroker redisTaskBroker;
	
	@Autowired
	PacketDecryptor packetDecryptor;
	
	@Autowired
	DaoAuthenticationProvider daoAuthenticationProvider;

	@Autowired
	AuthTokenGenerator authTokenGenerator;
	
	@Autowired
	CustomAuthenticationProvider customAuthenticationProvider;
	
	@Autowired
	AtalkConfig  atalkConfig;
	
	@Autowired
	ServletContext servletContext;

	SimpleDateFormat dateFormatter;

	SimpleDateFormat dateFormatterForFilePath;
	
	@Autowired
	AtalkUserProfileServiceLogic atalkUserProfileServiceLogic; 
	
	@PostConstruct
	private void init() {
		dateFormatter = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		dateFormatterForFilePath = new SimpleDateFormat("yyyy/MM/dd");
	}

	@Override
	public Optional<AtalkDataModelAll> updateProfileImage(SecureDataModel secModel, CustomUserDetail authUser,
			EnumProfileType profileType, MultipartFile file) throws Exception {
		
		String signatureDataAll = secModel.getData();
		/////////////////////////////////
		String secData = signatureDataAll.substring(
				0,
				signatureDataAll.length() - SecureDataModel.KEY_SEED_SIZE);
		
		String packetKeySeedValue = signatureDataAll.substring(
		signatureDataAll.length() - SecureDataModel.KEY_SEED_SIZE);
		log.debug("#### packetKeySeedValue : {}", packetKeySeedValue);
		
		/////////////////////////////////
		RedisPacketKeySeed redisKeyObj = redisTaskBroker.findKeySeedData(packetKeySeedValue);
		
		if (!redisKeyObj.getActiveYn().equals("Y")) {
			AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
			.httpStatusCode(425)
			.atalkPacketBase(null)
			.secureModel(null)
			.build();
			return Optional.ofNullable(resultObj);
		}
		////////////////////// GET PACKET KEY
		log.debug("#### redisKeyObj : {}", redisKeyObj);
		String packetKey = redisKeyObj.getPacketKey();
		MUser user = userAccountService.getUserByUserId(authUser.getUserId());
		
		SearchUserResponse respObj = atalkUserProfileServiceLogic.updateProfileImage(user, profileType, file);
		if (respObj == null) {
			return Optional.of(null);
		}
		///////////////////////// RESPONSE /////////////////////////////////////////////////////
		AtalkDataModelAll resData = AtalkDataModelAll.builder()
				.httpStatusCode(200)
				.atalkPacketBase(respObj)
				.secureModel(respObj.toFinalModel(packetKey))
				.build();
		resData.getSecureModel().setTransactinId(RandomHexString.genSecureRandomHex(16));
		return Optional.of(resData);
	}
}
