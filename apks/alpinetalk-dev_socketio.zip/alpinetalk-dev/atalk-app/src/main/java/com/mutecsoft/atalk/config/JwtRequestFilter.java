package com.mutecsoft.atalk.config;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtException;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;

import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.time.Instant;
import java.util.Collections;

@Slf4j
public class JwtRequestFilter extends OncePerRequestFilter {
//
//	@Autowired
//	private UserDetailsService userDetailsService;
//	

	private final JwtDecoder accessTokenDecoder;
	private final JwtDecoder refreshTokenDecoder;
	private final KeyUtils keyUtils;
	
	public JwtRequestFilter(JwtDecoder accessTokenDecoder, JwtDecoder refreshTokenDecoder, KeyUtils keyUtils) {
		this.accessTokenDecoder = accessTokenDecoder;
		this.refreshTokenDecoder = refreshTokenDecoder;
		this.keyUtils = keyUtils;
	}
//    public JwtRequestFilter(JwtDecoder accessTokenDecoder, JwtDecoder refreshTokenDecoder) {
//        this.accessTokenDecoder = accessTokenDecoder;
//        this.refreshTokenDecoder = refreshTokenDecoder;
//    }
	
//	@Autowired
//	private JwtUtils jwtUtil;

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		String token = extractToken(request);
	    
		log.debug("#### request uri : {}", request.getRequestURI());
		if (
			request.getRequestURI().contains("/api/v1/auth/login")
			|| request.getRequestURI().contains("/api/v1/auth/issueTempPassword")
			|| request.getRequestURI().contains("/api/v1/auth/issueToken")
			|| request.getRequestURI().contains("/api/v1/auth/checkIssueToken")
			|| request.getRequestURI().contains("/api/v1/profile/thumb")
			|| request.getRequestURI().contains("/api/v1/profile/view")
			|| request.getRequestURI().contains("/api/v1/user/checkDupAccount")
			
			|| request.getRequestURI().contains("/api/v1/auth/getUserId")
			|| request.getRequestURI().contains("/api/v1/auth/refresh")
			
			|| request.getRequestURI().contains("/api/v1/pi/getLatest")
			|| request.getRequestURI().contains("/api/v1/pf/getLatest")
			|| request.getRequestURI().contains("/api/v1/si/getLatest")

			|| request.getRequestURI().contains("/api/v1/pi/getLatestContent")
			|| request.getRequestURI().contains("/api/v1/pf/getLatestContent")
			|| request.getRequestURI().contains("/api/v1/si/getLatestContent")
			
			|| request.getRequestURI().contains("/api/v1/digitalSign")
			|| request.getRequestURI().contains("/api/v1/user/signup")
			|| request.getRequestURI().contains("/api/v1/user/deleteUserTest")
			|| request.getRequestURI().contains("/api/v1/svcctrl/resetAll")
			|| request.getRequestURI().contains("/api/v1/search/noauth/userId")
			
			|| request.getRequestURI().contains("/api/v1/chat/get")
		) {
			
			filterChain.doFilter(request, response);
			return;
		}
		if (
			request.getRequestURI().contains("/api/plain/v1/auth/login")
			|| request.getRequestURI().contains("/api/plain/v1/auth/issueTempPassword")
			|| request.getRequestURI().contains("/api/plain/v1/auth/issueToken")
			|| request.getRequestURI().contains("/api/plain/v1/auth/checkIssueToken")
			|| request.getRequestURI().contains("/api/plain/v1/user/checkDupAccount")
			|| request.getRequestURI().contains("/api/plain/v1/profile/thumb")
			|| request.getRequestURI().contains("/api/plain/v1/profile/view")
			
			|| request.getRequestURI().contains("/api/plain/v1/auth/getUserId")
			|| request.getRequestURI().contains("/api/plain/v1/auth/refresh")
			
			|| request.getRequestURI().contains("/api/v1/digitalSign")
			|| request.getRequestURI().contains("/api/v1/user/signup")

			|| request.getRequestURI().contains("/api/plain/v1/pi/getLatest")
			|| request.getRequestURI().contains("/api/plain/v1/pf/getLatest")
			|| request.getRequestURI().contains("/api/plain/v1/si/getLatest")
			
			|| request.getRequestURI().contains("/api/plain/v1/pi/getLatestContent")
			|| request.getRequestURI().contains("/api/plain/v1/pf/getLatestContent")
			|| request.getRequestURI().contains("/api/plain/v1/si/getLatestContent")
			
			|| request.getRequestURI().contains("/api/v1/chat/fileNoAuth")
			
			|| request.getRequestURI().contains("/api/v1/user/deleteUserTest")
			|| request.getRequestURI().contains("/api/v1/svcctrl/resetAll")
			|| request.getRequestURI().contains("/api/v1/search/noauth/userId")
			
			|| request.getRequestURI().contains("/api/plain/v1/chat/get")
				
				) {
			filterChain.doFilter(request, response);
			return;
		}
		try {
			// Assume the presence of a refresh token based on URL or some criteria
			if (isRefreshTokenRequest(request)) {
				Authentication authentication = getAuthentication(token, refreshTokenDecoder);
				SecurityContextHolder.getContext().setAuthentication(authentication);
			} else {
				Authentication authentication = getAuthentication(token, accessTokenDecoder);
				SecurityContextHolder.getContext().setAuthentication(authentication);
			}
		} catch (Exception e) {
			// Handle invalid token scenario
			response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			return;
		}
		filterChain.doFilter(request, response);
	    /*
	        
	        // Extract the Authorization header
	        final String authorizationHeader = request.getHeader("Authorization");
	
	        String username = null;
	        String jwt = null;
	
	        // Check if Authorization header is present and starts with Bearer
	        if (authorizationHeader != null && authorizationHeader.startsWith("Bearer ")) {
	        	String token = authorizationHeader.substring(7);
	            try {
	                // Validate and parse the token (use your JWT validation logic here)
	                if (validateJwtToken(token)) {
	                    // Set the Authentication object in the SecurityContext
	                    SecurityContextHolder.getContext().setAuthentication(getAuthenticationFromToken(token));
	                }
	            } catch (Exception e) {
	                // JWT validation failed, handle it here (optional logging, etc.)
	                System.out.println("JWT token validation failed: " + e.getMessage());
	            }
	        }
	
	        // Validate the token and set the authentication in the context if it's valid
	        if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
	
	            // Load user details from the database
	            UserDetails userDetails = this.userDetailsService.loadUserByUsername(username);
	
	            // Validate the token with the extracted user details
	//            if (jwtUtil.validateToken(jwt, userDetails)) {
	//
	//                // If valid, create an authentication token and set it in the context
	//                UsernamePasswordAuthenticationToken authenticationToken =
	//                        new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
	//
	//                authenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
	//
	//                // Set authentication in the context
	//                SecurityContextHolder.getContext().setAuthentication(authenticationToken);
	//            }
	        }
	
	        // Continue the request
	        filterChain.doFilter(request, response);
	        */
	}
	

    private boolean isRefreshTokenRequest(HttpServletRequest request) {
        // Implement your logic to determine if the token is a refresh token
        // For example, based on the URL pattern or request headers
        return request.getRequestURI().contains("/refresh"); // Example based on URL
    }

    private String extractToken(HttpServletRequest request) {
        // Extract token from the Authorization header
        String bearerToken = request.getHeader("Authorization");
        if (bearerToken != null && bearerToken.startsWith("Bearer ")) {
            return bearerToken.substring(7);
        }
        return null;
    }

    private Authentication getAuthentication(String encToken, JwtDecoder jwtDecoder) throws Exception {
        // Decode and validate the token using the appropriate decoder
    	
//    	EncryptedJWT encryptedJWT = EncryptedJWT.parse(encToken);
//    	RSADecrypter decrypter = new RSADecrypter(keyUtils.getSecureTokenPrivateKey());
//    	
//    	encryptedJWT.decrypt(decrypter);
//    	JWTClaimsSet jwtClaimSet = encryptedJWT.getJWTClaimsSet();
    	
//		//////////// DECRYPT JWT TOKEN ONE MORE 
//		// Parse the signed token into a SignedJWT object
//		SignedJWT signedJWT = SignedJWT.parse(signedToken);
//		// Example RSA public key for encryption (you need to use your actual key)
//		RSAPublicKey publicKey = keyUtils.getSecureTokenPublicKey();
//		// Create the JWE header
//		JWEHeader jweHeader = new JWEHeader(
//				JWEAlgorithm.RSA_OAEP_256
//				, EncryptionMethod.A128GCM);
//		// Create the Encrypted JWT (using the signed JWT's payload)
//		EncryptedJWT encryptedJWT = new EncryptedJWT(jweHeader, signedJWT.getJWTClaimsSet());
//		// Encrypt the signed JWT with the public key
//		RSAEncrypter encrypter = new RSAEncrypter(publicKey);
//		encryptedJWT.encrypt(encrypter);
//		// Get the final encrypted token
//		String finalEncryptedToken = encryptedJWT.serialize();
//		////////////ENCRYPT JWT TOKEN
    	
        Jwt jwt = jwtDecoder.decode(encToken);

        Instant expiredInst = jwt.getExpiresAt();
		Instant now = Instant.now();
		
		if (now.isBefore(expiredInst)) {
			return new JwtAuthenticationToken(jwt, Collections.EMPTY_LIST);
		} else {
			throw new JwtException("Token expired");
		}
    }
	
	
    private boolean validateJwtToken(String token) {
        // Implement your JWT token validation logic here (e.g., using jjwt)
    	
    	
        return true; // Placeholder for actual validation
    }

    private Authentication getAuthenticationFromToken(String token) {
        // Extract user details from token and create an Authentication object
        // Return an instance of a valid Authentication implementation
        return null; // Placeholder for actual implementation
    }
	
}

