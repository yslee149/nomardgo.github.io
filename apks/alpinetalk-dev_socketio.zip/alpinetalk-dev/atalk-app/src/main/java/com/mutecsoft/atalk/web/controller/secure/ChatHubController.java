package com.mutecsoft.atalk.web.controller.secure;

import com.mutecsoft.atalk.logic.model.AtalkDataModelAll;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.security.oauth2.model.CustomUserDetail;
import com.mutecsoft.atalk.service.AtalkChatHubService;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @PackageName com.mutecsoft.atalk.web.controller.secure
 * @fileName	ChatHubController.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description :
 * <pre>
 * 
 * </pre>
 */
@Slf4j
@Tag(name="ChatHub", description="ChatHub API")
@Controller
@RequestMapping(value = "/api/v1/chatHub")
public class ChatHubController {

	@Autowired
	AtalkChatHubService atalkChatHubService;
	
	/**
	 * 대화방 오픈
	 * 
	 * @param authUser
	 * @param secureReqModel
	 * @return
	 */
	@PostMapping("/openChathub")
	public ResponseEntity<?> openChathub(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @RequestBody SecureDataModel secureReqModel) {
		try {
			log.debug("################# OPEN CHATHUB");
			Optional<AtalkDataModelAll> respOp = atalkChatHubService.openChathub(authUser, secureReqModel);
			return new ResponseEntity<>(respOp.get().getSecureModel(), HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
	
	/**
	 * 대화방 오픈 그룹아이디로
	 * 
	 * @param authUser
	 * @param secureReqModel
	 * @return
	 */
	@PostMapping("/openChathub/{amigoSetNo}")
	public ResponseEntity<?> openChathub(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @PathVariable("amigoSetNo") Long amigoSetNo) {
		try {
			log.debug("################# OPEN CHATHUB by amigoSetNo");
			Optional<AtalkDataModelAll> respOp = atalkChatHubService.openChathubByAmigoSetNo(authUser, amigoSetNo);
			return new ResponseEntity<>(respOp.get().getSecureModel(), HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
	
	/**
	 * 대화방 오픈
	 * 
	 * @param authUser
	 * @param secureReqModel
	 * @return
	 */
	@PostMapping("/openChathubWithTitle")
	public ResponseEntity<?> openChathubWithTitle(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @RequestBody SecureDataModel secureReqModel) {
		try {
			log.debug("################# OPEN CHATHUB");
			Optional<AtalkDataModelAll> respOp = atalkChatHubService.openChathubWithTitle(authUser, secureReqModel);
			return new ResponseEntity<>(respOp.get().getSecureModel(), HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
	
	/**
	 * 대화방 목록 정보 처리
	 * 
	 * @param authUser
	 * @param secureReqModel
	 * @return
	 */
	@PostMapping("/list")
	public ResponseEntity<?> list(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @RequestBody SecureDataModel secureReqModel) {
		try {
			log.debug("################# GET CHATHUB INFO LIST");
			Optional<AtalkDataModelAll> respOp = atalkChatHubService.listChathub(authUser, secureReqModel);
			return new ResponseEntity<>(respOp.get().getSecureModel(), HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}

	/**
	 * 대화방 초대
	 * 
	 * @param authUser
	 * @param secureReqModel
	 * @return
	 */
	@PostMapping("/invite")
	public ResponseEntity<?> invite(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @RequestBody SecureDataModel secureReqModel) {
		try {
			log.debug("################# INVITE USERS TO CHATHUB");
			Optional<AtalkDataModelAll> respOp = atalkChatHubService.invite(authUser, secureReqModel);
			return new ResponseEntity<>(respOp.get().getSecureModel(), HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
	
	/**
	 * 대화방 강퇴
	 * 
	 * @param authUser
	 * @param secureReqModel
	 * @return
	 */
	@PostMapping("/forceExit/{chatHubNo}/{userNoList}")
	public ResponseEntity<?> forceExit(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @PathVariable("chatHubNo") Long chatHubNo
			, @PathVariable("userNoList") List<Long> userNoList
			) {
		try {
			log.debug("################# FORCE EXIT USERS");
			Optional<AtalkDataModelAll> respOp = atalkChatHubService.forceExit(authUser, chatHubNo, userNoList);
			return new ResponseEntity<>(respOp.get().getSecureModel(), HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}

	/**
	 * 대화방 나감
	 * 
	 * @param authUser
	 * @param secureReqModel
	 * @return
	 */
	@PostMapping("/exit/{chathubNo}/{exitQuietly}")
	public ResponseEntity<?> exit(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @PathVariable("chathubNo") Long chathubNo
			, @PathVariable("exitQuietly") String exitQuietly) {
		try {
			log.debug("################# EXIT USER");
			Optional<AtalkDataModelAll> respOp = atalkChatHubService.exit(authUser, chathubNo, exitQuietly);
			return new ResponseEntity<>(respOp.get().getSecureModel(), HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
	
	/**
	 * 대화방 정보
	 * 
	 * @param authUser
	 * @param secureReqModel
	 * @return
	 */
	@PostMapping("/info")
	public ResponseEntity<?> info(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @RequestBody SecureDataModel secureReqModel) {
		try {
			log.debug("################# INFO");
			Optional<AtalkDataModelAll> respOp = atalkChatHubService.info(authUser, secureReqModel);
			return new ResponseEntity<>(respOp.get().getSecureModel(), HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
}
