package com.mutecsoft.atalk.model.presentation;

import org.springframework.hateoas.Links;
import org.springframework.hateoas.RepresentationModel;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class ResBasicRepresentationModel<T extends ResBasicRepresentationModel<T>> extends RepresentationModel<T> {
    @JsonIgnore
    @Override
    public Links getLinks() {
        return super.getLinks();
    }
}
