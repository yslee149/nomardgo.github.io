package com.mutecsoft.atalk.logic.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Base64;
import java.util.Random;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * @PackageName 
 * @fileName	BufferComplex.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description : 
 * <pre>
 * 
 * </pre>
 */
public class BufferComplex {

	/**
	 * byte to hex ascii
	 * 
	 * @param bytes
	 * @return
	 */
	public static String bytesToHex(byte[] bytes) {
		StringBuilder hexBuilder = new StringBuilder();
		for (byte b : bytes) {
			hexBuilder.append(String.format("%02X", b));
		}
		return hexBuilder.toString();
	}

	/**
	 * 
	 * @param hex
	 * @return
	 */
	public static byte[] hexToBytes(String hex) {
		int len = hex.length();
		byte[] data = new byte[len / 2];
		for (int i = 0; i < len; i += 2) {
			data[i / 2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4)
					+ Character.digit(hex.charAt(i + 1), 16));
		}
		return data;
	}
	
	public static int sumHexDigits(String hexString) {
		int sum = 0;
		for (char hexChar : hexString.toCharArray()) {
			sum += Character.digit(hexChar, 16);
		}
		return sum;
	}

	/**
	 * 
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public static String compressAndEncode(String data) throws Exception {
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		try (GZIPOutputStream gzipOutputStream = new GZIPOutputStream(byteArrayOutputStream)) {
			gzipOutputStream.write(data.getBytes("UTF-8"));
		}
		byte[] compressedData = byteArrayOutputStream.toByteArray();
		return Base64.getEncoder().encodeToString(compressedData);
	}

	/**
	 * 
	 * @param base64Data
	 * @return
	 * @throws Exception
	 */
	public static String decodeAndDecompress(String base64Data) throws Exception {
		byte[] compressedData = Base64.getDecoder().decode(base64Data);
		try (GZIPInputStream gzipInputStream = new GZIPInputStream(new ByteArrayInputStream(compressedData))) {
			return new String(gzipInputStream.readAllBytes(), "UTF-8");
		}
	}
    
	/**
	 * 
	 * @param filePathString
	 * @return
	 */
	public static Object [] getFileDataAndFileName(String filePathString) {
		Object [] retArr = new Object[2];
		Path filePath = Paths.get(filePathString);
		try {
			byte[] fileBytes = Files.readAllBytes(filePath);
			retArr[0] = fileBytes;
			retArr[1] = filePath.getFileName().toString();
		} catch (IOException e) {
			return null;
		}
		return retArr;
	}
    
	/**
	 * 
	 * @param bytes
	 * @return
	 */
	public static String convertBytesToReadableSize(long bytes) {
		if (bytes < 1024) {
			return bytes + " B";
		} else if (bytes < 1024 * 1024) {
			return String.format("%.2f KB", bytes / 1024.0);
		} else if (bytes < 1024 * 1024 * 1024) {
			return String.format("%.2f MB", bytes / (1024.0 * 1024));
		} else {
			return String.format("%.2f GB", bytes / (1024.0 * 1024 * 1024));
		}
	}

	public static byte[] getLastNBytes(byte[] source, int n) {
		if (source == null || n < 0 || n > source.length) {
			throw new IllegalArgumentException("Invalid array or size");
		}
		byte[] buffer = new byte[n];
		System.arraycopy(source, source.length - n, buffer, 0, n);
		return buffer;
	}
	
	public static byte[] getFrontBytes(byte[] source, int length) {
		if (source == null || length < 0 || length > source.length) {
			throw new IllegalArgumentException("Invalid length for front buffer");
		}

		byte[] buffer = new byte[length];
		System.arraycopy(source, 0, buffer, 0, length);
		return buffer;
	}
    
	public static byte[] getMiddleBytes(byte[] source, int start, int length) {
		if (source == null || start < 0 || length < 0 || start + length > source.length) {
			throw new IllegalArgumentException("Invalid start index or length");
		}

		byte[] buffer = new byte[length];
		System.arraycopy(source, start, buffer, 0, length);
		return buffer;
	}
	public static int safeLongToInt(long value) {
		if (value > Integer.MAX_VALUE || value < Integer.MIN_VALUE) {
			throw new IllegalArgumentException("Long value is out of int range");
		}
		return (int) value;
	}

	public static byte[] appendBytes(byte[] originalBuffer, byte[] additionalBytes) {
		if (originalBuffer == null || additionalBytes == null) {
			throw new IllegalArgumentException("Buffers cannot be null");
		}
		byte[] combinedBuffer = new byte[originalBuffer.length + additionalBytes.length];
		System.arraycopy(originalBuffer, 0, combinedBuffer, 0, originalBuffer.length);
		System.arraycopy(additionalBytes, 0, combinedBuffer, originalBuffer.length, additionalBytes.length);
		return combinedBuffer;
	}
	
	public static byte[] appendBytesMore(byte[] originalBuffer, byte[]... additionalBytes) {
		try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
			outputStream.write(originalBuffer);
			for (byte[] bytes : additionalBytes) {
				outputStream.write(bytes);
			}
			return outputStream.toByteArray();
		} catch (IOException e) {
			return null;
		}
	}

	public static String generateRandomAscii(int length) {
		Random random = new Random();
		StringBuilder result = new StringBuilder(length);
        // Generate random ASCII characters (32 to 126, inclusive)
		for (int i = 0; i < length; i++) {
			int randomAscii = 32 + random.nextInt(95); // ASCII range 32 to 126
			result.append((char) randomAscii);
		}
		return result.toString();
	}
    
	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		{
			byte[] buffer = {10, 32, 45, 55, 127, -128, -1};  // Example byte array
			String hexString = bytesToHex(buffer);
			System.out.println("Hexadecimal ASCII String: " + hexString);
		}
	}


}
