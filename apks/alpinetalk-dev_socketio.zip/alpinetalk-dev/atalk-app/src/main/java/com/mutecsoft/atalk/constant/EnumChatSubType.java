package com.mutecsoft.atalk.constant;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public enum EnumChatSubType {

	// NO SUB TYPE
	MESSAGE_SUB_GENERAL_TYPE("C"),
	
	// file type
	MESSAGE_SUB_IMAGE_TYPE("I"),
	MESSAGE_SUB_MOVIE_TYPE("V"),
	MESSAGE_SUB_GENFILE_TYPE("F"),
	MESSAGE_SUB_DECUMENT_TYPE("D"),
	
	// info message
	MESSAGE_SUB_NEW_CHATHUB_OPEN_TYPE("N"),				// 신규 OPEN
	MESSAGE_SUB_INVITE_TO_CHATHUB_TYPE("J"),			// 초대
	MESSAGE_SUB_FORCE_EXIT_TO_CHATHUB_TYPE("F"),		// 강퇴
	MESSAGE_SUB_EXIT_TO_CHATHUB_TYPE("E");				// 스스로 나감
	
	private final String value;
	
	EnumChatSubType(final String newValue) {
		value = newValue;
	}
	
	public String getValue(){
		return value;
	}
	
	public static EnumChatSubType fromSubValue(String value) {
		EnumChatSubType retT = null;
		EnumChatSubType [] subTypeList = EnumChatSubType.values();
		for (EnumChatSubType t : subTypeList) {
			if (value.equals(t.getValue())) {
				retT = t;
				break;
			}
		}
		return retT;
	}
}

