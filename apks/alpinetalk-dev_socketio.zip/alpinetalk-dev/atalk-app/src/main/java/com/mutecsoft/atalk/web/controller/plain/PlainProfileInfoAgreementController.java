package com.mutecsoft.atalk.web.controller.plain;

import com.mutecsoft.atalk.common.repository.MAgreementHistRepository;
import com.mutecsoft.atalk.logic.model.auth.UserResultResponse;
import com.mutecsoft.atalk.logic.model.pf.PfAgreementResponse;
import com.mutecsoft.atalk.logic.model.response.AgreementResponse;
import com.mutecsoft.atalk.security.oauth2.model.CustomUserDetail;
import com.mutecsoft.atalk.service.AtalkPfServiceLogic;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.view.RedirectView;

/**
 * @PackageName com.mutecsoft.atalk.web.controller.plain
 * @fileName	PlainProfileInfoAgreementController2.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description :
 * <pre>
 * 
 * </pre>
 */
@Slf4j
@Tag(name="Profile Info agreement", description="Profile Info Agreement API(Plain)")
@Controller
@RequestMapping(value = "/api/plain/v1/pf")
public class PlainProfileInfoAgreementController {
	
	@Autowired
	AtalkPfServiceLogic atalkPfServiceLogic;

	@Autowired
	MAgreementHistRepository   mAgreementHistRepository;

	/**
	 * 최근 버전 개인정보 이용약관
	 * 
	 * @return
	 */
	@GetMapping(value = "/getLatest")
	public ResponseEntity<?> getLatest() {
		try {
			log.debug("################# GET profile Info usage agreement");
			PfAgreementResponse respOp = atalkPfServiceLogic.getLatestPfAgreement();
			return new ResponseEntity<>(respOp, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
	
	/**
	 * 최근 버전 개인정보 이용약관
	 * 
	 * @return
	 * @throws IOException 
	 */
	@GetMapping(value = "/getLatestContent")
	public ResponseEntity<String> getLatestContent() throws IOException {
		Resource resource = new ClassPathResource("static/pfagree.html");

		Path path = resource.getFile().toPath();
		String content = Files.readString(path, StandardCharsets.UTF_8);

		HttpHeaders headers = new HttpHeaders();
		headers.add(HttpHeaders.CONTENT_TYPE, "text/html; charset=UTF-8");

		return new ResponseEntity<>(content, headers, HttpStatus.OK);
	}
	
	
	/**
	 * 최근 버전 개인정보 이용약관
	 * 
	 * @return
	 */
	@PostMapping(value = "/agree/{versionNo}")
	public ResponseEntity<?> agree(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @PathVariable("versionNo") Long versionNo
			) {
		try {
			log.debug("#### agree");
			Long version = atalkPfServiceLogic.agree(authUser.getMUser(), versionNo);
			UserResultResponse respOp = new UserResultResponse();
			respOp.setResult(version.intValue() > 0 ? "SUCCESS": "FAIL");
			return new ResponseEntity<>(respOp, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
	
	/**
	 * 최근 버전 개인정보 이용약관 동의안함.
	 * 
	 * @return
	 */
	@RequestMapping(value = "/disagree/{versionNo}", method = {RequestMethod.POST, RequestMethod.GET})
	public ResponseEntity<?> disagree(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @PathVariable("versionNo") Long versionNo
			) {
		try {
			log.debug("#### disagree");
			Long version = atalkPfServiceLogic.disagree(authUser.getMUser(), versionNo);
			UserResultResponse respOp = new UserResultResponse();
			respOp.setResult(version.intValue() > 0 ? "SUCCESS": "FAIL");
			return new ResponseEntity<>(respOp, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
	
	/**
	 * 이력 정보
	 * 
	 * @return
	 */
	@RequestMapping(value = "/hist", method = {RequestMethod.POST, RequestMethod.GET})
	public ResponseEntity<?> myHist(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			) {
		try {
			AgreementResponse respOp = atalkPfServiceLogic.getHist(authUser.getMUser());
			return new ResponseEntity<>(respOp, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
}
