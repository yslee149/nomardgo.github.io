/*
 *  Copyright (c) 2024 CNU Global, Inc.
 *  All right reserved.
 *  This software is the confidential and proprietary information of DOUB
 *  , Inc. You shall not disclose such Confidential Information and
 *  shall use it only in accordance with the terms of the license agreement
 *  you entered into with CNU Global.
 *
 *  Revision History
 *  Date               Author         Description
 *  ------------------ -------------- ------------------
 *  2024. 8. 12.	   Hong Seok Woo  
 */
package com.mutecsoft.atalk.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.mutecsoft.atalk.common.model.MAmigo;
import com.mutecsoft.atalk.common.model.MAmigoSet;
import com.mutecsoft.atalk.common.model.MUser;
import com.mutecsoft.atalk.common.repository.MAmigoRepository;
import com.mutecsoft.atalk.common.repository.MAmigoSetRepository;
import com.mutecsoft.atalk.common.repository.MUserRepository;
import com.mutecsoft.atalk.logic.model.amigo.Amigo;
import com.mutecsoft.atalk.logic.model.amigoset.AddAmigoSetRequest;
import com.mutecsoft.atalk.logic.model.amigoset.AddAmigoSetResponse;
import com.mutecsoft.atalk.logic.model.amigoset.AmigoSet;
import com.mutecsoft.atalk.logic.model.amigoset.AmigoSetListResponse;
import com.mutecsoft.atalk.logic.model.amigoset.DeleteAmigoSetRequest;
import com.mutecsoft.atalk.logic.model.amigoset.DeleteAmigoSetResponse;
import com.mutecsoft.atalk.logic.model.amigoset.RenameAmigoSetRequest;
import com.mutecsoft.atalk.logic.model.amigoset.RenameAmigoSetResponse;
import com.mutecsoft.atalk.service.AtalkAmigoSetServiceLogic;
import com.mutecsoft.atalk.service.UserAccountService;

import lombok.extern.slf4j.Slf4j;

/**
 * 친구그룹 서비스
 * 
 */
@Slf4j
@Service("atalkAmigoSetServiceLogic")
public class AtalkAmigoSetServiceLogicImpl implements AtalkAmigoSetServiceLogic {

	@Autowired
	MUserRepository mUserRepository;
	
	@Autowired
	MAmigoSetRepository mAmigoSetRepository;

	@Autowired
	MAmigoRepository mAmigoRepository;
	
	@Autowired
	UserAccountService userAccountService;
	
	@Override
	public AddAmigoSetResponse addAmigoSet(MUser user, AddAmigoSetRequest reqObj)
			throws Exception {
		log.debug("################# ADD AMIGO SET");
	
		String amigoName = reqObj.getAmigoSetName();
		String displayYn = reqObj.getDisplayYn();
		if (amigoName.trim().isEmpty()) {
			return null;
		}
		Optional<List<MAmigoSet>> amigoSetList= mAmigoSetRepository.findByUserNoAndAmigoSetName(user.getUserNo(), amigoName);
		Optional<MAmigoSet> mAmigoSetObjOp = null;
		if (amigoSetList.isPresent() && amigoSetList.get().size() > 0) {
			mAmigoSetObjOp = Optional.of(amigoSetList.get().get(0));
		} else {
			mAmigoSetRepository.insertAmigoSet(user.getUserNo(), amigoName, displayYn);
			mAmigoSetObjOp = mAmigoSetRepository.findByUserNoAndMaximumAmigoSetNo(user.getUserNo());
		}
		///////////////////////// RESPONSE /////////////////////////////////////////////////////
		AddAmigoSetResponse respObj = new AddAmigoSetResponse();
		respObj.setAmigoSetNo(mAmigoSetObjOp.get().getAmigoSetNo());
		respObj.setAmigoSetName(mAmigoSetObjOp.get().getAmigoSetName());
		
		return respObj;
	}

	@Override
	public RenameAmigoSetResponse renameAmigoSet(MUser user, RenameAmigoSetRequest reqObj)
			throws Exception {
		if (reqObj.getAmigoSetNo() < 1L) {
			return null;
		}
		String amigoName = reqObj.getAmigoSetName();
		if (amigoName.trim().isEmpty()) {
			return null;
		}
		mAmigoSetRepository.renameAmigoSetName(user.getUserNo()
				, reqObj.getAmigoSetNo()
				, reqObj.getAmigoSetName());
			
		///////////////////////// RESPONSE /////////////////////////////////////////////////////
		RenameAmigoSetResponse respObj = new RenameAmigoSetResponse();
		respObj.setResult(Boolean.TRUE);
		return respObj;
	}

	@Override
	public DeleteAmigoSetResponse deleteAmigoSet(MUser user, DeleteAmigoSetRequest reqObj)
			throws Exception {
		log.debug("################# DELETE AMIGO SET");
			
		List<Long> amigoNoSetList = reqObj.getAmigoSetNoList();
		if (amigoNoSetList.size() < 1) {
			return null;
		}
		for (Long amigoSetNo : amigoNoSetList) {
			mAmigoSetRepository.updateDelete(user.getUserNo(), amigoSetNo);
		}
		///////////////////////// RESPONSE /////////////////////////////////////////////////////
		DeleteAmigoSetResponse respObj = new DeleteAmigoSetResponse();
		respObj.setResult(Boolean.TRUE);
		return respObj;
	}

	@Override
	public AmigoSetListResponse amigoSetList(MUser user) throws Exception {
		log.debug("################# GET LIST AMIGO SET");
		List<MAmigoSet> mAmigoSetList = mAmigoSetRepository.findByUserNoAndUseYn(user.getUserNo(), "Y");
		List<AmigoSet> amigoSetList = Lists.newArrayList();
		List<MAmigo> amigoList = null;
		for (MAmigoSet amigoSetObj : mAmigoSetList) {
			AmigoSet obj = new AmigoSet();
			obj.setAmigoSetName(amigoSetObj.getAmigoSetName());
			obj.setAmigoSetNo(amigoSetObj.getAmigoSetNo());
			obj.setAmigoList(new ArrayList<Amigo>());
			amigoList = mAmigoRepository.findByUserNoAndAmigoSetNoAndUseYn(
					user.getUserNo()
					, amigoSetObj.getAmigoSetNo()
					, "Y");
			for (MAmigo amigo : amigoList) {
				Amigo o = new Amigo();
			//	o.setUserName(amigo.getuser);
				Optional<MUser> uOp= mUserRepository.findByUserNo(amigo.getAmigoNo());
				if (uOp.isEmpty()
						|| !uOp.get().getActiveYn().equals("Y")
						|| !uOp.get().getUseYn().equals("Y")) {
					continue;
				}
				o.setUserName(uOp.get().getUserName());
				o.setUserNo(uOp.get().getUserNo());
				obj.getAmigoList().add(o);
			}
			amigoSetList.add(obj);
		}
		///////////////////////// RESPONSE /////////////////////////////////////////////////////
		AmigoSetListResponse respObj = new AmigoSetListResponse();
		respObj.setAmigoSetList(amigoSetList);
		return respObj;
	}
}
