package com.mutecsoft.atalk.service;

import java.util.Optional;

import org.springframework.web.multipart.MultipartFile;

import com.mutecsoft.atalk.constant.EnumProfileType;
import com.mutecsoft.atalk.logic.model.AtalkDataModelAll;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.security.oauth2.model.CustomUserDetail;

public interface AtalkUserProfileService {
	Optional<AtalkDataModelAll> updateProfileImage(
			SecureDataModel secModel
			, CustomUserDetail authUser
			, EnumProfileType profileType
			, MultipartFile file) throws Exception;
}
