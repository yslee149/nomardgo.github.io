/*
 *  Copyright (c) 2024 CNU Global, Inc.
 *  All right reserved.
 *  This software is the confidential and proprietary information of DOUB
 *  , Inc. You shall not disclose such Confidential Information and
 *  shall use it only in accordance with the terms of the license agreement
 *  you entered into with CNU Global.
 *
 *  Revision History
 *  Date               Author         Description
 *  ------------------ -------------- ------------------
 *  2024. 8. 12.	   Hong Seok Woo  
 */
package com.mutecsoft.atalk.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mutecsoft.atalk.common.model.MUser;
import com.mutecsoft.atalk.component.PacketDecryptor;
import com.mutecsoft.atalk.component.redis.RedisTaskBroker;
import com.mutecsoft.atalk.logic.model.AtalkDataModelAll;
import com.mutecsoft.atalk.logic.model.AtalkPacketBase;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.logic.model.amigoset.AddAmigoSetRequest;
import com.mutecsoft.atalk.logic.model.amigoset.AddAmigoSetResponse;
import com.mutecsoft.atalk.logic.model.amigoset.AmigoSetListResponse;
import com.mutecsoft.atalk.logic.model.amigoset.DeleteAmigoSetRequest;
import com.mutecsoft.atalk.logic.model.amigoset.DeleteAmigoSetResponse;
import com.mutecsoft.atalk.logic.model.amigoset.RenameAmigoSetRequest;
import com.mutecsoft.atalk.logic.model.amigoset.RenameAmigoSetResponse;
import com.mutecsoft.atalk.logic.util.RandomHexString;
import com.mutecsoft.atalk.secure.model.redis.RedisPacketKeySeed;
import com.mutecsoft.atalk.security.oauth2.model.CustomUserDetail;
import com.mutecsoft.atalk.service.AtalkAmigoSetService;
import com.mutecsoft.atalk.service.AtalkAmigoSetServiceLogic;
import com.mutecsoft.atalk.service.UserAccountService;

import lombok.extern.slf4j.Slf4j;

/**
 * 친구그룹 서비스
 * 
 */
@Slf4j
@Service("atalkAmigoSetService")
public class AtalkAmigoSetServiceImpl implements AtalkAmigoSetService {

	@Autowired
	UserAccountService userAccountService;
	
	@Autowired
	RedisTaskBroker redisTaskBroker;
	
	@Autowired
	PacketDecryptor packetDecryptor;
	
	@Autowired
	AtalkAmigoSetServiceLogic atalkAmigoSetServiceLogic;

	@Override
	public Optional<AtalkDataModelAll> addAmigoSet(CustomUserDetail authUser, SecureDataModel secModel)
			throws Exception {
		log.debug("################# ADD AMIGO SET");
		MUser user = userAccountService.getUserByUserId(authUser.getUserId());
		if (user != null) {
			log.debug("#### transactionId : {}", secModel.getTransactinId());
			log.debug("#### data : {}", secModel.getData());
			
			String [] decryptPacketData = packetDecryptor.packetStringFromModel(secModel);
			if (decryptPacketData == null || decryptPacketData[0].equals("")) {
				return Optional.ofNullable(null);
			}
			String objectJson = decryptPacketData[0];
			String packetKey = decryptPacketData[1];
			log.debug("#### request string : {}", objectJson);
			
			AddAmigoSetRequest reqObj = AtalkPacketBase.fromJson(objectJson, AddAmigoSetRequest.class);
			AddAmigoSetResponse respObj = atalkAmigoSetServiceLogic.addAmigoSet(user, reqObj);
			if (respObj == null) {
				 Optional.ofNullable(null);
			}
			///////////////////////// RESPONSE /////////////////////////////////////////////////////
			AtalkDataModelAll resData = AtalkDataModelAll.builder()
					.httpStatusCode(200)
					.atalkPacketBase(respObj)
					.secureModel(respObj.toFinalModel(packetKey))
					.build();
			resData.getSecureModel().setTransactinId(secModel.getTransactinId());
			return Optional.of(resData);
			// return new ResponseEntity<>(resData.getSecureModel(), HttpStatus.OK);
		}
		return Optional.ofNullable(null);
	}

	@Override
	public Optional<AtalkDataModelAll> renameAmigoSet(CustomUserDetail authUser, SecureDataModel secModel)
			throws Exception {
		log.debug("################# RENAME AMIGO SET");
		MUser user = userAccountService.getUserByUserId(authUser.getUserId());
		if (user != null) {
			log.debug("#### transactionId : {}", secModel.getTransactinId());
			log.debug("#### data : {}", secModel.getData());
			
			String [] decryptPacketData = packetDecryptor.packetStringFromModel(secModel);
			if (decryptPacketData == null || decryptPacketData[0].equals("")) {
				return Optional.ofNullable(null);
			}
			String objectJson = decryptPacketData[0];
			String packetKey = decryptPacketData[1];
			log.debug("#### request string : {}", objectJson);
			
			RenameAmigoSetRequest reqObj = AtalkPacketBase.fromJson(objectJson, RenameAmigoSetRequest.class);
			RenameAmigoSetResponse respObj = atalkAmigoSetServiceLogic.renameAmigoSet(user, reqObj);
			if (respObj == null) {
				return Optional.ofNullable(null);
			}
			///////////////////////// RESPONSE /////////////////////////////////////////////////////
			AtalkDataModelAll resData = AtalkDataModelAll.builder()
					.httpStatusCode(200)
					.atalkPacketBase(respObj)
					.secureModel(respObj.toFinalModel(packetKey))
					.build();
			resData.getSecureModel().setTransactinId(secModel.getTransactinId());
			return Optional.of(resData);
			// return new ResponseEntity<>(resData.getSecureModel(), HttpStatus.OK);
		}
		return Optional.ofNullable(null);
	}

	@Override
	public Optional<AtalkDataModelAll> deleteAmigoSet(CustomUserDetail authUser, SecureDataModel secModel)
			throws Exception {
		log.debug("################# DELETE AMIGO SET");
		MUser user = userAccountService.getUserByUserId(authUser.getUserId());
		if (user != null) {
			log.debug("#### transactionId : {}", secModel.getTransactinId());
			log.debug("#### data : {}", secModel.getData());
			
			String [] decryptPacketData = packetDecryptor.packetStringFromModel(secModel);
			if (decryptPacketData == null || decryptPacketData[0].equals("")) {
				return Optional.ofNullable(null);
			}
			String objectJson = decryptPacketData[0];
			String packetKey = decryptPacketData[1];
			log.debug("#### request string : {}", objectJson);
			
			DeleteAmigoSetRequest reqObj = AtalkPacketBase.fromJson(objectJson, DeleteAmigoSetRequest.class);
			DeleteAmigoSetResponse respObj = atalkAmigoSetServiceLogic.deleteAmigoSet(user, reqObj);
			if (respObj == null) {
				return Optional.ofNullable(null);
			}
			///////////////////////// RESPONSE /////////////////////////////////////////////////////
			AtalkDataModelAll resData = AtalkDataModelAll.builder()
					.httpStatusCode(200)
					.atalkPacketBase(respObj)
					.secureModel(respObj.toFinalModel(packetKey))
					.build();
			resData.getSecureModel().setTransactinId(secModel.getTransactinId());
			return Optional.of(resData);
			// return new ResponseEntity<>(resData.getSecureModel(), HttpStatus.OK);
		}
		return Optional.ofNullable(null);
	}

	@Override
	public Optional<AtalkDataModelAll> amigoSetList(CustomUserDetail authUser) throws Exception {
		log.debug("################# GET LIST AMIGO SET");
		MUser user = userAccountService.getUserByUserId(authUser.getUserId());
		if (user != null) {
			RedisPacketKeySeed redisKeyObj = redisTaskBroker.findKeyObjectByUserNo(user.getUserNo());
			String packetKey = redisKeyObj.getPacketKey();
			
			AmigoSetListResponse respObj = atalkAmigoSetServiceLogic.amigoSetList(user);
			if (respObj == null) {
				return Optional.ofNullable(null);
			}
			///////////////////////// RESPONSE /////////////////////////////////////////////////////
			AtalkDataModelAll resData = AtalkDataModelAll.builder()
					.httpStatusCode(200)
					.atalkPacketBase(respObj)
					.secureModel(respObj.toFinalModel(packetKey))
					.build();
			resData.getSecureModel().setTransactinId(RandomHexString.genSecureRandomHex(16));
			return Optional.of(resData);
		}
		return Optional.ofNullable(null);
	}
}
