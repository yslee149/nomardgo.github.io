package com.mutecsoft.atalk.service;

import java.util.Optional;

import com.mutecsoft.atalk.logic.model.AtalkDataModelAll;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.security.oauth2.model.CustomUserDetail;

public interface AtalkAmigoService {
	Optional<AtalkDataModelAll> addAmigo(CustomUserDetail authUser, SecureDataModel secModel) throws Exception;
	Optional<AtalkDataModelAll> addAmigo(CustomUserDetail authUser, String userName, String userId) throws Exception;
	Optional<AtalkDataModelAll> deleteAmigo(CustomUserDetail authUser, SecureDataModel secModel) throws Exception;
	Optional<AtalkDataModelAll> amigoList(CustomUserDetail authUser) throws Exception;	
	Optional<AtalkDataModelAll> detail(CustomUserDetail authUser, Long amigoUserNo) throws Exception;
}
