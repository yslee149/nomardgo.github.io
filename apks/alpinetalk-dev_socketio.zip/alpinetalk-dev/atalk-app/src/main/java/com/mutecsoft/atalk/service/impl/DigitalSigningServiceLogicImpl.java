package com.mutecsoft.atalk.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mutecsoft.atalk.component.redis.RedisTaskBroker;
import com.mutecsoft.atalk.constant.AtalkConstant;
import com.mutecsoft.atalk.logic.model.AtalkDataModelAll;
import com.mutecsoft.atalk.logic.model.BeanWrapper;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.logic.model.digitalsign.PacketKeyResult;
import com.mutecsoft.atalk.logic.util.DigitalSignComplex;
import com.mutecsoft.atalk.secure.model.redis.RedisPacketKeySeed;
import com.mutecsoft.atalk.service.DigitalSigningServiceLogic;

import lombok.extern.slf4j.Slf4j;

/**
 * 디지털 사이닝 처리
 * 
 */
@Slf4j
@Service("digitalSigningServiceLogic")
public class DigitalSigningServiceLogicImpl implements DigitalSigningServiceLogic {

	@Autowired
	RedisTaskBroker redisTaskBroker;

	@Override
	public String saveDigitalSigningSeed(String seedValue) {
		int retval = redisTaskBroker.insertSeedValue(seedValue);
		return seedValue;
	}

	@Override
	public Optional<AtalkDataModelAll> doSign(SecureDataModel secModel) throws Exception {
		
		// String reqTransactionId = secData.getTransactinId();
		String signatureDataAll = secModel.getData();
		/////////////////////////////////
		
		String signatureData = signatureDataAll.substring(
				0,
				signatureDataAll.length() - SecureDataModel.KEY_SEED_SIZE);
		log.debug("#### signatureData : {}", signatureData);
		
		String signingMessagePlain = signatureDataAll.substring(
				signatureDataAll.length() - SecureDataModel.KEY_SEED_SIZE);
		log.debug("#### signingMessagePlain : {}", signingMessagePlain);

		String extractSignature = signatureData.substring(0, AtalkConstant.SIGNATURE_BOUND_POS);
		String extractClientPublicKey = signatureData.substring( AtalkConstant.SIGNATURE_BOUND_POS);
		// String signingMessageHashServer = DigitalSignComplex.generateSigningMessageHash(signingMessagePlain);
		log.debug("#### client pubkey : " + extractClientPublicKey);
		log.debug("#### extractSignature : " + extractSignature);
		
		// DigitalSignComplex.decryptSignature(signingMessageHashServer, extractClientPublicKey);
		
		Boolean result = DigitalSignComplex.checkSignature(
				extractSignature
				, signingMessagePlain
				, extractClientPublicKey);
		if (result.equals(Boolean.TRUE)) {
			RedisPacketKeySeed rPktKeySeedObj = redisTaskBroker.findKeySeedData(signingMessagePlain);
			rPktKeySeedObj.setActiveYn("Y");
			redisTaskBroker.updateKeySeedObject(signingMessagePlain, rPktKeySeedObj);
			
			String packetEncDecKey = rPktKeySeedObj.getPacketKey();
			log.debug("######## PACKET KEY : {}", packetEncDecKey);
			BeanWrapper<PacketKeyResult> builder = new BeanWrapper<>(PacketKeyResult.class);
			PacketKeyResult pktKeyResult = builder
	            .with("packetKeyData", packetEncDecKey)
	            .with("publicKey", extractClientPublicKey)
	            .build();
			AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
					.atalkPacketBase(pktKeyResult)
					.secureModel(pktKeyResult.toFinalModel())
					.build();
			log.debug("#### checkSignature result : {}", result);
			
			//return Optional.ofNullable(null);
			return Optional.ofNullable(resultObj);
		}
		return Optional.ofNullable(null);
	}
}
