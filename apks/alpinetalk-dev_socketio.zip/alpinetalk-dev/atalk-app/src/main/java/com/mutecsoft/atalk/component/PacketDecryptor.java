package com.mutecsoft.atalk.component;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.mutecsoft.atalk.component.redis.RedisTaskBroker;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.logic.util.AesEncDecComplex;
import com.mutecsoft.atalk.secure.model.redis.RedisPacketKeySeed;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author voyzer
 *
 */
@Slf4j
@Component
@Getter
@Setter
public class PacketDecryptor {

	@Autowired
	RedisTaskBroker redisTaskBroker;
	public PacketDecryptor() {
		
	}
	
    /**
     * 
	 * @param secureModel
	 * @return
     * @throws Exception 
	 */
	public String [] packetStringFromModel(SecureDataModel secureModel) throws Exception {
		try {
			String signatureDataAll = secureModel.getData();
			/////////////////////////////////
			String secData = signatureDataAll.substring(
					0,
					signatureDataAll.length() - SecureDataModel.KEY_SEED_SIZE);
			String packetKeySeedValue = signatureDataAll.substring(
					signatureDataAll.length() - SecureDataModel.KEY_SEED_SIZE);
			log.debug("#### packetKeySeedValue : {}", packetKeySeedValue);
			/////////////////////////////////
			
			String encryptedSignupDataHex = secData;
			RedisPacketKeySeed redisKeyObj = redisTaskBroker.findKeySeedData(packetKeySeedValue);
			if (redisKeyObj.getUserNo() == null) {
				return new String [] {"","","",""};
			}
			if (!redisKeyObj.getActiveYn().equals("Y")) {
				return new String [] {"","","",""};
			}
			
			////////////////////// GET PACKET KEY
			log.debug("#### redisKeyObj : {}", redisKeyObj);
			String packetKey = redisKeyObj.getPacketKey();

			byte [] encBuffer = AesEncDecComplex.hexToBytes(encryptedSignupDataHex);
			byte [] decBuffer = AesEncDecComplex.decryptAesCtrWithIv(encBuffer, packetKey);  // AES DECRYPT
			
			String objectJson = new String(decBuffer);
			return new String [] { 
					objectJson
					, packetKey
					, packetKeySeedValue
					, String.valueOf(redisKeyObj.getUserNo())
					};
		} catch (JsonProcessingException e) {
			log.error("@@@@ Err : {}", e);
		}
		return null;
	}

    /**
     * 
	 * @param secureModel
	 * @return
     * @throws Exception 
	 */
	public String [] packetStringFromModelFirst(SecureDataModel secureModel) throws Exception {
		try {
			String signatureDataAll = secureModel.getData();
			/////////////////////////////////
			String secData = signatureDataAll.substring(
					0,
					signatureDataAll.length() - SecureDataModel.KEY_SEED_SIZE);
			String packetKeySeedValue = signatureDataAll.substring(
					signatureDataAll.length() - SecureDataModel.KEY_SEED_SIZE);
			log.debug("#### packetKeySeedValue : {}", packetKeySeedValue);
			/////////////////////////////////
			
			String encryptedSignupDataHex = secData;
			RedisPacketKeySeed redisKeyObj = redisTaskBroker.findKeySeedData(packetKeySeedValue);
			
			if (!redisKeyObj.getActiveYn().equals("Y")) {
				return new String [] {"","","",""};
			}
			
			////////////////////// GET PACKET KEY
			log.debug("#### redisKeyObj : {}", redisKeyObj);
			String packetKey = redisKeyObj.getPacketKey();

			byte [] encBuffer = AesEncDecComplex.hexToBytes(encryptedSignupDataHex);
			byte [] decBuffer = AesEncDecComplex.decryptAesCtrWithIv(encBuffer, packetKey);  // AES DECRYPT
			
			String objectJson = new String(decBuffer);
			return new String [] { 
					objectJson
					, packetKey
					, packetKeySeedValue
					, String.valueOf(redisKeyObj.getUserNo())
					};
		} catch (JsonProcessingException e) {
			log.error("@@@@ Err : {}", e);
		}
		return null;
	}

    /**
     * 
	 * 
	 * @param userNo
	 * @return
	 * @throws Exception
	 */
	public String packetKeyFromUserNo(Long userNo) throws Exception {
		try {
			RedisPacketKeySeed redisKeyObj = redisTaskBroker.findKeyUserNo(userNo);
			if (redisKeyObj.getUserNo() == null
					||
				!redisKeyObj.getUserNo().equals(userNo)) {
				return null;
			}
			if (!redisKeyObj.getActiveYn().equals("Y")) {
				return null;
			}
			////////////////////// GET PACKET KEY
			log.debug("#### redisKeyObj : {}", redisKeyObj);
			return redisKeyObj.getPacketKey();
		} catch (Exception e) {
			log.error("@@@@ Err : {}", e);
		}
		return null;
	}
	
	/**
	 * @param packetKeySeedValue
	 * @return
	 * @throws Exception
	 */
	public String getPacketKey(String packetKeySeedValue) {
		log.debug("#### packetKeySeedValue : {}", packetKeySeedValue);
		RedisPacketKeySeed redisKeyObj = redisTaskBroker.findKeySeedData(packetKeySeedValue);
		if (!redisKeyObj.getActiveYn().equals("Y")) {
			return null;
		}
		////////////////////// GET PACKET KEY
		log.debug("#### redisKeyObj : {}", redisKeyObj);
		return redisKeyObj.getPacketKey();
	}
}
