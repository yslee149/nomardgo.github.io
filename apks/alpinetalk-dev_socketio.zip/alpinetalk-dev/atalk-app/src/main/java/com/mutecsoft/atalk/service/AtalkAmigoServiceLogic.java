package com.mutecsoft.atalk.service;

import com.mutecsoft.atalk.common.model.MUser;
import com.mutecsoft.atalk.logic.model.amigo.AddAmigoRequest;
import com.mutecsoft.atalk.logic.model.amigo.AmigoDetailResponse;
import com.mutecsoft.atalk.logic.model.amigo.AmigoListResponse;
import com.mutecsoft.atalk.logic.model.amigo.DeleteAmigoRequest;
import com.mutecsoft.atalk.logic.model.amigo.DeleteAmigoResponse;

public interface AtalkAmigoServiceLogic {
	AmigoListResponse addAmigo(MUser user, AddAmigoRequest reqObj) throws Exception;
	AmigoDetailResponse addAmigoOne(MUser user, Long amigoNo) throws Exception;
	
	int updateNickName(MUser user, Long amigoNo, String nickName) throws Exception;
	
	DeleteAmigoResponse deleteAmigo(MUser user, DeleteAmigoRequest reqObj) throws Exception;
	AmigoListResponse amigoList(MUser user) throws Exception;
	AmigoDetailResponse detail(MUser user, Long amigoUserNo) throws Exception;
}
