package com.mutecsoft.atalk.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mutecsoft.atalk.common.model.MUser;
import com.mutecsoft.atalk.component.PacketDecryptor;
import com.mutecsoft.atalk.component.redis.RedisTaskBroker;
import com.mutecsoft.atalk.logic.model.AtalkDataModelAll;
import com.mutecsoft.atalk.logic.model.AtalkPacketBase;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.logic.model.user.SearchUserRequest;
import com.mutecsoft.atalk.logic.model.user.SearchUserResponse;
import com.mutecsoft.atalk.logic.util.AesEncDecComplex;
import com.mutecsoft.atalk.secure.model.redis.RedisPacketKeySeed;
import com.mutecsoft.atalk.security.oauth2.model.CustomUserDetail;
import com.mutecsoft.atalk.service.AtalkSearchService;
import com.mutecsoft.atalk.service.AtalkSearchServiceLogic;
import com.mutecsoft.atalk.service.UserAccountService;

import lombok.extern.slf4j.Slf4j;

/**
 * 검색 서비스
 * 
 */
@Slf4j
@Service("atalkSearchService")
public class AtalkSearchServiceImpl implements AtalkSearchService {

	@Autowired
	UserAccountService userAccountService;
	
	@Autowired
	RedisTaskBroker redisTaskBroker;
	
	@Autowired
	PacketDecryptor packetDecryptor;
	
	@Autowired
	AtalkSearchServiceLogic atalkSearchServiceLogic;
	
	@Override
	public Optional<AtalkDataModelAll> searchUser(CustomUserDetail authUser, SecureDataModel secModel)
			throws Exception {
		log.debug("################# SEARCH USER");
		MUser user = userAccountService.getUserByUserId(authUser.getUserId());
		if (user != null) {
			log.debug("#### transactionId : {}", secModel.getTransactinId());
			log.debug("#### data : {}", secModel.getData());
			
			String [] decryptPacketData = packetDecryptor.packetStringFromModel(secModel);
			if (decryptPacketData == null || decryptPacketData[0].equals("")) {
				return Optional.ofNullable(null);
			}
			String objectJson = decryptPacketData[0];
			String packetKey = decryptPacketData[1];
			log.debug("#### request string : {}", objectJson);
			
			SearchUserRequest reqObj = AtalkPacketBase.fromJson(objectJson, SearchUserRequest.class);
			SearchUserResponse respObj = atalkSearchServiceLogic.searchUser(user, reqObj);
			if (respObj == null) {
				Optional.ofNullable(null);
			}
			///////////////////////// RESPONSE /////////////////////////////////////////////////////
			AtalkDataModelAll resData = AtalkDataModelAll.builder()
					.httpStatusCode(200)
					.atalkPacketBase(respObj)
					.secureModel(respObj.toFinalModel(packetKey))
					.build();
			resData.getSecureModel().setTransactinId(secModel.getTransactinId());
			return Optional.of(resData);
		}
		return Optional.ofNullable(null);
	}

	@Override
	public Optional<AtalkDataModelAll> searchUserNoAuth(SecureDataModel secModel) throws Exception {
		
		String signatureDataAll = secModel.getData();
		/////////////////////////////////
		String secData = signatureDataAll.substring(
				0,
				signatureDataAll.length() - SecureDataModel.KEY_SEED_SIZE);
		String packetKeySeedValue = signatureDataAll.substring(
				signatureDataAll.length() - SecureDataModel.KEY_SEED_SIZE);
		log.debug("#### packetKeySeedValue : {}", packetKeySeedValue);
		/////////////////////////////////
		
		String encryptedSignupDataHex = secData;
		RedisPacketKeySeed redisKeyObj = redisTaskBroker.findKeySeedData(packetKeySeedValue);
		
		if (!redisKeyObj.getActiveYn().equals("Y")) {
			AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
					.httpStatusCode(425)
					.atalkPacketBase(null)
					.secureModel(null)
					.build();
			return Optional.ofNullable(resultObj);
		}
		//////////////////////GET PACKET KEY
		log.debug("#### redisKeyObj : {}", redisKeyObj);
		String packetKey = redisKeyObj.getPacketKey();
		byte [] encBuffer = AesEncDecComplex.hexToBytes(encryptedSignupDataHex);
		byte [] decBuffer = AesEncDecComplex.decryptAesWithIv(encBuffer, packetKey);  // AES DECRYPT
		
		String objectJson = new String(decBuffer);

		SearchUserRequest reqObj = AtalkPacketBase.fromJson(objectJson, SearchUserRequest.class);
		SearchUserResponse respObj = atalkSearchServiceLogic.searchUserNoAuth(reqObj);
		if (respObj == null) {
			Optional.ofNullable(null);
		}
		///////////////////////// RESPONSE /////////////////////////////////////////////////////
		AtalkDataModelAll resData = AtalkDataModelAll.builder()
				.httpStatusCode(200)
				.atalkPacketBase(respObj)
				.secureModel(respObj.toFinalModel(packetKey))
				.build();
		resData.getSecureModel().setTransactinId(secModel.getTransactinId());
		return Optional.of(resData);
	}
}
