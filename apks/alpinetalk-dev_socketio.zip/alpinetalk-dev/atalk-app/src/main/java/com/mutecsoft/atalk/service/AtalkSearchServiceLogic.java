package com.mutecsoft.atalk.service;

import com.mutecsoft.atalk.common.model.MUser;
import com.mutecsoft.atalk.logic.model.user.SearchUserRequest;
import com.mutecsoft.atalk.logic.model.user.SearchUserResponse;

public interface AtalkSearchServiceLogic {
	SearchUserResponse searchUser(MUser user, SearchUserRequest reqObj) throws Exception;
	SearchUserResponse searchUserNoAuth(SearchUserRequest reqObj) throws Exception;
}
