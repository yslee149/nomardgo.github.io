package com.mutecsoft.atalk.service;

import java.util.List;
import java.util.Optional;

import org.springframework.web.multipart.MultipartFile;

import com.mutecsoft.atalk.common.model.MUser;
import com.mutecsoft.atalk.logic.model.AtalkDataModelAll;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.logic.model.auth.UserAuthTokenRequest;
import com.mutecsoft.atalk.logic.model.auth.UserAuthTokenResponse;
import com.mutecsoft.atalk.logic.model.auth.UserLoginRequest;
import com.mutecsoft.atalk.logic.model.auth.UserLoginResponse;
import com.mutecsoft.atalk.logic.model.auth.UserPasswordRequest;
import com.mutecsoft.atalk.logic.model.auth.UserPasswordResponse;
import com.mutecsoft.atalk.logic.model.auth.UserResultResponse;
import com.mutecsoft.atalk.logic.model.user.UserDetailResponse;

public interface AtalkUserServiceLogic {
	
	Optional<AtalkDataModelAll> checkDupAccount(SecureDataModel secModel) throws Exception;
	Optional<AtalkDataModelAll> signup(SecureDataModel secModel) throws Exception;
	Optional<AtalkDataModelAll> signupMore(SecureDataModel secModel, List<MultipartFile> profileFiles) throws Exception;
	
	
	
	Optional<AtalkDataModelAll> deleteUser(SecureDataModel secModel) throws Exception;
	
	Optional<AtalkDataModelAll> resetAllForTest(SecureDataModel secModel) throws Exception;
	
	///////////
	void afterLogin(MUser userObj) throws Exception;


	UserLoginResponse login(String packetKeySeedValue, UserLoginRequest reqObj) throws Exception;
	UserAuthTokenResponse refreshToken(UserAuthTokenRequest reqObj) throws Exception;
	UserPasswordResponse changePassword(MUser user, UserPasswordRequest reqObj) throws Exception;
	UserResultResponse changeUserLanguage(MUser user, String lang) throws Exception;

	UserResultResponse checkPassword(MUser user, String encPassword) throws Exception;
	UserResultResponse issuePassword(String userId) throws Exception;
	UserResultResponse authEmail(String userEmail) throws Exception;
	UserResultResponse checkAuthToken(String userEmail, String tokenValue) throws Exception;
	UserResultResponse checkDupAccount(String userEmail) throws Exception;
	
	UserDetailResponse editProfile(MUser user, String statusMessage, String nickName, MultipartFile fg, MultipartFile bg) throws Exception;
	
	UserDetailResponse deleteFg(MUser user) throws Exception;
	UserDetailResponse deleteBg(MUser user) throws Exception;

	UserDetailResponse info(MUser user, Long userNo) throws Exception;
	
	UserResultResponse logout(MUser user) throws Exception;
	UserResultResponse deactivate(MUser user) throws Exception;

}

