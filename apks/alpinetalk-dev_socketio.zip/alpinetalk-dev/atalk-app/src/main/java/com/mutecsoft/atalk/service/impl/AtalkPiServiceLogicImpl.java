package com.mutecsoft.atalk.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.mutecsoft.atalk.common.model.MAgreementHist;
import com.mutecsoft.atalk.common.model.MPiAgreement;
import com.mutecsoft.atalk.common.model.MUser;
import com.mutecsoft.atalk.common.repository.MAgreementHistRepository;
import com.mutecsoft.atalk.common.repository.MPiAgreementRepository;
import com.mutecsoft.atalk.common.repository.MUserRepository;
import com.mutecsoft.atalk.logic.model.pi.PiAgreementResponse;
import com.mutecsoft.atalk.logic.model.response.AgreementResponse;
import com.mutecsoft.atalk.service.AtalkPiServiceLogic;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;

/**
 * 이용약관 서비스
 * 
 */
@Slf4j
@Service("atalkPiServiceLogic")
public class AtalkPiServiceLogicImpl implements AtalkPiServiceLogic {

	@Autowired
	MPiAgreementRepository mPiAgreementRepository;

	@Autowired
	MAgreementHistRepository   mAgreementHistRepository;

	@Autowired
	MUserRepository mUserRepository;
	
	@Override
	public PiAgreementResponse getLatestPiAgreement() throws Exception {
		
		Optional<MPiAgreement> piOp = mPiAgreementRepository.findByLatest();
		
		///////////////////////// RESPONSE /////////////////////////////////////////////////////
		PiAgreementResponse respObj = new PiAgreementResponse();
		respObj.setContent(piOp.get().getPiContent());
		respObj.setPiVersion(piOp.get().getPiNo());
		return respObj;
	}

	@Override
	public Long agree(MUser user, Long version) throws Exception {
		Optional<MPiAgreement> agreeOp = mPiAgreementRepository.findById(version);
		if (agreeOp.isPresent()) {
			user.setPiAgreeVersion(agreeOp.get().getPiNo());
			mUserRepository.save(user);
			
			MAgreementHist agreeHistObj = new MAgreementHist();
			agreeHistObj.setCat("PI");
			agreeHistObj.setRegDate(new Date());
			agreeHistObj.setUserNo(user.getUserNo());
			agreeHistObj.setVersionNo(version);
			agreeHistObj.setAgreeYn("Y");
			mAgreementHistRepository.save(agreeHistObj);
			
			return version;
		}
		return 0L;
	}

	SimpleDateFormat dateFormatter;
	
	@PostConstruct
	private void init() {
		dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	}
	
	@Override
	public AgreementResponse getHist(MUser user) throws Exception {
		Optional<MAgreementHist> agreementHistOp = mAgreementHistRepository.findByLatest(user.getUserNo(), "PI");
		
		///////////////////////// RESPONSE /////////////////////////////////////////////////////
		AgreementResponse respObj = new AgreementResponse();
		if (agreementHistOp.isPresent()) {
			respObj.setRegDt(dateFormatter.format(agreementHistOp.get().getRegDate()));
			respObj.setVersion(agreementHistOp.get().getVersionNo());
			respObj.setAgreeYn(agreementHistOp.get().getAgreeYn());
		} else {
			respObj.setRegDt(null);
			respObj.setVersion(0L);
			respObj.setAgreeYn("N");		
		}
		return respObj;
	}
}
