package com.mutecsoft.atalk.config;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class AtalkChatConfig {
	private Integer chatExtCriteriaSize;
	private Integer chatInqDefaultMaxCount;
	private String chatExtChatUrl;
	private String chatFileChatUrl;
	private String chatFilePath;
	private String baseAddress;
}
