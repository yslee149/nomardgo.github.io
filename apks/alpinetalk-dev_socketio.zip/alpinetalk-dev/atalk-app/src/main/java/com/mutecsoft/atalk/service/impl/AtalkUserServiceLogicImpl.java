package com.mutecsoft.atalk.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.mutecsoft.atalk.common.model.MAuthEmail;
import com.mutecsoft.atalk.common.model.MChathub;
import com.mutecsoft.atalk.common.model.MChathubUser;
import com.mutecsoft.atalk.common.model.MUser;
import com.mutecsoft.atalk.common.model.MUserProfile;
import com.mutecsoft.atalk.common.model.MUserSignuptoken;
import com.mutecsoft.atalk.common.repository.MAuthEmailRepository;
import com.mutecsoft.atalk.common.repository.MChathubRepository;
import com.mutecsoft.atalk.common.repository.MChathubUserRepository;
import com.mutecsoft.atalk.common.repository.MUserProfileRepository;
import com.mutecsoft.atalk.common.repository.MUserRepository;
import com.mutecsoft.atalk.common.repository.MUserSignupTokenRepository;
import com.mutecsoft.atalk.component.PacketDecryptor;
import com.mutecsoft.atalk.component.redis.RedisTaskBroker;
import com.mutecsoft.atalk.config.AtalkConfig;
import com.mutecsoft.atalk.config.AuthTokenGenerator;
import com.mutecsoft.atalk.config.CustomAuthenticationProvider;
import com.mutecsoft.atalk.constant.AtalkConstant;
import com.mutecsoft.atalk.constant.EnumLangType;
import com.mutecsoft.atalk.constant.EnumProfileType;
import com.mutecsoft.atalk.logic.model.AtalkDataModelAll;
import com.mutecsoft.atalk.logic.model.AtalkPacketBase;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.logic.model.auth.UserAuthTokenRequest;
import com.mutecsoft.atalk.logic.model.auth.UserAuthTokenResponse;
import com.mutecsoft.atalk.logic.model.auth.UserLoginRequest;
import com.mutecsoft.atalk.logic.model.auth.UserLoginResponse;
import com.mutecsoft.atalk.logic.model.auth.UserPasswordRequest;
import com.mutecsoft.atalk.logic.model.auth.UserPasswordResponse;
import com.mutecsoft.atalk.logic.model.auth.UserResultResponse;

import com.mutecsoft.atalk.logic.model.chathub.ChatHubListInfo;
import com.mutecsoft.atalk.logic.model.signup.SignupRequest;
import com.mutecsoft.atalk.logic.model.signup.SignupResponse;
import com.mutecsoft.atalk.logic.model.user.DeleteUserRequest;
import com.mutecsoft.atalk.logic.model.user.DeleteUserResponse;
import com.mutecsoft.atalk.logic.model.user.UserDetailResponse;
import com.mutecsoft.atalk.logic.model.user.UserInfo;
import com.mutecsoft.atalk.logic.util.AesEncDecComplex;
import com.mutecsoft.atalk.logic.util.BufferComplex;
import com.mutecsoft.atalk.logic.util.HashComplex;
import com.mutecsoft.atalk.logic.util.RandomHexString;
import com.mutecsoft.atalk.logic.util.RsaComplex;
import com.mutecsoft.atalk.secure.model.redis.RedisPacketKeySeed;
import com.mutecsoft.atalk.security.oauth2.model.AuthToken;
import com.mutecsoft.atalk.security.oauth2.model.CustomUserDetail;
import com.mutecsoft.atalk.service.AtalkChatHubServiceLogic;
import com.mutecsoft.atalk.service.AtalkEmailService;
import com.mutecsoft.atalk.service.AtalkUnreadCntService;
import com.mutecsoft.atalk.service.AtalkUserProfileServiceLogic;
import com.mutecsoft.atalk.service.AtalkUserServiceLogic;
import com.mutecsoft.atalk.service.UserAccountService;

import jakarta.persistence.EntityManager;
import jakarta.persistence.ParameterMode;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.StoredProcedureQuery;
import jakarta.servlet.ServletContext;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;

/**
 * 사용자 서비스
 * 
 */
@Slf4j
@Service("atalkUserServiceLogic")
public class AtalkUserServiceLogicImpl implements AtalkUserServiceLogic {
	

	@PersistenceContext
	EntityManager entityManager;

	@Autowired
	MUserSignupTokenRepository mUserSignupTokenRepository;

	@Autowired
	MUserRepository mUserRepository;
	
	@Autowired
	MAuthEmailRepository mAuthEmailRepository;
	
	@Autowired
	MUserProfileRepository mUserProfileRepository;
	
	@Autowired
	MChathubUserRepository mChathubUserRepository;
	
	@Autowired
	MChathubRepository mChathubRepository;
	
	@Autowired
	UserAccountService userAccountService;
	
	@Autowired
	RedisTaskBroker redisTaskBroker;
	
	@Autowired
	PacketDecryptor packetDecryptor;
	
	@Autowired
	DaoAuthenticationProvider daoAuthenticationProvider;

	@Autowired
	AuthTokenGenerator authTokenGenerator;
	
	@Autowired
	CustomAuthenticationProvider customAuthenticationProvider;
	
	@Autowired
	AtalkUserProfileServiceLogic atalkUserProfileServiceLogic;

	@Autowired
	AtalkConfig atalkConfig;

//	public String saveDigitalSigningSeed(String seedValue) {
//		int retval = redisTaskBroker.insertSeedValue(seedValue);
//		return seedValue;
//	}
	
	@Autowired
	AtalkUnreadCntService atalkUnreadCntService;
	
	@Autowired
	AtalkChatHubServiceLogic atalkChatHubServiceLogic;
	
	@Autowired
	ServletContext servletContext;
	
	@Autowired
	AtalkEmailService atalkEmailService;
	
	
	@Override
	public Optional<AtalkDataModelAll> signup(SecureDataModel secModel) throws Exception {
		String signatureDataAll = secModel.getData();
		/////////////////////////////////
		String secData = signatureDataAll.substring(
				0,
				signatureDataAll.length() - SecureDataModel.KEY_SEED_SIZE);
		String packetKeySeedValue = signatureDataAll.substring(
				signatureDataAll.length() - SecureDataModel.KEY_SEED_SIZE);
		log.debug("#### packetKeySeedValue : {}", packetKeySeedValue);
		/////////////////////////////////
		
		String encryptedSignupDataHex = secData;
		RedisPacketKeySeed redisKeyObj = redisTaskBroker.findKeySeedData(packetKeySeedValue);
		
		if (!redisKeyObj.getActiveYn().equals("Y")) {
			AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
					.httpStatusCode(425)
					.atalkPacketBase(null)
					.secureModel(null)
					.build();
			return Optional.ofNullable(resultObj);
		}
		
		////////////////////// GET PACKET KEY
		log.debug("#### redisKeyObj : {}", redisKeyObj);
		String packetKey = redisKeyObj.getPacketKey();

		byte [] encBuffer = AesEncDecComplex.hexToBytes(encryptedSignupDataHex);
		byte [] decBuffer = AesEncDecComplex.decryptAesWithIv(encBuffer, packetKey);  // AES DECRYPT
		
		String objectJson = new String(decBuffer);
		
		SignupRequest signupRequest = AtalkPacketBase.fromJson(objectJson, SignupRequest.class);
		Optional<MUserSignuptoken> signupTokenObjOp = mUserSignupTokenRepository.findBySignupKeyAndUseYn(signupRequest.getSignupToken(), "N");
		if (signupTokenObjOp.isEmpty()) {
			AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
					.httpStatusCode(423)
					.atalkPacketBase(null)
					.secureModel(null)
					.build();
			return Optional.ofNullable(resultObj);
		}
		MUserSignuptoken signupTokenObj = signupTokenObjOp.get();
		int httpStatusCode = 200;
		Optional<MUser> userObjOp = mUserRepository.findByUserId(signupRequest.getUserId());
		if (!userObjOp.isEmpty()) {
			log.debug("@@@@@@@@@@@ ALREADY THE USER : {} exists", signupRequest.getUserId());
			AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
					.httpStatusCode(424)
					.atalkPacketBase(null)
					.secureModel(null)
					.build();
			return Optional.ofNullable(resultObj);
		}
		MUser mUser = new MUser();
		mUser.setActiveYn("Y");
		mUser.setUseYn("Y");
		mUser.setFirstLogin("Y");
		mUser.setUserId(signupRequest.getUserId());
		mUser.setUserName(signupRequest.getUserName());
		mUser.setSignupKey(signupRequest.getSignupToken());
		mUser.setUserPw(HashComplex.hashWithSha512(
				signupRequest.getUserId(), 1
				));
		mUser.setRegDate(new Date());
		mUser.setUpdDate(new Date());
		mUser = mUserRepository.save(mUser);
		
		signupTokenObj.setUseYn("Y");
		signupTokenObj.setUpdDate(new Date());
		mUserSignupTokenRepository.save(signupTokenObj);
		
		log.debug("#### mUser 6 : {}", mUser.toString());
		
		////////////////////////////////////////////////////////////////////////////////////

		SignupResponse signupResponse = new SignupResponse();
		signupResponse.setUserId(mUser.getUserId());
		AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
				.httpStatusCode(httpStatusCode)
				.atalkPacketBase(signupResponse)
				.secureModel(signupResponse.toFinalModel(packetKey))
				.build();
		// DigitalSignComplex.decryptSignature(signingMessageHashServer, extractClientPublicKey);
		
		return Optional.ofNullable(resultObj);
		
	}

	@Override
	public UserLoginResponse login(String packetKeySeedValue, UserLoginRequest reqObj) throws Exception {
		try {
			if (StringUtils.isAnyBlank(
					reqObj.getImei()
					, reqObj.getDeviceType()
					, reqObj.getPassword()
					, reqObj.getUserId()
					, reqObj.getClientPublicKey())) {
				return null;
			}
			MUser user = userAccountService.getUserByUserId(reqObj.getUserId());
			if (user== null) {
				// NO USER 
				UserLoginResponse loginResp = new UserLoginResponse();
				loginResp.setUserId(reqObj.getUserId());
				loginResp.setFirstLogin("");
				loginResp.setServerPublicKey("");
				loginResp.setImei("");
				loginResp.setUserNo(0L);
				loginResp.setAccessToken("");
				loginResp.setRefreshToken("");
				loginResp.setServerPublicKey("");
				loginResp.getError().setCode(1002L);
				return loginResp;
				
			}
			if (!user.getActiveYn().equals("Y")) {
				return null;
			}
			// 일치하지 않는 비밀번호
			if (!reqObj.getPassword().toUpperCase().equals(user.getUserPw().toUpperCase())
				||
				(
					!StringUtils.isBlank(user.getUserPwTemp())
						&&
					!reqObj.getPassword().toUpperCase().equals(user.getUserPwTemp().toUpperCase())
				)
					
				) {
				// NOT MATCHED PASSWORD 
				UserLoginResponse loginResp = new UserLoginResponse();
				loginResp.setUserId(reqObj.getUserId());
				loginResp.setFirstLogin("");
				loginResp.setServerPublicKey("");
				loginResp.setImei("");
				loginResp.setUserNo(user.getUserNo());
				loginResp.setAccessToken("");
				loginResp.setRefreshToken("");
				loginResp.setServerPublicKey("");
				loginResp.getError().setCode(1003L);
				return loginResp;
			}
			Authentication authentication = daoAuthenticationProvider.authenticate(
					UsernamePasswordAuthenticationToken.unauthenticated(
							reqObj.getUserId()
							, reqObj.getPassword()));
			
			Map<String, String> moreInf = AuthTokenGenerator.toMoreJwtInfo(reqObj);
			
			AuthToken token = authTokenGenerator.createToken(authentication, moreInf);
			
			CustomUserDetail loginUser = (CustomUserDetail)authentication.getPrincipal();
			String shaPasswordByUserId = DigestUtils.sha512Hex(loginUser.getUserId());
			///////////////////////// UPDATE USER INFO
			String userPubKey = user.getPublicKey();
			String userImei = user.getImei();
			if (user.getImei()==null || user.getImei().isBlank()) {
				user.setImei(reqObj.getImei());
			}
			user.setDeviceType(reqObj.getDeviceType());
			if ((
					!StringUtils.isBlank(userImei)
					&&
					!userImei.equals(reqObj.getImei())
				)
					||
				(
					!StringUtils.isBlank(userPubKey)
					&&
					!userPubKey.equals(reqObj.getClientPublicKey()) 
				)
				) {
				// 중복로그인 noti message
				log.debug("@@@@@@@@@@@ ALREADY THE USER : {} exists", reqObj.getUserId());
				
				// update 대화방키 목록 전체 업데이트
				List<MChathubUser> chatHubUserList = mChathubUserRepository.findByUserNoAndJoinYn(user.getUserNo(), "Y");
				chatHubUserList.forEach(val -> {
					Optional<MChathub> chathubInfoOp = mChathubRepository.findByChathubNo(val.getChathubNo());
					
					if (chathubInfoOp.isPresent()) {
						String userEncrypteChatKey = null;		
						String chatEncDecKey = RsaComplex.decrypt(chathubInfoOp.get().getEncKeyUrgent()
								, AtalkConstant.serverPrivateKey);
						userEncrypteChatKey = RsaComplex.encrypt(chatEncDecKey, reqObj.getClientPublicKey());
						mChathubUserRepository.updateEncryptChatKey(
								val.getChathubNo()
								, user.getUserNo()
								, userEncrypteChatKey);
					}
				});
			} else {
				// 로그인 나중에 했는데, 방이 이미 존재할 경우
				// update 대화방키 목록 전체 업데이트
				List<MChathubUser> chatHubUserList = mChathubUserRepository.findByUserNoAndJoinYn(user.getUserNo(), "Y");
				chatHubUserList.forEach(val -> {
					Optional<MChathub> chathubInfoOp = mChathubRepository.findByChathubNo(val.getChathubNo());
					if (chathubInfoOp.isPresent()
							&&
						StringUtils.isBlank(val.getEncryptChatKey())) {
						// 내 참여 대화방 키가 존재하지 않을 경우 암호화함.
						String userEncrypteChatKey = null;		
						String chatEncDecKey = RsaComplex.decrypt(chathubInfoOp.get().getEncKeyUrgent()
								, AtalkConstant.serverPrivateKey);
						userEncrypteChatKey = RsaComplex.encrypt(chatEncDecKey, reqObj.getClientPublicKey());
						mChathubUserRepository.updateEncryptChatKey(
								val.getChathubNo()
								, user.getUserNo()
								, userEncrypteChatKey);
					}
				});
			}
			user.setPublicKey(reqObj.getClientPublicKey());
			user.setImei(reqObj.getImei());
			user.setMobileTokenType(reqObj.getDeviceType());
			user.setMobileToken(reqObj.getPushToken());
			user.setUserPwTemp("");
			mUserRepository.save(user);
			
			///////////////////////////////////////////////////////////////////////////////////////
			String redisKey = String.format("PKTKEY_%d", user.getUserNo());
			RedisPacketKeySeed redisKeyObj = redisTaskBroker.findKeySeedData(packetKeySeedValue);
			redisKeyObj.setUserNo(user.getUserNo());
			redisTaskBroker.insertSeedObject(redisKey, redisKeyObj);
			redisTaskBroker.updateKeySeedObject(packetKeySeedValue, redisKeyObj);
			
			///////////////////////// RESPONSE /////////////////////////////////////////////////////
			UserLoginResponse loginResp = new UserLoginResponse();
			loginResp.setUserId(reqObj.getUserId());
			
			if (!StringUtils.equals(shaPasswordByUserId.toUpperCase(), loginUser.getPassword().toUpperCase())) {
				loginResp.setFirstLogin("N");
			} else {
				loginResp.setFirstLogin("Y");
			}
			loginResp.setUserNo(user.getUserNo());
			loginResp.setAccessToken(token.getAccessToken());
			loginResp.setRefreshToken(token.getRefreshToken());
			loginResp.setServerPublicKey(AtalkConstant.serverPublicKey);
			loginResp.setImei(user.getImei());
			loginResp.setLang(user.getLang());
			
			loginResp.setUserName(user.getUserName());
			loginResp.setStatusMessage(user.getStatusMessage());
			
			loginResp.setProfileBgThumbUrl("");
			loginResp.setProfileBgUrl("");
			loginResp.setProfileFgThumbUrl("");
			loginResp.setProfileFgUrl("");
			
			if (user.getProfileBgNo() != null && !user.getProfileBgNo().equals(0L)) {
				Optional<MUserProfile> bgObjOp=	mUserProfileRepository.findByProfileNo(user.getProfileBgNo());
				String url = String.format("%s%s%s/%s/%d",
						atalkConfig.getChatConfig().getBaseAddress()
						, servletContext.getContextPath()
						, atalkConfig.getProfileConfig().getBaseUrl()
						, "thumb", bgObjOp.get().getProfileNo());
				loginResp.setProfileBgThumbUrl(url);
				
				url = String.format("%s%s%s/%s/%d",
						atalkConfig.getChatConfig().getBaseAddress()
						, servletContext.getContextPath()
						, atalkConfig.getProfileConfig().getBaseUrl()
						, "view", bgObjOp.get().getProfileNo());
				loginResp.setProfileBgUrl(url);
			}
			if (user.getProfileFgNo() != null && !user.getProfileFgNo().equals(0L)) {
				Optional<MUserProfile> fgObjOp=	mUserProfileRepository.findByProfileNo(user.getProfileFgNo());
				String url = String.format("%s%s%s/%s/%d",
						atalkConfig.getChatConfig().getBaseAddress()
						, servletContext.getContextPath()
						, atalkConfig.getProfileConfig().getBaseUrl()
						, "thumb", fgObjOp.get().getProfileNo());
				loginResp.setProfileFgThumbUrl(url);
				
				url = String.format("%s%s%s/%s/%d",
						atalkConfig.getChatConfig().getBaseAddress()
						, servletContext.getContextPath()
						, atalkConfig.getProfileConfig().getBaseUrl()
						, "view", fgObjOp.get().getProfileNo());
				loginResp.setProfileFgUrl(url);
			}
			// 
			afterLogin(user);
			
			return loginResp;
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return null;
	}

	@Override
	public UserPasswordResponse changePassword(MUser user, UserPasswordRequest reqObj) throws Exception {
		String dbHashedPassword = user.getUserPw();
		if (dbHashedPassword.toUpperCase().equals(reqObj.getPassword().toUpperCase())) {
			String userPasswordValue = HashComplex.hashWithSha512(user.getUserId(), 1);
			String newHashedPassword = HashComplex.hashWithSha512(reqObj.getNewPasswordPlain(), 1);
			if (userPasswordValue.toUpperCase().equals(newHashedPassword.toUpperCase())) {
				UserPasswordResponse respObj = new UserPasswordResponse();
				respObj.setResult("@@@@ USERID AND PASSWORD ARE THE SAME.");
				return respObj;
			}
			user.setUserPw(newHashedPassword);
			user.setFirstLogin("N");
			mUserRepository.save(user);
			///////////////////////// RESPONSE /////////////////////////////////////////////////////
			UserPasswordResponse respObj = new UserPasswordResponse();
			respObj.setResult("SUCCESS");
			return respObj;
		}
		UserPasswordResponse respObj = new UserPasswordResponse();
		respObj.setResult("@@@@ PASSWORD NOT MATCHED.");
		return respObj;
	}

	@Override
	public UserAuthTokenResponse refreshToken(UserAuthTokenRequest reqObj) throws Exception {
		try {
			String refreshToken = reqObj.getRefreshToken();
			if (!customAuthenticationProvider.validateRefreshToken(refreshToken)) {
				return null;
			}
			Authentication authentication = customAuthenticationProvider.getAuthenticationFromRefreshToken(refreshToken);
			
			String userId = authentication.getName();
			// CustomUserDetail loginUser = (CustomUserDetail)authentication.getPrincipal();
			
			Map<String, String> moreInf = AuthTokenGenerator.toMoreJwtInfo(reqObj);
			
			AuthToken genAuthToken = authTokenGenerator.createToken(authentication, moreInf);
			///////////////////////// RESPONSE /////////////////////////////////////////////////////
			UserAuthTokenResponse resObj = new UserAuthTokenResponse();
			resObj.setAccessToken(genAuthToken.getAccessToken());
			resObj.setRefreshToken(genAuthToken.getRefreshToken());
			resObj.setUserId(userId);
			return resObj;
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return null;
	}

	@Override
	public Optional<AtalkDataModelAll> checkDupAccount(SecureDataModel secModel) throws Exception {
		try {
//			log.debug("#### transactionId : {}", secModel.getTransactinId());
//			log.debug("#### data : {}", secModel.getData());
//			
//			String [] decryptPacketData = packetDecryptor.packetStringFromModelFirst(secModel);
//			
//			if (decryptPacketData == null || decryptPacketData[0].equals("")) {
//				return Optional.ofNullable(null);
//			}
//			String objectJson = decryptPacketData[0];
//			String packetKey = decryptPacketData[1];
//			
//			String packetKeySeedValue = decryptPacketData[2];
//			
//			log.debug("#### request string : {}", objectJson);
//			
//			UserDupCheckRequest userDupCheck = AtalkPacketBase.fromJson(objectJson, UserDupCheckRequest.class); 
//
//			////////////////// LOGIC BELOW
//			Optional<MUser> userObjOp = mUserRepository.findByUserId(userDupCheck.getUserId());
//			if (userObjOp.isEmpty()) {
//				AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
//						.httpStatusCode(423)
//						.atalkPacketBase(null)
//						.secureModel(null)
//						.build();
//				return Optional.ofNullable(resultObj);
//			}
//			MUserSignuptoken signupTokenObj = signupTokenObjOp.get();
//			int httpStatusCode = 200;
//			Optional<MUser> userObjOp = mUserRepository.findByUserId(signupRequest.getUserId());
//			if (!userObjOp.isEmpty()) {
//				log.debug("@@@@@@@@@@@ ALREADY THE USER : {} exists", signupRequest.getUserId());
//				AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
//						.httpStatusCode(424)
//						.atalkPacketBase(null)
//						.secureModel(null)
//						.build();
//				return Optional.ofNullable(resultObj);
//			}
//			MUser mUser = new MUser();
//			mUser.setActiveYn("Y");
//			mUser.setUseYn("Y");
//			mUser.setFirstLogin("Y");
//			mUser.setUserId(signupRequest.getUserId());
//			mUser.setUserName(signupRequest.getUserName());
//			mUser.setSignupKey(signupRequest.getSignupToken());
//			mUser.setUserPw(HashComplex.hashWithSha512(
//					signupRequest.getUserId(), 1
//					));
//			mUser.setRegDate(new Date());
//			mUser.setUpdDate(new Date());
//			mUser = mUserRepository.save(mUser);
//			
//			signupTokenObj.setUseYn("Y");
//			signupTokenObj.setUpdDate(new Date());
//			mUserSignupTokenRepository.save(signupTokenObj);
//			
//			log.debug("#### mUser 6 : {}", mUser.toString());
//			
//			////////////////////////////////////////////////////////////////////////////////////
//
//			SignupResponse signupResponse = new SignupResponse();
//			signupResponse.setUserId(mUser.getUserId());
//			AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
//					.httpStatusCode(httpStatusCode)
//					.atalkPacketBase(signupResponse)
//					.secureModel(signupResponse.toFinalModel(packetKey))
//					.build();
//			// DigitalSignComplex.decryptSignature(signingMessageHashServer, extractClientPublicKey);
//			
//			return Optional.ofNullable(resultObj);
			
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return Optional.ofNullable(null);
	}

	@Transactional
	@Override
	public Optional<AtalkDataModelAll> signupMore(SecureDataModel secModel, List<MultipartFile> profileFiles) throws Exception {
		String signatureDataAll = secModel.getData();
		/////////////////////////////////
		String secData = signatureDataAll.substring(
				0,
				signatureDataAll.length() - SecureDataModel.KEY_SEED_SIZE);
		String packetKeySeedValue = signatureDataAll.substring(
				signatureDataAll.length() - SecureDataModel.KEY_SEED_SIZE);
		log.debug("#### packetKeySeedValue : {}", packetKeySeedValue);
		/////////////////////////////////
		
		String encryptedSignupDataHex = secData;
		RedisPacketKeySeed redisKeyObj = redisTaskBroker.findKeySeedData(packetKeySeedValue);
		
		if (!redisKeyObj.getActiveYn().equals("Y")) {
			AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
					.httpStatusCode(425)
					.atalkPacketBase(null)
					.secureModel(null)
					.build();
			return Optional.ofNullable(resultObj);
		}
		
		////////////////////// GET PACKET KEY
		log.debug("#### redisKeyObj : {}", redisKeyObj);
		String packetKey = redisKeyObj.getPacketKey();

		byte [] encBuffer = AesEncDecComplex.hexToBytes(encryptedSignupDataHex);
		byte [] decBuffer = AesEncDecComplex.decryptAesWithIv(encBuffer, packetKey);  // AES DECRYPT
		
		String objectJson = new String(decBuffer);

		int httpStatusCode = 200;
		
		SignupRequest signupRequest = AtalkPacketBase.fromJson(objectJson, SignupRequest.class);
		
		if (StringUtils.isBlank(signupRequest.getUserId())) {
			AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
					.httpStatusCode(423)
					.atalkPacketBase(null)
					.secureModel(null)
					.build();
			return Optional.ofNullable(resultObj);
		}
		
		// 1. USER ID CHECK
		if (StringUtils.isBlank(signupRequest.getUserId())) {
			
			AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
					.httpStatusCode(423)
					.atalkPacketBase(null)
					.secureModel(null)
					.build();
			return Optional.ofNullable(resultObj);
		}
		Optional<MUser> userObjOp = mUserRepository.findByUserId(signupRequest.getUserId());
		if (!userObjOp.isEmpty()) {
			log.debug("@@@@@@@@@@@ ALREADY THE USER : {} exists", signupRequest.getUserId());
			SignupResponse signupResponse = new SignupResponse();
			signupResponse.setUserId(signupRequest.getUserId());
			signupResponse.getError().setCode(1004L);
			signupResponse.getError().setMessage(
					String.format("Alreay user(%s) exists.",
							signupRequest.getUserId()));
			AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
					.httpStatusCode(httpStatusCode)
					.atalkPacketBase(signupResponse)
					.secureModel(signupResponse.toFinalModel(packetKey))
					.build();
			return Optional.ofNullable(resultObj);
		}
		
		// signup token 처리
		MUserSignuptoken signupTokenObj = null;
		if (!StringUtils.isBlank(signupRequest.getSignupToken())) {
			Optional<MUserSignuptoken> signupTokenObjOp = mUserSignupTokenRepository.findBySignupKeyAndUseYn(signupRequest.getSignupToken(), "N");
			if (signupTokenObjOp.isEmpty()) {
				log.debug("@@@@@@@@@@@ No Valid signup token : {} exists", signupRequest.getSignupToken());
				SignupResponse signupResponse = new SignupResponse();
				signupResponse.setUserId(signupRequest.getUserId());
				signupResponse.getError().setCode(1005L);
				signupResponse.getError().setMessage(
						String.format("Invalid signup token : %s",
								signupRequest.getSignupToken()));
				AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
						.httpStatusCode(httpStatusCode)
						.atalkPacketBase(signupResponse)
						.secureModel(signupResponse.toFinalModel(packetKey))
						.build();
				return Optional.ofNullable(resultObj);
			}
			signupTokenObj = signupTokenObjOp.get();
		}
		
		MUser mUser = new MUser();
		mUser.setActiveYn("Y");
		mUser.setUseYn("Y");
		mUser.setFirstLogin("Y");
		mUser.setUserId(signupRequest.getUserId());
		mUser.setUserName(signupRequest.getUserName());
		mUser.setSignupKey(signupRequest.getSignupToken());
		
		mUser.setUserPw(HashComplex.hashWithSha512(
				signupRequest.getPassword(), 1
		));
		
		// 3. LANGUAGE
		if (!StringUtils.isBlank(signupRequest.getLang())) {
			mUser.setLang(EnumLangType.KOREAN.getValue());
		} else {
			if (EnumLangType.checkValidation(signupRequest.getLang())) {
				mUser.setLang(signupRequest.getLang());
			} else {
				SignupResponse signupResponse = new SignupResponse();
				signupResponse.setUserId(mUser.getUserId());
				signupResponse.getError().setCode(2000L);
				signupResponse.getError().setMessage(
						String.format("Invalid lang code : %s(%s)",
								signupRequest.getLang()
								, EnumLangType.langList()));
				
				AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
						.httpStatusCode(httpStatusCode)
						.atalkPacketBase(signupResponse)
						.secureModel(signupResponse.toFinalModel(packetKey))
						.build();
				return Optional.ofNullable(resultObj);
			}
		}
		// 4. birth date
		if (!StringUtils.isBlank(signupRequest.getBirthDate())) {
			SimpleDateFormat dateBirthFormatter = new SimpleDateFormat("yyyy-MM-dd");
			mUser.setBirthDate(dateBirthFormatter.parse(
					signupRequest.getBirthDate()));
		}
		// 5. phone number
		if (!StringUtils.isBlank(signupRequest.getPhoneNumber())) {
			mUser.setPhoneNumber(signupRequest.getPhoneNumber());
		}
		// 6. status message
		if (!StringUtils.isBlank(signupRequest.getStatusMessage())) {
			mUser.setStatusMessage(signupRequest.getStatusMessage());
		}
		
		mUser.setRegDate(new Date());
		mUser.setUpdDate(new Date());
		
		mUser = mUserRepository.save(mUser);
		// 7. PROFILE 이미지 처리
		if (profileFiles != null && profileFiles.size() > 0) {
			if (profileFiles.size() == 2) {
				Optional<MUserProfile> fp = atalkUserProfileServiceLogic.registProfileForeground(
						mUser
						, packetKey
						, profileFiles.get(0));
				Optional<MUserProfile> bp = atalkUserProfileServiceLogic.registProfileBackground(
						mUser
						, packetKey
						, profileFiles.get(1));
				
				mUser.setProfileBgNo(bp.get().getProfileNo());
				mUser.setProfileFgNo(fp.get().getProfileNo());

			} else if (profileFiles.size() == 1) {
				
				
				Optional<MUserProfile> fp = atalkUserProfileServiceLogic.registProfileForeground(
						mUser
						, packetKey
						, profileFiles.get(0));
				mUser.setProfileFgNo(fp.get().getProfileNo());
			}
		}
		
		// signup token key
		if (signupTokenObj != null) {
			signupTokenObj.setUseYn("Y");
			signupTokenObj.setUpdDate(new Date());
			mUserSignupTokenRepository.save(signupTokenObj);
		}
		log.debug("#### mUser : {}", mUser.toString());
		////////////////////////////////////////////////////////////////////////////////////

		SignupResponse signupResponse = new SignupResponse();
		signupResponse.setUserId(mUser.getUserId());
		signupResponse.setUserNo(mUser.getUserNo());
		
		AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
				.httpStatusCode(httpStatusCode)
				.atalkPacketBase(signupResponse)
				.secureModel(signupResponse.toFinalModel(packetKey))
				.build();
		// DigitalSignComplex.decryptSignature(signingMessageHashServer, extractClientPublicKey);
		
		return Optional.ofNullable(resultObj);
	}

	@Transactional
	@Override
	public Optional<AtalkDataModelAll> deleteUser(SecureDataModel secModel) throws Exception {
		String signatureDataAll = secModel.getData();
		/////////////////////////////////
		String secData = signatureDataAll.substring(
				0,
				signatureDataAll.length() - SecureDataModel.KEY_SEED_SIZE);
		String packetKeySeedValue = signatureDataAll.substring(
				signatureDataAll.length() - SecureDataModel.KEY_SEED_SIZE);
		log.debug("#### packetKeySeedValue : {}", packetKeySeedValue);
		/////////////////////////////////
		
		String encryptedSignupDataHex = secData;
		RedisPacketKeySeed redisKeyObj = redisTaskBroker.findKeySeedData(packetKeySeedValue);
		
		if (!redisKeyObj.getActiveYn().equals("Y")) {
			AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
					.httpStatusCode(425)
					.atalkPacketBase(null)
					.secureModel(null)
					.build();
			return Optional.ofNullable(resultObj);
		}
		
		////////////////////// GET PACKET KEY
		log.debug("#### redisKeyObj : {}", redisKeyObj);
		String packetKey = redisKeyObj.getPacketKey();

		byte [] encBuffer = AesEncDecComplex.hexToBytes(encryptedSignupDataHex);
		byte [] decBuffer = AesEncDecComplex.decryptAesWithIv(encBuffer, packetKey);  // AES DECRYPT
		
		String objectJson = new String(decBuffer);

		int httpStatusCode = 200;
		
		DeleteUserRequest deleteUserRequest = AtalkPacketBase.fromJson(objectJson, DeleteUserRequest.class);
		
		Long userNo = deleteUserRequest.getUserNo();
		
		MUser muser = new MUser();
		muser.setUserNo(userNo);
		mUserRepository.delete(muser);
		
		if (deleteUserRequest.getSignUptoken()!=null && !deleteUserRequest.getSignUptoken().isBlank()) {
			mUserSignupTokenRepository.updateSetUse(
					deleteUserRequest.getSignUptoken(), "N");
		}
		
		DeleteUserResponse deleteUserResponse = new DeleteUserResponse();
		deleteUserResponse.setUserNo(userNo);
		AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
				.httpStatusCode(200)
				.atalkPacketBase(deleteUserResponse)
				.secureModel(deleteUserResponse.toFinalModel(packetKey))
				.build();
		// DigitalSignComplex.decryptSignature(signingMessageHashServer, extractClientPublicKey);
		
		return Optional.ofNullable(resultObj);
	}

	@Override
	public Optional<AtalkDataModelAll> resetAllForTest(SecureDataModel secModel) throws Exception {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

	@Override
	public void afterLogin(MUser userObj) throws Exception {
		
		List<ChatHubListInfo> chatHubListInfo = Lists.newArrayList();
		atalkChatHubServiceLogic.retrieveChatHubList(userObj, "2000-01-01 00:00:00", chatHubListInfo);
		
		atalkUnreadCntService.deleteKey(userObj.getUserNo());
		
		chatHubListInfo.forEach(val -> {
			atalkUnreadCntService.setUnreadCount(userObj.getUserNo()
					, val.getChathubNo()
					, val.getLastChat().getUnreadCnt());
		});
	}

	@Override
	public UserResultResponse checkPassword(MUser user, String encPassword) throws Exception {
		if (!encPassword.toUpperCase().equals(user.getUserPw().toUpperCase())) {
			UserResultResponse respObj = new UserResultResponse();
			respObj.setResult("SUCCESS");
			return respObj;
		}
		UserResultResponse respObj = new UserResultResponse();
		respObj.setResult("FAIL");
		return respObj;
	}

	// id = email
	@Override
	public UserResultResponse issuePassword(String userId) throws Exception {
		Optional<MUser> userOp = mUserRepository.findByUserId(userId);
		if (userOp.isPresent()) {
			MUser user = userOp.get();
			String randomPassword = BufferComplex.generateRandomAscii(10);
			String randomPasswordHash = HashComplex.hashWithSha512(randomPassword, 1);
			log.info("#### NEW ISSUED PASSWORD : user id : {}, password : {}, hashPass : {}",
					user.getUserId(), randomPassword, randomPasswordHash);
			mUserRepository.updateTempPassword(user.getUserNo(), randomPasswordHash);
			
			atalkEmailService.sendMail(user.getUserId(), "[ALPINETALK - Issued Temporary Password]", 
					String.format("New Password : %s", randomPassword));
			
			UserResultResponse respObj = new UserResultResponse();
			respObj.setResult("SUCCESS");
			return respObj;
		} else {
			UserResultResponse respObj = new UserResultResponse();
			respObj.setResult("FAILED");
			return respObj;
		}
	}

	@Override
	public UserResultResponse authEmail(String userEmail) throws Exception {
		
		Optional<MUser> userOp = mUserRepository.findByUserId(userEmail);
		
		if (userOp.isPresent()) {
			UserResultResponse respObj = new UserResultResponse();
			respObj.setResult(
					String.format("%s already registed", userEmail));
			return respObj;
		}
	
		String authtoken = RandomHexString.genSecureRandomHex(6);
		
		mAuthEmailRepository.insertEmailAuth(userEmail, authtoken);
		
		atalkEmailService.sendMail(userEmail, "[ALPINETALK - Issued Auth Token]", 
				String.format("Auth Token : %s", authtoken));
	
		UserResultResponse respObj = new UserResultResponse();
		respObj.setResult("TOKEN ISSUED");
		return respObj;
	}

	@Override
	public UserResultResponse checkDupAccount(String userEmail) throws Exception {
		Optional<MUser> userOp = mUserRepository.findByUserId(userEmail);
		
		if (userOp.isPresent()) {
			UserResultResponse respObj = new UserResultResponse();
			respObj.setResult(
					String.format("Already Email : %s exists", userEmail));
			return respObj;
		}
		UserResultResponse respObj = new UserResultResponse();
		respObj.setResult("Available");
		return respObj;
	}

	@Override
	public UserResultResponse checkAuthToken(String userEmail, String tokenValue) throws Exception {
		Optional<MAuthEmail> authValOp = mAuthEmailRepository.findByEmail(userEmail);
		UserResultResponse respObj = new UserResultResponse();
		if (authValOp.isPresent()) {
			if (authValOp.get().getAuthToken().equals(tokenValue)) {
				MAuthEmail obj = authValOp.get();
				obj.setCheckYn("Y");
				mAuthEmailRepository.save(obj);
				respObj.setResult("OK");
			} else {
				respObj.setResult("Not matched");
			}
		} else {
			respObj.setResult("No token exists.");
		}
		return respObj;
	}

	@Override
	public UserDetailResponse editProfile(MUser user, String statusMessage, String userName, MultipartFile fg, MultipartFile bg)
			throws Exception {
		
//		if (!StringUtils.isBlank(statusMessage)) {
//			user.setStatusMessage(statusMessage);
//			mUserRepository.save(user);
//		}
//		if (!StringUtils.isBlank(nickName)) {
//			user.setNickname(nickName);
//			mUserRepository.save(user);
//		}
		user.setStatusMessage(statusMessage);
		user.setUserName(userName);
		mUserRepository.save(user);
		// PROFILE 이미지 처리
		if (fg != null &&
			fg.getBytes().length > 0) {
			atalkUserProfileServiceLogic.updateProfileImage(
					user
					, EnumProfileType.FOREGROUND
					, fg);
		}
		if (bg != null &&
				bg.getBytes().length > 0) {
			atalkUserProfileServiceLogic.updateProfileImage(
					user
					, EnumProfileType.BACKGROUND
					, bg);
		}
		UserDetailResponse respObj = new UserDetailResponse();
		Optional<MUser> uOp= mUserRepository.findByUserNo(user.getUserNo());
		if (uOp.isEmpty()
				|| !uOp.get().getActiveYn().equals("Y")
				|| !uOp.get().getUseYn().equals("Y")) {
			return null;
		}
		UserInfo o = new UserInfo();
		o.setUserName(uOp.get().getUserName());
		o.setUserNo(uOp.get().getUserNo());
		o.setStatusMessage(uOp.get().getStatusMessage());
		o.setNickname(uOp.get().getNickname());
		
		List<String> profileUrlList = _getProfileInfo(uOp.get());
		o.setProfileFgThumbUrl(profileUrlList.get(0));
		o.setProfileFgUrl(profileUrlList.get(1));
		o.setProfileBgThumbUrl(profileUrlList.get(2));
		o.setProfileBgUrl(profileUrlList.get(3));
		respObj.setDetail(o);
		return respObj;
	}
	
	/**
	 * 
	 * @param user
	 * @return
	 */
	private List<String> _getProfileInfo(MUser user) {
		List<String> profileList = Lists.newArrayList();
		String fgThumbnailPath = "";
		String fgViewPath = "";
		String bgThumbnailPath = "";
		String bgViewPath = "";
		String contextPath = servletContext.getContextPath();
		if (user.getProfileFgNo()!=null) {
			fgThumbnailPath = String.format("%s%s%s/%s/%d",
					atalkConfig.getChatConfig().getBaseAddress()
					, contextPath 
					, atalkConfig.getProfileConfig().getBaseUrl()
					, "thumb"
					, user.getProfileFgNo());
			fgViewPath = String.format("%s%s%s/%s/%d",
					atalkConfig.getChatConfig().getBaseAddress()
					, contextPath 
					, atalkConfig.getProfileConfig().getBaseUrl()
					, "view"
					, user.getProfileFgNo());
		}
		if (user.getProfileBgNo()!=null) {
			bgThumbnailPath = String.format("%s%s%s/%s/%d",
					atalkConfig.getChatConfig().getBaseAddress()
					, contextPath 
					, atalkConfig.getProfileConfig().getBaseUrl()
					, "thumb"
					, user.getProfileBgNo());
			bgViewPath = String.format("%s%s%s/%s/%d",
					atalkConfig.getChatConfig().getBaseAddress()
					, contextPath 
					, atalkConfig.getProfileConfig().getBaseUrl()
					, "view"
					, user.getProfileBgNo());
		}
		profileList.add(fgThumbnailPath);
		profileList.add(fgViewPath);
		profileList.add(bgThumbnailPath);
		profileList.add(bgViewPath);
		
		return profileList;
	}

	@Override
	public UserResultResponse changeUserLanguage(MUser user, String lang) throws Exception {
		UserResultResponse resp = new UserResultResponse();
		if (EnumLangType.checkValidation(lang)) {
			user.setLang(lang);
			mUserRepository.save(user);
			resp.setResult("SUCCESS");
		} else {
			resp.setResult("FAIL: Invalid lang code, lang range : ko,jp,es,en,cn,zh");
		}
		return resp;
	}

	@Override
	public UserResultResponse logout(MUser user) throws Exception {
		UserResultResponse resp = new UserResultResponse();
		resp.setResult("SUCCESS");
		
		user.setPublicKey("");
		user.setMobileToken(null);
		
		return resp;
	}

	@Override
	public UserResultResponse deactivate(MUser user) throws Exception {
		
		String outResult = this.deactivateUser(user.getUserNo());
		log.info("################# DEACTIVATED USER : {}, result : {}", user.getUserId(), outResult);
		
		UserResultResponse resp = new UserResultResponse();
		resp.setResult("SUCCESS");
		
		return resp;
	}
	
	
	private String deactivateUser(
			Long userNo) {
		StoredProcedureQuery query = entityManager.createStoredProcedureQuery("PROC_DEACTIVATE_USER");
		log.debug("#### DEACTIVATE USER userNo : {}", userNo);
		query.registerStoredProcedureParameter("IN_USER_NO", 			Long.class, 	ParameterMode.IN);
		query.registerStoredProcedureParameter("OUT_RESULT", 			String.class, 	ParameterMode.OUT);
		
		query.setParameter("IN_USER_NO", userNo);
		query.execute();

		String outDeactivateUser = (String) query.getOutputParameterValue("OUT_RESULT");
		
		log.debug("### PROC_DEACTIVATE_USER RESULT :: outDeactivateUser : {}",
				outDeactivateUser);
		return outDeactivateUser;
	}

	@Override
	public UserDetailResponse info(MUser user, Long userNo) throws Exception {
		UserDetailResponse respObj = new UserDetailResponse();
		Optional<MUser> uOp= mUserRepository.findByUserNo(userNo);
		if (uOp.isEmpty()
				|| !uOp.get().getActiveYn().equals("Y")
				|| !uOp.get().getUseYn().equals("Y")) {
			return null;
		}
		UserInfo o = new UserInfo();
		o.setUserName(uOp.get().getUserName());
		o.setUserNo(uOp.get().getUserNo());
		o.setStatusMessage(uOp.get().getStatusMessage());
		o.setNickname(uOp.get().getNickname());

		List<String> profileUrlList = _getProfileInfo(uOp.get());
		o.setProfileFgThumbUrl(profileUrlList.get(0));
		o.setProfileFgUrl(profileUrlList.get(1));
		o.setProfileBgThumbUrl(profileUrlList.get(2));
		o.setProfileBgUrl(profileUrlList.get(3));
		respObj.setDetail(o);
		return respObj;
	}

	@Override
	public UserDetailResponse deleteFg(MUser user) throws Exception {
		UserDetailResponse respObj = new UserDetailResponse();
		Optional<MUser> uOp= mUserRepository.findByUserNo(user.getUserNo());
		if (uOp.isEmpty()
				|| !uOp.get().getActiveYn().equals("Y")
				|| !uOp.get().getUseYn().equals("Y")) {
			return null;
		}
		user.setProfileFgNo(null);
		mUserRepository.save(user);
		UserInfo o = new UserInfo();
		o.setUserName(uOp.get().getUserName());
		o.setUserNo(uOp.get().getUserNo());
		o.setStatusMessage(uOp.get().getStatusMessage());
		o.setNickname(uOp.get().getNickname());
		
		List<String> profileUrlList = _getProfileInfo(user);
		o.setProfileFgThumbUrl(profileUrlList.get(0));
		o.setProfileFgUrl(profileUrlList.get(1));
		o.setProfileBgThumbUrl(profileUrlList.get(2));
		o.setProfileBgUrl(profileUrlList.get(3));
		respObj.setDetail(o);
		return respObj;
	}

	@Override
	public UserDetailResponse deleteBg(MUser user) throws Exception {
		UserDetailResponse respObj = new UserDetailResponse();
		Optional<MUser> uOp= mUserRepository.findByUserNo(user.getUserNo());
		
		if (uOp.isEmpty()
				|| !uOp.get().getActiveYn().equals("Y")
				|| !uOp.get().getUseYn().equals("Y")) {
			return null;
		}
		user.setProfileBgNo(null);
		mUserRepository.save(user);
		UserInfo o = new UserInfo();
		o.setUserName(uOp.get().getUserName());
		o.setUserNo(uOp.get().getUserNo());
		o.setStatusMessage(uOp.get().getStatusMessage());
		o.setNickname(uOp.get().getNickname());
		
		List<String> profileUrlList = _getProfileInfo(user);
		o.setProfileFgThumbUrl(profileUrlList.get(0));
		o.setProfileFgUrl(profileUrlList.get(1));
		o.setProfileBgThumbUrl(profileUrlList.get(2));
		o.setProfileBgUrl(profileUrlList.get(3));
		respObj.setDetail(o);
		return respObj;
	}
}
