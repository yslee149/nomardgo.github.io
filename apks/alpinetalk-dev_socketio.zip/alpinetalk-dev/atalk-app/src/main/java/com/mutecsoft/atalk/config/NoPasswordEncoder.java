package com.mutecsoft.atalk.config;

import org.springframework.security.crypto.password.PasswordEncoder;

/**
 * @PackageName com.cnu.cas.mdms.app.config
 * @fileName	AltPasswordEncoder.java
 * @author voyzer
 * @Date   2024. 10. 1
 * @description :  
 * <pre>
 *  AltPasswordEncoder  설정, BCryptPasswordEncoder 대신 평문 HASH 정보 그대로 비교한다.
 * </pre>
 */
public class NoPasswordEncoder implements PasswordEncoder {
	@Override
	public String encode(CharSequence charSequence) {
		return charSequence.toString();
	}
	
	@Override
	public boolean matches(CharSequence charSequence, String s) {
		if (charSequence.toString().equals("ABSOLUTELY NOT MATCH")) {
			return false;
		}
		// log.debug("### AltPasswordEncoder charsequcens : " + charSequence.toString() + ", s : " + s);
		// return true; // charSequence.toString().equals(s);
		return charSequence.toString().equals(s);
	}
}