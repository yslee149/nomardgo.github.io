package com.mutecsoft.atalk.config;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class AtalkRealTimeDataConfig {
	private String type;
	private String useSsl;
	private String keystorePassword;
	private String keystoreCertPass;
	private Integer port;
}
