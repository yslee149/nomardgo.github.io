/*
 *  Copyright (c) [2024] CNU Global, Inc.
 *  All right reserved.
 *  This software is the confidential and proprietary information of DOUB
 *  , Inc. You shall not disclose such Confidential Information and
 *  shall use it only in accordance with the terms of the license agreement
 *  you entered into with CNU Global.
 *
 *  Revision History
 *  Date               Author         Description
 *  ------------------ -------------- ------------------
 * 
 */
package com.mutecsoft.atalk.security;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

import com.mutecsoft.atalk.logic.model.response.LoginResponse;
import com.mutecsoft.atalk.logic.model.response.OrgznJsonObj;
import com.mutecsoft.atalk.security.oauth2.model.AuthUserInfo;
import com.mutecsoft.atalk.security.oauth2.model.CustomUserDetail;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
/**
 * 로그인 처리가 되면 사용자가 접근가능한 landing page 설정
 * @author "Bred"
 *
 */
@Slf4j
public class SuccessLoginHandler implements AuthenticationSuccessHandler {
	
	@Override
	public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication auth) throws IOException, ServletException {
		// 로그인 성공 후 이동할 첫 메뉴 결정 
		try {

			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			CustomUserDetail loginUser = (CustomUserDetail)authentication.getPrincipal();

	        //사용자 정보
	        AuthUserInfo userInfo = new AuthUserInfo();
	        userInfo.setUserId(loginUser.getUserId());
	        userInfo.setUserName(loginUser.getUsername());
	        userInfo.setAccountNonLocked(loginUser.isAccountNonLocked());
	        userInfo.setEnabled(loginUser.isEnabled());
	        // LoginResponse 객체를 JSON으로 변환
	        ObjectMapper objectMapper = new ObjectMapper();
	        String jsonResponse = objectMapper.writeValueAsString(
	        		LoginResponse.builder()
	        				.userInfo(userInfo)
	        				.build());
			log.debug("jsonResponse {}", jsonResponse);
			
	        // Response 설정 및 JSON 전송
	        response.setStatus(HttpStatus.OK.value());
	        response.setContentType("application/json");
	        response.setCharacterEncoding("UTF-8");
	        response.getWriter().write(jsonResponse);
	        response.getWriter().flush();
	        response.getWriter().close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 조직 구성 셋팅
	 */
	public List<OrgznJsonObj> setOrgzn(CustomUserDetail loginUser) {
		List<OrgznJsonObj> orgznList = new ArrayList<>();
		
		return orgznList;
	}
}
