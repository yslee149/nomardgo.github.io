/*
 *  Copyright (c) 2024 CNU Global, Inc.
 *  All right reserved.
 *  This software is the confidential and proprietary information of DOUB
 *  , Inc. You shall not disclose such Confidential Information and
 *  shall use it only in accordance with the terms of the license agreement
 *  you entered into with CNU Global.
 *
 *  Revision History
 *  Date               Author         Description
 *  ------------------ -------------- ------------------
 *  2024. 8. 12.	   Hong Seok Woo  
 */
package com.mutecsoft.atalk.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mutecsoft.atalk.common.model.MUser;
import com.mutecsoft.atalk.common.repository.MUserRepository;
import com.mutecsoft.atalk.logic.model.response.ResResult;
import com.mutecsoft.atalk.service.UserAccountService;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 */
@Slf4j
@Service("userAccountService")
@Transactional
public class UserAccountServiceImpl implements UserAccountService {
	

	@Autowired
	MUserRepository muserRepository;

	@Override
	public void updatePassword(MUser user) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int updateTmpPassword(MUser user) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getUserId(MUser user) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<ResResult> issueTempPassword(MUser user) throws Exception {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

	@Override
	public MUser getUserByUserId(String userId) {
		try {
			Optional<MUser> userOp = muserRepository.findByUserId(userId);
			return userOp.get();
		} catch (Exception e) {
			return null;
		}
	}
}
