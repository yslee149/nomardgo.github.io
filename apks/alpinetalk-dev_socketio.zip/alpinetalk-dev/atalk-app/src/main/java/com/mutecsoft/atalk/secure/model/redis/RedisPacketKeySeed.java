package com.mutecsoft.atalk.secure.model.redis;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Builder
@Getter
@Setter
@NoArgsConstructor // Required for MyBatis
@AllArgsConstructor
@ToString
@Data
public class RedisPacketKeySeed implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2971679056131213121L;

	@JsonProperty("active_yn")
	private String activeYn;

	@JsonProperty("seed")
	private String seed;
	
	@JsonProperty("packet_key")
	private String packetKey;

	@JsonProperty("user_no")
	private Long userNo;
	
	@JsonProperty("created_dt")
	private Date createdDt;
}
