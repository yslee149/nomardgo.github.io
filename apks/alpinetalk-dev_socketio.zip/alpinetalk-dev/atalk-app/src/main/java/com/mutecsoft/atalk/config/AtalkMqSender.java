package com.mutecsoft.atalk.config;

import java.security.SecureRandom;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.amqp.core.MessagePostProcessor;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mutecsoft.atalk.common.model.MUser;
import com.mutecsoft.atalk.component.redis.RedisTaskBroker;
import com.mutecsoft.atalk.constant.EnumPushType;
import com.mutecsoft.atalk.util.AtalkPacketUtil;

import jakarta.annotation.PostConstruct;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Component
@NoArgsConstructor
@AllArgsConstructor
@Slf4j
public class AtalkMqSender {
//	
	@Autowired
	private RabbitTemplate rabbitTemplate;

	@Autowired
	private RabbitAdmin rabbitAdmin;

	@Autowired
	RedisTaskBroker redisTaskBroker;
	
	@Autowired
	AtalkConfig atalkConfig;
	
	MessagePostProcessor messagePostProcessor;
	@PostConstruct
	public void init() {
		// this.rabbitTemplate.setBeforePublishPostProcessors(myMessagePostProcessor());
		messagePostProcessor = msg -> {
			msg.getMessageProperties().setExpiration(String.valueOf(60 * 1000L));
			return msg;
		};
	}

//	@Bean
//	public MessagePostProcessor myMessagePostProcessor() {
//	    return message -> null;
//	}
	
	/**
	 * noti 메시지 처리
	 * 
	 * @param exchange
	 * @param queueName
	 * @param message
	 * @param ttl
	 * @param user
	 * @param pushData
	 */
	@Deprecated
	public void publishMessageWithTTL_(String exchange, String queueName, String message, long ttl) {
		try {
//			MessagePostProcessor messagePostProcessor = msg -> {
//				msg.getMessageProperties().setExpiration(String.valueOf(ttl));
//				return msg;
//			};
			rabbitAdmin.declareQueue(new Queue(queueName, false, false, true, null));
			// durable = true => system reboot exists
			// exclusive = false => only one connection
			// autoDelete = true => q get deleted unused.
			log.info("### exchange : {}, queueName: {}, message : {}, ttl : {}", exchange, queueName, message, ttl);
			rabbitTemplate.convertAndSend(exchange, queueName, message, messagePostProcessor);
			// System.out.println("Published message with TTL: " + ttl + " ms");
			
			
			
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
	}
	
	/**
	 * noti 메시지 처리
	 * 
	 * @param exchange
	 * @param queueName
	 * @param message
	 * @param ttl
	 * @param user
	 * @param pushData
	 */
	public void publishMessageWithTTLThruWebSocket(
			Long chatHubNo, String message) {
		try {
			
			String groupName = String.format("chathub_%d",  chatHubNo);
			AtalkWebsocketConfig.broadCastToTheJoinedChathub(
					groupName
					, message);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
	}
	
	/**
	 * push 메시지 처리
	 * 
	 * @param user
	 * @param pushData
	 */
	public void sendPush(MUser user, Map<String, String> pushData) {
		try {
			if (StringUtils.isBlank(user.getMobileToken())) {
				return;
			}
			if (user.getDeviceType() != null) {
				if (user.getDeviceType().equals(EnumPushType.FCM.getValue())
						||
					user.getDeviceType().equals(EnumPushType.FCM2.getValue())) {
					try {
						AtalkPacketUtil.requestAtalkMessage(pushData
								, atalkConfig.getPushAgentUrl());
					} catch (Exception e) {
						log.error("@@@@ : {}", e);
					}				
				} else {
					// IOS push not supported
					log.error("@@@@ other push type not supported : {}", user.getDeviceType());
				}
			}
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
	}

	public String makeRandomPw(int len) {
	    // 소문자, 대문자, 숫자 
		final String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
		SecureRandom rm = new SecureRandom();
		StringBuffer sb = new StringBuffer();
		for (int i=0; i<len; i++) {
			int index = rm.nextInt(chars.length());
			//index의 위치한 랜덤값
			sb.append(chars.charAt(index));
		}
		return sb.toString();
	}
}
