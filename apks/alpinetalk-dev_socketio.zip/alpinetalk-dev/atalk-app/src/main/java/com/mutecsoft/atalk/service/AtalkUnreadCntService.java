package com.mutecsoft.atalk.service;

public interface AtalkUnreadCntService {
	void deleteKey(Long userNo);
	void incrementUnreadCount(Long userNo, Long chatHubNo);
	void setUnreadCount(Long userNo, Long chatHubNo, Long unreadCnt);
	void resetUnreadCount(Long userNo, Long chatHubNo);
	int getUnreadCount(Long userNo, Long chatHubNo);
	int getTotalUnreadCount(Long userNo);
}

