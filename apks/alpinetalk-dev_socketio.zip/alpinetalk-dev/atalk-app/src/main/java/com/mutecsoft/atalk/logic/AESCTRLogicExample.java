package com.mutecsoft.atalk.logic;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import com.google.common.collect.Maps;

import java.nio.ByteBuffer;
import java.security.SecureRandom;
import java.util.Map;

public class AESCTRLogicExample {

	private static final String ALGORITHM = "AES";
	private static final String TRANSFORMATION = "AES/CTR/NoPadding";  // NOT CBC BLOCK
	private static final int AES_KEY_SIZE = 256;
	private static final int IV_SIZE = 16;
	
	public static void main(String[] args) throws Exception {
		
		{
			String [] aaa = { "aaa", "bbb", "bbb", "ccc", "aaa" };
			Map<String, Integer> idCountByMeter = Maps.newHashMap();
			for (String val : aaa) {
				
				idCountByMeter.compute(val
						, (key, value) -> (value == null) ? 1 : value + 1);
				
			}
			System.out.println(idCountByMeter);
		}
		{
			// 5 bytes plain text case
			// Generate AES key and IV
			// SecretKey secretKey = generateAESKey();
	        
	        
			// Example 256-bit AES key in hex (32 bytes / 64 hex characters)
			String hexKey = "b62e85041ad6d2ddfa4863b21f9245ffd9ca7751ae5840cb3dbff6e047484e8f";
			String ivHex = "dd3b08b9afcd1509a622b882f73477f8";
			
			// String ivHex = "dd3b08b9afcd1509a622b882" + "00000000";   // 12 bytes + 4 bytes
			
			// Convert hex string to SecretKey
			SecretKey secretKey = hexStringToSecretKey(hexKey, "AES");
			
			
			// byte[] iv = generateIV();
			
			byte[] iv = hexToBytes(ivHex);
			
			// Sample plaintext (19 bytes)
			byte[] plaintext = "abcde".getBytes();
			
			// Encrypt the plaintext
			byte[] encrypted = encrypt(plaintext, secretKey, iv);
			System.out.println("Encrypted (Hex): " + bytesToHex(encrypted));
			
			// Decrypt the ciphertext
			byte[] decrypted = decrypt(encrypted, secretKey, iv);
			System.out.println("Decrypted: " + new String(decrypted));
		}
		
		{
			// Generate AES key and IV
			// SecretKey secretKey = generateAESKey();
	        
	        
			// Example 256-bit AES key in hex (32 bytes / 64 hex characters)
			String hexKey = "b62e85041ad6d2ddfa4863b21f9245ffd9ca7751ae5840cb3dbff6e047484e8f";
			String ivHex = "dd3b08b9afcd1509a622b882f73477f8";
			
			// String ivHex = "dd3b08b9afcd1509a622b882" + "00000000";   // 12 bytes + 4 bytes
			
			// Convert hex string to SecretKey
			SecretKey secretKey = hexStringToSecretKey(hexKey, "AES");
			
			
			// byte[] iv = generateIV();
			
			byte[] iv = hexToBytes(ivHex);
			
			// Sample plaintext (19 bytes)
			byte[] plaintext = "abcdefg123456789".getBytes();
			
			// Encrypt the plaintext
			byte[] encrypted = encrypt(plaintext, secretKey, iv);
			System.out.println("Encrypted (Hex): " + bytesToHex(encrypted));
			
			// Decrypt the ciphertext
			byte[] decrypted = decrypt(encrypted, secretKey, iv);
			System.out.println("Decrypted: " + new String(decrypted));
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		// 16 bytes block logics
		{
			System.out.println("#### 32 bytes plain block");
	        
			// Example 256-bit AES key in hex (32 bytes / 64 hex characters)
			String hexKey = "b62e85041ad6d2ddfa4863b21f9245ffd9ca7751ae5840cb3dbff6e047484e8f";
			String ivHex = "dd3b08b9afcd1509a622b882f73477f8";
			
			// Convert hex string to SecretKey
			SecretKey secretKey = hexStringToSecretKey(hexKey, "AES");
			byte[] iv = hexToBytes(ivHex);
			// byte[] plaintext = "abcdefg123456789abcdefg123456789".getBytes();
			byte[] plaintext = "abcde".getBytes();
			
			byte [] targetBuff = null;
			byte[] finalIv = new byte[16];
			
			int loopCnt = plaintext.length % 16 == 0 ? (plaintext.length / 16) : (plaintext.length / 16 + 1);
			int targetBuffCount = 0;
			
			int val = 0;
			StringBuffer sb = new StringBuffer();
			for (int i =0; i < loopCnt; i++) {
				if (i== (loopCnt -1)) { // last looped buffer
					targetBuffCount = plaintext.length % 16;
					targetBuffCount = plaintext.length % 16 == 0 ? 16 : plaintext.length % 16;
				} else {
					targetBuffCount = 16;
				}
				targetBuff = new byte[targetBuffCount];
				for (int j=0; j < targetBuffCount; j++) {
					targetBuff[j] = plaintext[ i * 16 + j];
				}
				for (int j=0; j < 12; j++) {  // 12 bytes iv block
					finalIv[j] = iv[j];
				}
				byte [] tiv = intToBytesBigEndian(val++);  // iv last 4 bytes counts per 16 bytes block loop
				for (int j=12, k=0; j < 16; j++,k++) {
					finalIv[j] = (byte)(iv[j] | tiv[k]);
				}
				// Encrypt the plaintext
				byte[] encrypted = encrypt(targetBuff, secretKey, finalIv);
				System.out.println("Encrypted (Hex): " + bytesToHex(encrypted));
				
//				// Decrypt the ciphertext
//				byte[] decrypted = decrypt(encrypted, secretKey, iv);
//				sb.append(new String(decrypted));
////				System.out.println("Decrypted: " + new String(decrypted));
			}
			System.out.println(sb.toString());
		}
	}
	
	
    // Convert int to byte array (big-endian)
    public static byte[] intToBytesBigEndian(int value) {
        return ByteBuffer.allocate(4).putInt(value).array();
    }
    

    // Convert hex string to SecretKey
    public static SecretKey hexStringToSecretKey(String hexKey, String algorithm) {
        byte[] decodedKey = hexToBytes(hexKey);
        return new SecretKeySpec(decodedKey, algorithm);
    }

    // Helper method: Convert hex string to byte array
    public static byte[] hexToBytes(String hex) {
        int len = hex.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4)
                                 + Character.digit(hex.charAt(i + 1), 16));
        }
        return data;
    }
    
    public static SecretKey generateAESKey() throws Exception {
        KeyGenerator keyGenerator = KeyGenerator.getInstance(ALGORITHM);
        keyGenerator.init(AES_KEY_SIZE);
        return keyGenerator.generateKey();
    }

    public static byte[] generateIV() {
        byte[] iv = new byte[IV_SIZE];
        new SecureRandom().nextBytes(iv);
        return iv;
    }

    public static byte[] encrypt(byte[] plainText, SecretKey key, byte[] iv) throws Exception {
        Cipher cipher = Cipher.getInstance(TRANSFORMATION);
        cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(iv));
        return cipher.doFinal(plainText);
    }

    public static byte[] decrypt(byte[] cipherText, SecretKey key, byte[] iv) throws Exception {
        Cipher cipher = Cipher.getInstance(TRANSFORMATION);
        cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(iv));
        return cipher.doFinal(cipherText);
    }

    public static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02X", b));
        }
        return sb.toString();
    }
}
