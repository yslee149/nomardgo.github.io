package com.mutecsoft.atalk.logic.model.response;

import com.mutecsoft.atalk.model.presentation.ResBasicRepresentationModel;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * RESULT
 * 
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class ResResult extends ResBasicRepresentationModel<ResResult> {

	private Boolean boolVal;
	
	private String errorMsg;
}
