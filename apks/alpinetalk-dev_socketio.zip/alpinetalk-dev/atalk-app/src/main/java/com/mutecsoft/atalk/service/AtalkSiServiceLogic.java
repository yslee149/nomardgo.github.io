package com.mutecsoft.atalk.service;

import com.mutecsoft.atalk.common.model.MUser;
import com.mutecsoft.atalk.logic.model.response.AgreementResponse;
import com.mutecsoft.atalk.logic.model.si.SiAgreementResponse;

public interface AtalkSiServiceLogic {

	SiAgreementResponse getLatestSiAgreement() throws Exception;
	
	Long agree(MUser user, Long version) throws Exception;
	
	AgreementResponse getHist(MUser user) throws Exception;
}

