package com.mutecsoft.atalk.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import com.mutecsoft.atalk.common.model.MAmigo;
import com.mutecsoft.atalk.common.model.MChathub;
import com.mutecsoft.atalk.common.model.MChathubUser;
import com.mutecsoft.atalk.common.model.MUser;
import com.mutecsoft.atalk.common.repository.MAmigoRepository;
import com.mutecsoft.atalk.common.repository.MAmigoSetRepository;
import com.mutecsoft.atalk.common.repository.MChathubRepository;
import com.mutecsoft.atalk.common.repository.MChathubUserRepository;
import com.mutecsoft.atalk.common.repository.MUserRepository;
import com.mutecsoft.atalk.component.redis.RedisTaskBroker;
import com.mutecsoft.atalk.config.AtalkConfig;
import com.mutecsoft.atalk.config.AtalkMqSender;
import com.mutecsoft.atalk.config.AtalkWebsocketConfig;
import com.mutecsoft.atalk.constant.AtalkConstant;
import com.mutecsoft.atalk.constant.EnumChatHubType;
import com.mutecsoft.atalk.constant.EnumChatSubType;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.logic.model.chat.Chat;
import com.mutecsoft.atalk.logic.model.chathub.ChatHubInfo;
import com.mutecsoft.atalk.logic.model.chathub.ChatHubListInfo;
import com.mutecsoft.atalk.logic.model.chathub.ChatHubUser;
import com.mutecsoft.atalk.logic.model.chathub.ChatInfoLast;
import com.mutecsoft.atalk.logic.model.chathub.ChathubInfoRequest;
import com.mutecsoft.atalk.logic.model.chathub.ExitChathubResponse;
import com.mutecsoft.atalk.logic.model.chathub.InviteChathubRequest;
import com.mutecsoft.atalk.logic.model.chathub.InviteChathubResponse;
import com.mutecsoft.atalk.logic.model.chathub.KickOutChathubResponse;
import com.mutecsoft.atalk.logic.model.chathub.ListChathubRequest;
import com.mutecsoft.atalk.logic.model.chathub.ListChathubResponse;
import com.mutecsoft.atalk.logic.model.chathub.OpenChathubRequest;
import com.mutecsoft.atalk.logic.model.chathub.OpenChathubResponse;
import com.mutecsoft.atalk.logic.model.chathub.OpenChathubWithTitleRequest;
import com.mutecsoft.atalk.logic.model.noti.ChatDataNoti;
import com.mutecsoft.atalk.logic.util.RandomHexString;
import com.mutecsoft.atalk.logic.util.RsaComplex;
import com.mutecsoft.atalk.secure.model.redis.RedisPacketKeySeed;
import com.mutecsoft.atalk.service.AtalkChatHubServiceLogic;
import com.mutecsoft.atalk.service.AtalkChatServiceLogic;
import com.mutecsoft.atalk.service.AtalkUnreadCntService;

import jakarta.annotation.PostConstruct;
import jakarta.persistence.EntityManager;
import jakarta.persistence.ParameterMode;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.StoredProcedureQuery;
import jakarta.servlet.ServletContext;
import lombok.extern.slf4j.Slf4j;

/**
 * 채팅방 관련 서비스
 * 
 */
@Slf4j
@Service("atalkChatHubServiceLogic")
public class AtalkChatHubServiceLogicImpl implements AtalkChatHubServiceLogic {

	@Autowired
	MUserRepository mUserRepository;
	
	@Autowired
	MChathubRepository mChathubRepository;

	@Autowired
	MChathubUserRepository mChathubUserRepository;
	
	@Autowired
	MAmigoSetRepository mAmigoSetRepository;

	@Autowired
	MAmigoRepository mAmigoRepository;
	
	@Autowired
	RedisTaskBroker redisTaskBroker;
	
	@PersistenceContext
	EntityManager entityManager;

	ObjectMapper objectMapper;
	
	@Autowired
	AtalkChatServiceLogic atalkChatServiceLogic;

	SimpleDateFormat dateFormatter;
	
	@Autowired
	private AtalkMqSender atalkMqSender;
	
	@Autowired
	AtalkUnreadCntService atalkUnreadCntService;
	@Autowired
	AtalkConfig atalkConfig;
	
	@Autowired
	ServletContext servletContext;
	
	@PostConstruct
	private void init() {
		objectMapper = new ObjectMapper();
		dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	}

	@Override
	public Pair<MChathub, String> getChatHubInfo2(Long myNo, ChathubInfoRequest reqObj) throws JsonProcessingException {
		Optional<MChathub> chatHubObjOp = mChathubRepository.findByChathubNoAndUseYn(reqObj.getChathubNo(), "Y");
		if (chatHubObjOp.isEmpty()) {
			return Pair.of(null, "N");
		}
		return Pair.of(chatHubObjOp.get(), "N");
	}
	
	/**
	 * 
	 */
	@Override
	public Pair<MChathub, String> getChatHubInfo(Long myNo, List<Long> userNoList) throws JsonProcessingException {
		StoredProcedureQuery query = entityManager.createStoredProcedureQuery("PROC_GEN_CHATHUB");

		String userNoListJson = objectMapper.writeValueAsString(userNoList);
		
		log.debug("#### userNoListJson : {}", userNoListJson);
		
		query.registerStoredProcedureParameter("IN_USER_NO", 		Integer.class, 	ParameterMode.IN);
		query.registerStoredProcedureParameter("IN_USER_LIST", 	String.class, 	ParameterMode.IN);
		query.registerStoredProcedureParameter("OUT_CHATHUB_NO",	Long.class, ParameterMode.OUT);
		query.registerStoredProcedureParameter("OUT_DATETIME", 		String.class, ParameterMode.OUT);
		query.registerStoredProcedureParameter("OUT_DEBUGSTRING", 		String.class, ParameterMode.OUT);
		query.registerStoredProcedureParameter("OUT_NEW_YN", 		String.class, ParameterMode.OUT);
		
		query.setParameter("IN_USER_NO", myNo);
		query.setParameter("IN_USER_LIST", userNoListJson);

		query.execute();

		Long outChatHubNo= (Long) query.getOutputParameterValue("OUT_CHATHUB_NO");
		String outDateTime = (String) query.getOutputParameterValue("OUT_DATETIME");
		String outDebugString = (String) query.getOutputParameterValue("OUT_DEBUGSTRING");
		String outNewYn = (String) query.getOutputParameterValue("OUT_NEW_YN");
		
		log.debug("### PROC_GEN_CHATHUB RESULT :: outChatHubNo : {}, outDateTime : {}, outDebugString : {}",
				outChatHubNo, outDateTime, outDebugString);
//		
//		ChatHubInfo retChatHubObj = new ChatHubInfo();
//		retChatHubObj.setChathubNo(outChatHubNo);
		Optional<MChathub> chatHubObjOp = mChathubRepository.findByChathubNoAndUseYn(outChatHubNo, "Y");
		if (chatHubObjOp.isEmpty()) {
			return Pair.of(null, "N");
		}
//		retChatHubObj.setChathubType(chatHubObjOp.get().getChathubType());
//		retChatHubObj.setUserNo(chatHubObjOp.get().getUserNo());
//		retChatHubObj.setUsersNum(chatHubObjOp.get().getUsersNum());
//		retChatHubObj.setUseYn(chatHubObjOp.get().getUseYn());

		return Pair.of(chatHubObjOp.get(), outNewYn);
	}


	/**
	 * 채팅방 오픈
	 * 
	 */
	@Override
	public OpenChathubResponse openChathub(MUser user, OpenChathubRequest reqObj)
			throws Exception {
		log.debug("################# OPEN CHATHUB");
		List<Long> chatHubUserList = reqObj.getUserNoList();
		if (chatHubUserList.size() < 1L) {
			return null;
		}
		///////////////////
		Pair<MChathub, String> mChatHubInfoOp = getChatHubInfo(
				user.getUserNo()
				, reqObj.getUserNoList());
		
		MChathub mChatHubInfo = mChatHubInfoOp.getLeft();
		String newChatHubYn = mChatHubInfoOp.getRight();
		if (mChatHubInfo == null || mChatHubInfo.getChathubNo().equals(0L)) {
			log.error("@@@@ No chathub info");
			return null;
		}
			
		String myEncChathubKey = "";
		
		List<MChathubUser> mChatHubUserList = mChathubUserRepository.findByChathubNoAndJoinYn(
				mChatHubInfo.getChathubNo(), "Y");
		String newChathubOpenMessage = mChathubUserRepository.chatUserNamesWithComma(
				mChatHubInfo.getChathubNo());

		/////////////////////////////////////////////////////////////////////////
		if (newChatHubYn.equals("Y")) {
			// 신규 대화방 케이스
			String chatEncDecKey = RandomHexString.genSecureRandomHex(64);
			
			// 긴급 상황시 사용자에게 키 재할당용.
			
			String encChatEncDecKeyUrgent =RsaComplex.encrypt(chatEncDecKey, AtalkConstant.serverPublicKey);
			mChathubRepository.updateEncUrgentKey(mChatHubInfo.getChathubNo(), encChatEncDecKeyUrgent);
			
			////////////////////////////////////////
			if (mChatHubUserList != null) {
				// 사용자별 대화방키 암호화 업데이트
				String userEncrypteChatKey = null;
				for (MChathubUser chathubUser : mChatHubUserList) {
					Optional<MUser> mUserOp = mUserRepository.findByUserNo(chathubUser.getUserNo());
					String userPublicKey = mUserOp.get().getPublicKey();
					if (userPublicKey != null && !userPublicKey.isBlank()) {
						userEncrypteChatKey = RsaComplex.encrypt(chatEncDecKey, userPublicKey);
						mChathubUserRepository.updateEncryptChatKey(
								mChatHubInfo.getChathubNo()
								, chathubUser.getUserNo()
								, userEncrypteChatKey);
					}
				}
			}
			
			Chat messageObj = atalkChatServiceLogic.getLastMessage(mChatHubInfo.getChathubNo());
			// 신규 대화방 생성인 경우이므로 멀티대화방
			if (mChatHubInfo.getChathubType().equals(EnumChatHubType.MULTI_USER.getValue())) {
				// NOTI MESSAGE 처리
				RedisPacketKeySeed pktSeedObj = null;
				String seedValue = null;
				String packetKeyOther = null;
				ChatDataNoti chatDataNoti = new ChatDataNoti();
				chatDataNoti.setChatData(messageObj);
				
				SecureDataModel model = null;
				String notiCode = null;
				String message = null;
				String queueName = null;
				Optional<MUser> uOp = null;
				Map<String, String> map = new HashMap<String, String>();

				int unreadCntSum = 0;
				
				notiCode = String.format("%02x", AtalkConstant.MSG_CODE_CHAT_NOTI).toUpperCase();
				message = String.format("%s%s",
						chatDataNoti.toJson(), notiCode);
				
				atalkMqSender.publishMessageWithTTLThruWebSocket(
						chatDataNoti.getChatData().getChathubNo()
						, message);
				
				for (MChathubUser chathubUser : mChatHubUserList) {
					atalkUnreadCntService.resetUnreadCount(chathubUser.getUserNo(), chathubUser.getChathubNo());
					if (!user.getUserNo().equals(chathubUser.getUserNo())) {
						atalkUnreadCntService.incrementUnreadCount(chathubUser.getUserNo(), chathubUser.getChathubNo());
						// NOTI 처리
						uOp = mUserRepository.findByUserNo(chathubUser.getUserNo());
//						pktSeedObj = redisTaskBroker.findKeyUserNo(chathubUser.getUserNo()); 
//						if (pktSeedObj != null) {
//							queueName = String.format("Q_%s_%d",
//									uOp.get().getImei()
//									, uOp.get().getUserNo());
//							
//							seedValue = pktSeedObj.getSeed();
//							packetKeyOther = pktSeedObj.getPacketKey();
//							
//							model = chatDataNoti.toFinalModel(packetKeyOther);
//							log.debug("#### noti data : {}",model.toJson());
//							notiCode = String.format("%02x", AtalkConstant.MSG_CODE_CHAT_NOTI).toUpperCase();
//							message = String.format("%s%s%s",
//									model.toJson(), notiCode, seedValue);
//							// mq noti 처리
//							atalkMqSender.publishMessageWithTTL(
//									""
//									, queueName
//									, message
//									, 60 * 1000L);								
//						}
						unreadCntSum = atalkUnreadCntService.getTotalUnreadCount(chathubUser.getUserNo());
						
						map.put("TYPE", messageObj.getChatType());
						map.put("KEY_ID", messageObj.getChathubNo().toString());
						map.put("CHAT_NO", messageObj.getChatNo().toString());
						map.put("SENDER_NO", user.getUserNo().toString());
						map.put("SENDER_NAME", user.getUserName());
						map.put("TITLE", chathubUser.getChathubName());
						map.put("UNREAD_CNT", String.valueOf(unreadCntSum));
						map.put("REG_DATE", messageObj.getRegDt());
						map.put("MESSAGE", chathubUser.getChathubName());
						map.put("collapse_key", atalkMqSender.makeRandomPw(8));
						map.put("token", uOp.get().getMobileToken());
						
						atalkMqSender.sendPush(uOp.get(), map);
					}
				}
			} else { // 일대일
//					for (MChathubUser chathubUser : mChatHubUserList) {
//						
//					}
			}
		}
		///////////////////////// RESPONSE /////////////////////////////////////////////////////
		
		OpenChathubResponse respObj = new OpenChathubResponse();
		// ChatHubInfo chatHubInfo = new ChatHubInfo();
		ChatHubInfo retChatHubObj = new ChatHubInfo();
		retChatHubObj.setChathubNo(mChatHubInfo.getChathubNo());
		retChatHubObj.setChathubType(mChatHubInfo.getChathubType());
		retChatHubObj.setUserNo(mChatHubInfo.getUserNo());
		retChatHubObj.setUsersNum(mChatHubInfo.getUsersNum());
		retChatHubObj.setUseYn(mChatHubInfo.getUseYn());
		
		List<ChatHubUser> chatHubUser = Lists.newArrayList();
		
		// 재조회처리
		mChatHubUserList = mChathubUserRepository.findByChathubNoAndJoinYn(mChatHubInfo.getChathubNo(), "Y");
		
		Optional<List<MUser>> userListOp = mUserRepository.findByChatHubNoJoined(mChatHubInfo.getChathubNo());
		Map<Long, MUser> userMap = userListOp.get().stream()
		        .collect(Collectors.toMap(MUser::getUserNo, muser -> muser));
		
		MUser mUser = null;
		for (MChathubUser mChatHubUser : mChatHubUserList) {
			mUser = null;
			for (Long key : userMap.keySet()) {
				if (key.longValue()==mChatHubUser.getUserNo().longValue()) {
					mUser = userMap.get(key);
					break;
				}
			}
			ChatHubUser u = new ChatHubUser();
			u.setChatHubNo(mChatHubInfo.getChathubNo());
			u.setUserNo(mChatHubUser.getUserNo());
			u.setUserName(userMap.get(u.getUserNo()).getUserName());
			u.setChathubName(mChatHubUser.getChathubName());
			if (mChatHubUser.getMainChathubName()==null
					||
					mChatHubUser.getMainChathubName().isBlank()) {
				u.setMainChathubName(newChathubOpenMessage);
			} else {
				u.setMainChathubName(mChatHubUser.getMainChathubName());
			}
			u.setJoinYn(mChatHubUser.getJoinYn());
			u.setNotiYn(mChatHubUser.getNotiYn());
			u.setUseYn(mChatHubUser.getUseYn());
			u.setLastChatNo(mChatHubUser.getLastChatNo());
			u.setStartChatNo(mChatHubUser.getStartChatNo());

			u.setReadChatNo(
					mChatHubUser.getStartChatNo() > mChatHubUser.getReadChatNo() ? mChatHubUser.getStartChatNo() : mChatHubUser.getReadChatNo());
			
			List<String> profileUrlList = _getProfileInfo(mUser);
			
			u.setProfileFgThumbUrl(profileUrlList.get(0));
			u.setProfileFgUrl(profileUrlList.get(1));
			u.setProfileBgThumbUrl(profileUrlList.get(2));
			u.setProfileBgUrl(profileUrlList.get(3));
			u.setStatusMessage(mUser.getStatusMessage());
			if (user.getUserNo().equals(mChatHubUser.getUserNo())) {
				myEncChathubKey = mChatHubUser.getEncryptChatKey();
			}
			chatHubUser.add(u);
		}
		retChatHubObj.setEncChathubKey(myEncChathubKey);
		respObj.setChatHubInfo(retChatHubObj);
		
		respObj.setChatHubUserList(chatHubUser);
		
		Pair<List<Chat>, Long> chatListResultOp = atalkChatServiceLogic.getMessageLatestList(
				mChatHubInfo.getChathubNo()
				, reqObj.getReqChatCount()); // 최근 10개
		List<Chat> chatList =  chatListResultOp.getLeft();
		Long lastChatNo =  chatListResultOp.getRight();
//			Optional<List<Chat>> chatListOp = atalkChatService.getMessageLatestList(
//					mChatHubInfo.getChathubNo()
//					, reqObj.getReqChatCount()); // 최근 10개
		respObj.setChatList(
				(chatList == null || chatList.size() < 1) ? Lists.newArrayList()
						:
				chatList
				);
		respObj.setLastInquireChatNo(lastChatNo);
		return respObj;
	}

	/**
	 * 대화방 목록 요청
	 * 
	 */
	@Override
	public ListChathubResponse listChathub(MUser user, ListChathubRequest reqObj) throws Exception {
		
		String updateDt = reqObj.getUpdateDt();
		List<ChatHubListInfo> chatHubListInfo = Lists.newArrayList();
		String currDt = retrieveChatHubList(user, updateDt, chatHubListInfo);
		
		///////////////////////// RESPONSE /////////////////////////////////////////////////////
		
		ListChathubResponse respObj = new ListChathubResponse();
		if (currDt==null) {
			currDt = dateFormatter.format(new Date());
		}
		respObj.setLastUpdateDt(currDt);
		respObj.setChatHubListInfo(chatHubListInfo);
		return respObj;
	}
	

	/**
	 * 대화방 초대
	 * 
	 */
	@Override
	public InviteChathubResponse invite(MUser user, InviteChathubRequest reqObj) throws Exception {
		Long chathubNo = reqObj.getChathubNo();
		Long userNo = user.getUserNo();
		
		Optional<MChathub> chathubOp = mChathubRepository.findByChathubNo(reqObj.getChathubNo());
		String encPacketKey = chathubOp.get().getEncKeyUrgent();
		String plainChathubPacketKey = RsaComplex.decrypt(encPacketKey, AtalkConstant.serverPrivateKey);
		
		List<Long> invitedUserNoList = reqObj.getInvitedUserNoList();
		if (chathubNo < 1L) {
			return null;
		}
		if (!userNo.equals(user.getUserNo())) {
			return null;
		}
		if (invitedUserNoList.size() < 1) {
			return null;				
		}
		Map<Long, Long> invitedUserNoMap = invitedUserNoList.stream()
                .collect(Collectors.toMap(value -> value, value -> value));
		List<MChathubUser> chathubUserList = mChathubUserRepository.findByChathubNoAndJoinYn(chathubNo, "Y");
		for (MChathubUser o : chathubUserList) {
			if (invitedUserNoMap.containsKey(o.getUserNo())) {
				invitedUserNoMap.remove(o.getUserNo());
			}
		}
		if (invitedUserNoMap.size() < 1) {
			///////////////////////// RESPONSE /////////////////////////////////////////////////////
			InviteChathubResponse respObj = new InviteChathubResponse();
			respObj.setChathubNo(chathubNo);
			respObj.setUserNo(user.getUserNo());
			respObj.setInvitedUserNoList(new ArrayList<Long>());
			respObj.setInvitedUserNameList("");
			return respObj;
		}
		invitedUserNoList = new ArrayList<>(invitedUserNoMap.keySet());
		reqObj.setInvitedUserNoList(invitedUserNoList);
		
		///////////////////////// LOGIC BELOW //////////////////////////////////////////////////
		// String invitedUserNameList = mChathubUserRepository.chatUserNamesList(chathubNo, invitedUserNoList);
		String invitedUserNameList = mChathubUserRepository.chatUserNamesList(invitedUserNoList);
		MChathub mChatHubInfo = inviteChatHub(user.getUserNo(), reqObj, invitedUserNameList);

		List<MChathubUser> mChathubUserList = mChathubUserRepository.findByChathubNoAndUserNoInAndJoinYn(
				chathubNo
				, invitedUserNoList
				, "Y");
		
		// key update
		for (MChathubUser chathubObj : mChathubUserList) {
			if (chathubObj.getUserNo().equals(user.getUserNo())) {
				continue;
			}
			try {
				// String encKeyUpdate = chathubObj.getEncryptChatKey();
				Optional<MUser> muserOp = mUserRepository.findByUserNo(chathubObj.getUserNo());
				String userPubKey = muserOp.get().getPublicKey();
				
				String userEncChathubKey = RsaComplex.encrypt(plainChathubPacketKey, userPubKey);
				mChathubUserRepository.updateChathubKey(chathubObj.getChathubNo()
						, chathubObj.getUserNo(), userEncChathubKey);

			} catch (Exception e) {
				log.error("@@@@ key update failed.");
			}
		}
		
		Chat messageObj = atalkChatServiceLogic.sendInfoMessage(
				EnumChatSubType.MESSAGE_SUB_INVITE_TO_CHATHUB_TYPE.getValue()
				, user.getUserNo()
				, chathubNo
				, invitedUserNameList);

		// 노티 메시지 처리
		RedisPacketKeySeed pktSeedObj = null;
		String seedValue = null;
		String packetKeyOther = null;
		ChatDataNoti chatDataNoti = new ChatDataNoti();
		chatDataNoti.setChatData(messageObj);
		
		SecureDataModel model = null;
		String notiCode = null;
		String message = null;
		String queueName = null;
		Optional<MUser> uOp = null;
		Map<String, String> map = new HashMap<String, String>();

		int unreadCntSum = 0;
		
		notiCode = String.format("%02x", AtalkConstant.MSG_CODE_INVITE_NOTI).toUpperCase();
		message = String.format("%s%s",
				chatDataNoti.toJson(), notiCode);
		
		atalkMqSender.publishMessageWithTTLThruWebSocket(
				chatDataNoti.getChatData().getChathubNo()
				, message);
		
		for (MChathubUser o : mChathubUserList) {
			if (o.getUserNo().equals(user.getUserNo())) {
				continue;
			}
			try {
				uOp = mUserRepository.findByUserNo(o.getUserNo());
//				pktSeedObj = redisTaskBroker.findKeyUserNo(o.getUserNo()); 
//				if (pktSeedObj != null) {
//					queueName = String.format("Q_%s_%d",
//							uOp.get().getImei()
//							, o.getUserNo());
//					
//					seedValue = pktSeedObj.getSeed();
//					packetKeyOther = pktSeedObj.getPacketKey();
//					
//					model = chatDataNoti.toFinalModel(packetKeyOther);
//					log.debug("#### noti data : {}",model.toJson());
//					notiCode = String.format("%02x", AtalkConstant.MSG_CODE_INVITE_NOTI).toUpperCase();
//					message = String.format("%s%s%s",
//							model.toJson(), notiCode, seedValue);
//					// mq noti 처리
//					atalkMqSender.publishMessageWithTTL(
//							""
//							, queueName
//							, message
//							, 60 * 1000L);
//				}

				unreadCntSum = atalkUnreadCntService.getTotalUnreadCount(o.getUserNo());
				
				map.put("TYPE", messageObj.getChatType());
				map.put("KEY_ID", messageObj.getChathubNo().toString());
				map.put("CHAT_NO", messageObj.getChatNo().toString());
				map.put("SENDER_NO", user.getUserNo().toString());
				map.put("SENDER_NAME", user.getUserName());
				map.put("TITLE", "info message");
				map.put("UNREAD_CNT", String.valueOf(unreadCntSum));
				map.put("REG_DATE", messageObj.getRegDt());
				map.put("MESSAGE", "info message");
				map.put("collapse_key", atalkMqSender.makeRandomPw(8));
				map.put("token", uOp.get().getMobileToken());
				
				atalkMqSender.sendPush(uOp.get(), map);
			} catch (Exception e) {
				log.error("@@@@ key update failed.");
			}
		}
		///////////////////////// RESPONSE /////////////////////////////////////////////////////
		InviteChathubResponse respObj = new InviteChathubResponse();
		respObj.setChathubNo(mChatHubInfo.getChathubNo());
		respObj.setUserNo(user.getUserNo());
		respObj.setInvitedUserNoList(invitedUserNoList);
		respObj.setInvitedUserNameList(invitedUserNameList);

		return respObj;
	}

	@Override
	public String retrieveChatHubList(MUser user, String updateDt, List<ChatHubListInfo> chatHubListInfo)
			throws ParseException {
		
		List<Object[]>  chatHubListData = null;
		if (updateDt.startsWith("2000")) {
			// 참여중인 것 전체, // join yn Y 인 것만.
			chatHubListData = mChathubRepository.findByAfterUpdateDtOnlyJoined(
				dateFormatter.parse(updateDt)
				, user.getUserNo());	
		} else {
			// 증분 
			chatHubListData = mChathubRepository.findByAfterUpdateDt(
				dateFormatter.parse(updateDt)
					, user.getUserNo());
		}
		Long chathubNo = null;
		String chathubType = null;
		Long chatNo = null;
		String chatType = null;
		String chatSubType = null;
		Long userNo = null;
		String message = null;
		String userName = null;
		Long unreadCnt = null;
		Long usersNum = null;
		String regDt = null;
		String joinYn = null;
		String currDt = null;
		String encChatKey = null;
		String chatHubName = null;
		ChatHubListInfo chathubObj = null;
		ChatInfoLast lastChatObj = null;
		int i =0;
		for (Object[] row : chatHubListData) {
			i =0;
			chathubObj = new ChatHubListInfo();
			lastChatObj = new ChatInfoLast();
			
			chathubNo = (Long)row[i++];
			chathubType = String.valueOf((Character)row[i++]);
			chatNo = (Long)row[i++];
			chatType = String.valueOf((Character)row[i++]);
			chatSubType = String.valueOf((Character)row[i++]);
			
			userNo = (Long)row[i++];
			message = (String)row[i++];
			if (message.isBlank()) {
				message = "No Message";
			}
			userName = (String)row[i++];
			unreadCnt = (Long)row[i++];
			usersNum = (Long)row[i++];
			
			regDt = dateFormatter.format((Date)row[i++]);
			joinYn = String.valueOf((Character)row[i++]);
			if (currDt == null) {
				currDt = dateFormatter.format((Date)row[i++]);
			} else {
				i++;
			}
			encChatKey = (String)row[i++];
			chatHubName = (String)row[i++];
			
			chathubObj.setChathubNo(chathubNo);
			chathubObj.setChathubName(chatHubName);
			chathubObj.setChathubType(chathubType);
			chathubObj.setEncChathubKey(encChatKey);
			chathubObj.setJoinYn(joinYn);
			chathubObj.setUsersNum(usersNum);
			
			lastChatObj.setChatNo(chatNo);
			lastChatObj.setChatType(chatType);
			lastChatObj.setChatSubType(chatSubType);
			
			lastChatObj.setUserNo(userNo);
			lastChatObj.setUserName(userName);
			lastChatObj.setUnreadCnt(unreadCnt);
			lastChatObj.setUserCount(usersNum);
			lastChatObj.setRegDt(regDt);
			lastChatObj.setChatMessage(message);
			
			chathubObj.setLastChat(lastChatObj);
			
			chathubObj.setUserList(_getChatUserList(user, chathubNo));
			
			chatHubListInfo.add(chathubObj);
		}
		return currDt;
	}
	
	private List<ChatHubUser> _getChatUserList(MUser user, Long chathubNo) {
		
		List<ChatHubUser> userList = Lists.newArrayList();
		List<MChathubUser> mChatHubUserList = mChathubUserRepository.findByChathubNo(
				chathubNo);
		Optional<List<MUser>> userListOp = mUserRepository.findByChatHubNo(chathubNo);
		Map<Long, MUser> userMap = userListOp.get().stream()
		        .collect(Collectors.toMap(MUser::getUserNo, muser -> muser));
		
		MUser mUser = null;
		for (MChathubUser mChatHubUser : mChatHubUserList) {
			mUser = null;
			for (Long key : userMap.keySet()) {
				if (key.longValue()==mChatHubUser.getUserNo().longValue()) {
					mUser = userMap.get(key);
					break;
				}
			}
			ChatHubUser u = new ChatHubUser();
			u.setChatHubNo(chathubNo);
			u.setUserNo(mChatHubUser.getUserNo());
			u.setUserName(userMap.get(u.getUserNo()).getUserName());
			u.setChathubName(mChatHubUser.getChathubName());
			
			u.setJoinYn(mChatHubUser.getJoinYn());
			u.setNotiYn(mChatHubUser.getNotiYn());
			u.setUseYn(mChatHubUser.getUseYn());
			u.setLastChatNo(mChatHubUser.getLastChatNo());
			
			u.setStartChatNo(mChatHubUser.getStartChatNo());

			u.setReadChatNo(
					mChatHubUser.getStartChatNo() > mChatHubUser.getReadChatNo() ? mChatHubUser.getStartChatNo() : mChatHubUser.getReadChatNo());
		
			
			List<String> profileUrlList = _getProfileInfo(mUser);
			
			u.setProfileFgThumbUrl(profileUrlList.get(0));
			u.setProfileFgUrl(profileUrlList.get(1));
			u.setProfileBgThumbUrl(profileUrlList.get(2));
			u.setProfileBgUrl(profileUrlList.get(3));
			u.setStatusMessage(mUser.getStatusMessage());
			userList.add(u);
		}
		return userList;
	}

	@Override
	public KickOutChathubResponse forceExit(MUser user, Long chatHubNo, List<Long> userList) throws Exception {
		Long userNo = user.getUserNo();
		List<Long> kickoutUserNoList = userList;
		if (chatHubNo < 1L) {
			return null;
		}
		if (!userNo.equals(user.getUserNo())) {
			return null;
		}
		if (kickoutUserNoList.size() < 1) {
			return null;
		}
		Map<Long, Long> kickoutUserNoMap = kickoutUserNoList.stream()
                .collect(Collectors.toMap(value -> value, value -> value));
		
		List<MChathubUser> chathubUserList = mChathubUserRepository.findByChathubNoAndJoinYn(chatHubNo, "Y");
		for (MChathubUser o : chathubUserList) {
			if (!kickoutUserNoMap.containsKey(o.getUserNo())) {
				kickoutUserNoMap.remove(o.getUserNo());
			}
		}
		if (kickoutUserNoMap.size() < 1) {
			return null;
		}
		kickoutUserNoList = new ArrayList<>(kickoutUserNoMap.keySet());
		mChathubUserRepository.updateDeleteList(kickoutUserNoList, chatHubNo);
		// String kickedOutUserNameList = mChathubUserRepository.chatUserNamesList(chatHubNo, kickoutUserNoList);
		String kickedOutUserNameList = mChathubUserRepository.chatUserNamesList(kickoutUserNoList);
		mChathubRepository.updateUserCount(chatHubNo);
		
		Chat messageObj = atalkChatServiceLogic.sendInfoMessage(
				EnumChatSubType.MESSAGE_SUB_FORCE_EXIT_TO_CHATHUB_TYPE.getValue()
				, user.getUserNo()
				, chatHubNo
				, kickedOutUserNameList);
		
		
		//////////////////////////NOTI ///////////////////////
		chathubUserList = mChathubUserRepository.findByChathubNoAndJoinYn(messageObj.getChathubNo(), "Y");
		RedisPacketKeySeed pktSeedObj = null;
		String seedValue = null;
		String packetKeyOther = null;
		ChatDataNoti chatDataNoti = new ChatDataNoti();
		chatDataNoti.setChatData(messageObj);
		Optional<MUser> uOp = null;
		String queueName = null;

		int unreadCntSum = 0;
		
		String notiCode = String.format("%02x", AtalkConstant.MSG_CODE_CHAT_NOTI).toUpperCase();
		String message = String.format("%s%s",
				chatDataNoti.toJson(), notiCode);
		
		atalkMqSender.publishMessageWithTTLThruWebSocket(
				chatDataNoti.getChatData().getChathubNo()
				, message);
		
		Map<String, String> map = new HashMap<String, String>();
		for (MChathubUser o : chathubUserList) {
			if (!user.getUserNo().equals(o.getUserNo())) {
				uOp = mUserRepository.findByUserNo(o.getUserNo());
//				pktSeedObj = redisTaskBroker.findKeyUserNo(o.getUserNo()); 
//				if (pktSeedObj != null) {
//					queueName = String.format("Q_%s_%d",
//							uOp.get().getImei()
//							, o.getUserNo());
//					
//					seedValue = pktSeedObj.getSeed();
//					packetKeyOther = pktSeedObj.getPacketKey();
//					
//					SecureDataModel model = chatDataNoti.toFinalModel(packetKeyOther);
//					log.debug("#### noti data : {}",model.toJson());
//					notiCode = String.format("%02x", AtalkConstant.MSG_CODE_CHAT_NOTI).toUpperCase();
//					String tmessage = String.format("%s%s%s",
//							model.toJson(), notiCode, seedValue);
//					atalkMqSender.publishMessageWithTTL("", queueName, tmessage, 60 * 1000L);
//				}

				unreadCntSum = atalkUnreadCntService.getTotalUnreadCount(o.getUserNo());
				
				map.put("TYPE", messageObj.getChatType());
				map.put("KEY_ID", messageObj.getChathubNo().toString());
				map.put("CHAT_NO", messageObj.getChatNo().toString());
				map.put("SENDER_NO", user.getUserNo().toString());
				map.put("SENDER_NAME", user.getUserName());
				map.put("TITLE", "info message");
				map.put("UNREAD_CNT", String.valueOf(unreadCntSum));
				map.put("REG_DATE", messageObj.getRegDt());
				map.put("MESSAGE", "info message");
				map.put("collapse_key", RandomHexString.makeRandomPw(8));
				map.put("token", uOp.get().getMobileToken());
				
				atalkMqSender.sendPush(uOp.get(), map);
			}
		}
		//////////////////////////NOTI ///////////////////////
		
		///////////////////////// RESPONSE /////////////////////////////////////////////////////
		KickOutChathubResponse respObj = new KickOutChathubResponse();
		respObj.setChathubNo(chatHubNo);
		respObj.setUserNo(user.getUserNo());
		respObj.setKickedOutUserList(kickedOutUserNameList);
		respObj.setKickedOutUserNoList(kickoutUserNoList);
		return respObj;
	}

	@Override
	public MChathub inviteChatHub(Long myNo, InviteChathubRequest reqObj, String userNameList) throws JsonProcessingException {
		StoredProcedureQuery query = entityManager.createStoredProcedureQuery("PROC_JOIN_CHATHUB");

		String userNoListJson = objectMapper.writeValueAsString(reqObj.getInvitedUserNoList());
		
		log.debug("#### userNoListJson : {}", userNoListJson);
		
		query.registerStoredProcedureParameter("IN_USER_NO", 		Integer.class, 	ParameterMode.IN);
		query.registerStoredProcedureParameter("IN_CHATHUB_NO", 	Long.class, 	ParameterMode.IN);
		query.registerStoredProcedureParameter("IN_USER_LIST", 		String.class, 	ParameterMode.IN);
		query.registerStoredProcedureParameter("IN_USERNAME_LIST", 	String.class, 	ParameterMode.IN);
		query.registerStoredProcedureParameter("OUT_DATETIME", 		String.class, ParameterMode.OUT);
		
		query.setParameter("IN_USER_NO", myNo);
		query.setParameter("IN_CHATHUB_NO", reqObj.getChathubNo());
		query.setParameter("IN_USER_LIST", userNoListJson);
		query.setParameter("IN_USERNAME_LIST", userNameList);

		query.execute();
		String outDateTime = (String) query.getOutputParameterValue("OUT_DATETIME");
		
		log.debug("### PROC_JOIN_CHATHUB RESULT :: outChatHubNo : {}, outDateTime : {}",
				reqObj.getChathubNo(), outDateTime);

		Optional<MChathub> chatHubObjOp = mChathubRepository.findByChathubNoAndUseYn(reqObj.getChathubNo(), "Y");
		if (chatHubObjOp.isEmpty()) {
			return null;
		}
		return chatHubObjOp.get();
	}

	@Override
	public ExitChathubResponse exit(MUser user, Long chatHubNo, String quietYn) throws Exception {
	
		Long userNo = user.getUserNo();
		if (!quietYn.equals("Y")) {
			// 
			Chat messageObj = atalkChatServiceLogic.sendInfoMessage(
				EnumChatSubType.MESSAGE_SUB_EXIT_TO_CHATHUB_TYPE.getValue()
				, user.getUserNo()
				, chatHubNo
				, user.getUserName());

			mChathubUserRepository.updateDelete(userNo, chatHubNo);
			mChathubUserRepository.updateChathubUpdDt(chatHubNo);
			mChathubRepository.updateUserCount(chatHubNo);
			// NOTI 처리

			// 노티 메시지 처리
			RedisPacketKeySeed pktSeedObj = null;
			String seedValue = null;
			String packetKeyOther = null;
			ChatDataNoti chatDataNoti = new ChatDataNoti();
			chatDataNoti.setChatData(messageObj);
			
			SecureDataModel model = null;
			String notiCode = null;
			String message = null;
			String queueName = null;
			Optional<MUser> uOp = null;
			Map<String, String> map = new HashMap<String, String>();

			int unreadCntSum = 0;
			List<MChathubUser> mChatHubUserList = mChathubUserRepository.findByChathubNoAndJoinYn(
					chatHubNo, "Y");
			
			notiCode = String.format("%02x", AtalkConstant.MSG_CODE_EXIT_NOTI).toUpperCase();
			message = String.format("%s%s",
					chatDataNoti.toJson(), notiCode);
			
			atalkMqSender.publishMessageWithTTLThruWebSocket(
					chatDataNoti.getChatData().getChathubNo()
					, message);
			
			for (MChathubUser o : mChatHubUserList) {
				if (o.getUserNo().equals(user.getUserNo())) {
					continue;
				}
				try {
					uOp = mUserRepository.findByUserNo(o.getUserNo());
//					pktSeedObj = redisTaskBroker.findKeyUserNo(o.getUserNo()); 
//					if (pktSeedObj != null) {
//						queueName = String.format("Q_%s_%d",
//								uOp.get().getImei()
//								, o.getUserNo());
//						
//						seedValue = pktSeedObj.getSeed();
//						packetKeyOther = pktSeedObj.getPacketKey();
//						
//						model = chatDataNoti.toFinalModel(packetKeyOther);
//						log.debug("#### noti data : {}",model.toJson());
//						notiCode = String.format("%02x", AtalkConstant.MSG_CODE_EXIT_NOTI).toUpperCase();
//						message = String.format("%s%s%s",
//								model.toJson(), notiCode, seedValue);
//						// mq noti 처리
//						atalkMqSender.publishMessageWithTTL(
//								""
//								, queueName
//								, message
//								, 60 * 1000L);
//					}

					unreadCntSum = atalkUnreadCntService.getTotalUnreadCount(o.getUserNo());
					
					map.put("TYPE", messageObj.getChatType());
					map.put("KEY_ID", messageObj.getChathubNo().toString());
					map.put("CHAT_NO", messageObj.getChatNo().toString());
					map.put("SENDER_NO", user.getUserNo().toString());
					map.put("SENDER_NAME", user.getUserName());
					map.put("TITLE", "exit message");
					map.put("UNREAD_CNT", String.valueOf(unreadCntSum));
					map.put("REG_DATE", messageObj.getRegDt());
					map.put("MESSAGE", "info message");
					map.put("collapse_key", atalkMqSender.makeRandomPw(8));
					map.put("token", uOp.get().getMobileToken());
					
					atalkMqSender.sendPush(uOp.get(), map);
				} catch (Exception e) {
					log.error("@@@@ key update failed.");
				}
			}
		} else {
			mChathubUserRepository.updateDelete(userNo, chatHubNo);
			mChathubUserRepository.updateChathubUpdDt(chatHubNo);
			mChathubRepository.updateUserCount(chatHubNo);
		}
		
		///////////////////////// RESPONSE /////////////////////////////////////////////////////
		ExitChathubResponse respObj = new ExitChathubResponse();
		respObj.setChathubNo(chatHubNo);
		respObj.setUserNo(user.getUserNo());
		respObj.setUserName(user.getUserName());
		
		return respObj;
	}

	@Override
	public OpenChathubResponse info(MUser user, ChathubInfoRequest reqObj) throws Exception {
		///////////////////////// LOGIC BELOW //////////////////////////////////////////////////
		Pair<MChathub, String> mChatHubInfoOp = getChatHubInfo2(user.getUserNo(), reqObj);
			
		MChathub mChatHubInfo = mChatHubInfoOp.getLeft();
		// String newChatHubYn = mChatHubInfoOp.getRight();
		if (mChatHubInfo == null || mChatHubInfo.getChathubNo().equals(0L)) {
			log.error("@@@@ No chathub info");
			return null;
		}
			
		String myEncChathubKey = "";
		
		List<MChathubUser> mChatHubUserList = mChathubUserRepository.findByChathubNoAndJoinYn(
				mChatHubInfo.getChathubNo(), "Y");
		String newChathubOpenMessage = mChathubUserRepository.chatUserNamesWithComma(
				mChatHubInfo.getChathubNo());
		
		///////////////////////// RESPONSE /////////////////////////////////////////////////////
		
		OpenChathubResponse respObj = new OpenChathubResponse();
		// ChatHubInfo chatHubInfo = new ChatHubInfo();
		ChatHubInfo retChatHubObj = new ChatHubInfo();
		retChatHubObj.setChathubNo(mChatHubInfo.getChathubNo());
		retChatHubObj.setChathubType(mChatHubInfo.getChathubType());
		retChatHubObj.setUserNo(mChatHubInfo.getUserNo());
		retChatHubObj.setUsersNum(mChatHubInfo.getUsersNum());
		retChatHubObj.setUseYn(mChatHubInfo.getUseYn());
		
		List<ChatHubUser> chatHubUser = Lists.newArrayList();
		
		// 재조회처리
		mChatHubUserList = mChathubUserRepository.findByChathubNoAndJoinYn(mChatHubInfo.getChathubNo(), "Y");
		
		Optional<List<MUser>> userListOp = mUserRepository.findByChatHubNoJoined(mChatHubInfo.getChathubNo());
		Map<Long, MUser> userMap = userListOp.get().stream()
		        .collect(Collectors.toMap(MUser::getUserNo, muser -> muser));
		
		MUser mUser = null;
		for (MChathubUser mChatHubUser : mChatHubUserList) {
			mUser = null;
			for (Long key : userMap.keySet()) {
				if (key.longValue()==mChatHubUser.getUserNo().longValue()) {
					mUser = userMap.get(key);
					break;
				}
			}
			ChatHubUser u = new ChatHubUser();
			u.setChatHubNo(mChatHubInfo.getChathubNo());
			u.setUserNo(mChatHubUser.getUserNo());
			u.setUserName(userMap.get(u.getUserNo()).getUserName());
			u.setChathubName(mChatHubUser.getChathubName());
			if (mChatHubUser.getMainChathubName()==null
					||
					mChatHubUser.getMainChathubName().isBlank()) {
				u.setMainChathubName(newChathubOpenMessage);
			} else {
				u.setMainChathubName(mChatHubUser.getMainChathubName());
			}
			u.setJoinYn(mChatHubUser.getJoinYn());
			u.setNotiYn(mChatHubUser.getNotiYn());
			u.setUseYn(mChatHubUser.getUseYn());
			u.setLastChatNo(mChatHubUser.getLastChatNo());

			
			u.setStartChatNo(mChatHubUser.getStartChatNo());

			u.setReadChatNo(
					mChatHubUser.getStartChatNo() > mChatHubUser.getReadChatNo() ? mChatHubUser.getStartChatNo() : mChatHubUser.getReadChatNo());
		
			
			if (user.getUserNo().equals(mChatHubUser.getUserNo())) {
				myEncChathubKey = mChatHubUser.getEncryptChatKey();
			}
			
			List<String> profileUrlList = _getProfileInfo(mUser);
			
			u.setProfileFgThumbUrl(profileUrlList.get(0));
			u.setProfileFgUrl(profileUrlList.get(1));
			u.setProfileBgThumbUrl(profileUrlList.get(2));
			u.setProfileBgUrl(profileUrlList.get(3));
			u.setStatusMessage(mUser.getStatusMessage());
			
			chatHubUser.add(u);
		}
		retChatHubObj.setEncChathubKey(myEncChathubKey);
		respObj.setChatHubInfo(retChatHubObj);
		respObj.setChatHubUserList(chatHubUser);
		
		Pair<List<Chat>, Long> chatListResultOp = atalkChatServiceLogic.getMessageLatestList(
				mChatHubInfo.getChathubNo()
				, reqObj.getReqChatCount()); // 최근 10개
		List<Chat> chatList =  chatListResultOp.getLeft();
		Long lastChatNo =  chatListResultOp.getRight();
		respObj.setChatList(
				(chatList == null || chatList.size() < 1) ? Lists.newArrayList()
						:
				chatList
				);
		respObj.setLastInquireChatNo(lastChatNo);
		return respObj;
	}
	
	@Override
	public OpenChathubResponse openChathubWithTitle(MUser user, OpenChathubWithTitleRequest reqObj) throws Exception {

		List<Long> chatHubUserList = reqObj.getUserNoList();
		
		if (chatHubUserList.size() < 1L) {
			return null;
		}
		///////////////////
		Pair<MChathub, String> mChatHubInfoOp = getChatHubInfo(
				user.getUserNo()
				, reqObj.getUserNoList());
			
		MChathub mChatHubInfo = mChatHubInfoOp.getLeft();
		String newChatHubYn = mChatHubInfoOp.getRight();
		if (mChatHubInfo == null || mChatHubInfo.getChathubNo().equals(0L)) {
			log.error("@@@@ No chathub info");
			return null;
		}
		
		String myEncChathubKey = "";
		
		List<MChathubUser> mChatHubUserList = mChathubUserRepository.findByChathubNoAndJoinYn(
				mChatHubInfo.getChathubNo(), "Y");
		String newChathubOpenMessage = mChathubUserRepository.chatUserNamesWithComma(
				mChatHubInfo.getChathubNo());

		/////////////////////////////////////////////////////////////////////////
		if (newChatHubYn.equals("Y")) {
			
			// 대화방명 변경
			mChathubUserRepository.updateChathubMasterTitle(mChatHubInfo.getChathubNo()
					, reqObj.getChathubMasterTitle());
			
			// 신규 대화방 케이스
			String chatEncDecKey = RandomHexString.genSecureRandomHex(64);
			
			// 긴급 상황시 사용자에게 키 재할당용.
			
			String encChatEncDecKeyUrgent =RsaComplex.encrypt(chatEncDecKey, AtalkConstant.serverPublicKey);
			mChathubRepository.updateEncUrgentKey(mChatHubInfo.getChathubNo(), encChatEncDecKeyUrgent);
			
			////////////////////////////////////////
			if (mChatHubUserList != null) {
				// 사용자별 대화방키 암호화 업데이트
				String userEncrypteChatKey = null;
				for (MChathubUser chathubUser : mChatHubUserList) {
					Optional<MUser> mUserOp = mUserRepository.findByUserNo(chathubUser.getUserNo());
					String userPublicKey = mUserOp.get().getPublicKey();
					if (userPublicKey != null && !userPublicKey.isBlank()) {
						userEncrypteChatKey = RsaComplex.encrypt(chatEncDecKey, userPublicKey);
						mChathubUserRepository.updateEncryptChatKey(
								mChatHubInfo.getChathubNo()
								, chathubUser.getUserNo()
								, userEncrypteChatKey);
					}
				}
			}
				
			Chat messageObj = atalkChatServiceLogic.getLastMessage(mChatHubInfo.getChathubNo());
			// 신규 대화방 생성인 경우이므로 멀티대화방
			if (mChatHubInfo.getChathubType().equals(EnumChatHubType.MULTI_USER.getValue())) {
				// NOTI MESSAGE 처리
				RedisPacketKeySeed pktSeedObj = null;
				String seedValue = null;
				String packetKeyOther = null;
				ChatDataNoti chatDataNoti = new ChatDataNoti();
				chatDataNoti.setChatData(messageObj);
				
				SecureDataModel model = null;
				String notiCode = null;
				String message = null;
				String queueName = null;
				Optional<MUser> uOp = null;
				Map<String, String> map = new HashMap<String, String>();
				
				int unreadCntSum = 0;
				
				notiCode = String.format("%02x", AtalkConstant.MSG_CODE_CHAT_NOTI).toUpperCase();
				message = String.format("%s%s",
						chatDataNoti.toJson(), notiCode);
				
				atalkMqSender.publishMessageWithTTLThruWebSocket(
						chatDataNoti.getChatData().getChathubNo()
						, message);
				
				for (MChathubUser chathubUser : mChatHubUserList) {
					atalkUnreadCntService.resetUnreadCount(chathubUser.getUserNo(), chathubUser.getChathubNo());
					if (!user.getUserNo().equals(chathubUser.getUserNo())) {
						atalkUnreadCntService.incrementUnreadCount(chathubUser.getUserNo(), chathubUser.getChathubNo());
						// NOTI 처리
						uOp = mUserRepository.findByUserNo(chathubUser.getUserNo());
//						pktSeedObj = redisTaskBroker.findKeyUserNo(chathubUser.getUserNo()); 
//						if (pktSeedObj != null) {
//							queueName = String.format("Q_%s_%d",
//									uOp.get().getImei()
//									, uOp.get().getUserNo());
//							
//							seedValue = pktSeedObj.getSeed();
//							packetKeyOther = pktSeedObj.getPacketKey();
//							
//							model = chatDataNoti.toFinalModel(packetKeyOther);
//							log.debug("#### noti data : {}",model.toJson());
//							notiCode = String.format("%02x", AtalkConstant.MSG_CODE_CHAT_NOTI).toUpperCase();
//							message = String.format("%s%s%s",
//									model.toJson(), notiCode, seedValue);
//							// mq noti 처리
//							atalkMqSender.publishMessageWithTTL(
//									""
//									, queueName
//									, message
//									, 60 * 1000L);								
//						}
						unreadCntSum = atalkUnreadCntService.getTotalUnreadCount(chathubUser.getUserNo());
						
						map.put("TYPE", messageObj.getChatType());
						map.put("KEY_ID", messageObj.getChathubNo().toString());
						map.put("CHAT_NO", messageObj.getChatNo().toString());
						map.put("SENDER_NO", user.getUserNo().toString());
						map.put("SENDER_NAME", user.getUserName());
						map.put("TITLE", chathubUser.getChathubName());
						map.put("UNREAD_CNT", String.valueOf(unreadCntSum));
						map.put("REG_DATE", messageObj.getRegDt());
						map.put("MESSAGE", chathubUser.getChathubName());
						map.put("collapse_key", atalkMqSender.makeRandomPw(8));
						map.put("token", uOp.get().getMobileToken());
						
						atalkMqSender.sendPush(uOp.get(), map);
					}
				}
			} else { // 일대일
//					for (MChathubUser chathubUser : mChatHubUserList) {
//						
//					}
			}
		}
//			Chat messageObj = atalkChatService.sendMessage(user.getUserNo()
//					, mChatHubInfo.getChathubNo()
//					, reqObj.getMessage());
		
		///////////////////////// RESPONSE /////////////////////////////////////////////////////
		
		OpenChathubResponse respObj = new OpenChathubResponse();
		// ChatHubInfo chatHubInfo = new ChatHubInfo();
		ChatHubInfo retChatHubObj = new ChatHubInfo();
		retChatHubObj.setChathubNo(mChatHubInfo.getChathubNo());
		retChatHubObj.setChathubType(mChatHubInfo.getChathubType());
		retChatHubObj.setUserNo(mChatHubInfo.getUserNo());
		retChatHubObj.setUsersNum(mChatHubInfo.getUsersNum());
		retChatHubObj.setUseYn(mChatHubInfo.getUseYn());
		
		List<ChatHubUser> chatHubUser = Lists.newArrayList();
		
		// 재조회처리
		mChatHubUserList = mChathubUserRepository.findByChathubNoAndJoinYn(mChatHubInfo.getChathubNo(), "Y");
		
		Optional<List<MUser>> userListOp = mUserRepository.findByChatHubNoJoined(mChatHubInfo.getChathubNo());
		Map<Long, MUser> userMap = userListOp.get().stream()
		        .collect(Collectors.toMap(MUser::getUserNo, muser -> muser));

		MUser mUser = null; // userMap.get(u.getUserNo());
		for (MChathubUser mChatHubUser : mChatHubUserList) {
			mUser = null;
			ChatHubUser u = new ChatHubUser();
			for (Long key : userMap.keySet()) {
				if (key.longValue()==mChatHubUser.getUserNo().longValue()) {
					mUser = userMap.get(key);
					break;
				}
			}
			u.setChatHubNo(mChatHubInfo.getChathubNo());
			u.setUserNo(mChatHubUser.getUserNo());
			u.setUserName(mUser.getUserName());
			u.setChathubName(mChatHubUser.getChathubName());
			if (mChatHubUser.getMainChathubName()==null
					||
					mChatHubUser.getMainChathubName().isBlank()) {
				u.setMainChathubName(newChathubOpenMessage);
			} else {
				u.setMainChathubName(mChatHubUser.getMainChathubName());
			}
			u.setJoinYn(mChatHubUser.getJoinYn());
			u.setNotiYn(mChatHubUser.getNotiYn());
			u.setUseYn(mChatHubUser.getUseYn());
			u.setLastChatNo(mChatHubUser.getLastChatNo());
			u.setReadChatNo(mChatHubUser.getReadChatNo());
			u.setStartChatNo(mChatHubUser.getStartChatNo());
			if (user.getUserNo().equals(mChatHubUser.getUserNo())) {
				myEncChathubKey = mChatHubUser.getEncryptChatKey();
			}
			
			u.setStatusMessage(mUser.getStatusMessage());
			
			List<String> profileUrlList = _getProfileInfo(mUser);
			
			u.setProfileFgThumbUrl(profileUrlList.get(0));
			u.setProfileFgUrl(profileUrlList.get(1));
			u.setProfileBgThumbUrl(profileUrlList.get(2));
			u.setProfileBgUrl(profileUrlList.get(3));
			
			chatHubUser.add(u);
		}
		retChatHubObj.setEncChathubKey(myEncChathubKey);
		respObj.setChatHubInfo(retChatHubObj);
		
		respObj.setChatHubUserList(chatHubUser);
		
		Pair<List<Chat>, Long> chatListResultOp = atalkChatServiceLogic.getMessageLatestList(
				mChatHubInfo.getChathubNo()
				, reqObj.getReqChatCount()); // 최근 10개
		List<Chat> chatList =  chatListResultOp.getLeft();
		Long lastChatNo =  chatListResultOp.getRight();
//			Optional<List<Chat>> chatListOp = atalkChatService.getMessageLatestList(
//					mChatHubInfo.getChathubNo()
//					, reqObj.getReqChatCount()); // 최근 10개
		respObj.setChatList(
				(chatList == null || chatList.size() < 1) ? Lists.newArrayList()
						:
				chatList
				);
		respObj.setLastInquireChatNo(lastChatNo);
		
		return respObj;
	}

	@Override
	public OpenChathubResponse openChathubByAmigoSetNo(MUser user, Long amigoSetNo) throws Exception {
		log.debug("################# OPEN CHATHUB BY AMIGO SET NO");

		List<MAmigo> amigoList = mAmigoRepository.findByUserNoAndAmigoSetNoAndUseYn(user.getUserNo(), amigoSetNo, "Y");
		if (amigoList == null) {
			return null;
		}
		List<Long> chatHubUserList = amigoList.stream()
				 .map(MAmigo::getAmigoNo)
				 .collect(Collectors.toList());
		chatHubUserList.add(user.getUserNo());
		if (chatHubUserList.size() < 1L) {
			return null;
		}
		///////////////////
		Pair<MChathub, String> mChatHubInfoOp = getChatHubInfo(
				user.getUserNo()
				, chatHubUserList);
		
		MChathub mChatHubInfo = mChatHubInfoOp.getLeft();
		String newChatHubYn = mChatHubInfoOp.getRight();
		if (mChatHubInfo == null || mChatHubInfo.getChathubNo().equals(0L)) {
			log.error("@@@@ No chathub info");
			return null;
		}
			
		String myEncChathubKey = "";
		
		List<MChathubUser> mChatHubUserList = mChathubUserRepository.findByChathubNoAndJoinYn(
				mChatHubInfo.getChathubNo(), "Y");
		String newChathubOpenMessage = mChathubUserRepository.chatUserNamesWithComma(
				mChatHubInfo.getChathubNo());

		/////////////////////////////////////////////////////////////////////////
		if (newChatHubYn.equals("Y")) {
			// 신규 대화방 케이스
			String chatEncDecKey = RandomHexString.genSecureRandomHex(64);
			
			// 긴급 상황시 사용자에게 키 재할당용.
			
			String encChatEncDecKeyUrgent =RsaComplex.encrypt(chatEncDecKey, AtalkConstant.serverPublicKey);
			mChathubRepository.updateEncUrgentKey(mChatHubInfo.getChathubNo(), encChatEncDecKeyUrgent);
			
			////////////////////////////////////////
			if (mChatHubUserList != null) {
				// 사용자별 대화방키 암호화 업데이트
				String userEncrypteChatKey = null;
				for (MChathubUser chathubUser : mChatHubUserList) {
					Optional<MUser> mUserOp = mUserRepository.findByUserNo(chathubUser.getUserNo());
					String userPublicKey = mUserOp.get().getPublicKey();
					if (userPublicKey != null && !userPublicKey.isBlank()) {
						userEncrypteChatKey = RsaComplex.encrypt(chatEncDecKey, userPublicKey);
						mChathubUserRepository.updateEncryptChatKey(
								mChatHubInfo.getChathubNo()
								, chathubUser.getUserNo()
								, userEncrypteChatKey);
					}
				}
			}
			
			Chat messageObj = atalkChatServiceLogic.getLastMessage(mChatHubInfo.getChathubNo());
			// 신규 대화방 생성인 경우이므로 멀티대화방
			if (mChatHubInfo.getChathubType().equals(EnumChatHubType.MULTI_USER.getValue())) {
				// NOTI MESSAGE 처리
				RedisPacketKeySeed pktSeedObj = null;
				String seedValue = null;
				String packetKeyOther = null;
				ChatDataNoti chatDataNoti = new ChatDataNoti();
				chatDataNoti.setChatData(messageObj);
				
				SecureDataModel model = null;
				String notiCode = null;
				String message = null;
				String queueName = null;
				Optional<MUser> uOp = null;
				
				int unreadCntSum = 0;
				
				notiCode = String.format("%02x", AtalkConstant.MSG_CODE_CHAT_NOTI).toUpperCase();
				message = String.format("%s%s",
						chatDataNoti.toJson(), notiCode);
				
				atalkMqSender.publishMessageWithTTLThruWebSocket(
						chatDataNoti.getChatData().getChathubNo()
						, message);
				
				Map<String, String> map = new HashMap<String, String>();
				for (MChathubUser chathubUser : mChatHubUserList) {
					atalkUnreadCntService.resetUnreadCount(chathubUser.getUserNo(), chathubUser.getChathubNo());
					if (!user.getUserNo().equals(chathubUser.getUserNo())) {
						atalkUnreadCntService.incrementUnreadCount(chathubUser.getUserNo(), chathubUser.getChathubNo());
						// NOTI 처리
						uOp = mUserRepository.findByUserNo(chathubUser.getUserNo());
//						pktSeedObj = redisTaskBroker.findKeyUserNo(chathubUser.getUserNo()); 
//						if (pktSeedObj != null) {
//							queueName = String.format("Q_%s_%d",
//									uOp.get().getImei()
//									, uOp.get().getUserNo());
//							
//							seedValue = pktSeedObj.getSeed();
//							packetKeyOther = pktSeedObj.getPacketKey();
//							
//							model = chatDataNoti.toFinalModel(packetKeyOther);
//							log.debug("#### noti data : {}",model.toJson());
//							notiCode = String.format("%02x", AtalkConstant.MSG_CODE_CHAT_NOTI).toUpperCase();
//							message = String.format("%s%s%s",
//									model.toJson(), notiCode, seedValue);
//							// mq noti 처리
//							atalkMqSender.publishMessageWithTTL(
//									""
//									, queueName
//									, message
//									, 60 * 1000L);								
//						}
						unreadCntSum = atalkUnreadCntService.getTotalUnreadCount(chathubUser.getUserNo());
						
						map.put("TYPE", messageObj.getChatType());
						map.put("KEY_ID", messageObj.getChathubNo().toString());
						map.put("CHAT_NO", messageObj.getChatNo().toString());
						map.put("SENDER_NO", user.getUserNo().toString());
						map.put("SENDER_NAME", user.getUserName());
						map.put("TITLE", chathubUser.getChathubName());
						map.put("UNREAD_CNT", String.valueOf(unreadCntSum));
						map.put("REG_DATE", messageObj.getRegDt());
						map.put("MESSAGE", chathubUser.getChathubName());
						map.put("collapse_key", atalkMqSender.makeRandomPw(8));
						map.put("token", uOp.get().getMobileToken());
						
						atalkMqSender.sendPush(uOp.get(), map);
					}
				}
			} else { // 일대일
//					for (MChathubUser chathubUser : mChatHubUserList) {
//						
//					}
			}
		}
		///////////////////////// RESPONSE /////////////////////////////////////////////////////
		
		OpenChathubResponse respObj = new OpenChathubResponse();
		// ChatHubInfo chatHubInfo = new ChatHubInfo();
		ChatHubInfo retChatHubObj = new ChatHubInfo();
		retChatHubObj.setChathubNo(mChatHubInfo.getChathubNo());
		retChatHubObj.setChathubType(mChatHubInfo.getChathubType());
		retChatHubObj.setUserNo(mChatHubInfo.getUserNo());
		retChatHubObj.setUsersNum(mChatHubInfo.getUsersNum());
		retChatHubObj.setUseYn(mChatHubInfo.getUseYn());
		
		List<ChatHubUser> chatHubUser = Lists.newArrayList();
		
		// 재조회처리
		mChatHubUserList = mChathubUserRepository.findByChathubNoAndJoinYn(mChatHubInfo.getChathubNo(), "Y");
		
		Optional<List<MUser>> userListOp = mUserRepository.findByChatHubNoJoined(mChatHubInfo.getChathubNo());
		Map<Long, MUser> userMap = userListOp.get().stream()
		        .collect(Collectors.toMap(MUser::getUserNo, muser -> muser));

		MUser mUser = null;
		for (MChathubUser mChatHubUser : mChatHubUserList) {
			mUser = null;
			for (Long key : userMap.keySet()) {
				if (key.longValue()==mChatHubUser.getUserNo().longValue()) {
					mUser = userMap.get(key);
					break;
				}
			}
			ChatHubUser u = new ChatHubUser();
			u.setChatHubNo(mChatHubInfo.getChathubNo());
			u.setUserNo(mChatHubUser.getUserNo());
			u.setUserName(mUser.getUserName());
			u.setChathubName(mChatHubUser.getChathubName());
			if (mChatHubUser.getMainChathubName()==null
					||
					mChatHubUser.getMainChathubName().isBlank()) {
				u.setMainChathubName(newChathubOpenMessage);
			} else {
				u.setMainChathubName(mChatHubUser.getMainChathubName());
			}
			u.setJoinYn(mChatHubUser.getJoinYn());
			u.setNotiYn(mChatHubUser.getNotiYn());
			u.setUseYn(mChatHubUser.getUseYn());
			u.setLastChatNo(mChatHubUser.getLastChatNo());
			
			u.setStartChatNo(mChatHubUser.getStartChatNo());

			u.setReadChatNo(
					mChatHubUser.getStartChatNo() > mChatHubUser.getReadChatNo() ? mChatHubUser.getStartChatNo() : mChatHubUser.getReadChatNo());
		
			
			if (user.getUserNo().equals(mChatHubUser.getUserNo())) {
				myEncChathubKey = mChatHubUser.getEncryptChatKey();
			}
			chatHubUser.add(u);
		}
		retChatHubObj.setEncChathubKey(myEncChathubKey);
		respObj.setChatHubInfo(retChatHubObj);
		
		respObj.setChatHubUserList(chatHubUser);
		
		Pair<List<Chat>, Long> chatListResultOp = atalkChatServiceLogic.getMessageLatestList(
				mChatHubInfo.getChathubNo()
				, 10); // 최근 10개
		List<Chat> chatList =  chatListResultOp.getLeft();
		Long lastChatNo =  chatListResultOp.getRight();
//			Optional<List<Chat>> chatListOp = atalkChatService.getMessageLatestList(
//					mChatHubInfo.getChathubNo()
//					, reqObj.getReqChatCount()); // 최근 10개
		respObj.setChatList(
				(chatList == null || chatList.size() < 1) ? Lists.newArrayList()
						:
				chatList
				);
		respObj.setLastInquireChatNo(lastChatNo);
		return respObj;
	}


	/**
	 * 
	 * @param user
	 * @return
	 */
	private List<String> _getProfileInfo(MUser user) {
		List<String> profileList = Lists.newArrayList();
		String fgThumbnailPath = "";
		String fgViewPath = "";
		String bgThumbnailPath = "";
		String bgViewPath = "";
		String contextPath = servletContext.getContextPath();
		if (user.getProfileFgNo()!=null) {
			fgThumbnailPath = String.format("%s%s%s/%s/%d",
					atalkConfig.getChatConfig().getBaseAddress()
					, contextPath 
					, atalkConfig.getProfileConfig().getBaseUrl()
					, "thumb"
					, user.getProfileFgNo());
			fgViewPath = String.format("%s%s%s/%s/%d",
					atalkConfig.getChatConfig().getBaseAddress()
					, contextPath 
					, atalkConfig.getProfileConfig().getBaseUrl()
					, "view"
					, user.getProfileFgNo());
		}
		if (user.getProfileFgNo()!=null) {
			bgThumbnailPath = String.format("%s%s%s/%s/%d",
					atalkConfig.getChatConfig().getBaseAddress()
					, contextPath 
					, atalkConfig.getProfileConfig().getBaseUrl()
					, "thumb"
					, user.getProfileBgNo());
			bgViewPath = String.format("%s%s%s/%s/%d",
					atalkConfig.getChatConfig().getBaseAddress()
					, contextPath 
					, atalkConfig.getProfileConfig().getBaseUrl()
					, "view"
					, user.getProfileBgNo());
		}
		profileList.add(fgThumbnailPath);
		profileList.add(fgViewPath);
		profileList.add(bgThumbnailPath);
		profileList.add(bgViewPath);
		
		return profileList;
	}
}
