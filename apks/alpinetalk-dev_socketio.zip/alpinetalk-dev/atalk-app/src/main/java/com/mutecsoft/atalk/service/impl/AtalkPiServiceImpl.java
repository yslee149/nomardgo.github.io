package com.mutecsoft.atalk.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mutecsoft.atalk.component.PacketDecryptor;
import com.mutecsoft.atalk.component.redis.RedisTaskBroker;
import com.mutecsoft.atalk.logic.model.AtalkDataModelAll;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.logic.model.pi.PiAgreementResponse;
import com.mutecsoft.atalk.logic.util.RandomHexString;
import com.mutecsoft.atalk.secure.model.redis.RedisPacketKeySeed;
import com.mutecsoft.atalk.service.AtalkPiService;
import com.mutecsoft.atalk.service.AtalkPiServiceLogic;
import lombok.extern.slf4j.Slf4j;

/**
 * 이용약관 서비스
 * 
 */
@Slf4j
@Service("atalkPiService")
public class AtalkPiServiceImpl implements AtalkPiService {
	
	@Autowired
	RedisTaskBroker redisTaskBroker;
	
	@Autowired
	PacketDecryptor packetDecryptor;
	
	@Autowired
	AtalkPiServiceLogic atalkPiServiceLogic;
	
	@Override
	public Optional<AtalkDataModelAll> getLatestPiAgreement(SecureDataModel secModel) throws Exception {
		String signatureDataAll = secModel.getData();
		/////////////////////////////////
		String secData = signatureDataAll.substring(
				0,
				signatureDataAll.length() - SecureDataModel.KEY_SEED_SIZE);
		String packetKeySeedValue = signatureDataAll.substring(
				signatureDataAll.length() - SecureDataModel.KEY_SEED_SIZE);
		log.debug("#### packetKeySeedValue : {}", packetKeySeedValue);
		RedisPacketKeySeed redisKeyObj = redisTaskBroker.findKeySeedData(packetKeySeedValue);
		
		if (!redisKeyObj.getActiveYn().equals("Y")) {
			AtalkDataModelAll resultObj = AtalkDataModelAll.builder()
					.httpStatusCode(425)
					.atalkPacketBase(null)
					.secureModel(null)
					.build();
			return Optional.ofNullable(resultObj);
		}
		
		////////////////////// GET PACKET KEY
		log.debug("#### redisKeyObj : {}", redisKeyObj);
		String packetKey = redisKeyObj.getPacketKey();
		
		PiAgreementResponse respObj = atalkPiServiceLogic.getLatestPiAgreement();
		if (respObj==null) {
			return Optional.ofNullable(null);
		}
		AtalkDataModelAll resData = AtalkDataModelAll.builder()
				.httpStatusCode(200)
				.atalkPacketBase(respObj)
				.secureModel(respObj.toFinalModel(packetKey))
				.build();
		resData.getSecureModel().setTransactinId(RandomHexString.genSecureRandomHex(16));
		return Optional.of(resData);
	}
}
