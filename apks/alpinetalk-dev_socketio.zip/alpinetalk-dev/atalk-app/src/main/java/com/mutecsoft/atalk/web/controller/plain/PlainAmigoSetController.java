package com.mutecsoft.atalk.web.controller.plain;

import com.mutecsoft.atalk.component.PacketDecryptor;
import com.mutecsoft.atalk.config.CustomAuthenticationProvider;
import com.mutecsoft.atalk.logic.model.amigoset.AddAmigoSetRequest;
import com.mutecsoft.atalk.logic.model.amigoset.AddAmigoSetResponse;
import com.mutecsoft.atalk.logic.model.amigoset.AmigoSetListResponse;
import com.mutecsoft.atalk.logic.model.amigoset.DeleteAmigoSetRequest;
import com.mutecsoft.atalk.logic.model.amigoset.DeleteAmigoSetResponse;
import com.mutecsoft.atalk.logic.model.amigoset.RenameAmigoSetRequest;
import com.mutecsoft.atalk.logic.model.amigoset.RenameAmigoSetResponse;
import com.mutecsoft.atalk.security.oauth2.model.CustomUserDetail;
import com.mutecsoft.atalk.service.AtalkAmigoSetServiceLogic;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;

import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationProvider;
import org.springframework.security.provisioning.UserDetailsManager;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @PackageName com.mutecsoft.atalk.web.controller.plain
 * @fileName	PlainAmigoSetController.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description :
 * <pre>
 * 
 * </pre>
 */
@Slf4j
@Tag(name="Amigo Set", description="Amigo Set API(Plain)")
@Controller
@RequestMapping(value = "/api/plain/v1/amigoSet")
public class PlainAmigoSetController {
	@Autowired
	UserDetailsManager userDetailsManager;
	
	@Autowired
	@Qualifier("jwtRefreshTokenAuthProvider")
	JwtAuthenticationProvider refreshTokenAuthProvider;
	
	@Autowired
	CustomAuthenticationProvider customAuthenticationProvider;

	@Autowired
	AtalkAmigoSetServiceLogic atalkAmigoSetServiceLogic;
	
	@Autowired
	PacketDecryptor packetDecryptor;

	/**
	 * 친구그룹 등록
	 * 
	 * @param authUser
	 * @param reqObj
	 * @return
	 */
	@PostMapping("/add")
	public ResponseEntity<?> addAmigoSet(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @RequestBody AddAmigoSetRequest reqObj) {
		try {
			log.debug("################# ADD AMIGO SET");
			AddAmigoSetResponse respObj = atalkAmigoSetServiceLogic.addAmigoSet(
					authUser.getMUser(), reqObj);
			return new ResponseEntity<>(respObj, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("@@@@ Unauthorized");
	}
	
	/**
	 * 친구그룹 수정
	 * 
	 * @param authUser
	 * @param reqObj
	 * @return
	 */
	@PostMapping("/rename")
	public ResponseEntity<?> rename(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @RequestBody RenameAmigoSetRequest reqObj) {
		try {
			log.debug("################# RENAME AMIGO SET");
			RenameAmigoSetResponse respObj = atalkAmigoSetServiceLogic.renameAmigoSet(
					authUser.getMUser(), reqObj);
			return new ResponseEntity<>(respObj, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("@@@@ Unauthorized");
	}

	/**
	 * 친구그룹 삭제
	 * 
	 * @param authUser
	 * @param reqObj
	 * @return
	 */
	@PostMapping("/delete")
	public ResponseEntity<?> delete(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @RequestBody DeleteAmigoSetRequest reqObj) {
		try {
			log.debug("################# DELETE AMIGO SET");
			DeleteAmigoSetResponse respObj = atalkAmigoSetServiceLogic.deleteAmigoSet(
					authUser.getMUser(), reqObj);
			return new ResponseEntity<>(respObj, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("@@@@ Unauthorized");
	}
	
	/**
	 * 친구그룹 조회
	 * 
	 * @param authUser
	 * @return
	 */
	@GetMapping("/list")
	public ResponseEntity<?> list(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			) {
		try {
			log.debug("################# DELETE AMIGO SET");
			AmigoSetListResponse respObj = atalkAmigoSetServiceLogic.amigoSetList(
					authUser.getMUser());
			return new ResponseEntity<>(respObj, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("@@@@ Unauthorized");
	}
}
