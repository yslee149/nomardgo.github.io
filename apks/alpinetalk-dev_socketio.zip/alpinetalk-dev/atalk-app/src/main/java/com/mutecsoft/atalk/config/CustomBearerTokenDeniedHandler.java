package com.mutecsoft.atalk.config;

import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Component;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@Component
public class CustomBearerTokenDeniedHandler implements AccessDeniedHandler {

    @Override
    public void handle(HttpServletRequest request, HttpServletResponse response
    		, AccessDeniedException accessDeniedException)
            throws IOException {

        // Customize the response when access is denied
        response.setContentType("application/json");
        response.setStatus(HttpServletResponse.SC_FORBIDDEN);  // 403 Forbidden

        // Send custom error message
        String errorMessage = "Access denied: You do not have permission to access this resource.";
        response.getWriter().write("{\"error\": \"" + errorMessage + "\"}");
    }
}
