package com.mutecsoft.atalk.config;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;

import com.mutecsoft.atalk.security.oauth2.model.TokenKeysProperty;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.*;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.EncodedKeySpec;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Arrays;
import java.util.Objects;

/**
 * @PackageName com.cnu.cas.mdms.app.config
 * @fileName	KeyUtils.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description :
 * <pre>
 *  WebSecurity  설정
 * </pre>
 */
@Slf4j
@Component
public class KeyUtils {
	@Autowired
	Environment environment;

    @Autowired
    private ResourceLoader resourceLoader;
	
	@Autowired
	private TokenKeysProperty tokenProperty;
	
	private KeyPair accessTokenKeyPair;
	private KeyPair refreshTokenKeyPair;
	
	private KeyPair secureJwtKeyPair;

	private KeyPair getAccessTokenKeyPair() {
		if (Objects.isNull(accessTokenKeyPair)) {
			accessTokenKeyPair = getKeyPair(
					tokenProperty.getAccessToken().getPublicKeyPath()
					, tokenProperty.getAccessToken().getPrivateKeyPath());
		}
		return accessTokenKeyPair;
	}

	private KeyPair getRefreshTokenKeyPair() {
		if (Objects.isNull(refreshTokenKeyPair)) {
			refreshTokenKeyPair = getKeyPair(
					tokenProperty.getRefreshToken().getPublicKeyPath()
					, tokenProperty.getRefreshToken().getPrivateKeyPath());
		}
		return refreshTokenKeyPair;
	}


	public KeyPair getSecureJwtKeyPair() {
		if (Objects.isNull(secureJwtKeyPair)) {
			secureJwtKeyPair = getKeyPair(
					tokenProperty.getSecureJwtToken().getPublicKeyPath()
					, tokenProperty.getSecureJwtToken().getPrivateKeyPath());
		}
		return secureJwtKeyPair;
	}
    
	private byte[] readFileAsBytes(String path) {
        try {
            ClassPathResource resource = new ClassPathResource(path);
            return Files.readAllBytes(Path.of(resource.getURI()));
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
    
	private KeyPair getKeyPair(String publicKeyPath, String privateKeyPath) {
		KeyPair keyPair;
		
		Resource publicKeyFile = resourceLoader.getResource("classpath:" + publicKeyPath);
		Resource privateKeyFile = resourceLoader.getResource("classpath:" + privateKeyPath);
		
//		if (resource.equals(resource))
//        BufferedReader reader = new BufferedReader(new InputStreamReader(resource.getInputStream(), StandardCharsets.UTF_8));
//      
//		File publicKeyFile = new File(publicKeyPath);
//		File privateKeyFile = new File(privateKeyPath);

		if (publicKeyFile.exists() && privateKeyFile.exists()) {
			try {
				KeyFactory keyFactory = KeyFactory.getInstance("RSA");
				
				byte[] publicKeyBytes = readFileAsBytes(publicKeyPath);
				EncodedKeySpec publicKeySpec = new X509EncodedKeySpec(publicKeyBytes);
				PublicKey publicKey = keyFactory.generatePublic(publicKeySpec);
				
				byte[] privateKeyBytes = readFileAsBytes(privateKeyPath);
				PKCS8EncodedKeySpec privateKeySpec = new PKCS8EncodedKeySpec(privateKeyBytes);
				PrivateKey privateKey = keyFactory.generatePrivate(privateKeySpec);
				
				keyPair = new KeyPair(publicKey, privateKey);
				return keyPair;
			} catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
				throw new RuntimeException(e);
			}
		} else {
			if (Arrays.stream(environment.getActiveProfiles()).anyMatch(s -> s.equals("prod"))) {
				throw new RuntimeException("public and private keys don't exist");
			}
		}
//		Path pubPath = Paths.get(publicKeyPath);		
//		File baseKeyPathFile = pubPath.getParent().toFile();
//		if (!baseKeyPathFile.exists()) {
//			baseKeyPathFile.mkdirs();
//		}
//		try {
//			//log.info("Generating new public and private keys: {}, {}", publicKeyPath, privateKeyPath);
//			KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
//			keyPairGenerator.initialize(2048);
//			keyPair = keyPairGenerator.generateKeyPair();
//			try (FileOutputStream fos = new FileOutputStream(publicKeyPath)) {
//				X509EncodedKeySpec keySpec = new X509EncodedKeySpec(keyPair.getPublic().getEncoded());
//			    fos.write(keySpec.getEncoded());
//			}
//			try (FileOutputStream fos = new FileOutputStream(privateKeyPath)) {
//				PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(keyPair.getPrivate().getEncoded());
//				fos.write(keySpec.getEncoded());
//			}
//		} catch (NoSuchAlgorithmException | IOException e) {
//			throw new RuntimeException(e);
//		}
		return null;
	}

	public RSAPublicKey getAccessTokenPublicKey() {
		return (RSAPublicKey) getAccessTokenKeyPair().getPublic();
	}
	public RSAPrivateKey getAccessTokenPrivateKey() {
		return (RSAPrivateKey) getAccessTokenKeyPair().getPrivate();
	}
	public RSAPublicKey getRefreshTokenPublicKey() {
		return (RSAPublicKey) getRefreshTokenKeyPair().getPublic();
	}
	public RSAPrivateKey getRefreshTokenPrivateKey() {
		return (RSAPrivateKey) getRefreshTokenKeyPair().getPrivate();
	}

	public RSAPublicKey getSecureTokenPublicKey() {
		return (RSAPublicKey) getSecureJwtKeyPair().getPublic();
	}
	public RSAPrivateKey getSecureTokenPrivateKey() {
		return (RSAPrivateKey) getSecureJwtKeyPair().getPrivate();
	}
}
