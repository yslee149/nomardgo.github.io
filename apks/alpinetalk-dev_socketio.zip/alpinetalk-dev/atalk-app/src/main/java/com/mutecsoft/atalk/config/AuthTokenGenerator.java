package com.mutecsoft.atalk.config;

import java.security.NoSuchAlgorithmException;
import java.text.MessageFormat;
import java.text.ParseException;
import java.time.Duration;
import java.time.Instant;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.jwt.JwtClaimsSet;
import org.springframework.security.oauth2.jwt.JwtEncoder;
import org.springframework.security.oauth2.jwt.JwtEncoderParameters;

import com.google.common.collect.Maps;
import com.mutecsoft.atalk.logic.model.auth.UserAuthTokenRequest;
import com.mutecsoft.atalk.logic.model.auth.UserLoginRequest;
import com.mutecsoft.atalk.security.oauth2.model.AuthToken;
import com.mutecsoft.atalk.security.oauth2.model.CustomUserDetail;
import com.mutecsoft.atalk.security.oauth2.model.TokenKeysProperty;
import com.nimbusds.jose.JOSEException;

import lombok.extern.slf4j.Slf4j;

import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Component;

/**
 * @PackageName com.cnu.cas.mdms.app.config
 * @fileName	AuthTokenGenerator.java
 * @author voyzer
 * @Date   2024. 10. 1
 * @description :
 * <pre>
 * 
 * </pre>
 */
@Slf4j
@Component
public class AuthTokenGenerator {

//	@Autowired
//	@Qualifier("jwtAccessTokenDecoder")
//	JwtDecoder accessTokenDecoder;
//	
	@Autowired
	@Qualifier("jwtAccessTokenEncoder")
	JwtEncoder accessTokenEncoder;
	
	@Autowired
	@Qualifier("jwtRefreshTokenEncoder")
	JwtEncoder refreshTokenEncoder;
    
	@Autowired
	KeyUtils keyUtils;
	
	@Autowired
	TokenKeysProperty tokenKeysProperty;
	
	/**
	 * ACCESS TOKEN 생성
	 * 
	 * @param userId
	 * @param moreInfo
	 * @return
	 * @throws JOSEException
	 * @throws ParseException
	 * @throws NoSuchAlgorithmException
	 */
	private String createAccessToken(String userId, Map<String, String> moreInfo) throws JOSEException, ParseException, NoSuchAlgorithmException {
		// gmt time
		Instant now = Instant.now();  // Get the current time
		long expireDurationSeconds = tokenKeysProperty.getAccessToken().getJwtDurationMinutes() * 60;
		
		JwtClaimsSet.Builder claimsBuilder = JwtClaimsSet.builder()
			.issuer("CASAPP")
			.issuedAt(now)
			.expiresAt(
					now.plusSeconds(expireDurationSeconds)) // short term, 30 minutes around
			.subject(userId);
		
		// Add additional claims
		moreInfo.forEach(claimsBuilder::claim);
		
		JwtClaimsSet claimsSet = claimsBuilder.build();
		
		return accessTokenEncoder.encode(JwtEncoderParameters.from(claimsSet)).getTokenValue();
//		
//		// Create the JWS Header (for signing)
//		JwsHeader jwsHeader = JwsHeader.with(SignatureAlgorithm.RS256).build();
//		
//		// encode jwt
//		String signedToken = accessTokenEncoder.encode(
//				JwtEncoderParameters.from(jwsHeader, claimsSet)).getTokenValue();
//		
//		Jwt jwt = accessTokenDecoder.decode(signedToken);
//		
//		return signedToken;
//		
//		// Create the JWS Header (for signing)
//		JwsHeader jwsHeader = JwsHeader.with(SignatureAlgorithm.RS256).build();
//		
//		// encode jwt
//		String signedToken = accessTokenEncoder.encode(
//				JwtEncoderParameters.from(jwsHeader, claimsSet)).getTokenValue();
//		
//		JWEObject jweObject = new JWEObject(
//                new JWEHeader.Builder(
//                		JWEAlgorithm.DIR, EncryptionMethod.A256GCM).build(),
//                new Payload(signedJWT)  // Replace with your payload
//        );
//
//		jweObject.encrypt(new DirectEncrypter(secretKey));
//
//        String encryptedJwt = jweObject.serialize();
//
//		return encryptedJwt;
//		
//
//		//////////// ENCRYPT JWT TOKEN ONE MORE 
//		// Parse the signed token into a SignedJWT object
//		SignedJWT signedJWT = SignedJWT.parse(signedToken);
//		// Example RSA public key for encryption (you need to use your actual key)
//		RSAPublicKey publicKey = keyUtils.getSecureTokenPublicKey();
//		// Create the JWE header
//		JWEHeader jweHeader = new JWEHeader(
//				JWEAlgorithm.RSA_OAEP_256
//				, EncryptionMethod.A128GCM);
//		// Create the Encrypted JWT (using the signed JWT's payload)
//		EncryptedJWT encryptedJWT = new EncryptedJWT(jweHeader, signedJWT.getJWTClaimsSet());
//		// Encrypt the signed JWT with the public key
//		RSAEncrypter encrypter = new RSAEncrypter(publicKey);
//		encryptedJWT.encrypt(encrypter);
//		// Get the final encrypted token
//		String finalEncryptedToken = encryptedJWT.serialize();
//		////////////ENCRYPT JWT TOKEN
//		
//		return finalEncryptedToken;
	}
    
	/**
	 * refresh token 생성
	 * 
	 * @param userId
	 * @param moreInfo
	 * @return
	 */
	private String createRefreshToken(String userId, Map<String, String> moreInfo) {
		Instant now = Instant.now();
		long expireDurationSeconds = tokenKeysProperty.getRefreshToken().getJwtDurationMinutes() * 60;
		
		JwtClaimsSet.Builder claimsBuilder = JwtClaimsSet.builder()
			.issuer("CASAPP")
			.issuedAt(now)
			.expiresAt(
					now.plusSeconds(expireDurationSeconds)) // 10 days
			.subject(userId);

		// Add additional claims
		moreInfo.forEach(claimsBuilder::claim);
		
		JwtClaimsSet claimsSet = claimsBuilder.build();
		return refreshTokenEncoder.encode(JwtEncoderParameters.from(claimsSet)).getTokenValue();
	}
	
	/**
	 * 
	 * @return
	 */
	public static Map<String, String> toMoreJwtInfo(UserAuthTokenRequest req) {
		Map<String, String> moreInf = Maps.newHashMap();
		
	//	moreInf.put("11",  req.get)
		
		return moreInf;
	}
	
	/**
	 * 
	 * @return
	 */
	public static Map<String, String> toMoreJwtInfo(UserLoginRequest req) {
		Map<String, String> moreInf = Maps.newHashMap();
		
		moreInf.put("imei",  req.getImei());
		
		return moreInf;
	}
	
	/**
	 * GENERATE TOKEN 토큰 생성
	 * 
	 * @param authentication
	 * @param moreInfo
	 * @return
	 * @throws JOSEException
	 * @throws ParseException
	 * @throws NoSuchAlgorithmException
	 */
	public AuthToken createToken(
			Authentication authentication,
			Map<String, String> moreInfo) throws JOSEException, ParseException, NoSuchAlgorithmException {
		
		String userId = null;
		if (authentication.getPrincipal() instanceof CustomUserDetail user) {
			userId = user.getUserId();
		} else if (authentication.getPrincipal() instanceof org.springframework.security.oauth2.jwt.Jwt jwtObj) {
			userId = jwtObj.getSubject();
		} else {
			throw new BadCredentialsException(
					MessageFormat.format("principal {0} is not of User type", authentication.getPrincipal().getClass())
			);
		}
		log.debug("################ USER ID : {}", userId);
		AuthToken tokenDTO = new AuthToken();
		tokenDTO.setUserId(userId);
		tokenDTO.setAccessToken(createAccessToken(userId, moreInfo));

		String refreshToken;
		if (authentication.getCredentials() instanceof Jwt jwt) {
			Instant now = Instant.now();
			Instant expiresAt = jwt.getExpiresAt();
			Duration duration = Duration.between(now, expiresAt);
			long daysUntilExpired = duration.toDays();
			if (daysUntilExpired < 7) {
			    refreshToken = createRefreshToken(userId, moreInfo);
			} else {
			    refreshToken = jwt.getTokenValue();
			}
		} else {
			refreshToken = createRefreshToken(userId, moreInfo);
		}
		tokenDTO.setRefreshToken(refreshToken);
		tokenDTO.setMoreInfo(moreInfo);
		return tokenDTO;
	}
	
	
	
	///////////// check token
	public int validateRefreshToken(String refreshToken) {
		
		
		return 0;
	}
}
