package com.mutecsoft.atalk.service;

import org.apache.commons.lang3.tuple.Pair;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

import com.mutecsoft.atalk.common.model.MUser;
import com.mutecsoft.atalk.constant.EnumChatSubType;
import com.mutecsoft.atalk.constant.EnumChatType;
import com.mutecsoft.atalk.logic.model.chat.Chat;
import com.mutecsoft.atalk.logic.model.chat.ChatInfoRequest;
import com.mutecsoft.atalk.logic.model.chat.ChatInfoResponse;
import com.mutecsoft.atalk.logic.model.chat.ChatResponse;
import com.mutecsoft.atalk.logic.model.chat.DeleteChatRequest;
import com.mutecsoft.atalk.logic.model.chat.DeleteChatResponse;
import com.mutecsoft.atalk.logic.model.chat.ExtChatResponse;
import com.mutecsoft.atalk.logic.model.chat.ReadChatRequest;
import com.mutecsoft.atalk.logic.model.chat.ReadChatResponse;
import com.mutecsoft.atalk.logic.model.chat.RetrieveChatRequest;
import com.mutecsoft.atalk.logic.model.chat.RetrieveChatResponse;
import com.mutecsoft.atalk.logic.model.chat.SendChatRequest;
import com.mutecsoft.atalk.logic.model.chat.SendChatResponse;
import com.mutecsoft.atalk.logic.model.chat.SendFileChatResponse;

public interface AtalkChatServiceLogic {
	
	Chat sendInfoMessage(String subType, Long userNo, Long chatHubNo, String message);
	Chat sendMessage(
			Long userNo
			, Long chatHubNo
			, String message
			, EnumChatType chatType
			, EnumChatSubType chatSubType);
	
	Chat sendFileMessage(Long userNo, Long chatHubNo, String fileName, byte [] fileBuffer);
	
	Pair<List<Chat>, Long> getMessageList(Long chatHubNo, Long baseChatNo, int chatCount);
	Pair<List<Chat>, Long> getMessageLatestList(Long chatHubNo, int chatCount);
	
	///////////////////////////////////////////////
	
	SendChatResponse procMessage(MUser user, SendChatRequest reqObj) throws Exception;
	SendFileChatResponse procFileMessage(
			MUser user
			, Long chathubNo
			, String fileType
			, MultipartFile file) throws Exception;
	ChatInfoResponse chatList(MUser user, ChatInfoRequest reqObj) throws Exception;
	ExtChatResponse getExtChat(MUser user, Long extChatNo) throws Exception;
	DeleteChatResponse deleteChatList(MUser user, DeleteChatRequest reqObj) throws Exception;
	RetrieveChatResponse retrieveChatList(MUser user, RetrieveChatRequest reqObj) throws Exception;
	ReadChatResponse readChat(MUser user, ReadChatRequest reqObj) throws Exception;
	
	ChatResponse get(Long userNo, Long chatHubNo, Long chatNo) throws Exception;
	
	// get 마지막 대화 정보 요청
	Chat getLastMessage(Long chatHubNo);
	
}

