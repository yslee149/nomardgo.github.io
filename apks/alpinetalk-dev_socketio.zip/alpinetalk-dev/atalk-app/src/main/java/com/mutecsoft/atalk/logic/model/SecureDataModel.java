package com.mutecsoft.atalk.logic.model;

import java.io.Serializable;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mutecsoft.atalk.logic.util.AesEncDecComplex;

/**
 * @PackageName com.mutecsoft.atalk.logic.model
 * @fileName	SecureDataModel.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description :
 * <pre>
 * 
 * </pre>
 */
public class SecureDataModel implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = -7029422274605777744L;
	

	protected static final ObjectMapper objectMapper = new ObjectMapper();
	
	
	public static int KEY_SEED_SIZE = 32;
	
	private String transactinId;
    private String data;
    
//    
//	public String getPacketSeedVal() {
//		return packetSeedVal;
//	}
//	public void setPacketSeedVal(String packetSeedVal) {
//		this.packetSeedVal = packetSeedVal;
//	}
	public String getTransactinId() {
		return transactinId;
	}
	public void setTransactinId(String transactinId) {
		this.transactinId = transactinId;
	}
	public String getData() {
		return data;
	}

	public String toJson() throws JsonProcessingException {
		return objectMapper.writeValueAsString(this);
	}
	/**
	 * extract key seed
	 * 
	 * @return
	 */
	public String extractKeySeed() {
		return data.substring(data.length() - SecureDataModel.KEY_SEED_SIZE);
	}
	
	/**
	 * extract secure data
	 * 
	 * @return
	 */
	public String extractData() {
		return data.substring(0, data.length() - SecureDataModel.KEY_SEED_SIZE);
	}
	
	/**
	 *
	 * @param data
	 * @param seedVal
	 */
	public void setData(String data, String seedVal) {
		this.data = String.format("%s%s", data, seedVal);
	}
	
	/**
	 *
	 * @param dataMore
	 */
	public void setDataAfter(String dataMore) {
		StringBuffer sb = new StringBuffer();
		sb.append(this.data);
		sb.append(dataMore);
		this.data = sb.toString();
	}
	
	/**
	 *
	 * @param dataMore
	 */
	public void setDataBefore(String dataMore) {
		StringBuffer sb = new StringBuffer();
		sb.append(dataMore);
		sb.append(this.data);
		this.data = sb.toString();
	}
	
	/**
	 * 
	 * @param data
	 */
	public void setData(String data) {
		this.data = data;
	}
	
	/**
	 * 
	 * @param jsonString
	 * @return
	 * @throws JsonMappingException
	 * @throws JsonProcessingException
	 */
	public static SecureDataModel fromBuffer(String jsonString) throws JsonMappingException, JsonProcessingException {
		SecureDataModel secureModel = objectMapper.readValue(jsonString, SecureDataModel.class);
		return secureModel;
	}
	
	/**
	 * 
	 * 
	 * @param <T>
	 * @param encryptHexBuffer
	 * @param packetKey
	 * @param clazz
	 * @return
	 * @throws Exception 
	 */
	public static <T extends AtalkPacketBase> T fromEncHexBuffer (
			String encryptHexBuffer
			, String packetKey
			, Class<T> clazz) throws Exception {
		byte [] encBytesBuffer = AesEncDecComplex.hexToBytes(encryptHexBuffer);
		byte [] decBuffer = AesEncDecComplex.decryptAesCtrWithIv(encBytesBuffer, packetKey);
		String decBuffString = new String(decBuffer);
	    return objectMapper.readValue(decBuffString, clazz);
	}
}
