package com.mutecsoft.atalk.logic.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.mutecsoft.atalk.security.oauth2.model.AuthToken;
import com.mutecsoft.atalk.security.oauth2.model.AuthUserInfo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;

/**
 * Login Response
 * @author 
 */
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL) // null 제외
public class LoginResponse {
	/**
	 * 사용자 메뉴 권한
	 */
	@Schema(name="tokenInfo", description = "토큰 정보")
	@JsonProperty("tokenInfo")
    @Expose
    @SerializedName("tokenInfo")
	AuthToken tokenInfo;
	
	/**
	 * 유저 정보
	 */
	@Schema(name="userInfo", description = "유저 정보")
	@JsonProperty("userInfo")
    @Expose
    @SerializedName("userInfo")
	AuthUserInfo userInfo;

//	public LoginResponse() {}
//	
//	/**
//	 * @param userMenuList
//	 * @param landingPageUrl
//	 * @param userInfo
//	 */
//	public LoginResponse(List<MenuJsonObj> userMenuList, AuthUserInfo userInfo) {
//		this.userMenuList = userMenuList;
//		this.userInfo = userInfo;
//	}
//		
}
