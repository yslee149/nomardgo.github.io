package com.mutecsoft.atalk.web.controller.plain;

import com.mutecsoft.atalk.logic.model.chathub.ChathubInfoRequest;
import com.mutecsoft.atalk.logic.model.chathub.ExitChathubResponse;
import com.mutecsoft.atalk.logic.model.chathub.InviteChathubRequest;
import com.mutecsoft.atalk.logic.model.chathub.InviteChathubResponse;
import com.mutecsoft.atalk.logic.model.chathub.KickOutChathubResponse;
import com.mutecsoft.atalk.logic.model.chathub.ListChathubRequest;
import com.mutecsoft.atalk.logic.model.chathub.ListChathubResponse;
import com.mutecsoft.atalk.logic.model.chathub.OpenChathubRequest;
import com.mutecsoft.atalk.logic.model.chathub.OpenChathubResponse;
import com.mutecsoft.atalk.logic.model.chathub.OpenChathubWithTitleRequest;
import com.mutecsoft.atalk.security.oauth2.model.CustomUserDetail;
import com.mutecsoft.atalk.service.AtalkChatHubServiceLogic;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @PackageName com.mutecsoft.atalk.web.controller.plain
 * @fileName	PlainAtalkChatHubController.java
 * @author voyzer
 * @Date   2024. 12. 1.
 * @description :
 * <pre>
 * 
 * </pre>
 */
@Slf4j
@Tag(name="ChatHub", description="ChatHub API")
@Controller
@RequestMapping(value = "/api/plain/v1/chatHub")
public class PlainAtalkChatHubController {

	@Autowired
	AtalkChatHubServiceLogic atalkChatHubServiceLogic;
	
	/**
	 * 대화방 오픈
	 * 
	 * @param authUser
	 * @param reqObj
	 * @return
	 */
	@PostMapping("/openChathub")
	public ResponseEntity<?> openChathub(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @RequestBody OpenChathubRequest reqObj) {
		try {
			log.debug("################# OPEN CHATHUB");
			OpenChathubResponse respObj = atalkChatHubServiceLogic.openChathub(
					authUser.getMUser(), reqObj);
			return new ResponseEntity<>(respObj, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
	
	/**
	 * 대화방 목록 정보 처리
	 * 
	 * @param authUser
	 * @param reqObj
	 * @return
	 */
	@PostMapping("/list/{updDate}")
	public ResponseEntity<?> list(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @PathVariable("updDate") String updDate) {
		try {
			log.debug("################# LIST CHATHUB");
			ListChathubRequest reqObj = new ListChathubRequest();
			reqObj.setUpdateDt(updDate);
			ListChathubResponse respObj = atalkChatHubServiceLogic.listChathub(
					authUser.getMUser(), reqObj);
			return new ResponseEntity<>(respObj, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}

	/**
	 * 대화방 초대
	 * 
	 * @param authUser
	 * @param reqObj
	 * @return
	 */
	@PostMapping("/invite")
	public ResponseEntity<?> invite(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @RequestBody InviteChathubRequest reqObj) {
		try {
			log.debug("################# LIST CHATHUB");
			InviteChathubResponse respObj = atalkChatHubServiceLogic.invite(
					authUser.getMUser(), reqObj);
			return new ResponseEntity<>(respObj, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
	
	/**
	 * 대화방 강퇴
	 * 
	 * @param authUser
	 * @param reqObj
	 * @return
	 */
	@PostMapping("/forceExit/{chatHubNo}/{userNoList}")
	public ResponseEntity<?> forceExit(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @PathVariable("chatHubNo") Long chatHubNo
			, @PathVariable("userNoList") List<Long> userNoList
			) {
		try {
			log.debug("################# FORCE EXIT USERS");
			KickOutChathubResponse respObj = atalkChatHubServiceLogic.forceExit(
					authUser.getMUser(), chatHubNo, userNoList);
			return new ResponseEntity<>(respObj, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}

	/**
	 * 대화방 나감
	 * 
	 * @param authUser
	 * @param chathubNo
	 * @param exitQuietly
	 * @return
	 */
	@PostMapping("/exit/{chathubNo}/{exitQuietly}")
	public ResponseEntity<?> exit(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @PathVariable("chathubNo") Long chathubNo
			, @PathVariable("exitQuietly") String exitQuietly) {
		try {
			log.debug("################# LIST CHATHUB");
			ExitChathubResponse respObj = atalkChatHubServiceLogic.exit(
					authUser.getMUser(), chathubNo, exitQuietly);
			return new ResponseEntity<>(respObj, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
	
	/**
	 * 대화방 오픈 그룹아이디로
	 * 
	 * @param authUser
	 * @param secureReqModel
	 * @return
	 */
	@PostMapping("/openChathub/{amigoSetNo}")
	public ResponseEntity<?> openChathub(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @PathVariable("amigoSetNo") Long amigoSetNo) {
		try {
			log.debug("################# OPEN CHATHUB by amigoSetNo");
			OpenChathubResponse respObj = atalkChatHubServiceLogic.openChathubByAmigoSetNo(
					authUser.getMUser(), amigoSetNo);
			return new ResponseEntity<>(respObj, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}

	/**
	 * 대화방 오픈
	 * 
	 * @param authUser
	 * @param secureReqModel
	 * @return
	 */
	@PostMapping("/openChathubWithTitle")
	public ResponseEntity<?> openChathubWithTitle(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @RequestBody OpenChathubWithTitleRequest reqObj) {
		try {
			log.debug("################# OPEN CHATHUB");
			OpenChathubResponse respObj = atalkChatHubServiceLogic.openChathubWithTitle(
					authUser.getMUser(), reqObj);
			return new ResponseEntity<>(respObj, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
	
	/**
	 * 대화방 오픈 그룹아이디로
	 * 
	 * @param authUser
	 * @param secureReqModel
	 * @return
	 */
	@PostMapping("/info/{chathubNo}")
	public ResponseEntity<?> info(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @PathVariable("chathubNo") Long chathubNo) {
		try {
			log.debug("################# INFO CHATHUB by chathubNo");
			ChathubInfoRequest reqObj = new ChathubInfoRequest();
			reqObj.setChathubNo(chathubNo);
			OpenChathubResponse respObj = atalkChatHubServiceLogic.info(
					authUser.getMUser(), reqObj);
			return new ResponseEntity<>(respObj, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}
}
