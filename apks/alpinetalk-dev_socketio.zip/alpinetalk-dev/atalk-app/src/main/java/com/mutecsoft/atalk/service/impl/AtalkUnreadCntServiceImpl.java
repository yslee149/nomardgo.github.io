package com.mutecsoft.atalk.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import com.mutecsoft.atalk.config.AtalkConfig;
import com.mutecsoft.atalk.service.AtalkUnreadCntService;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;

/**
 * UNREAD COUNT 서비스
 * 
 */
@Slf4j
@Service("atalkUnreadCntService")
public class AtalkUnreadCntServiceImpl implements AtalkUnreadCntService {
    
	@Autowired
	@Qualifier("redisTemplateUnreadCntDb")
	RedisTemplate<String, Object> redisTemplateUnreadCntDb;
	
	@Autowired
	AtalkConfig atalkConfig;
	
	private String keyPrefix;
	private String keyHashPrefix;
	
	@PostConstruct
	private void init() {
		keyPrefix = "unread_cnt:";
		keyHashPrefix = "chathub_";
	}
	
	@Override
	public void incrementUnreadCount(Long userNo, Long chatHubNo) {
		redisTemplateUnreadCntDb.opsForHash().increment(
				keyPrefix + userNo.toString()
				, keyHashPrefix + chatHubNo.toString()
				, 1);
	}

	@Override
	public void resetUnreadCount(Long userNo, Long chatHubNo) {
		redisTemplateUnreadCntDb.opsForHash().put(
				keyPrefix + userNo.toString()
				, keyHashPrefix + chatHubNo.toString()
				, 0);

	}

	@Override
	public int getUnreadCount(Long userNo, Long chatHubNo) {
		Object count = redisTemplateUnreadCntDb.opsForHash().get(
				keyPrefix + userNo.toString()
				, keyHashPrefix + chatHubNo.toString());
		return count != null ? Integer.parseInt(count.toString()) : 0;
	}

	@Override
	public int getTotalUnreadCount(Long userNo) {
		List<Object> counts = redisTemplateUnreadCntDb.opsForHash().values(
				keyPrefix + userNo.toString());
		return counts.stream().mapToInt(count -> Integer.parseInt(count.toString())).sum();
	}

	@Override
	public void deleteKey(Long userNo) {
		redisTemplateUnreadCntDb.delete(keyPrefix + userNo.toString());
	}

	@Override
	public void setUnreadCount(Long userNo, Long chatHubNo, Long unreadCnt) {
		redisTemplateUnreadCntDb.opsForHash().put(
				keyPrefix + userNo.toString()
				, keyHashPrefix + chatHubNo.toString()
				, unreadCnt);
	}
}
