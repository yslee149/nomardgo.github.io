package com.mutecsoft.atalk.service;

import com.mutecsoft.atalk.logic.model.SecureDataModel;

public interface AtalkCtrlService {
	
	String resetAll(SecureDataModel secModel) throws Exception;
}
