package com.mutecsoft.atalk.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;

import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtEncoder;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.security.oauth2.jwt.NimbusJwtEncoder;

import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationProvider;
import org.springframework.security.oauth2.server.resource.web.authentication.BearerTokenAuthenticationFilter;
import org.springframework.security.web.SecurityFilterChain;

import com.mutecsoft.atalk.component.PacketDecryptor;
import com.mutecsoft.atalk.security.UserDetailsManageService;
import com.nimbusds.jose.jwk.JWK;
import com.nimbusds.jose.jwk.JWKSet;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jose.jwk.source.ImmutableJWKSet;
import com.nimbusds.jose.jwk.source.JWKSource;
import com.nimbusds.jose.proc.SecurityContext;

import lombok.extern.slf4j.Slf4j;

/**
 * @PackageName com.cnu.cas.mdms.app.config
 * @fileName	WebSecrityConfig.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description :
 * <pre>
 *  WebSecurity  설정
 * </pre>
 */

@Slf4j
@Configuration
@EnableWebSecurity
public class WebSecrityConfig {
//	@Autowired
//	CustomAuthenticationProvider customAuthenticationProvider;
	
	@Autowired
	JWTtoUserConvertor jwtToUserConverter;
	
//	@Autowired
//	JwtRequestFilter jwtRequestFilter;
	
	@Autowired
	KeyUtils keyUtils;
	
    @Autowired
    PasswordEncoder passwordEncoder;
    
	@Autowired
	UserDetailsManageService userDetailsManageService;
	
	@Autowired
	CustomBearerTokenAuthenticationEntryPoint customBearerTokenAuthenticationEntryPoint;
	
	@Autowired
	CustomBearerTokenDeniedHandler customBearerTokenDeniedHandler;
	
	@Autowired
	PacketDecryptor packetDecryptor;
	
	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
		http
//			.authenticationProvider(
//					new CustomJwtAuthenticationProvider(keyUtils))// Add your custom provider
			.addFilterBefore(jwtTokenFilter() , BearerTokenAuthenticationFilter.class)
	        .headers(headersConfigurer ->headersConfigurer
	        		.frameOptions(HeadersConfigurer.FrameOptionsConfig::sameOrigin)
	        )
	    	.authorizeHttpRequests((authorize) -> authorize
	            .requestMatchers(
	            		"/api/v1/auth/login"
	            		, "/api/v1/auth/getUserId"
	            		, "/api/v1/auth/refresh"
	            		, "/api/v1/auth/issueTempPassword/**"
	            		, "/api/v1/auth/issueToken/**"
	            		, "/api/v1/auth/checkIssueToken/**"
	            		, "/api/v1/user/checkDupAccount/**"
	            		, "/api/v1/profile/thumb/**"
	            		, "/api/v1/profile/view/**"
	            		, "/api/v1/digitalSign/**"
	            		, "/api/v1/user/signup"
	            		, "/api/v1/search/noauth/userId"
	            		, "/api/v1/user/deleteUserTest"
	            		, "/api/v1/svcctrl/resetAll"
	            		
	        			, "/api/v1/pi/getLatest"
	        			, "/api/v1/pf/getLatest"
	        			, "/api/v1/si/getLatest"
	        			
	            		, "/api/plain/v1/auth/login"
	            		, "/api/plain/v1/auth/getUserId"
	            		, "/api/plain/v1/auth/refresh"
	            		, "/api/plain/v1/auth/issueTempPassword/**"
	            		, "/api/plain/v1/user/checkDupAccount/**"
	            		, "/api/plain/v1/auth/issueToken/**"
	            		, "/api/plain/v1/auth/checkIssueToken/**"
	            		, "/api/plain/v1/profile/thumb/**"
	            		, "/api/plain/v1/profile/view/**"
	            		, "/api/plain/v1/digitalSign/**"
	            		, "/api/plain/v1/user/signup"
	            		, "/api/plain/v1/search/noauth/userId"
	            		
	            		, "/api/plain/v1/chat/get/**"
	            		
	            		, "/api/plain/v1/user/deleteUserTest"
	            		, "/api/plain/v1/svcctrl/resetAll"
	            		
	        			, "/api/plain/v1/pi/getLatest"
	        			, "/api/plain/v1/pf/getLatest"
	        			, "/api/plain/v1/si/getLatest"
	        			
	        			, "/api/plain/v1/pi/getLatestContent"
	        			, "/api/plain/v1/pf/getLatestContent"
	        			, "/api/plain/v1/si/getLatestContent"
	        			
	        			
	        			, "/api/v1/chat/fileNoAuth/**"
	        			
	        			
	            		).permitAll()
	            .anyRequest().authenticated()
			)
			.csrf(AbstractHttpConfigurer::disable)
			// .cors(AbstractHttpConfigurer::disable)
			.httpBasic(basic -> basic.disable())
			.exceptionHandling((exceptions) -> exceptions
					.authenticationEntryPoint(customBearerTokenAuthenticationEntryPoint)
					.accessDeniedHandler(customBearerTokenDeniedHandler))
			.oauth2ResourceServer(oauth2 -> oauth2
	                .jwt(jwt -> jwt
	                	// .decoder(accessTokenDecoder1())  // Use custom JwtDecoder
	                    .jwtAuthenticationConverter(jwtToUserConverter)
	                )
	            )
//			.oauth2ResourceServer((oauth2) ->
//					oauth2.jwt((jwt) -> {
//						jwt.jwtAuthenticationConverter(jwtToUserConverter);
//					}
//				)
//			)
//		.oauth2Login((oauth2) -> oauth2
//				// .loginProcessingUrl("")
//				.successHandler(new SuccessLoginHandler())
//				.failureHandler(new FailureLoginHandler())
//		)
//		.formLogin(login -> login.loginPage("/login.html")
//				.usernameParameter("id")
//				.passwordParameter("pw")
//				.loginProcessingUrl("/api/loginProcess")
//				.successHandler(new SuccessLoginHandler())
//				.failureHandler(new FailureLoginHandler())
//				.permitAll()
//		)
//       	.logout(logout -> logout.logoutUrl("/api/logout")
//        		.logoutSuccessHandler(new SuccessLogoutHandler())
//        		.clearAuthentication(true)
//    	        .deleteCookies("SESSION", "AUTHORITY", "JSESSIONID")
//    	        .invalidateHttpSession(true)
//    	        .permitAll()
//    	        .permitAll()
//        )
			.sessionManagement((session) -> session.sessionCreationPolicy(
					SessionCreationPolicy.STATELESS)  // NO SESSION USED

		);
		return http.build();
	}

	@Bean
	JwtDecoder jwtAccessTokenDecoder() {
		return NimbusJwtDecoder.withPublicKey(keyUtils.getAccessTokenPublicKey()).build();
	}

	@Bean
	@Primary
	@Qualifier("jwtAccessTokenEncoder")
	JwtEncoder jwtAccessTokenEncoder() {
		JWK jwk = new RSAKey
				.Builder(keyUtils.getAccessTokenPublicKey())
				.privateKey(keyUtils.getAccessTokenPrivateKey())
				.build();
		JWKSource<SecurityContext> jwks = new ImmutableJWKSet<>(new JWKSet(jwk));
		return new NimbusJwtEncoder(jwks);
	}

	@Bean
//	@Qualifier("jwtRefreshTokenDecoder")
	JwtDecoder jwtRefreshTokenDecoder() {
		return NimbusJwtDecoder.withPublicKey(keyUtils.getRefreshTokenPublicKey()).build();
	}

	@Bean
	@Qualifier("jwtRefreshTokenEncoder")
	JwtEncoder jwtRefreshTokenEncoder() {
		JWK jwk = new RSAKey
			.Builder(keyUtils.getRefreshTokenPublicKey())
			.privateKey(keyUtils.getRefreshTokenPrivateKey())
			.build();
		JWKSource<SecurityContext> jwks = new ImmutableJWKSet<>(new JWKSet(jwk));
		return new NimbusJwtEncoder(jwks);
	}

	@Bean
	JwtAuthenticationProvider jwtRefreshTokenAuthProvider() {
		JwtAuthenticationProvider provider = new JwtAuthenticationProvider(jwtRefreshTokenDecoder());
		provider.setJwtAuthenticationConverter(jwtToUserConverter);
		return provider;
	}

	@Bean
	DaoAuthenticationProvider daoAuthenticationProvider() {
		// DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
		DaoAuthenticationProvider provider = new CustomDaoAuthenticationProvider();
		provider.setPasswordEncoder(passwordEncoder);
		provider.setUserDetailsService(userDetailsManageService);
		return provider;
	}

//    @Bean
//    public CustomAuthenticationProvider authenticationProvider(UserDetailsService userDetailsService) {
//        CustomAuthenticationProvider provider = new CustomAuthenticationProvider(
//        		userDetailsService, passwordEncoder);
//        return provider;
//    }
	
//    @Bean
//    public AuthenticationManager authenticationManager(HttpSecurity http) throws Exception {
//        AuthenticationManagerBuilder auth = http.getSharedObject(AuthenticationManagerBuilder.class);
//        auth.authenticationProvider(customAuthenticationProvider);  // Register custom AuthenticationProvider
//        return auth.build();
//    }
    

//    @Bean
//    public AuthenticationManager authenticationManager(HttpSecurity http, CustomAuthenticationProvider provider) throws Exception {
//        AuthenticationManagerBuilder auth = http.getSharedObject(AuthenticationManagerBuilder.class);
//        auth.authenticationProvider(provider);
//        return auth.build();
//    }
    
    
    @Bean
    public JwtRequestFilter jwtTokenFilter() {
        return new JwtRequestFilter(accessTokenDecoder1(), refreshTokenDecoder1(), keyUtils);
    }
    

	@Bean
	@Primary
    public JwtDecoder accessTokenDecoder1() {
		CustomEncryptedJwtDecoder jwtEncDecoder = new CustomEncryptedJwtDecoder(jwtAccessTokenDecoder(), keyUtils);
 		jwtEncDecoder.setPktDecryptor(packetDecryptor);
 		return jwtEncDecoder;
    }

    @Bean
    public JwtDecoder refreshTokenDecoder1() {
    	CustomEncryptedRefreshJwtDecoder jwtEncDecoder = new CustomEncryptedRefreshJwtDecoder(jwtRefreshTokenDecoder(), keyUtils);
 		return jwtEncDecoder;
    }
}
