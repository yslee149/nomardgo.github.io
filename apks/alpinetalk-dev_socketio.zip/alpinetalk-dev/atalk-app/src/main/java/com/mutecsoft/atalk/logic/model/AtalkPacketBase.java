package com.mutecsoft.atalk.logic.model;

import java.io.Serializable;
import java.lang.reflect.Field;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mutecsoft.atalk.logic.util.RandomHexString;
import com.fasterxml.jackson.core.type.TypeReference;

/**
 * @PackageName com.mutecsoft.atalk.logic.model
 * @fileName	AtalkPacketBase.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description :
 * <pre>
 * 
 * </pre>
 */

public abstract class AtalkPacketBase implements Serializable {

	private static final long serialVersionUID = -7029422274605777744L;
	
	protected static final ObjectMapper objectMapper = new ObjectMapper();
	
	protected String transactinId;
	
	public AtalkPacketBase() {
		this.transactinId = RandomHexString.genSecureRandomHex(16);
	}
	
	public String getTransactinId() {
		return transactinId;
	}
	public void setTransactinId(String transactinId) {
		this.transactinId = transactinId;
	}

	public static <T> T fromJson(String json, Class<T> clazz) throws JsonProcessingException {
	    return objectMapper.readValue(json, clazz);
	}
	
	public static <T> T fromJson(String json, TypeReference<T> typeReference) throws JsonProcessingException {
	    return objectMapper.readValue(json, typeReference);
	}
	
//	public static <T> String toJson(T object) throws JsonProcessingException {
//	    return objectMapper.writeValueAsString(object);
//	}

	public abstract String toJson() throws JsonProcessingException;

//	
//	public static <T> T fromJson(String json, TypeReference<T> typeReference) throws JsonProcessingException {
//	    return objectMapper.readValue(json, typeReference);
//	}
	
	public abstract SecureDataModel toFinalModel() throws Exception;
	
	public abstract SecureDataModel toFinalModel(String seedValue, String packetKey) throws Exception;
	
	public abstract SecureDataModel toFinalModel(String packetKey) throws Exception;
	
	/**
	 * print all members info
	 * 
	 * @param obj
	 * @return
	 */
	public static String printAllFields(Object obj) {
		StringBuffer sb = new StringBuffer();
		Class<?> objClass = obj.getClass();
		System.out.println("Class: " + objClass.getName());
        Field [] fields = objClass.getDeclaredFields();

        for (Field field : fields) {
        	field.setAccessible(true);
        	try {
        		sb.append(field.getName() + ":" + field.getByte(obj));
//        		System.out.println("Field name: " + field.getName());
//        		System.out.println("Field value: " + field.get(obj));
        	} catch (IllegalAccessException e) {
        		// System.out.println("Cannot access field: " + field.getName());
        	}
        }
        return sb.toString();
	}
}
