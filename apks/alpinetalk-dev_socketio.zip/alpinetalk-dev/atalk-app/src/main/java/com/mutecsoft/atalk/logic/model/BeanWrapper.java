package com.mutecsoft.atalk.logic.model;

import java.lang.reflect.Field;
import java.util.Objects;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class BeanWrapper<T> {
	private final T instance;
	
	public BeanWrapper(Class<T> clazz) {
		try {
			this.instance = clazz.getDeclaredConstructor().newInstance();  // 기본 생성자로 인스턴스 생성
		} catch (Exception e) {
			log.error("@@@@ err : {}", e);
			throw new RuntimeException("Failed to create an instance of " + clazz.getName(), e);
		}
	}
	
	public BeanWrapper(T instance) {
		this.instance = instance;
	}
	
	public T build() {
		return instance;
	}
	
	public BeanWrapper<T> with(String fieldName, Object value) {
		try {
			Field field = instance.getClass().getDeclaredField(fieldName);
			field.setAccessible(true);
			field.set(instance, value);
	    } catch (Exception e) {
	    	log.error("@@@@ err : {}", e);
	    	throw new RuntimeException("Failed to set field " + fieldName, e);
	    }
		return this;
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder(instance.getClass().getSimpleName() + "{");
		for (Field field : instance.getClass().getDeclaredFields()) {
			field.setAccessible(true);
			try {
				sb.append(field.getName()).append("=").append(field.get(instance)).append(", ");
	        } catch (IllegalAccessException e) {
	        	log.error("@@@@ err : {}", e);
	        }
	    }
		return sb.replace(sb.length() - 2, sb.length(), "}").toString();
	}
	
	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		BeanWrapper<?> that = (BeanWrapper<?>) o;
		return Objects.equals(instance, that.instance);
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(instance);
	}
}
