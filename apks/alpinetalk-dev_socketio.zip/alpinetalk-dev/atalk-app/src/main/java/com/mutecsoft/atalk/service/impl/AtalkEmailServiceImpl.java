package com.mutecsoft.atalk.service.impl;

import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.stereotype.Service;

import com.mutecsoft.atalk.config.AtalkConfig;
import com.mutecsoft.atalk.service.AtalkEmailService;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;

import java.util.Properties;

@Slf4j
@Service("atalkEmailService")
public class AtalkEmailServiceImpl implements AtalkEmailService {

	private JavaMailSender mailSender;

	@Autowired
	private AtalkConfig atalkConfig;
	
	@PostConstruct
    private void init() {
		this.mailSender = configureMailSender();
    }
	
	private JavaMailSender configureMailSender() {
		JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
		mailSender.setHost(atalkConfig.getSmtpConfig().getHost());
		mailSender.setPort(atalkConfig.getSmtpConfig().getPort()); // Use 465 for SSL
	    // mailSender.setPort(465); // Use 465 for SSL
	    
		mailSender.setUsername(atalkConfig.getSmtpConfig().getUsername());
		mailSender.setPassword(atalkConfig.getSmtpConfig().getPassword());
	    
		Properties props = mailSender.getJavaMailProperties();
		props.put("mail.transport.protocol", "smtp");
	    props.put("mail.smtp.auth", "true");
	    props.put("mail.smtp.starttls.enable", "true"); // Use "true" for TLS, "false" for SSL
	    props.put("mail.debug", "true");
	    return mailSender;
	}
	
//	private JavaMailSender configureMailSender() {
//		JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
//		mailSender.setHost("smtp.gmail.com");
//		mailSender.setPort(587); // Use 465 for SSL
//	    // mailSender.setPort(465); // Use 465 for SSL
//	    
//		mailSender.setUsername("voyzer@stormchaser.co.kr");
//		mailSender.setPassword("qaau zbjn koqf lbfz"); // App Password
//	    
//		Properties props = mailSender.getJavaMailProperties();
//		props.put("mail.transport.protocol", "smtp");
//	    props.put("mail.smtp.auth", "true");
//	    props.put("mail.smtp.starttls.enable", "true"); // Use "true" for TLS, "false" for SSL
//	    props.put("mail.debug", "true");
//	    return mailSender;
//	}
	
	@Override
	public void sendMail(String to, String subject, String text) {
		SimpleMailMessage message = new SimpleMailMessage();
		message.setTo(to);
		message.setSubject(subject);
		message.setText(text);
		message.setFrom(atalkConfig.getSmtpConfig().getUsername());
		mailSender.send(message);
	}
//	
//	public static void main(String [] args) {
//		
//		new EmailService().sendMail("voyzer@gmail.com", "title", "content aaaaa");
//	}
}

