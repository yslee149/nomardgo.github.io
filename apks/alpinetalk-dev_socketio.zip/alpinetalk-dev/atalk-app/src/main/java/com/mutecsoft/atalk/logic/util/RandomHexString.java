package com.mutecsoft.atalk.logic.util;

import java.security.SecureRandom;

/**
 * 
 * @author voyzer
 *
 */
public class RandomHexString {

    private static final String HEX_CHARS = "0123456789ABCDEF";

    public static String genSecureRandomHex(int length) {
        SecureRandom secureRandom = new SecureRandom();
        StringBuilder hexString = new StringBuilder(length);

        for (int i = 0; i < length; i++) {
            int randomIndex = secureRandom.nextInt(HEX_CHARS.length());
            hexString.append(HEX_CHARS.charAt(randomIndex));
        }
        return hexString.toString();
    }
    

	public static String makeRandomPw(int len) {
	    // 소문자, 대문자, 숫자 
		final String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
		SecureRandom rm = new SecureRandom();
		StringBuffer sb = new StringBuffer();
		for (int i=0; i<len; i++) {
			int index = rm.nextInt(chars.length());
			//index의 위치한 랜덤값
			sb.append(chars.charAt(index));
		}
		return sb.toString();
	}

    
    public static void main(String[] args) {
    	String val = RandomHexString.genSecureRandomHex(16);
    	System.out.println(val);
    	
    	byte [] b = BufferComplex.hexToBytes(val);
    	System.out.println(b.length);
    	System.out.println(BufferComplex.bytesToHex(b));
    }
}
