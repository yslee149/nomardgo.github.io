package com.mutecsoft.atalk.service;

import java.util.Optional;

import com.mutecsoft.atalk.common.model.MUser;
import com.mutecsoft.atalk.logic.model.response.ResResult;

/**
 * 
 */
public interface UserAccountService {
	void updatePassword(MUser user);
	int updateTmpPassword(MUser user);
	String getUserId(MUser user);
	MUser getUserByUserId(String userId);
	Optional<ResResult> issueTempPassword(MUser user) throws Exception ;
}
