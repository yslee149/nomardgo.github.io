package com.mutecsoft.atalk.web.controller.plain;

import com.mutecsoft.atalk.common.model.MUserProfile;
import com.mutecsoft.atalk.common.repository.MUserProfileRepository;
import com.mutecsoft.atalk.config.AtalkConfig;
import com.mutecsoft.atalk.constant.EnumProfileType;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.logic.model.user.SearchUserResponse;
import com.mutecsoft.atalk.security.oauth2.model.CustomUserDetail;
import com.mutecsoft.atalk.service.AtalkUserProfileServiceLogic;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

/**
 * @PackageName com.mutecsoft.atalk.web.controller.plain
 * @fileName	ProfileController.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description :
 * <pre>
 * 
 * </pre>
 */
@Slf4j
@Tag(name="Profile", description="Profile API(Plain)")
@Controller
@RequestMapping(value = "/api/plain/v1/profile")
public class PlainProfileController {

	@Autowired
	MUserProfileRepository mUserProfileRepository;
	
	@Autowired
	AtalkUserProfileServiceLogic atalkUserProfileServiceLogic;
	
	@Autowired
	AtalkConfig atalkConfig;
	
	/**
	 * 프로파일 다운로드
	 * 
	 * @param authUser
	 * @param profileNo
	 * @return
	 */
	@RequestMapping(value = "/thumb/{profileNo}", method = {RequestMethod.POST, RequestMethod.GET})
	public ResponseEntity<?> getThumb(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @PathVariable("profileNo") Long profileNo) {
		Optional<MUserProfile> profileOp = mUserProfileRepository.findByProfileNo(profileNo);
		if (profileOp.isEmpty()) {
			log.error("@@@@ : No profile exists : {]", profileNo);
			return null;
		}
		Path downloadPath = Paths.get(
				profileOp.get().getThumbnailPath());
		if (!Files.exists(downloadPath)) {
			return null;
		}
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "attachment; filename="+profileOp.get().getFileName());
		ByteArrayResource resource = new ByteArrayResource(toByteArrayOutputStream(downloadPath).toByteArray());
        return ResponseEntity.status(HttpStatus.OK)
	            .header("Content-Type", "application/octet-stream")
	            .header("Content-Disposition", "attachment;filename="+profileOp.get().getFileName())
	            .header("Content-Length", String.valueOf(resource.getByteArray().length))
	            .body(resource);
	}
	
	/**
	 * 프로파일 다운로드
	 * 
	 * @param authUser
	 * @param profileNo
	 * @return
	 */
	@RequestMapping(value = "/view/{profileNo}", method = {RequestMethod.POST, RequestMethod.GET})
	public ResponseEntity<?> getOriginal(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @PathVariable("profileNo") Long profileNo) {
		Optional<MUserProfile> profileOp = mUserProfileRepository.findByProfileNo(profileNo);
		if (profileOp.isEmpty()) {
			log.error("@@@@ : No profile exists : {]", profileNo);
			return null;
		}
		Path downloadPath = Paths.get(
				profileOp.get().getFilePath());
		if (!Files.exists(downloadPath)) {
			return null;
		}
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "attachment; filename="+profileOp.get().getFileName());
		ByteArrayResource resource = new ByteArrayResource(toByteArrayOutputStream(downloadPath).toByteArray());
        return ResponseEntity.status(HttpStatus.OK)
	            .header("Content-Type", "application/octet-stream")
	            .header("Content-Disposition", "attachment;filename="+profileOp.get().getFileName())
	            .header("Content-Length", String.valueOf(resource.getByteArray().length))
	            .body(resource);
	}

	/**
	 * 프로파일 FOREGROUND 변경
	 * 
	 * @param authUser
	 * @param profileFile
	 * @param secureReqModel
	 * @return
	 */
	@PostMapping(value = "/update/fg")
	public ResponseEntity<?> updateForground(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @RequestParam(value = "profileFile", required = false) MultipartFile profileFile
			, @ModelAttribute SecureDataModel secureReqModel) {
		try {
			log.debug("#### transactionId : {}", secureReqModel.getTransactinId());
			log.debug("#### data : {}", secureReqModel.getData());
			SearchUserResponse respObj = atalkUserProfileServiceLogic.updateProfileImage(
					authUser.getMUser()
					, EnumProfileType.FOREGROUND
					, profileFile);
			return new ResponseEntity<>(respObj, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}

	/**
	 * 프로파일 BACKGROUND 변경
	 * 
	 * @param authUser
	 * @param profileFile
	 * @param secureReqModel
	 * @return
	 */
	@PostMapping(value = "/update/bg")
	public ResponseEntity<?> updageBackground(
			@Parameter(hidden = true) @AuthenticationPrincipal CustomUserDetail authUser
			, @RequestParam(value = "profileFile", required = false) MultipartFile profileFile
			, @ModelAttribute SecureDataModel secureReqModel) {
		try {
			log.debug("#### transactionId : {}", secureReqModel.getTransactinId());
			log.debug("#### data : {}", secureReqModel.getData());
	///////// signup
			SearchUserResponse respObj = atalkUserProfileServiceLogic.updateProfileImage(
					authUser.getMUser()
					, EnumProfileType.BACKGROUND
					, profileFile);
			return new ResponseEntity<>(respObj, HttpStatus.OK);
		} catch (Exception e) {
			log.error("@@@@ : {}", e);
		}
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("@@@@ Unprocessable");
	}

	/**
	 * 
	 * @param filePath
	 * @return
	 */
	private ByteArrayOutputStream toByteArrayOutputStream(Path filePath) {
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		try (FileInputStream fileInputStream = new FileInputStream(filePath.toFile())) {
			byte[] buffer = new byte[4096]; // Buffer size for reading chunks
			int bytesRead;
			while ((bytesRead = fileInputStream.read(buffer)) != -1) {
				byteArrayOutputStream.write(buffer, 0, bytesRead);
			}
		} catch (IOException e) {
			log.error("@@@@ : {}", e);
		}
		return byteArrayOutputStream;
	}
}
