package com.mutecsoft.atalk.logic.model;

import java.lang.reflect.Field;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;

/**
 * @PackageName com.mutecsoft.atalk.logic.model
 * @fileName	AtalkPacketRespBase.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description :
 * <pre>
 * 
 * </pre>
 */

public abstract class AtalkPacketRespBase extends AtalkPacketBase {

	private static final long serialVersionUID = -7029422274605777744L;
	
	protected ErrorRespModel error;
	
	public AtalkPacketRespBase() {
		this.error = new ErrorRespModel();
	}
	
	public ErrorRespModel getError() {
		return error;
	}

	public void setError(ErrorRespModel error) {
		this.error = error;
	}

	public static <T> T fromJson(String json, Class<T> clazz) throws JsonProcessingException {
	    return objectMapper.readValue(json, clazz);
	}
	
	public static <T> T fromJson(String json, TypeReference<T> typeReference) throws JsonProcessingException {
	    return objectMapper.readValue(json, typeReference);
	}

//	public abstract String toJson() throws JsonProcessingException;
	
//	public abstract SecureDataModel toFinalModel() throws Exception;
//	
//	public abstract SecureDataModel toFinalModel(String seedValue, String packetKey) throws Exception;
//	
//	public abstract SecureDataModel toFinalModel(String packetKey) throws Exception;
	
	/**
	 * print all members info
	 * 
	 * @param obj
	 * @return
	 */
	public static String printAllFields(Object obj) {
		StringBuffer sb = new StringBuffer();
		Class<?> objClass = obj.getClass();
		System.out.println("Class: " + objClass.getName());
        Field [] fields = objClass.getDeclaredFields();

        for (Field field : fields) {
        	field.setAccessible(true);
        	try {
        		sb.append(field.getName() + ":" + field.getByte(obj));
//        		System.out.println("Field name: " + field.getName());
//        		System.out.println("Field value: " + field.get(obj));
        	} catch (IllegalAccessException e) {
        		// System.out.println("Cannot access field: " + field.getName());
        	}
        }
        return sb.toString();
	}
}
