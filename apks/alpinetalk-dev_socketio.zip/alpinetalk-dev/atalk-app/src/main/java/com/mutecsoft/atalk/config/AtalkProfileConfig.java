package com.mutecsoft.atalk.config;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class AtalkProfileConfig {
	private Integer fgResolutionWidth;
	private Integer fgResolutionHeight;	
	private Integer fgResolutionThumbWidth;
	private Integer fgResolutionThumbHeight;	
	
	private Integer bgResolutionWidth;
	private Integer bgResolutionHeight;	
	private Integer bgResolutionThumbWidth;
	private Integer bgResolutionThumbHeight;	

	private String groundFilePath;
	private String baseUrl;
}
