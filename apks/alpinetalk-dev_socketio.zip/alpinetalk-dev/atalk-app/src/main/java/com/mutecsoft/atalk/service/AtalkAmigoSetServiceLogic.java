package com.mutecsoft.atalk.service;

import com.mutecsoft.atalk.common.model.MUser;
import com.mutecsoft.atalk.logic.model.amigoset.AddAmigoSetRequest;
import com.mutecsoft.atalk.logic.model.amigoset.AddAmigoSetResponse;
import com.mutecsoft.atalk.logic.model.amigoset.AmigoSetListResponse;
import com.mutecsoft.atalk.logic.model.amigoset.DeleteAmigoSetRequest;
import com.mutecsoft.atalk.logic.model.amigoset.DeleteAmigoSetResponse;
import com.mutecsoft.atalk.logic.model.amigoset.RenameAmigoSetRequest;
import com.mutecsoft.atalk.logic.model.amigoset.RenameAmigoSetResponse;

public interface AtalkAmigoSetServiceLogic {
	AddAmigoSetResponse addAmigoSet(MUser user, AddAmigoSetRequest reqObj) throws Exception;
	RenameAmigoSetResponse renameAmigoSet(MUser user, RenameAmigoSetRequest reqObj) throws Exception;
	DeleteAmigoSetResponse deleteAmigoSet(MUser user, DeleteAmigoSetRequest reqObj) throws Exception;
	AmigoSetListResponse amigoSetList(MUser user) throws Exception;
}
