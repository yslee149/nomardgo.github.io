package com.mutecsoft.atalk.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import java.nio.charset.Charset;
import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

@Configuration
public class RedisConfig {
	@Value("${spring.redis.host}")
	private String redisHost;

	@Value("${spring.redis.port}")
	private int redisPort;

	@Value("${spring.redis.password}")
	private String redisPwd;

	@Value("${spring.redis.unreadcnt-dbnum}")
	private int unreadcntDbNum;
//	
//	@Value("${spring.redis.trans-mutex-dbnum}")
//	private int transMutexDbnum;
	
	// @Autowired
    // private TransLgcnsConf transConf;
	
	///////////////////////////////////////////////////
	//	@Value("${spring.redis.invoke-password}")
//	private String redisInvokePwd;
	
	
	//	@Bean
//	public RedisConnectionFactory redisConnectionFactory() {
//		RedisStandaloneConfiguration redisStandaloneConfiguration = new RedisStandaloneConfiguration();
//		redisStandaloneConfiguration.setPassword(redisPwd); //redis에 비밀번호가 설정 되어 있는 경우 설정해주면 됩니다.
//		LettuceConnectionFactory lettuceConnectionFactory = new LettuceConnectionFactory(redisStandaloneConfiguration);
//		return lettuceConnectionFactory;
//	}
	
    public RedisConnectionFactory createLettuceConnectionFactory(int dbIndex) {
        final RedisStandaloneConfiguration redisStandaloneConfiguration = new RedisStandaloneConfiguration();
        redisStandaloneConfiguration.setHostName(redisHost);
        redisStandaloneConfiguration.setPort(redisPort);
        
        redisStandaloneConfiguration.setPassword(redisPwd);
        redisStandaloneConfiguration.setDatabase(dbIndex);
        return new LettuceConnectionFactory(redisStandaloneConfiguration);
    }
    
    /**
     * INVOKE ID REDIS SERVER REDIS CONNECTIONS
     * 
     * @param dbIndex
     * @return
     */
    public RedisConnectionFactory createLettuceConnectionFactoryInvokeIdInfo(int dbIndex) {
        final RedisStandaloneConfiguration redisStandaloneConfiguration = new RedisStandaloneConfiguration();
        redisStandaloneConfiguration.setHostName(redisHost);
        redisStandaloneConfiguration.setPort(redisPort);
        
        redisStandaloneConfiguration.setPassword(redisPwd);
        redisStandaloneConfiguration.setDatabase(dbIndex);
        return new LettuceConnectionFactory(redisStandaloneConfiguration);
    }

	@Bean
    @Primary
    public RedisConnectionFactory defaultRedisConnectionFactory() {
        return createLettuceConnectionFactory(10);
    }
	@Bean
    public RedisConnectionFactory redisConnectionFactoryPacketKeyDb() {
		LocalDate currentDate = LocalDate.now();
        int dayOfMonth = currentDate.getDayOfMonth();  // 현재 날짜의 일(day) 숫자 가져오기
        int dbIndex = dayOfMonth % 10;  // 0,1,2,3,4,5,6,7,8,9
        return createLettuceConnectionFactory(dbIndex);
    }
	
	@Bean
    public RedisConnectionFactory redisConnectionFactoryUnreadCntDb() {
        return createLettuceConnectionFactory(unreadcntDbNum);
    }
	
//	@Bean
//    public RedisConnectionFactory redisConnectionFactoryTransMutexDb() {
//        return createLettuceConnectionFactory(transMutexDbnum);
//    }
	
	@Bean(name="basicRedisTemplate")
	@Primary
	public RedisTemplate<String, Object> redisTemplate() {
		RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();
		redisTemplate.setConnectionFactory(defaultRedisConnectionFactory());
		redisTemplate.setKeySerializer(new StringRedisSerializer(Charset.forName("UTF-8")));
		// 객체를 json 형태로 깨지지 않고 받기 위한 직렬화 작업
		redisTemplate.setValueSerializer(new Jackson2JsonRedisSerializer<>(String.class));
		
		return redisTemplate;
	}
	
	@Bean(name="redisTemplatePacketKeyDb")
	public RedisTemplate<String, String> redisTemplatePacketKeyDb() {
		RedisTemplate<String, String> redisTemplate = new RedisTemplate<>();
		redisTemplate.setConnectionFactory(redisConnectionFactoryPacketKeyDb());
		redisTemplate.setKeySerializer(new StringRedisSerializer(Charset.forName("UTF-8")));
		// 객체를 json 형태로 깨지지 않고 받기 위한 직렬화 작업
		// redisTemplate.setValueSerializer(new Jackson2JsonRedisSerializer<>(TransEventData.class));
		// redisTemplate.setValueSerializer(new Jackson2JsonRedisSerializer<>(String.class));
		// redisTemplate.setKeySerializer(new StringRedisSerializer());
		redisTemplate.setValueSerializer(new StringRedisSerializer());
		redisTemplate.setHashKeySerializer(new StringRedisSerializer());
		redisTemplate.setHashValueSerializer(new StringRedisSerializer());

		redisTemplate.afterPropertiesSet();
		    
		return redisTemplate;
	}
	
	/**
	 * unread count redis db
	 * 
	 * @return
	 */
	@Bean(name="redisTemplateUnreadCntDb")
	public RedisTemplate<String, Object> redisTemplateUnreadCntDb() {
//		RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();
//		redisTemplate.setConnectionFactory(redisConnectionFactoryUnreadCntDb());
//		redisTemplate.setKeySerializer(new StringRedisSerializer(Charset.forName("UTF-8")));
//		redisTemplate.setValueSerializer(new StringRedisSerializer());
//		redisTemplate.setHashKeySerializer(new StringRedisSerializer());
//		redisTemplate.setHashValueSerializer(new StringRedisSerializer());
//
//		redisTemplate.afterPropertiesSet();
//		
        RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(redisConnectionFactoryUnreadCntDb());
        // Use String serializer for keys
        redisTemplate.setKeySerializer(new StringRedisSerializer());
        // Use String serializer for hash keys
        redisTemplate.setHashKeySerializer(new StringRedisSerializer());
        // Use GenericJackson2JsonRedisSerializer for values
        redisTemplate.setValueSerializer(new GenericJackson2JsonRedisSerializer());
        redisTemplate.setHashValueSerializer(new GenericJackson2JsonRedisSerializer());
		
		return redisTemplate;
	}
	
//	@Bean(name="redisTemplateTransMutexDb")
//	public RedisTemplate<String, Object> redisTemplateTransMutexDb() {
//		RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();
//		redisTemplate.setConnectionFactory(redisConnectionFactoryTransMutexDb());
//		redisTemplate.setKeySerializer(new StringRedisSerializer(Charset.forName("UTF-8")));
//		// 객체를 json 형태로 깨지지 않고 받기 위한 직렬화 작업
//		// redisTemplate.setValueSerializer(new Jackson2JsonRedisSerializer<>(TransLockData.class));
//		
//		return redisTemplate;
//	}
	
//	@Bean(name="redisTemplateAddressDb")
//	public RedisTemplate<String, Object> redisTemplateAddressDb() {
//		RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();
//		redisTemplate.setConnectionFactory(redisConnectionFactoryAddressDb());
//		redisTemplate.setKeySerializer(new StringRedisSerializer(Charset.forName("UTF-8")));
//		// 객체를 json 형태로 깨지지 않고 받기 위한 직렬화 작업
//		redisTemplate.setValueSerializer(new Jackson2JsonRedisSerializer<>(String.class));
//		
//		return redisTemplate;
//	}
//	
//	@Bean(name="redisTemplateXmlImgInfoDb")
//	public RedisTemplate<String, Object> redisTemplateXmlImgInfoDb() {
//		RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();
//		redisTemplate.setConnectionFactory(redisConnectionFactoryXmlImgDb());
//		redisTemplate.setKeySerializer(new StringRedisSerializer(Charset.forName("UTF-8")));
//		// 객체를 json 형태로 깨지지 않고 받기 위한 직렬화 작업
//		redisTemplate.setValueSerializer(new Jackson2JsonRedisSerializer<>(String.class));
//		
//		return redisTemplate;
//	}
//	
//	@Bean(name="redisTemplateInvokeInfoDb")
//	public RedisTemplate<String, Object> redisTemplateInvokeInfoDb() {
//		RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();
//		redisTemplate.setConnectionFactory(redisConnectionFactoryInvokeDb());
//		redisTemplate.setKeySerializer(new StringRedisSerializer(Charset.forName("UTF-8")));
//		// 객체를 json 형태로 깨지지 않고 받기 위한 직렬화 작업
//		redisTemplate.setValueSerializer(new Jackson2JsonRedisSerializer<>(String.class));
//		
//		return redisTemplate;
//	}
}


