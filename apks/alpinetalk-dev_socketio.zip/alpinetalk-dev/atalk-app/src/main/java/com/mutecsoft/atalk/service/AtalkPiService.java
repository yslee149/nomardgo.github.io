package com.mutecsoft.atalk.service;

import java.util.Optional;

import com.mutecsoft.atalk.logic.model.AtalkDataModelAll;
import com.mutecsoft.atalk.logic.model.SecureDataModel;

public interface AtalkPiService {
	
	Optional<AtalkDataModelAll> getLatestPiAgreement(SecureDataModel secModel) throws Exception;
}

