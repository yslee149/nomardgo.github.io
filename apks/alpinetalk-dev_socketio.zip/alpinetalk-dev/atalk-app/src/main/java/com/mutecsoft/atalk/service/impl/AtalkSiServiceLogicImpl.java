package com.mutecsoft.atalk.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.mutecsoft.atalk.common.model.MAgreementHist;
import com.mutecsoft.atalk.common.model.MSiAgreement;
import com.mutecsoft.atalk.common.model.MUser;
import com.mutecsoft.atalk.common.repository.MAgreementHistRepository;
import com.mutecsoft.atalk.common.repository.MSiAgreementRepository;
import com.mutecsoft.atalk.common.repository.MUserRepository;
import com.mutecsoft.atalk.logic.model.response.AgreementResponse;
import com.mutecsoft.atalk.logic.model.si.SiAgreementResponse;
import com.mutecsoft.atalk.service.AtalkSiServiceLogic;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;

/**
 * 서비스 이용약관 서비스
 * 
 */
@Slf4j
@Service("atalkSiServiceLogic")
public class AtalkSiServiceLogicImpl implements AtalkSiServiceLogic {

	@Autowired
	MSiAgreementRepository mSiAgreementRepository;

	@Autowired
	MAgreementHistRepository   mAgreementHistRepository;
	
	@Autowired
	MUserRepository mUserRepository;
	
	@Override
	public SiAgreementResponse getLatestSiAgreement() throws Exception {

		Optional<MSiAgreement> pfOp = mSiAgreementRepository.findByLatest();
		
		///////////////////////// RESPONSE /////////////////////////////////////////////////////
		SiAgreementResponse respObj = new SiAgreementResponse();
		respObj.setContent(pfOp.get().getSiContent());
		respObj.setSiVersion(pfOp.get().getSiNo());
		return respObj;
	}

	@Override
	public Long agree(MUser user, Long version) throws Exception {
		Optional<MSiAgreement> agreeOp = mSiAgreementRepository.findById(version);
		if (agreeOp.isPresent()) {
			user.setSiAgreeVersion(agreeOp.get().getSiNo());
			mUserRepository.save(user);
			
			MAgreementHist agreeHistObj = new MAgreementHist();
			agreeHistObj.setCat("SI");
			agreeHistObj.setRegDate(new Date());
			agreeHistObj.setUserNo(user.getUserNo());
			agreeHistObj.setVersionNo(version);
			agreeHistObj.setAgreeYn("Y");
			mAgreementHistRepository.save(agreeHistObj);
			
			return version;
		}
		return 0L;
	}

	SimpleDateFormat dateFormatter;
	
	@PostConstruct
	private void init() {
		dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	}
	
	@Override
	public AgreementResponse getHist(MUser user) throws Exception {
		Optional<MAgreementHist> agreementHistOp = mAgreementHistRepository.findByLatest(user.getUserNo(), "SI");
		
		///////////////////////// RESPONSE /////////////////////////////////////////////////////
		AgreementResponse respObj = new AgreementResponse();
		if (agreementHistOp.isPresent()) {
			respObj.setRegDt(dateFormatter.format(agreementHistOp.get().getRegDate()));
			respObj.setVersion(agreementHistOp.get().getVersionNo());
			respObj.setAgreeYn(agreementHistOp.get().getAgreeYn());
		} else {
			respObj.setRegDt(null);
			respObj.setVersion(0L);
			respObj.setAgreeYn("N");		
		}
		return respObj;
	}
}
