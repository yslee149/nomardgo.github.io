/**
 * 
 */
package com.mutecsoft.atalk.common.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.mutecsoft.atalk.common.model.MUser;

import jakarta.transaction.Transactional;

/**
 * 사용자 repository
 *
 * @author voyzer
 *
 */
public interface MUserRepository extends CrudRepository<MUser, Long> {

	Optional<MUser> findByUserNo(Long userNo);
	
	Optional<MUser> findByUserId(String userId);
	
	List<MUser> findByUserNameContainingIgnoreCaseAndUseYnAndActiveYn(String userName, String useYn, String activeYn);
	
	List<MUser> findByUserIdAndUseYnAndActiveYn(String userName, String useYn, String activeYn);
	
	@Query
	(
		value = "SELECT "
				+ "A.* "
				+ "FROM m_user A "
				+ "INNER JOIN m_chathub_user B "
				+ "ON A.USER_NO=B.USER_NO "
				+ "WHERE B.CHATHUB_NO=:chathubNo",
		nativeQuery = true
	)
	Optional<List<MUser>> findByChatHubNo(@Param("chathubNo") Long chathubNo);
	
	
	@Query
	(
		value = "SELECT "
				+ "A.* "
				+ "FROM m_user A "
				+ "INNER JOIN m_chathub_user B "
				+ "ON A.USER_NO=B.USER_NO "
				+ "WHERE B.CHATHUB_NO=:chathubNo AND B.JOIN_YN='Y'",
		nativeQuery = true
	)
	Optional<List<MUser>> findByChatHubNoJoined(@Param("chathubNo") Long chathubNo);
	
	@Transactional
	@Modifying
	@Query
	(
		value = "update m_user set use_yn='N', upd_date=now() where user_no = :userNo",
		nativeQuery = true
	)
	void updateDelete(@Param("userNo") Long userNo);
	
	@Transactional
	@Modifying
	@Query
	(
		value = "update m_user set user_pw=:userPw, pw_upd_date=now(), upd_date=now() where user_no = :userNo",
		nativeQuery = true
	)
	void updatePassword(@Param("userNo") Long userNo, @Param("userPw") String userPw);
	
	@Transactional
	@Modifying
	@Query
	(
		value = "update m_user set user_pw_temp=:userPw, upd_date=now() where user_no = :userNo",
		nativeQuery = true
	)
	void updateTempPassword(@Param("userNo") Long userNo, @Param("userPw") String userPw);
	
	@Transactional
	@Modifying
	@Query
	(
		value = "update m_user set mobile_token=:mobileToken, mobile_token_type=:mobileTokenType, upd_date=now() where user_no = :userNo",
		nativeQuery = true
	)
	void updateToken(
			@Param("userNo") Long userNo
			, @Param("mobileTokenType") String mobileTokenType
			, @Param("mobileToken") String mobileToken);
	

	@Transactional
	@Modifying
	@Query
	(
		value = "update m_user set signup_key=:signupKey, upd_date=now() where user_no = :userNo",
		nativeQuery = true
	)
	void updateToken(
			@Param("userNo") Long userNo
			, @Param("signupKey") String signupKey);
	
	
}
