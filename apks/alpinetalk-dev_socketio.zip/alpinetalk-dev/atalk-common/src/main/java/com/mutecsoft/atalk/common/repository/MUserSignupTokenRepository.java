/**
 * 
 */
package com.mutecsoft.atalk.common.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.mutecsoft.atalk.common.model.MUserSignuptoken;

import jakarta.transaction.Transactional;

/**
 * 사용자 signupkey repository
 *
 * @author voyzer
 *
 */
public interface MUserSignupTokenRepository extends CrudRepository<MUserSignuptoken, String> {

	Optional<MUserSignuptoken> findBySignupKeyAndUseYn(String signupKey, String useYn);
	
	@Transactional
	@Modifying
	@Query
	(
		value = "update m_user_signuptoken set use_yn=:useYn, upd_date=now() where signup_key = :signupKey",
		nativeQuery = true
	)
	void updateSetUse(@Param("signupKey") String signupKey, @Param("useYn") String useYn);
	
	
	@Transactional
	@Modifying
	@Query
	(
		value = "update m_user set issue_prvkey=:issuePrvkey, upd_date=now() where signup_key = :signupKey",
		nativeQuery = true
	)
	void updatePrivateKey(@Param("signupKey") String signupKey, @Param("issuePrvkey") String issuePrvkey);
}
