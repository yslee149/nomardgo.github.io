/**
 * 
 */
package com.mutecsoft.atalk.common.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.mutecsoft.atalk.common.model.MAuthEmail;

import jakarta.transaction.Transactional;


/**
 * 친구 정보 Repository
 *
 * @author voyzer
 *
 */
public interface MAuthEmailRepository extends CrudRepository<MAuthEmail, Long> {
	
	@Query
	(
		value = "SELECT * FROM m_auth_email WHERE email=:email order by auth_email_seq desc limit 1",
		nativeQuery = true
	)
	Optional<MAuthEmail> findByEmail(
			@Param("email") String email);
	
	@Transactional
	@Modifying
	@Query
	(
		value = "INSERT INTO m_auth_email "
				+ "	(auth_email_seq, email, auth_token, check_yn, reg_date) "
				+ "	VALUES (NULL, :email, :authToken, 'N', NOW())",
		nativeQuery = true
	)
	int insertEmailAuth(@Param("email") String email, @Param("authToken") String authToken);
}
