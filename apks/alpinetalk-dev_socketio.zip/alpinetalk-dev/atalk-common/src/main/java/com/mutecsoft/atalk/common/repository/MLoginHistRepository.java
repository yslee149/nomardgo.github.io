/**
 * 
 */
package com.mutecsoft.atalk.common.repository;

import org.springframework.data.repository.CrudRepository;
import com.mutecsoft.atalk.common.model.MLoginHist;

/**
 * 사용자 로그인 이력 repository
 *
 * @author voyzer
 *
 */
public interface MLoginHistRepository extends CrudRepository<MLoginHist, Long> {

}
