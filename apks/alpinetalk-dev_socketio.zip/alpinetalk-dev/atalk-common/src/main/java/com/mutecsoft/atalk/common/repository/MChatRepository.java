/**
 * 
 */
package com.mutecsoft.atalk.common.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.mutecsoft.atalk.common.model.MChatCompositKey;

import jakarta.transaction.Transactional;

import com.mutecsoft.atalk.common.model.MChat;

/**
 * 대화 정보 Repository
 *
 * @author voyzer
 *
 */
public interface MChatRepository extends CrudRepository<MChat, MChatCompositKey> {

	// 마지막 대화 조회
	@Query
	(
		value = "SELECT A.* FROM m_chat A WHERE A.CHATHUB_NO=:chathubNo ORDER BY A.CHAT_NO DESC LIMIT 1",
		nativeQuery = true
	)
	MChat getLastMessage(@Param("chathubNo") Long chathubNo);
	
	@Query
	(
		value = "SELECT "
				+ "	A.* "
				+ "FROM m_chat A "
				+ "LEFT JOIN m_chat_DEL B "
				+ "ON A.CHATHUB_NO=B.CHATHUB_NO AND A.CHAT_NO=B.CHAT_NO "
				+ "WHERE 1=1 "
				+ "AND A.CHATHUB_NO=:chathubNo "
				+ "AND B.USER_NO IS NULL "
				// + "AND A.CHAT_TYPE != 'I' "
				+ "ORDER BY A.CHAT_NO DESC "
				+ "LIMIT :chatInqCount ",
		nativeQuery = true
	)
	List<MChat> findByChathubLatestWithCount(
			@Param("chathubNo") Long chathubNo
			, @Param("chatInqCount") Long chatInqCount);
	@Query
	(
		value = "SELECT "
				+ "	A.* "
				+ "FROM m_chat A "
				+ "LEFT JOIN m_chat_DEL B "
				+ "ON A.CHATHUB_NO=B.CHATHUB_NO AND A.CHAT_NO=B.CHAT_NO "
				+ "WHERE 1=1 "
				+ "AND A.CHATHUB_NO=:chathubNo "
				+ "AND A.CHATH_NO < :criteriaChatNo "
				+ "AND B.USER_NO IS NULL "
				// + "AND A.CHAT_TYPE != 'I' "
				+ "ORDER BY A.CHAT_NO DESC "
				+ "LIMIT :chatInqCount ",
		nativeQuery = true
	)
	List<MChat> findByChathubAndLessThanChatNotWithCount(
			@Param("chathubNo") Long chathubNo
			, @Param("criteriaChatNo") Long criteriaChatNo
			, @Param("chatInqCount") Long chatInqCount);
	
//	List<MChat> findByChathubNoAndChatNoIn(
//			Long chathubNo
//			, List<Long> chatNoList);
//
//	Optional<MChat> findByChathubNoAndChatNo(
//			Long chathubNo
//			, Long chatNo);
	
	

	@Query
	(
		value = "SELECT "
				+ "	A.chat_no "
				+ "	, A.chat_type "
				+ "	, A.chat_sub_type "
				+ "	, A.user_no "
				+ " , (SELECT USER_NAME FROM m_user WHERE USER_no=A.user_no) AS user_name "
				+ " , IFNULL((SELECT COUNT(1) FROM m_chathub_user WHERE CHATHUB_NO=A.CHATHUB_NO AND JOIN_YN='Y' AND read_chat_no < A.chat_no), 0) AS unread_cnt "
				+ " , A.users_num "
				+ "	, A.chat "
				+ "	, A.reg_date "
				+ "	, IFNULL(C.ext_chat, '') "
				+ "	, IFNULL(F.chat_file_no, 0) "
				+ "	, IFNULL(F.parent_chat_file_no, 0) "
				+ "	, IFNULL(F.file_type, '') "
				+ "	, IFNULL(F.disp_name, '') "
				+ "	, IFNULL(F.file_size, 0) "
				+ "FROM m_chat A "
				+ "LEFT JOIN m_chat_DEL B "
				+ "ON A.CHATHUB_NO=B.CHATHUB_NO AND A.CHAT_NO=B.CHAT_NO "
				+ "LEFT JOIN m_chat_ext C "
				+ "ON A.CHATHUB_NO=C.CHATHUB_NO AND A.CHAT_NO=C.CHAT_NO "
				+ "LEFT JOIN m_chat_file F "
				+ "ON A.CHATHUB_NO=F.CHATHUB_NO AND A.CHAT_NO=F.CHAT_NO "
				+ "WHERE 1=1 "
				+ "AND A.CHATHUB_NO=:chathubNo "
				+ "AND B.USER_NO IS NULL "
				+ "AND A.CHAT_TYPE != 'I' "
				+ "ORDER BY A.CHAT_NO DESC "
				+ "LIMIT :chatInqCount ",
		nativeQuery = true
	)
	List<Object[]> findByChathubLatestWithCount(
			@Param("chathubNo") Long chathubNo
			, @Param("chatInqCount") Integer chatInqCount);
	

	@Query
	(
		value = "SELECT "
				+ "	A.chat_no "
				+ "	, A.chat_type "
				+ "	, A.chat_sub_type "
				+ "	, A.user_no "
				+ " , (SELECT USER_NAME FROM m_user WHERE USER_no=A.user_no) AS user_name "
				+ " , IFNULL((SELECT COUNT(1) FROM m_chathub_user WHERE CHATHUB_NO=A.CHATHUB_NO AND JOIN_YN='Y' AND read_chat_no < A.chat_no), 0) AS unread_cnt "
				+ " , A.users_num "
				+ "	, A.chat "
				+ "	, A.reg_date "
				+ "	, IFNULL(C.ext_chat, '') "
				+ "	, IFNULL(F.chat_file_no, 0) "
				+ "	, IFNULL(F.parent_chat_file_no, 0) "
				+ "	, IFNULL(F.file_type, '') "
				+ "	, IFNULL(F.disp_name, '') "
				+ "	, IFNULL(F.file_size, 0) "
				+ "FROM m_chat A "
				+ "LEFT JOIN m_chat_DEL B "
				+ "ON A.CHATHUB_NO=B.CHATHUB_NO AND A.CHAT_NO=B.CHAT_NO "
				+ "LEFT JOIN m_chat_ext C "
				+ "ON A.CHATHUB_NO=C.CHATHUB_NO AND A.CHAT_NO=C.CHAT_NO "
				+ "LEFT JOIN m_chat_file F "
				+ "ON A.CHATHUB_NO=F.CHATHUB_NO AND A.CHAT_NO=F.CHAT_NO "
				+ "WHERE 1=1 "
				+ "AND A.CHATHUB_NO=:chathubNo "
				+ "AND A.CHAT_NO < :baseChatNo "
				+ "AND B.USER_NO IS NULL "
				+ "AND A.CHAT_TYPE != 'I' "
				+ "ORDER BY A.CHAT_NO DESC "
				+ "LIMIT :chatInqCount ",
		nativeQuery = true
	)
	List<Object[]> findByChathubAndBaseChatNotWithCount(
			@Param("chathubNo") Long chathubNo
			, @Param("baseChatNo") Long baseChatNo
			, @Param("chatInqCount") Integer chatInqCount);
	
	
	@Transactional
	@Modifying
	@Query
	(
		value = "update m_chat set chat_type = 'R' where CHATHUB_NO = :chathubNo and chat_no = :chatNo",
		nativeQuery = true
	)
	void retriveChat(@Param("chathubNo") Long chathubNo, @Param("chatNo") Long chatNo);
	
	@Query
	(
		value = "SELECT MAX(chat_no) FROM m_chat WHERE chathub_no=:chathubNo",
		nativeQuery = true
	)
	Long getMaxChatNo(@Param("chathubNo") Long chathubNo);
	
	Optional<MChat> findByChathubNoAndChatNo(Long chathubNo, Long chatNo);
			
}
