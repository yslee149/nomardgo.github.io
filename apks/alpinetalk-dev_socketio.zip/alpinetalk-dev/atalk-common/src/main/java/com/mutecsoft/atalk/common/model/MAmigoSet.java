/**
 * 
 */
package com.mutecsoft.atalk.common.model;

import java.io.Serializable;
import java.util.Date;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import org.springframework.data.annotation.LastModifiedDate;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * 친구 정보 그룹 테이블
 * 
 * @author voyzer
 *
 */
@Entity(name="mAmigoSet")
@Table(name="m_amigo_set")
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@ToString
@IdClass(MAmigoSetCompositKey.class)
public class MAmigoSet implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6943246215995783832L;

	@Id
	@Column(name = "user_no", updatable = false)
	private Long userNo;

	@Id
	@Column(name = "amigo_set_no", updatable = false)
	private Long amigoSetNo;
	
	@Column(name = "amigo_set_name", updatable = false)
	private String amigoSetName;
	
	@Column(name = "use_yn", updatable = false)
	private String useYn;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "reg_date")
	@LastModifiedDate
	private Date regDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "upd_date")
	@LastModifiedDate
	private Date updDate;
}
/*
"Field"	"Type"	"Null"	"Key"	"Default"	"Extra"
"USER_NO"	"int(11)"	"NO"	"PRI"	\N	""
"AMIGO_SET_NO"	"int(11)"	"NO"	"PRI"	\N	""
"AMIGO_SET_NAME"	"varchar(80)"	"NO"	""	\N	""
"USE_YN"	"char(1)"	"NO"	""	"Y"	""
"REG_DATE"	"datetime"	"NO"	""	\N	""
"UPD_DATE"	"datetime"	"NO"	""	\N	""

*/