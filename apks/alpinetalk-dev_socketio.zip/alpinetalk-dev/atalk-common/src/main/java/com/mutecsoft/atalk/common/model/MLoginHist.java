/**
 * 
 */
package com.mutecsoft.atalk.common.model;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.annotation.LastModifiedDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * alpine talk login 이력 테이블
 * 
 * @author voyzer
 *
 */
@Entity(name="mLoginHist")
@Table(name="m_login_hist")
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@ToString
public class MLoginHist implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6943246215995783832L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "login_hist_no")
	private Long loginHistNo;

	@Column(name = "user_no", updatable = false)
	private Long userNo;
	
	@Column(name = "ip", updatable = false)
	private String ip;
	
	@Column(name = "version", updatable = false)
	private String version;
	
	@Column(name = "device_type")
	private String deviceType;
	
	@Column(name = "login_type")
	private String loginType;
	
	@Column(name = "server_idx")
	private Long serverIdx;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "reg_date")
	@LastModifiedDate
	private Date regDate;
}
