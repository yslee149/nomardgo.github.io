/**
 * 
 */
package com.mutecsoft.atalk.common.model;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * 친구 정보 키 
 * 
 * @author voyzer
 *
 */
@Data
@NoArgsConstructor
@EqualsAndHashCode
public class MAmigoUserCompositKey implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6943246215995783832L;

	private Long userNo;
	private Long amigoSetNo;
	private Long amigoNo;
	
}
