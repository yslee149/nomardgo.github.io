/**
 * 
 */
package com.mutecsoft.atalk.common.model;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.annotation.LastModifiedDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * 서비스 약관
 * 
 * @author voyzer
 *
 */
@Entity(name="mServiceInfoAgreement")
@Table(name="m_service_info_agreement")
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@ToString
public class MSiAgreement implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4032401532465553738L;

	@Id
	@Column(name = "si_no")
	private Long siNo;

	@Column(name = "si_version")
	private String siVersion;
	
	@Column(name = "si_content")
	private String siContent;
	
	@Column(name = "use_yn")
	private String useYn;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "reg_date")
	@LastModifiedDate
	private Date regDate;
	
}
