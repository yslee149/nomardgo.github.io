/**
 * 
 */
package com.mutecsoft.atalk.common.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.mutecsoft.atalk.common.model.MChatExt;

/**
 * 대화 대용량 정보 Repository
 *
 * @author voyzer
 *
 */
public interface MChatExtRepository extends CrudRepository<MChatExt, Long> {

	List<MChatExt> findByChathubNoAndChatNoIn(
			Long chathubNo
			, List<Long> chatNoList);

	Optional<MChatExt> findByChathubNoAndChatNo(
			Long chathubNo
			, Long chatNo);
	

	@Query
	(
		value = "SELECT "
			+ "	A.* "
			+ "	FROM m_chat_ext A "
			+ "	INNER join m_chathub B "
			+ "	ON A.chathub_no=B.chathub_no  "
			+ "	INNER JOIN m_chathub_user C "
			+ "	ON A.chathub_no=C.CHATHUB_NO AND C.user_no=:userNo "
			+ "	WHERE A.chat_ext_no=:chatExtNo ",
		nativeQuery = true
	)
	Optional<MChatExt> findByUserNoAndChatExtNo(
			@Param("userNo") Long userNo
			, @Param("chatExtNo") Long chatExtNo);
}
