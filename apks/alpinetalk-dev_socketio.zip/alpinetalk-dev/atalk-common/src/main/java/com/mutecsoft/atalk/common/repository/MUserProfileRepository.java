/**
 * 
 */
package com.mutecsoft.atalk.common.repository;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import com.mutecsoft.atalk.common.model.MUserProfile;

/**
 * 사용자 프로파일 정보 Repository
 *
 * @author voyzer
 *
 */
public interface MUserProfileRepository extends CrudRepository<MUserProfile, Long> {

	Optional<MUserProfile> findByProfileNo(
			Long profileNo);
}
