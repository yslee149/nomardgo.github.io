/**
 * 
 */
package com.mutecsoft.atalk.common.model;

import java.io.Serializable;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * 디바이스 설정 정보
 * 
 * @author voyzer
 *
 */
@Entity(name="mDeviceConfig")
@Table(name="m_device_config")
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@ToString
// @DynamicInsert
public class MDeviceConfig implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8243281164334539601L;

	@Id
	@Column(name = "device_type")
	private String deviceType;

	@Column(name = "version")
	private String version;
	
	@Column(name = "app_path")
	private String appPath;
}

/*
"Field"	"Type"	"Null"	"Key"	"Default"	"Extra"
"DEVICE_TYPE"	"char(1)"	"NO"	"PRI"	\N	""
"VERSION"	"varchar(45)"	"NO"	""	\N	""
"APP_PATH"	"varchar(200)"	"YES"	""	\N	""


*/