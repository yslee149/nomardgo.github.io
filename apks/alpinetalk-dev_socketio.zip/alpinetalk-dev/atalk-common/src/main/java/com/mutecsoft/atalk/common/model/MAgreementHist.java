/**
 * 
 */
package com.mutecsoft.atalk.common.model;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.annotation.LastModifiedDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * 약관 동의 이력
 * 
 * @author voyzer
 *
 */
@Entity(name="mAgreementHistory")
@Table(name="m_agreement_history")
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@ToString
public class MAgreementHist implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4032401532465553738L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "hist_seq")
	private Long histSeq;

	@Column(name = "user_no")
	private Long userNo;
	
	@Column(name = "version_no")
	private Long versionNo;
	
	@Column(name = "cat")
	private String cat;

	@Column(name = "agree_yn")
	private String agreeYn;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "reg_date")
	@LastModifiedDate
	private Date regDate;
	
}
