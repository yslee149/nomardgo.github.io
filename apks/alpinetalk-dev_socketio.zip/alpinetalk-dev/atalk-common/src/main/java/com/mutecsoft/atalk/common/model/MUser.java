/**
 * 
 */
package com.mutecsoft.atalk.common.model;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.annotation.LastModifiedDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * 사용자 정보
 * 
 * @author voyzer
 *
 */
@Entity(name="mUser")
@Table(name="m_user")
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@ToString
// @DynamicInsert
public class MUser implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "user_no")
	private Long userNo;

	@Column(name = "user_id")
	private String userId;
	
	@Column(name = "signup_key")
	private String signupKey;
	
	@Column(name = "user_pw")
	private String userPw;

	@Column(name = "public_key")
	private String publicKey;
	
	@Column(name = "first_login")
	private String firstLogin;

	@Column(name = "user_pw_temp")
	private String userPwTemp;
	
	@Column(name = "user_name")
	private String userName;

	@Column(name = "nickname")
	private String nickname;
	
	@Column(name = "mobile_token")
	private String mobileToken;

	@Column(name = "imei")
	private String imei;
	
	@Column(name = "mobile_token_type")
	private String mobileTokenType;
	
	@Column(name = "device_type")
	private String deviceType;
	
	@Column(name = "sort_order")
	private String sortOrder;
	
	@Column(name = "grade")
	private String grade;
	
	@Column(name = "email")
	private String email;
	
	@Column(name = "profile_fg_no")
	private Long profileFgNo;
	
	@Column(name = "profile_bg_no")
	private Long profileBgNo;
	
	@Column(name = "phone_number")
	private String phoneNumber;
	
	//////////////
	
	@Column(name = "pi_agree_version")
	private Long piAgreeVersion;
	
	@Column(name = "pf_agree_version")
	private Long pfAgreeVersion;
	
	@Column(name = "si_agree_version")
	private Long siAgreeVersion;
	
	@Column(name = "birth_date")
	@Temporal(TemporalType.DATE)
	private Date birthDate;

	@Column(name = "gender")
	private String gender;
	
	@Column(name = "status_message")
	private String statusMessage;
	
	@Column(name = "lang")
	private String lang;	
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "pw_upd_date")
	@LastModifiedDate
	private Date pwUpdDate;
	
	@Column(name = "use_yn")
	private String useYn;
	
	@Column(name = "active_yn")
	private String activeYn;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "reg_date")
	@LastModifiedDate
	private Date regDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "upd_date")
	@LastModifiedDate
	private Date updDate;;
}

/*
"Field"	"Type"	"Null"	"Key"	"Default"	"Extra"
"USER_NO"	"int(11)"	"NO"	"PRI"	\N	"auto_increment"
"USER_ID"	"varchar(30)"	"NO"	""	\N	""
"SIGNUP_KEY"	"varchar(32)"	"NO"	""	\N	""
"USER_PW"	"varchar(128)"	"YES"	""	\N	""
"USER_PW_TEMP"	"varchar(128)"	"YES"	""	\N	""
"USER_NAME"	"varchar(50)"	"NO"	""	\N	""
"MOBILE_TOKEN"	"varchar(300)"	"YES"	""	\N	""
"IMEI"	"varchar(300)"	"YES"	""	\N	""
"MOBILE_TOKEN_TYPE"	"char(1)"	"NO"	""	"F"	""
"DEVICE_TYPE"	"char(3)"	"NO"	""	"A"	""
"SORT_ORDER"	"varchar(20)"	"YES"	""	"0"	""
"GRADE"	"varchar(50)"	"YES"	""	\N	""
"EMAIL"	"varchar(50)"	"YES"	""	\N	""
"PROFILE_PATH"	"varchar(50)"	"YES"	""	\N	""
"PHONE_NUMBER"	"varchar(20)"	"YES"	""	\N	""
"IMAGE_FILE"	"varchar(100)"	"YES"	""	\N	""
"PW_UPD_DATE"	"datetime"	"YES"	""	\N	""
"USE_YN"	"char(1)"	"NO"	""	"Y"	""
"ACTIVE_YN"	"char(1)"	"NO"	""	"Y"	""
"REG_DATE"	"datetime"	"NO"	""	\N	""
"UPD_DATE"	"datetime"	"NO"	""	\N	""

*/