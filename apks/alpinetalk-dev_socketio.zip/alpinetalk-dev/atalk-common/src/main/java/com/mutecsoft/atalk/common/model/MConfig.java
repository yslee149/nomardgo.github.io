/**
 * 
 */
package com.mutecsoft.atalk.common.model;

import java.io.Serializable;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * alpine talk config 테이블
 * 
 * @author voyzer
 *
 */
@Entity(name="mConfig")
@Table(name="m_config")
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@ToString
public class MConfig implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6943246215995783832L;

	@Id
	@Column(name = "config_no", updatable = false)
	private Long configNo;
		
	@Column(name = "profile_basepath", updatable = false)
	private String profileBasepath;
	
	@Column(name = "file_basepath", updatable = false)
	private String fileBasepath;
	
	@Column(name = "version")
	private String version;
}

/*
"Field"	"Type"	"Null"	"Key"	"Default"	"Extra"
"CONFIG_NO"	"int(11)"	"NO"	"PRI"	\N	"auto_increment"
"PROFILE_BASEPATH"	"varchar(50)"	"NO"	""	""	""
"FILE_BASEPATH"	"varchar(50)"	"NO"	""	""	""
"VERSION"	"varchar(20)"	"NO"	""	\N	""


*/


/*
"Field"	"Type"	"Null"	"Key"	"Default"	"Extra"
"ORG_NO"	"int(11)"	"NO"	"PRI"	\N	"auto_increment"
"ORG_CD"	"varchar(30)"	"YES"	""	\N	""
"ORG_TYPE"	"char(1)"	"NO"	""	\N	""
"PARENT_ORG_NO"	"int(11)"	"YES"	""	\N	""
"ORG_NAME"	"varchar(50)"	"NO"	""	\N	""
"SORT_VAL"	"varchar(20)"	"YES"	""	"0"	""
"DEPT_VAL"	"int(11)"	"YES"	""	\N	""
"USE_YN"	"char(1)"	"NO"	""	\N	""
"UPD_DATE"	"datetime"	"NO"	""	\N	""
"REG_DATE"	"datetime"	"NO"	""	\N	""

*/