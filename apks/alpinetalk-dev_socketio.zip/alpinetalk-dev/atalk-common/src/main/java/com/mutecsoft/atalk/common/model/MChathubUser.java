/**
 * 
 */
package com.mutecsoft.atalk.common.model;

import java.io.Serializable;
import java.util.Date;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import org.springframework.data.annotation.LastModifiedDate;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * 대화방 사용자 테이블
 * 
 * @author voyzer
 *
 */
@Entity(name="mChathubUser")
@Table(name="m_chathub_user")
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@ToString
@IdClass(MChathubUserCompositKey.class)
public class MChathubUser implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6943246215995783832L;

	@Id
	@Column(name = "chathub_no", updatable = false)
//	@ManyToOne
//	@JoinColumn(name = "chathub_no", referencedColumnName = "chathub_no")
//	private MChathub chathub;
	private Long chathubNo;
	
	@Id
	@Column(name = "user_no", updatable = false)
//	@ManyToOne
//	@JoinColumn(name = "user_no", referencedColumnName = "user_no")
//	private MUser user;
	private Long userNo;
	
	@Column(name = "chathub_name")
	private String chathubName;
	
	@Column(name = "main_chathub_name")
	private String mainChathubName;
	
	@Column(name = "encrypt_chat_key")
	private String encryptChatKey;

	@Column(name = "join_yn")
	private String joinYn;

	@Column(name = "use_yn")
	private String useYn;

	@Column(name = "noti_yn")
	private String notiYn;

	@Column(name = "start_chat_no")
	private Long startChatNo;
	
	@Column(name = "read_chat_no")
	private Long readChatNo;
	
	@Column(name = "last_chat_no")
	private Long lastChatNo;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "reg_date")
	@LastModifiedDate
	private Date regDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "upd_date")
	@LastModifiedDate
	private Date updDate;;
}

/*
"Field"	"Type"	"Null"	"Key"	"Default"	"Extra"
"CHATHUB_NO"	"bigint(20)"	"NO"	"PRI"	\N	""
"USER_NO"	"int(11)"	"NO"	"PRI"	\N	""
"CHATHUB_NAME"	"varchar(100)"	"YES"	""	\N	""
"MAIN_CHATHUB_NAME"	"varchar(100)"	"YES"	""	\N	""
"JOIN_YN"	"char(1)"	"NO"	""	\N	""
"USE_YN"	"char(1)"	"NO"	""	\N	""
"NOTI_YN"	"char(1)"	"NO"	""	"Y"	""
"START_CHAT_NO"	"int(11)"	"NO"	""	\N	""
"READ_CHAT_NO"	"int(11)"	"NO"	""	\N	""
"LAST_CHAT_NO"	"int(11)"	"YES"	""	\N	""
"REG_DATE"	"datetime"	"YES"	""	\N	""
"UPD_DATE"	"datetime"	"YES"	""	\N	""

*/