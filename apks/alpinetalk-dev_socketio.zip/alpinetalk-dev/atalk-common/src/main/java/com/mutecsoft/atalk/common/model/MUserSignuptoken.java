/**
 * 
 */
package com.mutecsoft.atalk.common.model;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.annotation.LastModifiedDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * 사용자 등록 토큰 정보
 * 
 * @author voyzer
 *
 */
@Entity(name="mUserSignuptoken")
@Table(name="m_user_signuptoken")
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@ToString
public class MUserSignuptoken implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "signup_key")
	private String signupKey;
	
	@Column(name = "use_yn")
	private String useYn;
	
	@Column(name = "active_yn")
	private String activeYn;
	
	@Column(name = "issue_prvkey")
	private String issuePrvkey;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "reg_date")
	@LastModifiedDate
	private Date regDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "upd_date")
	@LastModifiedDate
	private Date updDate;;
}

/*
"Field"	"Type"	"Null"	"Key"	"Default"	"Extra"
"SIGNUP_KEY"	"varchar(32)"	"NO"	"PRI"	\N	""
"USE_YN"	"char(1)"	"NO"	""	"N"	""
"ACTIVE_YN"	"char(1)"	"NO"	""	"Y"	""
"ISSUE_PRVKEY"	"text"	"YES"	""	\N	""
"REG_DATE"	"datetime"	"NO"	""	\N	""
"UPD_DATE"	"datetime"	"NO"	""	\N	""
*/

