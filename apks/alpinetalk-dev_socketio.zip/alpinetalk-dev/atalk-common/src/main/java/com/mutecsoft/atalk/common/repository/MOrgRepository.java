/**
 * 
 */
package com.mutecsoft.atalk.common.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.mutecsoft.atalk.common.model.MOrg;

import jakarta.transaction.Transactional;

/**
 * 조직도 정보 Repository
 *
 * @author voyzer
 *
 */
public interface MOrgRepository extends CrudRepository<MOrg, Long> {

	List<MOrg> findByOrgNo(Long orgNo);
	
	@Query
	(
		value = "SELECT * FROM m_org WHERE org_no=:orgNo AND upd_date > :updDate",
		nativeQuery = true
	)
	List<MOrg> findByOrgNoAndUpdDateAfter(
			@Param("orgNo") Long orgNo
			, @Param("updDate") Date updDate);

	@Transactional
	@Modifying
	@Query
	(
		value = "update m_org set use_yn='N', upd_date=now() where org_no = :orgNo",
		nativeQuery = true
	)
	void updateDelete(@Param("orgNo") Long orgNo);
}
