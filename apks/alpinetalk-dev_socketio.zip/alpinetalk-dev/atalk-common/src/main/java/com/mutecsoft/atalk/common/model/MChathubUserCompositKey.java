package com.mutecsoft.atalk.common.model;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode
public class MChathubUserCompositKey implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8521744056269480237L;
	private Long chathubNo;
	private Long userNo;
}
