/**
 * 
 */
package com.mutecsoft.atalk.common.model;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.annotation.LastModifiedDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * 개인정보동의
 * 
 * @author voyzer
 *
 */
@Entity(name="mPersonalInfoAgreement")
@Table(name="m_personal_info_agreement")
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@ToString
public class MPiAgreement implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4032401532465553738L;

	@Id
	@Column(name = "pi_no")
	private Long piNo;

	@Column(name = "pi_version")
	private String piVersion;
	
	@Column(name = "pi_content")
	private String piContent;
	
	@Column(name = "use_yn")
	private String useYn;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "reg_date")
	@LastModifiedDate
	private Date regDate;
	
}
