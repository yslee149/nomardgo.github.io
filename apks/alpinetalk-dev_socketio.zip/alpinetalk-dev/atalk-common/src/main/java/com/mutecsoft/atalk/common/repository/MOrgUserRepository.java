/**
 * 
 */
package com.mutecsoft.atalk.common.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.mutecsoft.atalk.common.model.MOrgUser;
import com.mutecsoft.atalk.common.model.MOrgUserCompositKey;

import jakarta.transaction.Transactional;

/**
 * 조직 사용자 정보 Repository
 *
 * @author voyzer
 *
 */
public interface MOrgUserRepository extends CrudRepository<MOrgUser, MOrgUserCompositKey> {

	List<MOrgUser> findByOrgNo(Long orgNo);
	
	@Query
	(
		value = "SELECT * FROM m_org_user WHERE org_no=:orgNo AND upd_date > :updDate",
		nativeQuery = true
	)
	List<MOrgUser> findByOrgNoAndUpdDateAfter(
			@Param("orgNo") Long orgNo
			, @Param("updDate") Date updDate);

	@Transactional
	@Modifying
	@Query
	(
		value = "update m_org_user set use_yn='N', upd_date=now() where org_no = :orgNo and user_no = :userNo",
		nativeQuery = true
	)
	void updateDelete(@Param("orgNo") Long orgNo, @Param("userNo") Long userNo);
}
