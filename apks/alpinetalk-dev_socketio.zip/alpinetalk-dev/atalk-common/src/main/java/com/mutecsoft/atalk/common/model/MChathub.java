/**
 * 
 */
package com.mutecsoft.atalk.common.model;

import java.io.Serializable;
import java.util.Date;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import org.springframework.data.annotation.LastModifiedDate;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * 대화방 테이블
 * 
 * @author voyzer
 *
 */
@Entity(name="mChathub")
@Table(name="m_chathub")
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@ToString
public class MChathub implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6943246215995783832L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "chathub_no", updatable = false)
	private Long chathubNo;
	
	@Column(name = "chathub_type", updatable = false)
	private String chathubType;
	
	@Column(name = "user_no")
	private Long userNo;
	
	@Column(name = "users_num")
	private Long usersNum;

	@Column(name = "use_yn")
	private String useYn;
	
	@Column(name = "ENC_KEY_URGENT")
	private String encKeyUrgent;  // by server pubkey encrypted.
	
	@Column(name = "userlist_hash")
	private String userlistHash;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "reg_date")
	@LastModifiedDate
	private Date regDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "upd_date")
	@LastModifiedDate
	private Date updDate;
}

/*

"Field"	"Type"	"Null"	"Key"	"Default"	"Extra"
"CHATHUB_NO"	"bigint(20)"	"NO"	"PRI"	\N	"auto_increment"
"CHATHUB_TYPE"	"char(1)"	"NO"	""	\N	""
"USER_NO"	"int(11)"	"NO"	""	\N	""
"USERS_NUM"	"smallint(4)"	"NO"	""	\N	""
"USE_YN"	"char(1)"	"NO"	""	\N	""
"USERLIST_HASH"	"varchar(64)"	"YES"	"MUL"	\N	""
"REG_DATE"	"datetime"	"NO"	""	\N	""
"UPD_DATE"	"datetime"	"NO"	""	\N	""


*/