/**
 * 
 */
package com.mutecsoft.atalk.common.model;

import java.io.Serializable;
import java.util.Date;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import org.springframework.data.annotation.LastModifiedDate;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * 삭제 대화 테이블
 * 
 * @author voyzer
 *
 */
@Entity(name="mChatDel")
@Table(name="m_chat_del")
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@ToString
@IdClass(MChatDelCompositKey.class)
public class MChatDel implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6943246215995783832L;
	
	@Id
	@Column(name = "chathub_no")
	private Long chathubNo;
	
	@Id
	@Column(name = "chat_no")
	private Long chatNo;
	
	@Id
	@Column(name = "userNo")
	private Long userNo;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "reg_date")
	@LastModifiedDate
	private Date regDate;
}
