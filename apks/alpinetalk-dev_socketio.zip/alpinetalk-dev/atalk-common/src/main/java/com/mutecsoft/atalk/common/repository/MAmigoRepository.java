/**
 * 
 */
package com.mutecsoft.atalk.common.repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.mutecsoft.atalk.common.model.MAmigo;
import com.mutecsoft.atalk.common.model.MAmigoUserCompositKey;

import jakarta.transaction.Transactional;

/**
 * 친구 정보 Repository
 *
 * @author voyzer
 *
 */
public interface MAmigoRepository extends CrudRepository<MAmigo, MAmigoUserCompositKey> {


	Optional<MAmigo> findByUserNoAndAmigoSetNoAndUseYnAndAmigoNo(
			Long userNo
			, Long amigoSetNo
			, String useYn
			, Long amigoNo);
	
	List<MAmigo> findByUserNoAndUseYn(
			Long userNo
			, String useYn);
	
	List<MAmigo> findByUserNoAndAmigoSetNoAndUseYnAndAmigoNoIn(
			Long userNo
			, Long amigoSetNo
			, String useYn
			, List<Long> amigoNos);
	
	List<MAmigo> findByUserNoAndAmigoSetNoAndUseYn(
			Long userNo
			, Long amigoSetNo
			, String useYn);
	
	@Query
	(
		value = "SELECT * FROM m_amigo WHERE user_no=:userNo AND upd_date > :updDate",
		nativeQuery = true
	)
	List<MAmigo> findByUserNoAndUpdDateAfter(
			@Param("userNo") Long userNo
			, @Param("updDate") Date updDate);
	

//	@Transactional
//	@Modifying
//	@Query
//	(
//		value = "delete from m_amigo set use_yn='N', upd_date=now() where user_no = :userNo and amigo_no = :amigoNo",
//		nativeQuery = true
//	)
//	void updateDeleteAmigo(@Param("userNo") Long userNo, @Param("amigoNo") Long amigoNo);
	
	@Transactional
	@Modifying
	@Query
	(
		value = "delete from m_amigo where user_no = :userNo and amigo_no IN :amigoNoList",
		nativeQuery = true
	)
	void deleteAmigos(
			@Param("userNo") Long userNo
			, @Param("amigoNoList") List<Long> amigoNoList);
	
	@Transactional
	@Modifying
	@Query
	(
		value = "INSERT INTO m_amigo "
				+ "(user_no, amigo_set_no, amigo_no, sort_val, tag, use_yn, reg_date, upd_date) "
				+ "SELECT :userNo, :amigoSetNo, user_no, '', '', 'Y', NOW(), NOW() FROM m_user WHERE USER_NO IN :amigoNoList",
		nativeQuery = true
	)
	int insertAmigos(
			@Param("userNo") Long userNo
			, @Param("amigoSetNo") Long amigoSetNo 
			, @Param("amigoNoList") List<Long> amigoNoList);

	Optional<MAmigo> findByUserNoAndAmigoNo(
			Long userNo
			, Long amigoNo);

	@Transactional
	@Modifying
	@Query
	(
		value = "UPDATE m_amigo set nickname=:nickName where user_no = :userNo and amigo_no = :amigoNo",
		nativeQuery = true
	)
	void updateNickname(
			@Param("userNo") Long userNo
			, @Param("nickName") String nickName
			, @Param("amigoNo") Long amigoNo
			);
}
