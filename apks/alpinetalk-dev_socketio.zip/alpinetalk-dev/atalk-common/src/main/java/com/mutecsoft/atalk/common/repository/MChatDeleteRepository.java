/**
 * 
 */
package com.mutecsoft.atalk.common.repository;

import org.springframework.data.repository.CrudRepository;
import com.mutecsoft.atalk.common.model.MChatDel;
import com.mutecsoft.atalk.common.model.MChatDelCompositKey;

/**
 * 대화 대용량 정보 Repository
 *
 * @author voyzer
 *
 */
public interface MChatDeleteRepository extends CrudRepository<MChatDel, MChatDelCompositKey> {


}
