/**
 * 
 */
package com.mutecsoft.atalk.common.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.mutecsoft.atalk.common.model.MAgreementHist;

/**
 * 약관 동의 이력 정보 Repository
 *
 * @author voyzer
 *
 */
public interface MAgreementHistRepository extends CrudRepository<MAgreementHist, Long> {

	@Query
	(
		value = "SELECT * FROM m_agreement_history WHERE user_no=:userNo AND cat=:verCat ORDER BY reg_Date DESC LIMIT 1",
		nativeQuery = true
	)
	Optional<MAgreementHist> findByLatest(@Param("userNo") Long userNo, @Param("verCat") String verCat);
}
