/**
 * 
 */
package com.mutecsoft.atalk.common.model;

import java.io.Serializable;
import java.util.Date;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import org.springframework.data.annotation.LastModifiedDate;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * 파일 대화 테이블
 * 
 * @author voyzer
 *
 */
@Entity(name="mChatFile")
@Table(name="m_chat_file")
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@ToString
public class MChatFile implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6943246215995783832L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "chat_file_no", updatable = false)
	private Long chatFileNo;
	
	@Column(name = "parent_chat_file_no")
	private Long parentChatFileNo;

//	@ManyToOne
//	@JoinColumn(name = "chathub_no", referencedColumnName = "chathub_no")
	@Column(name = "chathub_no")
//	private MChathub chathub;
	private Long chathubNo;
	
	@Column(name = "chat_no")
	private Long chatNo;

	@Column(name = "file_type")
	private String fileType;
	
	@Column(name = "file_name")
	private String fileName;
	
	@Column(name = "disp_name")
	private String dispName;
	
	@Column(name = "file_path")
	private String filePath;
	
	@Column(name = "thumbnail_path")
	private String thumbnailPath;
	
	@Column(name = "file_size")
	private Long fileSize;
	
	@Column(name = "use_yn")
	private String useYn;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "reg_date")
	@LastModifiedDate
	private Date regDate;
}
