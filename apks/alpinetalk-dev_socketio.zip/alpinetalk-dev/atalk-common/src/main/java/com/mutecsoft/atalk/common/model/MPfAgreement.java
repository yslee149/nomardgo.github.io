/**
 * 
 */
package com.mutecsoft.atalk.common.model;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.annotation.LastModifiedDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * 프로필정보 약관
 * 
 * @author voyzer
 *
 */
@Entity(name="mProfileInfoAgreement")
@Table(name="m_profile_info_agreement")
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@ToString
public class MPfAgreement implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4032401532465553738L;

	@Id
	@Column(name = "pf_no")
	private Long pfNo;

	@Column(name = "pf_version")
	private String pfVersion;
	
	@Column(name = "pf_content")
	private String pfContent;
	
	@Column(name = "use_yn")
	private String useYn;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "reg_date")
	@LastModifiedDate
	private Date regDate;
	
}
