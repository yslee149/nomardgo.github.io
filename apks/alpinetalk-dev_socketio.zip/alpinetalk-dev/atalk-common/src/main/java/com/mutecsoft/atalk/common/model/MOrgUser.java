/**
 * 
 */
package com.mutecsoft.atalk.common.model;

import java.io.Serializable;
import java.util.Date;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import org.springframework.data.annotation.LastModifiedDate;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * 사용자 조직도 매핑 테이블
 * 
 * @author voyzer
 *
 */
@Entity(name="mOrgUser")
@Table(name="m_org_user")
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@ToString
@IdClass(MOrgUserCompositKey.class)
public class MOrgUser implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6943246215995783832L;

	@Id
	@Column(name = "org_no", updatable = false)
//	@ManyToOne
//	@JoinColumn(name = "org_no", referencedColumnName = "org_no")
//	private MOrg org;
	private Long orgNo;
	
	@Id
	@Column(name = "user_no", updatable = false)
//	@ManyToOne
//	@JoinColumn(name = "user_no", referencedColumnName = "user_no")
//	private MUser user;
	private Long userNo;
	
	@Column(name = "sort_val", updatable = false)
	private String sortVal;
	
	@Column(name = "use_yn", updatable = false)
	private String useYn;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "reg_date")
	@LastModifiedDate
	private Date regDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "upd_date")
	@LastModifiedDate
	private Date updDate;;
}

/*
"Field"	"Type"	"Null"	"Key"	"Default"	"Extra"
"CHATHUB_NO"	"bigint(20)"	"NO"	"PRI"	\N	""
"USER_NO"	"int(11)"	"NO"	"PRI"	\N	""
"CHATHUB_NAME"	"varchar(100)"	"YES"	""	\N	""
"MAIN_CHATHUB_NAME"	"varchar(100)"	"YES"	""	\N	""
"JOIN_YN"	"char(1)"	"NO"	""	\N	""
"USE_YN"	"char(1)"	"NO"	""	\N	""
"NOTI_YN"	"char(1)"	"NO"	""	"Y"	""
"START_CHAT_NO"	"int(11)"	"NO"	""	\N	""
"READ_CHAT_NO"	"int(11)"	"NO"	""	\N	""
"LAST_CHAT_NO"	"int(11)"	"YES"	""	\N	""
"REG_DATE"	"datetime"	"YES"	""	\N	""
"UPD_DATE"	"datetime"	"YES"	""	\N	""

*/