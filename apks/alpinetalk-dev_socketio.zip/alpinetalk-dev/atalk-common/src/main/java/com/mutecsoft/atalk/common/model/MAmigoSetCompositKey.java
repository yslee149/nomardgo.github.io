/**
 * 
 */
package com.mutecsoft.atalk.common.model;

import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * 친구 정보 그룹 SET 키
 * 
 * @author voyzer
 *
 */
@Data
@NoArgsConstructor
@EqualsAndHashCode
public class MAmigoSetCompositKey implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6943246215995783832L;

	private Long userNo;
	private Long amigoSetNo;
	
}

/*

"Field"	"Type"	"Null"	"Key"	"Default"	"Extra"
"CHAT_EXT_NO"	"bigint(20)"	"NO"	"PRI"	\N	"auto_increment"
"CHATHUB_NO"	"bigint(20)"	"YES"	""	\N	""
"USER_NO"	"int(11)"	"NO"	""	\N	""
"CHAT"	"mediumtext"	"YES"	""	\N	""
"REG_DATE"	"datetime"	"YES"	""	\N	""

*/

