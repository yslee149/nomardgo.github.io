/**
 * 
 */
package com.mutecsoft.atalk.common.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.mutecsoft.atalk.common.model.MChatFile;

/**
 * 첨부파일 정보 Repository
 *
 * @author voyzer
 *
 */
public interface MChatFileRepository extends CrudRepository<MChatFile, Long> {

	List<MChatFile> findByChathubNoAndChatNoIn(
			Long chathubNo
			, List<Long> chatNoList);

	Optional<MChatFile> findByChathubNoAndChatNo(
			Long chathubNo
			, Long chatNo);
	
	
	@Query
	(
		value = "SELECT "
			+ "	A.* "
			+ "	FROM m_chat_file A "
			+ "	INNER join m_chathub B "
			+ "	ON A.chathub_no=B.chathub_no  "
			+ "	INNER JOIN m_chathub_user C "
			+ "	ON A.chathub_no=C.CHATHUB_NO AND C.user_no=:userNo "
			+ "	WHERE A.chat_file_no=:chatFileNo ",
		nativeQuery = true
	)
	Optional<MChatFile> findByUserNoAndChatFileNo(
			@Param("userNo") Long userNo
			, @Param("chatFileNo") Long chatFileNo);
}
