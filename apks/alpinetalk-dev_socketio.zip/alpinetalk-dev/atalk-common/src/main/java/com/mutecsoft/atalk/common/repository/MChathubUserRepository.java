/**
 * 
 */
package com.mutecsoft.atalk.common.repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.mutecsoft.atalk.common.model.MChathubUser;
import com.mutecsoft.atalk.common.model.MChathubUserCompositKey;

import jakarta.transaction.Transactional;

/**
 * 대화 사용자 정보 Repository
 *
 * @author voyzer
 *
 */
public interface MChathubUserRepository extends CrudRepository<MChathubUser, MChathubUserCompositKey> {

	List<MChathubUser> findByChathubNoAndUserNoInAndJoinYn(
			Long chathubNo
			, List<Long> userNo
			, String joinYn);
	
	// 내가 참여한 대화방 목록
	List<MChathubUser> findByUserNoAndJoinYn(
			Long userNo
			, String joinYn);
	
	Optional<MChathubUser> findByChathubNoAndUserNoAndJoinYn(
			Long chathubNo
			, Long userNo
			, String joinYn);
	
	
	List<MChathubUser> findByChathubNoAndJoinYn(
			Long chathubNo
			, String joinYn);
	
	List<MChathubUser> findByChathubNo(
			Long chathubNo);
	
	@Query
	(
		value = "SELECT * FROM m_chathub_user WHERE user_no=:userNo AND upd_date > :updDate",
		nativeQuery = true
	)
	List<MChathubUser> findByUserNoAndUpdDateAfter(
			@Param("userNo") Long userNo
			, @Param("updDate") Date updDate);
	
	@Query
	(
		value = "SELECT GROUP_CONCAT(C.user_name) "
				+ "	FROM m_chathub_user A "
				+ "	INNER JOIN m_chathub B "
				+ "	ON A.CHATHUB_NO=B.CHATHUB_NO "
				+ "	INNER JOIN m_user C "
				+ "	ON A.user_no=C.user_no "
				+ "	WHERE 1=1 "
				+ "	AND B.CHATHUB_NO=:chathubNo "
				+ "	AND A.join_yn='Y' "
				+ "	AND A.user_no != :userNo",
		nativeQuery = true
	)
	String chatUserNamesWithoutMeWithComma(
			@Param("chathubNo") Long chathubNo
			, @Param("userNo") Long userNo);
	
	@Query
	(
		value = "SELECT "
				+ "	GROUP_CONCAT(U.USER_NAME) "
				+ "FROM m_chathub_user HU "
				+ "INNER JOIN m_user U "
				+ "ON HU.USER_NO=U.USER_NO "
				+ "WHERE 1=1 "
				+ "AND HU.CHATHUB_NO=:chathubNo AND HU.JOIN_YN='Y' "
				+ "AND U.user_no IN (:userList)",
		nativeQuery = true
	)
	String chatUserNamesList(
			@Param("chathubNo") Long chathubNo
			, @Param("userList") List<Long> userList);
	
	@Query
	(
		value = "SELECT "
				+ "	GROUP_CONCAT(U.USER_NAME) "
				+ "FROM m_user U "
				+ "WHERE 1=1 "
				+ "AND U.user_no IN (:userList)",
		nativeQuery = true
	)
	String chatUserNamesList(@Param("userList") List<Long> userList);
	
	@Query
	(
		value = "SELECT GROUP_CONCAT(C.user_name) "
				+ "	FROM m_chathub_user A "
				+ "	INNER JOIN m_chathub B "
				+ "	ON A.CHATHUB_NO=B.CHATHUB_NO "
				+ "	INNER JOIN m_user C "
				+ "	ON A.user_no=C.user_no "
				+ "	WHERE 1=1 "
				+ "	AND B.CHATHUB_NO=:chathubNo "
				+ "	AND A.join_yn='Y'",
		nativeQuery = true
	)
	String chatUserNamesWithComma(
			@Param("chathubNo") Long chathubNo);
	
	@Transactional
	@Modifying
	@Query
	(
		value = "update m_chathub_user set use_yn='N', join_yn='N', encrypt_chat_key=null, upd_date=now() where user_no = :userNo and chathub_no = :chathubNo",
		nativeQuery = true
	)
	void updateDelete(@Param("userNo") Long userNo, @Param("chathubNo") Long chathubNo);
	
	@Transactional
	@Modifying
	@Query
	(
		value = "update m_chathub_user set upd_date=now() where chathub_no = :chathubNo",
		nativeQuery = true
	)
	void updateChathubUpdDt(@Param("chathubNo") Long chathubNo);
	
	@Transactional
	@Modifying
	@Query
	(
		value = "update m_chathub_user set use_yn='N', join_yn='N', encrypt_chat_key=null, upd_date=now() where chathub_no = :chathubNo and user_no IN (:userNoList)",
		nativeQuery = true
	)
	void updateDeleteList(@Param("userNoList") List<Long> userNoList, @Param("chathubNo") Long chathubNo);
	
	@Transactional
	@Modifying
	@Query
	(
		value = "update m_chathub_user set upd_date=now(), encrypt_chat_key = :encChathubKey where chathub_no = :chathubNo and user_no = :userNo",
		nativeQuery = true
	)
	void updateChathubKey(@Param("chathubNo") Long chathubNo
			, @Param("userNo") Long userNo 
			, @Param("encChathubKey") String encChathubKey);
	
	@Transactional
	@Modifying
	@Query
	(
		value = "update m_chathub_user set upd_date=now() where chathub_no = :chathubNo",
		nativeQuery = true
	)
	void updateDate(@Param("chathubNo") Long chathubNo);
	
	Optional<MChathubUser> findByChathubNoAndUserNo(
			Long chathubNo
			, Long chatNo);
	
	
	@Transactional
	@Modifying
	@Query
	(
		value = "update m_chathub_user set encrypt_chat_key=:encryptChatKey, upd_date=now() where chathub_no = :chathubNo and user_no = :userNo",
		nativeQuery = true
	)
	void updateEncryptChatKey(
			@Param("chathubNo") Long chathubNo
			, @Param("userNo") Long userNo
			, @Param("encryptChatKey") String encryptChatKey);
	

	@Transactional
	@Modifying
	@Query
	(
		value = "update m_chathub_user SET read_chat_no=(SELECT MAX(chat_no) FROM m_chat WHERE chathub_no=:chathubNo), upd_date=NOW() where user_no = :userNo and chathub_no = :chathubNo",
		nativeQuery = true
	)
	void updateRead(@Param("userNo") Long userNo, @Param("chathubNo") Long chathubNo);
	
	@Transactional
	@Modifying
	@Query
	(
		value = "update m_chathub_user set upd_date=now(), main_chathub_name = :mainChathubName where chathub_no = :chathubNo",
		nativeQuery = true
	)
	void updateChathubMasterTitle(@Param("chathubNo") Long chathubNo
			, @Param("mainChathubName") String mainChathubName);
	
	
	
}
