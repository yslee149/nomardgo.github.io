/**
 * 
 */
package com.mutecsoft.atalk.common.repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.mutecsoft.atalk.common.model.MAmigoSet;
import com.mutecsoft.atalk.common.model.MAmigoSetCompositKey;

import jakarta.transaction.Transactional;

/**
 * 친구 그룹 Repository
 *
 * @author voyzer
 *
 */
public interface MAmigoSetRepository extends CrudRepository<MAmigoSet, MAmigoSetCompositKey> {

	List<MAmigoSet> findByUserNoAndUseYn(
			Long userNo
			, String useYn);
	
	@Transactional
	@Modifying
	@Query
	(
		value = "INSERT INTO m_amigo_set "
				+ "(user_no, amigo_set_no, amigo_set_name, display_yn, use_yn, REG_DATE, UPD_DATE) "
				+ "SELECT ?1, IFNULL(MAX(AMIGO_SET_NO), 0) + 1, ?2, ?3, 'Y', NOW(), NOW() FROM m_amigo_set WHERE USER_NO=?1",
		nativeQuery = true
	)
	int insertAmigoSet(
			Long userNo, String amigoSetName, String displayYn);
	
	@Transactional
	@Modifying
	@Query
	(
		value = "update m_amigo_set set amigo_set_name = :amigoSetName, upd_date=now() where user_no = :userNo and amigo_set_no = :amigoSetNo",
		nativeQuery = true
	)
	void renameAmigoSetName(@Param("userNo") Long userNo, @Param("amigoSetNo") Long amigoSetNo, @Param("amigoSetName") String amigoSetName);
	
	
//	@Query
//	(
//		value = "SELECT * FROM m_amigo_set WHERE user_no = :userNo and amigo_set_name = :amigoSetName LIMIT 1",
//		nativeQuery = true
//	)
	Optional<List<MAmigoSet>> findByUserNoAndAmigoSetName(@Param("userNo") Long userNo, @Param("amigoSetName") String amigoSetName);
	
	@Query
	(
		value = "SELECT * FROM m_amigo_set WHERE user_no = :userNo ORDER BY amigo_set_no DESC LIMIT 1",
		nativeQuery = true
	)
	Optional<MAmigoSet> findByUserNoAndMaximumAmigoSetNo(@Param("userNo") Long userNo);
	
	
	@Query
	(
		value = "SELECT * FROM m_amigo_set WHERE user_no=:userNo AND upd_date > :updDate",
		nativeQuery = true
	)
	List<MAmigoSet> findByUserNoAndUpdDateAfter(
			@Param("userNo") Long userNo
			, @Param("updDate") Date updDate);
		
	@Transactional
	@Modifying
	@Query
	(
		value = "update m_amigo_set set use_yn='N', upd_date=now() where user_no = :userNo and amigo_set_no = :amigoSetNo",
		nativeQuery = true
	)
	void updateDelete(@Param("userNo") Long userNo, @Param("amigoSetNo") Long amigoSetNo);

	Optional<MAmigoSet> findByUserNoAndAmigoSetNo(
			Long userNo
			, Long amigoSetNo);
}
