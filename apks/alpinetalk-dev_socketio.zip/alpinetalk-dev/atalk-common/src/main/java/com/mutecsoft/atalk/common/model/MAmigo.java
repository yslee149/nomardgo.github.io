/**
 * 
 */
package com.mutecsoft.atalk.common.model;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import org.springframework.data.annotation.LastModifiedDate;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * 친구 정보 테이블
 * 
 * @author voyzer
 *
 */
@Entity(name="mAmigo")
@Table(name="m_amigo")
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@ToString
@IdClass(MAmigoUserCompositKey.class)
public class MAmigo implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6943246215995783832L;

	@Id
	@Column(name = "user_no", updatable = false)
	private Long userNo;
	
	@Id
	@Column(name = "amigo_set_no", updatable = false)
	private Long amigoSetNo;
	
	@Id
	@Column(name = "amigo_no", updatable = false)
	private Long amigoNo;
//
//	@Id
//	@ManyToOne(targetEntity=MUser.class
//			, fetch=FetchType.LAZY
//			, cascade = CascadeType.DETACH)
//	@JoinColumn(name = "amigo_no", referencedColumnName = "user_no", updatable = false, nullable = false)
//	private MUser amigoUser;
	
	@Column(name = "sort_val", updatable = false)
	private String sortVal;
	
	@Column(name = "nickname")
	private String nickname;
	
	@Column(name = "tag")
	private String tag;
	
	@Column(name = "use_yn", updatable = false)
	private String useYn;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "reg_date")
	@LastModifiedDate
	private Date regDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "upd_date")
	@LastModifiedDate
	private Date updDate;
}
/*
"Field"	"Type"	"Null"	"Key"	"Default"	"Extra"
"USER_NO"	"int(11)"	"NO"	"PRI"	\N	""
"AMIGO_NO"	"int(11)"	"NO"	"PRI"	\N	""
"SORT_VAL"	"varchar(20)"	"YES"	""	""	""
"TAG"	"varchar(20)"	"YES"	""	\N	""
"USE_YN"	"char(1)"	"YES"	""	\N	""
"REG_DATE"	"varchar(20)"	"YES"	""	\N	""
"UPD_DATE"	"varchar(20)"	"YES"	""	\N	""

*/