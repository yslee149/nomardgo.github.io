/**
 * 
 */
package com.mutecsoft.atalk.common.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import com.mutecsoft.atalk.common.model.MPiAgreement;

/**
 * 개인정보 동의 약관 정보 Repository
 *
 * @author voyzer
 *
 */
public interface MPiAgreementRepository extends CrudRepository<MPiAgreement, Long> {

	Optional<MPiAgreement> findByPiNo(Long piNo);
	
	@Query
	(
		value = "SELECT * from m_personal_info_agreement where use_yn='Y' ORDER BY pi_no DESC LIMIT 1",
		nativeQuery = true
	)
	Optional<MPiAgreement> findByLatest();

}
