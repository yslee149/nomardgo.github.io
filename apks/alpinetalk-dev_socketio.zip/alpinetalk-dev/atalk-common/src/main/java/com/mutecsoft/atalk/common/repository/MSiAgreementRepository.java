/**
 * 
 */
package com.mutecsoft.atalk.common.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import com.mutecsoft.atalk.common.model.MSiAgreement;

/**
 * 서비스 동의 약관 정보 Repository
 *
 * @author voyzer
 *
 */
public interface MSiAgreementRepository extends CrudRepository<MSiAgreement, Long> {

	Optional<MSiAgreement> findBySiNo(Long siNo);
	
	@Query
	(
		value = "SELECT * from m_service_info_agreement where use_yn='Y' ORDER BY si_no DESC LIMIT 1",
		nativeQuery = true
	)
	Optional<MSiAgreement> findByLatest();

}
