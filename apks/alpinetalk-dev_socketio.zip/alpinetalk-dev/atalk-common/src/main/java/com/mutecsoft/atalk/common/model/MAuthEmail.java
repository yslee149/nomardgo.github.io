/**
 * 
 */
package com.mutecsoft.atalk.common.model;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.annotation.LastModifiedDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * alpine talk 이메일 인증 테이블
 * 
 * @author voyzer
 *
 */
@Entity(name="mAuthEmail")
@Table(name="m_auth_email")
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@ToString
public class MAuthEmail implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6943246215995783832L;

	@Id
	@Column(name = "auth_email_seq", updatable = false)
	private Long authEmailSeq;
		
	@Column(name = "email", updatable = false)
	private String email;
	
	@Column(name = "auth_token", updatable = false)
	private String authToken;

	@Column(name = "check_yn")
	private String checkYn;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "reg_date")
	@LastModifiedDate
	private Date regDate;
}
