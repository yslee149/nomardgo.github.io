/**
 * 
 */
package com.mutecsoft.atalk.common.repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.mutecsoft.atalk.common.model.MChathub;

import jakarta.transaction.Transactional;

/**
 * 대화 정보 Repository
 *
 * @author voyzer
 *
 */
public interface MChathubRepository extends CrudRepository<MChathub, Long> {

	Optional<MChathub> findByChathubNoAndUseYn(
			Long chathubNo
			, String useYn);

	List<MChathub> findByChathubNoIn(List<Long> chathubNoList);
	
	@Query
	(
		value = "SELECT * FROM m_chathub WHERE user_no=:userNo AND upd_date > :updDate",
		nativeQuery = true
	)
	List<MChathub> findByUpdDateAfter(@Param("updDate") Date updDate);
	
	@Transactional
	@Modifying
	@Query
	(
		value = "update m_chathub set ENC_KEY_URGENT=:encKeyUrgent, upd_date=now() where chathub_no = :chathubNo",
		nativeQuery = true
	)
	void updateEncUrgentKey(@Param("chathubNo") Long chathubNo, @Param("encKeyUrgent") String encKeyUrgent);
	
	@Transactional
	@Modifying
	@Query
	(
		value = "update m_chathub set use_yn='N', upd_date=now() where chathub_no = :chathubNo",
		nativeQuery = true
	)
	void updateDelete(@Param("chathubNo") Long chathubNo);
	
	Optional<MChathub> findByChathubNo(Long chathubNo);
	
	@Query
	(
		value = "SELECT "
				+ "	H.CHATHUB_NO "
				+ " , H.chathub_type "
				+ "	, IFNULL(C.chat_no, 0) AS chat_no "
				+ "	, IFNULL(C.chat_type, '') AS chat_type "
				+ "	, IFNULL(C.chat_sub_type, '') AS chat_sub_type "
				+ "	, IFNULL(C.user_no, 0) AS user_no "
				+ "	, IFNULL(C.chat, '') AS chat "
				+ "	, (SELECT USER_NAME FROM m_user WHERE USER_no=C.user_no) AS user_name "
				+ " , CASE WHEN C.user_no IS NULL THEN 0 " 
				+ "   ELSE "
				+ "        IFNULL((SELECT (LAST_CHAT_NO - READ_CHAT_NO) FROM m_chathub_user WHERE CHATHUB_NO=H.CHATHUB_NO AND JOIN_YN='Y' AND USER_NO=:userNo), 0) "
				+ "    END AS unread_cnt " 
				+ "	, H.users_num "
				+ "	, IFNULL(C.reg_date, NOW()) AS REG_DATE "
				+ "	, HU.join_yn "
				// + "	, HU.UPD_DATE "
				+ "	, NOW() AS CURR_DATE "
				+ " , IFNULL(HU.encrypt_chat_key, '') AS encrypt_chat_key "
				+ " , CASE WHEN HU.main_chathub_name IS NOT NULL AND HU.main_chathub_name != '' THEN HU.main_chathub_name "
				+ "        WHEN HU.chathub_name IS NOT NULL AND HU.chathub_name != '' THEN HU.chathub_name "
				+ "   ELSE "
				+ "        (SELECT group_concat(B.USER_NAME) FROM m_chathub_user A INNER JOIN m_user B ON A.USER_NO=B.USER_NO WHERE A.CHATHUB_NO=H.CHATHUB_NO AND A.JOIN_YN='Y' AND A.USER_NO != :userNo) "
				+ "   END AS CHATHUB_NAME "
				+ "FROM m_chathub H "
				+ "INNER JOIN m_chathub_user HU "
				+ "ON H.CHATHUB_NO=HU.CHATHUB_NO "
				+ "LEFT JOIN m_chat C "
				+ "ON H.CHATHUB_NO=C.CHATHUB_NO AND C.chat_no=HU.last_chat_no "
				+ "WHERE 1=1 "
				+ "AND HU.user_no=:userNo "
				+ "AND HU.UPD_DATE > :updateDt "
				+ "ORDER BY HU.UPD_DATE DESC",
		nativeQuery = true
	)
	List<Object[]> findByAfterUpdateDt(
			@Param("updateDt") Date updateDt
			, @Param("userNo") Long userNo);
	
	
	@Query
	(
		value = "SELECT "
				+ "	H.CHATHUB_NO "
				+ " , H.chathub_type "
				+ "	, IFNULL(C.chat_no, 0) AS chat_no "
				+ "	, IFNULL(C.chat_type, '') AS chat_type "
				+ "	, IFNULL(C.chat_sub_type, '') AS chat_sub_type "
				+ "	, IFNULL(C.user_no, 0) AS user_no "
				+ "	, IFNULL(C.chat, '') AS chat "
				+ "	, (SELECT USER_NAME FROM m_user WHERE USER_no=C.user_no) AS user_name "
				+ " , CASE WHEN C.user_no IS NULL THEN 0 " 
				+ "   ELSE "
				+ "        IFNULL((SELECT (LAST_CHAT_NO - READ_CHAT_NO) FROM m_chathub_user WHERE CHATHUB_NO=H.CHATHUB_NO AND JOIN_YN='Y' AND USER_NO=:userNo), 0) "
				+ "    END AS unread_cnt " 
				+ "	, H.users_num "
				+ "	, IFNULL(C.reg_date, NOW()) AS REG_DATE "
				+ "	, HU.join_yn "
				// + "	, HU.UPD_DATE "
				+ "	, NOW() AS CURR_DATE "
				+ " , IFNULL(HU.encrypt_chat_key, '') AS encrypt_chat_key "
				+ " , CASE WHEN HU.main_chathub_name IS NOT NULL AND HU.main_chathub_name != '' THEN HU.main_chathub_name "
				+ "        WHEN HU.chathub_name IS NOT NULL AND HU.chathub_name != '' THEN HU.chathub_name "
				+ "   ELSE "
				+ "        (SELECT group_concat(B.USER_NAME) FROM m_chathub_user A INNER JOIN m_user B ON A.USER_NO=B.USER_NO WHERE A.CHATHUB_NO=H.CHATHUB_NO AND A.JOIN_YN='Y' AND A.USER_NO != :userNo) "
				+ "   END AS CHATHUB_NAME "
				+ "FROM m_chathub H "
				+ "INNER JOIN m_chathub_user HU "
				+ "ON H.CHATHUB_NO=HU.CHATHUB_NO "
				+ "LEFT JOIN m_chat C "
				+ "ON H.CHATHUB_NO=C.CHATHUB_NO AND C.chat_no=HU.last_chat_no "
				+ "WHERE 1=1 "
				+ "AND HU.user_no=:userNo AND HU.join_yn='Y' "
				+ "AND HU.UPD_DATE > :updateDt AND HU.JOIN_YN='Y' "
				+ "ORDER BY HU.UPD_DATE DESC",
		nativeQuery = true
	)
	List<Object[]> findByAfterUpdateDtOnlyJoined(
			@Param("updateDt") Date updateDt
			, @Param("userNo") Long userNo);
	
	@Transactional
	@Modifying
	@Query
	(
		value = "UPDATE m_chathub "
				+ "SET upd_date=NOW(), users_num=(SELECT COUNT(1) FROM m_chathub_user WHERE chathub_no=:chathubNo AND join_yn='Y') "
				+ "WHERE chathub_no=:chathubNo ",
		nativeQuery = true
	)
	void updateUserCount(@Param("chathubNo") Long chathubNo);
}
