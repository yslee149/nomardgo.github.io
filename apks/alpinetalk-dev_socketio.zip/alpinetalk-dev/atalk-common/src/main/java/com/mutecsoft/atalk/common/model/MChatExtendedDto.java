/**
 * 
 */
package com.mutecsoft.atalk.common.model;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * DTO
 * 
 * @author voyzer
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class MChatExtendedDto implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6943246215995783832L;


	private Long chatNo;
	private String chatType;
	private String chatSubType;
	private Long userNo;
	private String userName;
	
//	private Integer unreadCnt;
//	private Integer usersNum;
//	private String chat;
//	private String extChat;
//	private Long chatFileNo;
//	private Long parentChatFileNo;
//	private String fileType;
//	private String dispName;
//	private Long fileSize;
//	private Date regDate;
}
