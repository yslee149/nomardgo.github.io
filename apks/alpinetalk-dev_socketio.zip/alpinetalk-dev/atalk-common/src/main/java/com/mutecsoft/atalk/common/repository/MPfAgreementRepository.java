/**
 * 
 */
package com.mutecsoft.atalk.common.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.mutecsoft.atalk.common.model.MPfAgreement;

/**
 * 프로필 동의 약관 정보 Repository
 *
 * @author voyzer
 *
 */
public interface MPfAgreementRepository extends CrudRepository<MPfAgreement, Long> {

	Optional<MPfAgreement> findByPfNo(Long pfNo);
	
	@Query
	(
		value = "SELECT * from m_profile_info_agreement where use_yn='Y' ORDER BY pf_no DESC LIMIT 1",
		nativeQuery = true
	)
	Optional<MPfAgreement> findByLatest();

}
