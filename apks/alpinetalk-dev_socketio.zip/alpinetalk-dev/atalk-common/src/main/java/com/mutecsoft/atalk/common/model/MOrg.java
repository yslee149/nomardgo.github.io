/**
 * 
 */
package com.mutecsoft.atalk.common.model;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.annotation.LastModifiedDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * 조직정보
 * 
 * @author voyzer
 *
 */
@Entity(name="mOrg")
@Table(name="m_org")
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@ToString
public class MOrg implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4032401532465553738L;

	@Id
	@Column(name = "org_no")
	private Long orgNo;

	@Column(name = "ord_cd")
	private String orgCd;
	
	@Column(name = "org_type")
	private String orgType;
	
	@Column(name = "parent_org_no")
	private String parentOrgNo;

	@Column(name = "org_name")
	private String orgName;
	
	@Column(name = "sort_val")
	private String sortVal;

	@Column(name = "dept_val")
	private String deptVal;

	@Column(name = "use_yn")
	private String useYn;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "reg_date")
	@LastModifiedDate
	private Date regDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "upd_date")
	@LastModifiedDate
	private Date updDate;;
}

/*
"Field"	"Type"	"Null"	"Key"	"Default"	"Extra"
"USER_NO"	"int(11)"	"NO"	"PRI"	\N	"auto_increment"
"USER_ID"	"varchar(30)"	"NO"	""	\N	""
"SIGNUP_KEY"	"varchar(32)"	"NO"	""	\N	""
"USER_PW"	"varchar(128)"	"YES"	""	\N	""
"USER_PW_TEMP"	"varchar(128)"	"YES"	""	\N	""
"USER_NAME"	"varchar(50)"	"NO"	""	\N	""
"MOBILE_TOKEN"	"varchar(300)"	"YES"	""	\N	""
"IMEI"	"varchar(300)"	"YES"	""	\N	""
"MOBILE_TOKEN_TYPE"	"char(1)"	"NO"	""	"F"	""
"DEVICE_TYPE"	"char(3)"	"NO"	""	"A"	""
"SORT_ORDER"	"varchar(20)"	"YES"	""	"0"	""
"GRADE"	"varchar(50)"	"YES"	""	\N	""
"EMAIL"	"varchar(50)"	"YES"	""	\N	""
"PROFILE_PATH"	"varchar(50)"	"YES"	""	\N	""
"PHONE_NUMBER"	"varchar(20)"	"YES"	""	\N	""
"IMAGE_FILE"	"varchar(100)"	"YES"	""	\N	""
"PW_UPD_DATE"	"datetime"	"YES"	""	\N	""
"USE_YN"	"char(1)"	"NO"	""	"Y"	""
"ACTIVE_YN"	"char(1)"	"NO"	""	"Y"	""
"REG_DATE"	"datetime"	"NO"	""	\N	""
"UPD_DATE"	"datetime"	"NO"	""	\N	""

*/