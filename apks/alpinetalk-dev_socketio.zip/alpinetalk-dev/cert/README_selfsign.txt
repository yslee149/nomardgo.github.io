D:\WorkspaceMutecsoft\alpinetalk-dev\cert>D:\Project\openssl340\bin\openssl genrsa -out key.pem 2048
Generating RSA private key, 2048 bit long modulus (2 primes)
....................+++++
......................................................................................................................+++++
e is 65537 (0x010001)

D:\WorkspaceMutecsoft\alpinetalk-dev\cert>D:\Project\openssl340\bin\openssl req -new -x509 -key key.pem -out cert.pem -days 365
Can't open Z:/extlib/_openssl111__/ssl/openssl.cnf for reading, No such file or directory
7452:error:02001003:system library:fopen:No such process:crypto/bio/bss_file.c:69:fopen('Z:/extlib/_openssl111__/ssl/openssl.cnf','r')
7452:error:2006D080:BIO routines:BIO_new_file:no such file:crypto/bio/bss_file.c:76:

D:\WorkspaceMutecsoft\alpinetalk-dev\cert>Z:
�ý����� ������ ����̺긦 ã�� �� �����ϴ�.

D:\WorkspaceMutecsoft\alpinetalk-dev\cert>where openssl
C:\Strawberry\c\bin\openssl.exe
D:\Project\openssl340\bin\openssl.exe


D:\WorkspaceMutecsoft\alpinetalk-dev\cert>D:\Project\openssl340\bin\openssl req -new -x509 -key key.pem -out cert.pem -days 19999
Can't open Z:/extlib/_openssl111__/ssl/openssl.cnf for reading, No such file or directory
28280:error:02001003:system library:fopen:No such process:crypto/bio/bss_file.c:69:fopen('Z:/extlib/_openssl111__/ssl/openssl.cnf','r')
28280:error:2006D080:BIO routines:BIO_new_file:no such file:crypto/bio/bss_file.c:76:

D:\WorkspaceMutecsoft\alpinetalk-dev\cert>D:\Project\openssl340\bin\openssl req -new -x509 -key key.pem -out cert.pem -days 365
You are about to be asked to enter information that will be incorporated
into your certificate request.
What you are about to enter is what is called a Distinguished Name or a DN.
There are quite a few fields but you can leave some blank
For some fields there will be a default value,
If you enter '.', the field will be left blank.
-----
Country Name (2 letter code) [AU]:KO
State or Province Name (full name) [Some-State]:Geonggi-do
Locality Name (eg, city) []:Gunpo
Organization Name (eg, company) [Internet Widgits Pty Ltd]:stormchaser
Organizational Unit Name (eg, section) []:
Common Name (e.g. server FQDN or YOUR name) []:adrian
Email Address []:voyzer@gmail.com

D:\WorkspaceMutecsoft\alpinetalk-dev\cert>dir
 D ����̺��� ����: �� ����
 ���� �Ϸ� ��ȣ: 689B-2865

 D:\WorkspaceMutecsoft\alpinetalk-dev\cert ���͸�

2025-01-27  ���� 12:47    <DIR>          .
2025-01-27  ���� 12:44    <DIR>          ..
2025-01-27  ���� 12:47             1,414 cert.pem
2025-01-27  ���� 12:44             1,702 key.pem
               2�� ����               3,116 ����Ʈ
               2�� ���͸�  1,557,642,125,312 ����Ʈ ����

D:\WorkspaceMutecsoft\alpinetalk-dev\cert>D:\Project\openssl340\bin\openssl pkcs12 -export -out keystore.pfx -inkey key.pem -in cert.pem -password pass:12345

D:\WorkspaceMutecsoft\alpinetalk-dev\cert>

