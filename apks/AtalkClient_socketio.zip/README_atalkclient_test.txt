java -cp ./target/AtalkClient-1.0.jar com.mutecsoft.atalk.logic.AtalkRabbitMqTest

java -cp ./target/AtalkClient-1.0.jar com.mutecsoft.atalk.logic.AtalkMain