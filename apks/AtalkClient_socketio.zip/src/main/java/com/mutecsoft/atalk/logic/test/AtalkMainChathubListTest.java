package com.mutecsoft.atalk.logic.test;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mutecsoft.atalk.logic.AtalkComplex;
import com.mutecsoft.atalk.logic.model.chathub.ChatHubListInfo;
import com.mutecsoft.atalk.logic.model.chathub.ChatInfoLast;
import com.mutecsoft.atalk.logic.model.chathub.ListChathubRequest;
import com.mutecsoft.atalk.logic.model.chathub.ListChathubResponse;
import com.mutecsoft.atalk.logic.util.AesEncDecComplex;
import com.mutecsoft.atalk.logic.util.AtalkPacketUtil;

/**
 * 
 *   대화방 목록 정보. 마지막 메시지 안읽은 뱃지 갯수 등을 표시하는 화면.
 * 
 * 
 */
public class AtalkMainChathubListTest {

	private static final Logger logger = LoggerFactory.getLogger(AtalkMainChathubListTest.class);

	public static void main(String [] args) throws Exception {
		final String userId = "user1003@aaa.com";
		final String passwordPlain = "111111";
		
		getChatHubInfoList(userId, passwordPlain);
	}

	static ListChathubResponse getChatHubInfoList(String userId, String passwordPlain) throws Exception {
		

//		String userId = "USER999";
//		String passwordPlain = "USER999";
		ListChathubResponse responseData = null;
		
		logger.info("#### 1. START - DETERMINE PACKET KEY");
		AtalkMainPacketKeyTest packetKeyTestObj = new AtalkMainPacketKeyTest();
		packetKeyTestObj.determinePacketKey();
		logger.info("#### 1. END - DETERMINE PACKET KEY");
		
		logger.info("#### 2. START - LOGIN");

		String imei = "111112222233333";
		String deviceType = "A";
		String pushToken = "google fcm device token value";
		
		AtalkMainLoginTest.login(
				userId
				, passwordPlain
				, imei
				, deviceType
				, pushToken);
		logger.info("#### 2. END - LOGIN");
		
		//////////////////////////////////////////////////////////////////////////////////////
		
		String updateDt = "2020-01-01 00:00:00";
		logger.info("#### 3. START - CHATHUB LIST, last update : {}", updateDt);  
		{
			String reqUrl =	AtalkMainPacketKeyTest.REQ_HOST_VAL + "/atalk/api/v1/chatHub/list";
			ListChathubRequest obj = new ListChathubRequest();
			obj.setUpdateDt(updateDt);
			responseData = AtalkPacketUtil.requestAtalkMessage(
					obj, ListChathubResponse.class, reqUrl);
			
			List<ChatHubListInfo> chathubListInfo = responseData.getChatHubListInfo();			
			ChatInfoLast lastChatObj = null;
			if (chathubListInfo != null) {
				for (ChatHubListInfo chatObj : chathubListInfo) {
					
					// 1. 대화방의 ENC 대화방키 를 내 개인키로 복호화
					String plainChathubKey =AtalkComplex.instance().decryptChathubKey(
							chatObj.getEncChathubKey());
					
					// 2. 파일 버퍼를 대화방 암호화키로 암호화.
					logger.info("### plainChathubKey : {}", plainChathubKey);
					try {
						logger.info("### message(enc) : {}", chatObj.getLastChat());
						lastChatObj = chatObj.getLastChat();						
						lastChatObj.setChatMessage(
								new String(
										AesEncDecComplex.decryptAesWithIv(
										AesEncDecComplex.hexToBytes(lastChatObj.getChatMessage())
										, plainChathubKey)));
						logger.info("### message(dec) : {}", lastChatObj.getChatMessage());
					} catch (Exception e) {
						// lastChatObj.setChatMessage("");
					}
				}
			}
			
			updateDt = responseData.getLastUpdateDt();
		}
		logger.info("#### 3. END  - CHATHUB LIST");
		logger.info("#### 3. START - CHATHUB LIST, last update : {}", updateDt);  
		{			
			// 두번째 목록 요청에서는 정보가 없음. 이미 증분 일시정보를 갱신된 값으로 요청했으므로
			// 클라이언트에서는 이정보를 로컬에 보관하고 있어야
			// 요청시 이 updateDt 로 요청하면, 로그인시마다 대화이력이 없을 경우 데이타를 주지 않는다.
			// 
			String reqUrl =	AtalkMainPacketKeyTest.REQ_HOST_VAL + "/atalk/api/v1/chatHub/list";
			ListChathubRequest obj = new ListChathubRequest();
			obj.setUpdateDt(updateDt);
			ListChathubResponse responseData2 = AtalkPacketUtil.requestAtalkMessage(
					obj, ListChathubResponse.class, reqUrl);
			List<ChatHubListInfo> chathubListInfo = responseData2.getChatHubListInfo();			
			ChatInfoLast lastChatObj = null;
			if (chathubListInfo != null) {
				for (ChatHubListInfo chatObj : chathubListInfo) {
					String plainChathubKey =AtalkComplex.instance().decryptChathubKey(
							chatObj.getEncChathubKey());
					logger.info("### plainChathubKey : {}", plainChathubKey);
					try {
						lastChatObj = chatObj.getLastChat();
						logger.info("### message(enc) : {}", lastChatObj.getChatMessage());
												
						lastChatObj.setChatMessage(
								new String(
										AesEncDecComplex.decryptAesWithIv(
										AesEncDecComplex.hexToBytes(lastChatObj.getChatMessage())
										, plainChathubKey)));
						logger.info("### message(dec) : {}", lastChatObj.getChatMessage());
					} catch (Exception e) {
						// lastChatObj.setChatMessage("");
					}
				}
			}
		}
		logger.info("#### 3. END  - CHATHUB LIST");
		return responseData;
	}
}
