package com.mutecsoft.atalk.logic;

import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;

import com.mutecsoft.atalk.logic.inf.InfAtalkDigitalSign;
import com.mutecsoft.atalk.logic.model.digitalsign.PacketKeySeed;
import com.mutecsoft.atalk.logic.model.digitalsign.PacketKeySignature;
import com.mutecsoft.atalk.logic.util.DigitalSignComplex;

public class AtalkDigitalSignImpl implements InfAtalkDigitalSign {

	@Override
	public PacketKeySeed generatePacketKeySeed() {
		PacketKeySeed pkt = new PacketKeySeed();
		String signingMessagePlain = DigitalSignComplex.generateSigningMessage(32);
		pkt.setSeedValue(signingMessagePlain);
		return pkt;
	}

	@Override
	public PacketKeySignature generatePacketSignature(String packetKeySeedValue, RSAPrivateKey privateKey,
			RSAPublicKey pubKey) throws Exception {
		PacketKeySignature signatureData = new PacketKeySignature(packetKeySeedValue);
		String signatureValue = DigitalSignComplex.generateSignature(
				packetKeySeedValue, privateKey, pubKey);
		signatureData.setSignature(signatureValue);
		return signatureData;
	}
}
