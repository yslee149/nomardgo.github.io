package com.mutecsoft.atalk.logic.test;

import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mutecsoft.atalk.logic.AtalkComplex;
import com.mutecsoft.atalk.logic.model.AtalkDataModelAll;
import com.mutecsoft.atalk.logic.model.AtalkPacketBase;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.logic.model.user.SearchUserRequest;
import com.mutecsoft.atalk.logic.model.user.SearchUserResponse;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class AtalkMainSearchUserTest {

	private static final Logger logger = LoggerFactory.getLogger(AtalkMainSearchUserTest.class);

	public static void main(String [] args) throws Exception {
		
		logger.info("#### 1. START - DETERMINE PACKET KEY");
		AtalkMainPacketKeyTest packetKeyTestObj = new AtalkMainPacketKeyTest();
		packetKeyTestObj.determinePacketKey();
		logger.info("#### 1. END - DETERMINE PACKET KEY");
		
		logger.info("#### 2. START - LOGIN");
		String userId = "user1003@aaa.com";
		String passwordPlain = "111111";
		String imei = "111112222233333";
		String deviceType = "A";
		String pushToken = "google fcm device token value";
		
		AtalkMainLoginTest.login(
				userId
				, passwordPlain
				, imei
				, deviceType
				, pushToken);
		logger.info("#### 2. END - LOGIN");

		logger.info("#### 3. START - SEARCH USER");
		String searchWord = "user7";
		searchUser(searchWord);
		logger.info("#### 3. END - SEARCH USER");
		
	}

	/**
	 * 
	 * 
	 * @param searchName
	 * @throws Exception
	 */
	private static void searchUser(String searchName) throws Exception {
		
		Long amigoSetNo = 0L;
		String url1 = AtalkMainPacketKeyTest.REQ_HOST_VAL + "/atalk/api/v1/search/user";
		{
			SearchUserRequest reqObj = new SearchUserRequest();
			reqObj.setSearchWord(searchName);
			
			AtalkDataModelAll secureModel = new AtalkDataModelAll();
			secureModel.setSecureModel(
					AtalkComplex.instance().toEncPacket(reqObj));
			logger.info("############# 1. client -> server : search user");
			String json = AtalkComplex.toPacketData(secureModel);
			logger.info("## REQDATA : {}", json);
			
			OkHttpClient client = new OkHttpClient().newBuilder()
					.connectTimeout(40, TimeUnit.SECONDS)  // Connection timeout
		            .readTimeout(40, TimeUnit.SECONDS)     // Read timeout
		            .writeTimeout(40, TimeUnit.SECONDS)    // Write timeout
		            .build();
			
			MediaType jsonMediaType = MediaType.get("application/json; charset=utf-8");
			RequestBody body = RequestBody.Companion.create(json, jsonMediaType);
			
			////////// ENCRYPT ACCESS TOKEN
			String encJwtHexToken = AtalkComplex.instance().generateEncAccessToken();
			// encJwtHexToken = jwtToken;
			logger.info("### access token(enchex) : {}", encJwtHexToken);
			////////// ENCRYPT ACCESS TOKEN
			Request request = new Request.Builder()
					.url(url1)
					.addHeader("Authorization", "Bearer " + encJwtHexToken) // Add JWT token here
					.post(body)
					.build();
			try (Response response = client.newCall(request).execute()) {
				if (response.isSuccessful()) {
					String responseJson = response.body().string();
					logger.info("Response: http code : {}, value : {}", 
							response.code()
							, responseJson);
					SecureDataModel respObj = SecureDataModel.fromBuffer(responseJson);
				
					final SearchUserResponse responseData = SecureDataModel.fromEncHexBuffer(respObj.getData()
							, AtalkComplex.instance().getPACKET_KEY()
							, SearchUserResponse.class);
					logger.info("### RESP DATA : {}",
							AtalkPacketBase.printAllFields(responseData));
					logger.info("#### RESP JSON : {}", responseData.toJson());
					
				} else {
					logger.error("Error: " + response.code());
					logger.error("@@@@@@@@@ SIGNUP ERR CASE 1");
					System.exit(1);
				}
			} catch (Exception e) {
				logger.error("@@@@@@@@@ SIGNUP ERR CASE 2 : {}", e);
				System.exit(2);
			}
		}
	}
	
}
