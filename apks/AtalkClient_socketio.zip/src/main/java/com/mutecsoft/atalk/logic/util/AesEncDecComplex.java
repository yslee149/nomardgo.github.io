package com.mutecsoft.atalk.logic.util;

import java.security.SecureRandom;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;
 
/**
 * @PackageName com.mutecsoft.atalk.logic.util
 * @fileName	AesEncDecComplex.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description : 
 * <pre>
 * 
 * </pre>
 */
public class AesEncDecComplex {
	private static final String ALGORITHM = "AES";
	private static final String TRANSFORMATION_AES_GCM_NOPADDING = "AES/GCM/NoPadding";
	private static final String TRANSFORMATION_AES_CTR_NOPADDING = "AES/CTR/NoPadding";
	
	private static final int AES_KEY_SIZE = 256;  // Key size
	private static final int IV_SIZE = 12;        // 12 bytes for GCM recommended
	private static final int TAG_LENGTH = 128;    // Authentication tag length in bits

	// Generate a 256-bit AES key
	public static SecretKey generateAESKey() throws Exception {
		KeyGenerator keyGenerator = KeyGenerator.getInstance(ALGORITHM);
		keyGenerator.init(AES_KEY_SIZE);
		return keyGenerator.generateKey();
	}

	// Generate a random IV
	public static byte[] generateIV() {
		byte[] iv = new byte[IV_SIZE];
		new SecureRandom().nextBytes(iv);
		return iv;
	}

	// Encrypt a string using AES-256 with IV
	private static String encrypt(String plainText, SecretKey key, byte[] iv) throws Exception {
		Cipher cipher = Cipher.getInstance(TRANSFORMATION_AES_GCM_NOPADDING);
		GCMParameterSpec parameterSpec = new GCMParameterSpec(TAG_LENGTH, iv);
		cipher.init(Cipher.ENCRYPT_MODE, key, parameterSpec);
		
		byte[] encryptedBytes = cipher.doFinal(plainText.getBytes());
		
		// String encoded = Base64.getEncoder().encodeToString(encryptedBytes);
		return Base64.getEncoder().encodeToString(encryptedBytes);
	}

	// Decrypt a string using AES-256 with IV
	private static String decrypt(String encryptedText, SecretKey key, byte[] iv) throws Exception {
		Cipher cipher = Cipher.getInstance(TRANSFORMATION_AES_GCM_NOPADDING);
		GCMParameterSpec parameterSpec = new GCMParameterSpec(TAG_LENGTH, iv);
		cipher.init(Cipher.DECRYPT_MODE, key, parameterSpec);
		
//		byte[] decodedBytes = Base64.decodeBase64(encryptedText);
//		byte[] decryptedBytes = cipher.doFinal(decodedBytes);
//		
		
		byte[] decodedBytes = Base64.getDecoder().decode(encryptedText);
		byte[] decryptedBytes = cipher.doFinal(decodedBytes);
		return new String(decryptedBytes);
	}
	

	/**
	 * Convert hex string to SecretKey
	 * 
	 * @param hexKey
	 * @param algorithm
	 * @return
	 */
	private static SecretKey hexStringToSecretKey(String hexKey, String algorithm) {
		byte[] decodedKey = hexToBytes(hexKey);
		return new SecretKeySpec(decodedKey, algorithm);
	}


	/**
	 * 
	 * @param hex
	 * @return
	 */
	public static byte[] hexToBytes(String hex) {
		int len = hex.length();
		byte[] data = new byte[len / 2];
		for (int i = 0; i < len; i += 2) {
			data[i / 2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4)
					+ Character.digit(hex.charAt(i + 1), 16));
		}
		return data;
	}

	
	////////////////////////////// USE BELOW => TRANSFORMATION_AES_CTR_NOPADDING algorithm ///////////////
	
//
//	/**
//	 * 
//	 * @param plainBuffer
//	 * @param key
//	 * @param iv
//	 * @return
//	 * @throws Exception
//	 */
//	public static byte[] encrypt(byte[] plainText, SecretKey key, byte[] iv) throws Exception {
//		Cipher cipher = Cipher.getInstance(TRANSFORMATION_AES_CTR_NOPADDING);
//		cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(iv));
//		return cipher.doFinal(plainText);
//	}
//
//	/**
//	 * 
//	 * @param cipherText
//	 * @param key
//	 * @param iv
//	 * @return
//	 * @throws Exception
//	 */
//	public static byte[] decrypt(byte[] cipherText, SecretKey key, byte[] iv) throws Exception {
//		Cipher cipher = Cipher.getInstance(TRANSFORMATION_AES_CTR_NOPADDING);
//		cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(iv));
//		return cipher.doFinal(cipherText);
//	}

	/**
	 * 
	 * @param plainText
	 * @param hexKey
	 * @param hexIv
	 * @return
	 * @throws Exception
	 */
	public static byte[] encryptAesCtr(byte[] plainText, String hexKey, String hexIv) throws Exception {
		Cipher cipher = Cipher.getInstance(TRANSFORMATION_AES_CTR_NOPADDING);
		
		SecretKey key = hexStringToSecretKey(hexKey, "AES");
		byte [] iv = hexToBytes(hexIv);
		cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(iv));
		return cipher.doFinal(plainText);
	}

	/**
	 * 
	 * @param cipherText
	 * @param hexKey
	 * @param hexIv
	 * @return
	 * @throws Exception
	 */
	public static byte[] decryptAesCtr(byte[] cipherText, String hexKey, String hexIv) throws Exception {
		Cipher cipher = Cipher.getInstance(TRANSFORMATION_AES_CTR_NOPADDING);
		
		SecretKey key = hexStringToSecretKey(hexKey, "AES");
		byte [] iv = hexToBytes(hexIv);
		cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(iv));
		return cipher.doFinal(cipherText);
	}
	
	
//	/**
//	 * 
//	 * @param plainText
//	 * @param hexKey
//	 * @param hexIv
//	 * @return
//	 * @throws Exception
//	 */
//	public static byte[] encryptAesCtrWithIv(byte[] plainText, String hexKey, String hexIv) throws Exception {
//		Cipher cipher = Cipher.getInstance(TRANSFORMATION_AES_CTR_NOPADDING);
//		
//		SecretKey key = hexStringToSecretKey(hexKey, "AES");
//		byte [] iv = hexToBytes(hexIv);
//		cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(iv));
//		byte [] encBuffer = cipher.doFinal(plainText);
//		
//		return concatArrays(encBuffer, iv);
//	}

	/**
	 * 
	 * @param cipherText
	 * @param hexKey
	 * @return
	 * @throws Exception
	 */
	public static byte[] decryptAesCtrWithIv(byte[] cipherText, String hexKey) throws Exception {
		Cipher cipher = Cipher.getInstance(TRANSFORMATION_AES_CTR_NOPADDING);
		
		SecretKey key = hexStringToSecretKey(hexKey, "AES");
		byte [] cipherBuffer = Arrays.copyOfRange(cipherText, 0, cipherText.length - 16);
		byte [] iv 			 = Arrays.copyOfRange(cipherText, cipherText.length - 16, cipherText.length);
		cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(iv));
		return cipher.doFinal(cipherBuffer);
	}

	///////////////////////////
	

	/**
	 * 
	 * 
	 * @param plainText
	 * @param hexKey
	 * @return
	 * @throws Exception
	 */
	public static byte[] encryptAesCtrWithRandomIv(byte[] plainText, String hexKey) throws Exception {
		Cipher cipher = Cipher.getInstance(TRANSFORMATION_AES_CTR_NOPADDING);

		String hexIv = RandomHexString.genSecureRandomHex(32);
		SecretKey key = hexStringToSecretKey(hexKey, "AES");
		byte [] iv = hexToBytes(hexIv);
		cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(iv));
		byte [] encBuffer = cipher.doFinal(plainText);
		
		return concatArrays(encBuffer, iv);
	}

	/**
	 * 
	 * @param cipherText
	 * @param hexKey
	 * @return
	 * @throws Exception
	 */
	public static byte[] decryptAesCtrWithRandomIv(byte[] cipherText, String hexKey) throws Exception {
		Cipher cipher = Cipher.getInstance(TRANSFORMATION_AES_CTR_NOPADDING);
		
		SecretKey key = hexStringToSecretKey(hexKey, "AES");
		byte [] cipherBuffer = Arrays.copyOfRange(cipherText, 0, cipherText.length - 16);
		byte [] iv 			 = Arrays.copyOfRange(cipherText, cipherText.length - 16, cipherText.length);
		cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(iv));
		return cipher.doFinal(cipherBuffer);
	}
	
    public static byte[] concatArrays(byte[] array1, byte[] array2) {
        byte[] result = new byte[array1.length + array2.length];
        System.arraycopy(array1, 0, result, 0, array1.length);
        System.arraycopy(array2, 0, result, array1.length, array2.length);
        return result;
    }
    
    public static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02X", b));
        }
        return sb.toString();
    }
    
	public static void main(String[] args) throws Exception {
		{
			String hexKey = "b62e85041ad6d2ddfa4863b21f9245ffd9ca7751ae5840cb3dbff6e047484e8f";
			String ivHex = "dd3b08b9afcd1509a622b882f73477f8";
			String plainBuffer = "abcdefg123456789";
			
			byte [] encBuffer = AesEncDecComplex.encryptAesCtr(plainBuffer.getBytes(), hexKey, ivHex);
			System.out.println("Encrypted (Hex): " + bytesToHex(encBuffer));
			
			byte [] decBuffer = AesEncDecComplex.decryptAesCtr(encBuffer, hexKey, ivHex);
			System.out.println("Decrypted (Hex): " + bytesToHex(decBuffer));
			System.out.println("Decrypted : " + new String(decBuffer));
		}
		System.out.println("###################################################################");
		System.out.println("###################################################################");
		/////////////////// USE THIS IN THE CHAT
		{
			System.out.println("##### aes256 with counter iv, including IV data in ciphered data.");
			String hexKey = "b62e85041ad6d2ddfa4863b21f9245ffd9ca7751ae5840cb3dbff6e047484e8f";
			String plainBuffer = "abcdefg12345678922222";
			
			byte [] encBuffer = AesEncDecComplex.encryptAesCtrWithRandomIv(plainBuffer.getBytes(), hexKey);
			System.out.println("Encrypted (Hex): " + bytesToHex(encBuffer));
			
			byte [] decBuffer = AesEncDecComplex.decryptAesCtrWithIv(encBuffer, hexKey);
			System.out.println("Decrypted (Hex): " + bytesToHex(decBuffer));
			System.out.println("Decrypted : " + new String(decBuffer));
		}
		{
			// Generate a 256-bit AES key
			SecretKey secretKey = generateAESKey();
			
			// Generate a random IV
			byte[] iv = generateIV();
			
			String originalText = "Hello, AES-256 with IV!";
			System.out.println("Original Text: " + originalText);
	
			// Encrypt the text
			String encryptedText = encrypt(originalText, secretKey, iv);
			System.out.println("Encrypted Text: " + encryptedText);
	
			// Decrypt the text
			String decryptedText = decrypt(encryptedText, secretKey, iv);
			System.out.println("Decrypted Text: " + decryptedText);
		}
 	}
	
	/**
	 * 
	 * 
	 * @param plainText
	 * @param hexKey
	 * @return
	 * @throws Exception
	 */
	public static byte[] encryptAesWithRandomIv(byte[] plainText, String hexKey) throws Exception {
		Cipher cipher = Cipher.getInstance(TRANSFORMATION_AES_CTR_NOPADDING);

		String hexIv = RandomHexString.genSecureRandomHex(32);
		SecretKey key = hexStringToSecretKey(hexKey, "AES");
		byte [] iv = hexToBytes(hexIv);
		cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(iv));
		byte [] encBuffer = cipher.doFinal(plainText);
		
		return concatArrays(encBuffer, iv);
	}


	/**
	 * 
	 * @param cipherText
	 * @param hexKey
	 * @return
	 * @throws Exception
	 */
	public static byte[] decryptAesWithIv(byte[] cipherText, String hexKey) throws Exception {
		Cipher cipher = Cipher.getInstance(TRANSFORMATION_AES_CTR_NOPADDING);
		
		SecretKey key = hexStringToSecretKey(hexKey, "AES");
		byte [] cipherBuffer = Arrays.copyOfRange(cipherText, 0, cipherText.length - 16);
		byte [] iv 			 = Arrays.copyOfRange(cipherText, cipherText.length - 16, cipherText.length);
		cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(iv));
		return cipher.doFinal(cipherBuffer);
	}
}
