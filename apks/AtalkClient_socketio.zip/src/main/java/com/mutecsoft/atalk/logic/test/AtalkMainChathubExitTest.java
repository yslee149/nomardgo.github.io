package com.mutecsoft.atalk.logic.test;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mutecsoft.atalk.logic.AtalkComplex;
import com.mutecsoft.atalk.logic.model.chathub.ChatHubListInfo;
import com.mutecsoft.atalk.logic.model.chathub.ExitChathubRequest;
import com.mutecsoft.atalk.logic.model.chathub.ExitChathubResponse;
import com.mutecsoft.atalk.logic.model.chathub.ListChathubResponse;
import com.mutecsoft.atalk.logic.util.AtalkPacketUtil;

/**
 * 대화방 나감
 * 
 * 
 */
public class AtalkMainChathubExitTest {

	private static final Logger logger = LoggerFactory.getLogger(AtalkMainChathubExitTest.class);

	public static void main(String [] args) throws Exception {

		final String userId = "user1003@aaa.com";
		final String passwordPlain = "111111";
		
		// 로그인 후 대화방 목록 조회
		ListChathubResponse responseChatListData  = AtalkMainChathubListTest.getChatHubInfoList(
				userId, passwordPlain);
		
		List<ChatHubListInfo> chatHubList = responseChatListData.getChatHubListInfo();
		Long targetChathubNo = null;
		///////////////////////////////////////////////////////////
		for (ChatHubListInfo chathubObj : chatHubList) {
			
			if (chathubObj.getJoinYn().equals("Y")) {
				targetChathubNo = chathubObj.getChathubNo();
				break;
			}
		}
		// 대화방 나감
		logger.info("#### 3. START - EXIT USER FROM CHATHUB INFO, chathub no : {}, user no : {}", 
				targetChathubNo, AtalkComplex.instance().getUserInfo().getUserNo());
		{
			String reqUrl =	AtalkMainPacketKeyTest.REQ_HOST_VAL + "/atalk/api/v1/chatHub/exit";
			ExitChathubRequest obj = new ExitChathubRequest();
			obj.setChathubNo(targetChathubNo);

			/////////////////////////////////////////////////////////////////////////
			ExitChathubResponse responseData = AtalkPacketUtil.requestAtalkMessage(
					obj, ExitChathubResponse.class, reqUrl);
			
			Long chathubNo = responseData.getChathubNo();
			Long meNo = responseData.getUserNo();
			
			logger.info("#### (RES) EXIT USER FROM CHATHUB INFO, chathubNo: {}, meNo : {}",
					chathubNo, meNo);
		}
		logger.info("#### 3. END - EXIT USER FROM CHATHUB INFO : {}, user no : {}",
				targetChathubNo, AtalkComplex.instance().getUserInfo().getUserNo());
		
	}


	
	static String chatMessage = "최근 인터넷의 빠른 성장과 전자출판으로 인해 정보에 접근하는 방법이 상당히 변화하고 있다. 이와 함께,"
			+ "디지털 문서에서 적합한 정보를 결정하고 효율적으로 추출할 필요가 있을 것이다. 이 연구는 디지털 문서에서 여러 "
			+ "가지 정보를 추출하기 위해 템플릿 마이닝이 사용될 수 있음을 제시하고, 참조연결시스템과 관련된 연구를 고찰하였다. "
			+ "또한 실제적으로 논문 샘플을 분석한 결과를 이용하여 참조정보를 위한 템플릿을 구축하고, 이 템플릿을 이용하여 수작업으로"
			+ " 논문 샘플을 테스트한 결과, 템플릿 마이닝의 이용은 인용 데이터베이스를 자동으로 만들 수 있는 가능성을 보여주었다."
			+ ""
			+ "Recently, the way information is accessed has changed significantly because of "
			+ "the rapid growth of the Internet and a move toward electronic publishing. With "
			+ "that condition, there will be a need to efficiently determine and extract relevant "
			+ "information from digital documents. This study has proposed that template mining can "
			+ "be used for extracting different kinds of information from digital documents, and "
			+ "described research of reference linking system and then built template for citation information"
			+ " using analysis result of sample articles. Also, this study has shown the potential of "
			+ "template mining to automatically create citation databases."
			+ "최근 인터넷의 빠른 성장과 전자출판으로 인해 정보에 접근하는 방법이 상당히 변화하고 있다. 이와 함께,"
			+ "디지털 문서에서 적합한 정보를 결정하고 효율적으로 추출할 필요가 있을 것이다. 이 연구는 디지털 문서에서 여러 "
			+ "가지 정보를 추출하기 위해 템플릿 마이닝이 사용될 수 있음을 제시하고, 참조연결시스템과 관련된 연구를 고찰하였다. "
			+ "또한 실제적으로 논문 샘플을 분석한 결과를 이용하여 참조정보를 위한 템플릿을 구축하고, 이 템플릿을 이용하여 수작업으로"
			+ " 논문 샘플을 테스트한 결과, 템플릿 마이닝의 이용은 인용 데이터베이스를 자동으로 만들 수 있는 가능성을 보여주었다."
			+ ""
			+ "Recently, the way information is accessed has changed significantly because of "
			+ "the rapid growth of the Internet and a move toward electronic publishing. With "
			+ "that condition, there will be a need to efficiently determine and extract relevant "
			+ "information from digital documents. This study has proposed that template mining can "
			+ "be used for extracting different kinds of information from digital documents, and "
			+ "described research of reference linking system and then built template for citation information"
			+ " using analysis result of sample articles. Also, this study has shown the potential of "
			+ "template mining to automatically create citation databases.";
}
