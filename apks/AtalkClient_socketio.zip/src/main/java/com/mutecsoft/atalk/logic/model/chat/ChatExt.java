package com.mutecsoft.atalk.logic.model.chat;

import java.io.Serializable;

/**
 * @PackageName com.mutecsoft.atalk.logic.model.chat
 * @fileName	ChatExt.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description : 확장 대화
 * <pre>
 * 
 * </pre>
 */
public class ChatExt implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -245976247312274504L;

	private String chatContent;
	

	public String getChatContent() {
		return chatContent;
	}

	public void setChatContent(String chatContent) {
		this.chatContent = chatContent;
	}
}

