package com.mutecsoft.atalk.logic.test;

import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mutecsoft.atalk.logic.AtalkComplex;
import com.mutecsoft.atalk.logic.model.AtalkDataModelAll;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.logic.model.digitalsign.PacketKeySeed;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class AtalkMainPacketKeyTest {

	private static final Logger logger = LoggerFactory.getLogger(AtalkMainPacketKeyTest.class);

	public static String REQ_HOST_VAL = "http://chillaxmax.kr:9095";
	// static String REQ_HOST_VAL = "http://localhost:9095";
	/**
	 * 
	 * @param args
	 * @throws Exception
	 */
	public static void main(String [] args) throws Exception {
		
		AtalkMainPacketKeyTest packetKeyTestObj = new AtalkMainPacketKeyTest();
		packetKeyTestObj.determinePacketKey();
	}

	/**
	 * 
	 * @throws Exception
	 */
	public void determinePacketKey() throws Exception {
		String determinePacketKeyUrl1 = REQ_HOST_VAL + "/atalk/api/v1/digitalSign/seedvalue";
		String determinePacketKeyUrl2 = REQ_HOST_VAL + "/atalk/api/v1/digitalSign/doSign";
		
		String packetKeySeedValue = "";
		{
			logger.info("############# 1. client -> server : packageKeySeed value");
			AtalkDataModelAll secureModel = AtalkComplex.instance().generatePacketKeySeed();
			OkHttpClient client = new OkHttpClient().newBuilder()
							.connectTimeout(40, TimeUnit.SECONDS)  // Connection timeout
				            .readTimeout(40, TimeUnit.SECONDS)     // Read timeout
				            .writeTimeout(40, TimeUnit.SECONDS)    // Write timeout
				            .build();
			
			String json = AtalkComplex.toPacketData(secureModel);
			
			logger.info("## REQDATA : {}", json);
			
			MediaType jsonMediaType = MediaType.get("application/json; charset=utf-8");
			RequestBody body = RequestBody.Companion.create(json, jsonMediaType);
			Request request = new Request.Builder()
					.url(determinePacketKeyUrl1)
					.post(body)
					.build();
			try (Response response = client.newCall(request).execute()) {
				if (response.isSuccessful()) {
					logger.info("Response: http code : {}, value : {}",
							response.code()
							, response.body().string());
					AtalkComplex.instance().setPacketSeedValue(((PacketKeySeed)secureModel.getAtalkPacketBase()).getSeedValue());
					packetKeySeedValue = AtalkComplex.instance().getPacketSeedValue();
					
				} else {
					logger.error("Error: " + response.code());
					logger.error("@@@@@@@@@ DIGITALSIGN HALTED CASE 1");
					System.exit(1);
				}
			} catch (Exception e) {
				logger.error("@@@@@@@@@ DIGITALSIGN HALTED CASE 2 : {}", e);
				System.exit(2);
			}
		}
		{
			logger.info("############# 2. client -> server : digital sigin");
			AtalkDataModelAll secureModel = AtalkComplex.instance().generateSignature();
			OkHttpClient client = new OkHttpClient();
			String json = AtalkComplex.toPacketData(secureModel);
			
			logger.info("## REQDATA : {}", json);
			
			MediaType jsonMediaType = MediaType.get("application/json; charset=utf-8");
			RequestBody body = RequestBody.Companion.create(json, jsonMediaType);
			Request request = new Request.Builder()
					.url(determinePacketKeyUrl2)
					.post(body)
					.build();
			try (Response response = client.newCall(request).execute()) {
				if (response.isSuccessful()) {
					// logger.info("Response: " + response.body().string());
					String responseBuffer = response.body().string();
					logger.info("Response: {}", responseBuffer);
					SecureDataModel responseModel = SecureDataModel.fromBuffer(responseBuffer);
					String PACKET_KEY = AtalkComplex.instance().determinePacketKey(responseModel);
					
					logger.info("########## SET PACKET KEY : {}", PACKET_KEY);
					
				} else {
					logger.error("Error: " + response.code());
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
