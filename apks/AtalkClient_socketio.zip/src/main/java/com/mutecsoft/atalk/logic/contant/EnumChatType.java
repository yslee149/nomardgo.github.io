package com.mutecsoft.atalk.logic.contant;

public enum EnumChatType {

	MESSAGE_GENERAL_TYPE("C"),
	MESSAGE_EXT_GENERAL_TYPE("E"),
	
	MESSAGE_FILE_TYPE("F"),
	MESSAGE_CANCELED_TYPE("R"), // 회수된 메시지
	
	MESSAGE_INFO_TYPE("I"),
	
	MESSAGE_SUB_IMAGE_TYPE("I"),
	MESSAGE_SUB_MOVIE_TYPE("V"),
	MESSAGE_SUB_GENFILE_TYPE("F"),
	
	MESSAGE_SUB_NEW_CHATHUB_OPEN_TYPE("N"),
	MESSAGE_SUB_INVITE_TO_CHATHUB_TYPE("I"),
	MESSAGE_SUB_EXIT_TO_CHATHUB_TYPE("E");
	
	private final String value;
	
	EnumChatType(final String newValue) {
		value = newValue;
	}
	
	public String getValue(){
		return value;
	}
}

