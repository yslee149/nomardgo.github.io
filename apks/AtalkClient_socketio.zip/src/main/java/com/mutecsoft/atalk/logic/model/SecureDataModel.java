package com.mutecsoft.atalk.logic.model;

import java.io.Serializable;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mutecsoft.atalk.logic.model.auth.UserLoginResponse;
import com.mutecsoft.atalk.logic.util.AesEncDecComplex;

/**
 * @PackageName com.mutecsoft.atalk.logic.model
 * @fileName	SecureDataModel.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description :
 * <pre>
 * 
 * </pre>
 */
public class SecureDataModel implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = -7029422274605777744L;
	

	protected static final ObjectMapper objectMapper = new ObjectMapper();
	
	
	public static int KEY_SEED_SIZE = 32;
	
	private String transactinId;
    private String data;
    
//    
//	public String getPacketSeedVal() {
//		return packetSeedVal;
//	}
//	public void setPacketSeedVal(String packetSeedVal) {
//		this.packetSeedVal = packetSeedVal;
//	}
	public String getTransactinId() {
		return transactinId;
	}
	public void setTransactinId(String transactinId) {
		this.transactinId = transactinId;
	}
	public String getData() {
		return data;
	}

	public String toJson() throws JsonProcessingException {
		return objectMapper.writeValueAsString(this);
	}
	/**
	 * extract key seed
	 * 
	 * @return
	 */
	public String extractKeySeed() {
		return data.substring(data.length() - SecureDataModel.KEY_SEED_SIZE);
	}
	
	/**
	 * extract secure data
	 * 
	 * @return
	 */
	public String extractData() {
		return data.substring(0, data.length() - SecureDataModel.KEY_SEED_SIZE);
	}
	
	/**
	 *
	 * @param data
	 * @param seedVal
	 */
	public void setData(String data, String seedVal) {
		this.data = String.format("%s%s", data, seedVal);
	}
	
	/**
	 *
	 * @param dataMore
	 */
	public void setDataAfter(String dataMore) {
		StringBuffer sb = new StringBuffer();
		sb.append(this.data);
		sb.append(dataMore);
		this.data = sb.toString();
	}
	
	/**
	 *
	 * @param dataMore
	 */
	public void setDataBefore(String dataMore) {
		StringBuffer sb = new StringBuffer();
		sb.append(dataMore);
		sb.append(this.data);
		this.data = sb.toString();
	}
	
	/**
	 * 
	 * @param data
	 */
	public void setData(String data) {
		this.data = data;
	}
	
	/**
	 * 
	 * @param jsonString
	 * @return
	 * @throws JsonMappingException
	 * @throws JsonProcessingException
	 */
	public static SecureDataModel fromBuffer(String jsonString) throws JsonMappingException, JsonProcessingException {
		SecureDataModel secureModel = objectMapper.readValue(jsonString, SecureDataModel.class);
		return secureModel;
	}
	
	/**
	 * 
	 * 
	 * @param <T>
	 * @param encryptHexBuffer
	 * @param packetKey
	 * @param clazz
	 * @return
	 * @throws Exception 
	 */
	public static <T extends AtalkPacketBase> T fromEncHexBuffer (
			String encryptHexBuffer
			, String packetKey
			, Class<T> clazz) throws Exception {
		byte [] encBytesBuffer = AesEncDecComplex.hexToBytes(encryptHexBuffer);
		byte [] decBuffer = AesEncDecComplex.decryptAesCtrWithIv(encBytesBuffer, packetKey);
		String decBuffString = new String(decBuffer);
		objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
	    return objectMapper.readValue(decBuffString, clazz);
	}
	
	/**
	 * json buffer
	 * 
	 * @param <T>
	 * @param encryptHexBuffer
	 * @param packetKey
	 * @param clazz
	 * @return
	 * @throws Exception 
	 */
	public static String fromEncHexBuffer (
			String encryptHexBuffer
			, String packetKey) throws Exception {
		byte [] encBytesBuffer = AesEncDecComplex.hexToBytes(encryptHexBuffer);
		byte [] decBuffer = AesEncDecComplex.decryptAesWithIv(encBytesBuffer, packetKey);
		String decBuffString = new String(decBuffer);
		return decBuffString;
	}
	
	public static void main(String [] args) throws JsonMappingException, JsonProcessingException {
		
		String val = "{\"transactinId\":\"739BB8B4053DCF7D\",\"error\":{\"code\":0,\"message\":\"\"},\"userNo\":50,\"userId\":\"user1003@aaa.com\",\"accessToken\":\"eyJhbGciOiJSUzI1NiJ9.eyJpc3MiOiJDQVNBUFAiLCJzdWIiOiJ1c2VyMTAwM0BhYWEuY29tIiwiZXhwIjoxNzMxOTgwNDA5LCJpYXQiOjE3MzE5Nzg2MDl9.KBr23yUcTz3UfCFevfKO1v5k1j7Ztz7ato8p2GhvOj2E1JV7TYRQnUDrKbJ2tZmAoCPTLDsxx15FjAkr_nCzjPsmnxclbFSOUtxMgd6PIKZ-K8HxrGnRooEaImc7pFHPlSLxcpho4HOiCuvqwnBVQXElI-8X2QC_aTZyMBYUyAE_zK0ugweB7pMhqT-OQgXdNXIVNagit57mG3oKD-IXTnRaHf81xt3vEcDPfQMLTNBo_SqIiPrVLfDkBzeMo7CICta7nADhwbGKLkxLnAmnYvKRW4MgM2y9n7TzXE8FClQggmlyPfQ5_fAI1YZQjzGd4stn797l8zKJgZMiLNaThw\",\"refreshToken\":\"eyJhbGciOiJSUzI1NiJ9.eyJpc3MiOiJDQVNBUFAiLCJzdWIiOiJ1c2VyMTAwM0BhYWEuY29tIiwiZXhwIjoxNzMyODQyNjA5LCJpYXQiOjE3MzE5Nzg2MDl9.IYK8UCCWwvrHjvrUcvcNtqpbzM5IbAfKj6_opbd_Vrsb7bji1xlQtgh2l69fRQC03uYChb_-XJMpqmu9iKL_4ueAtSQj32q4xXwKZzcsTqD6UyNecNJ2hIcO_apzMu0Yass9S8TieNvWsFVG-GEQldiddTJWJdvb6_vgUm6eQV1rwmbm09dA_4BTG2bOeOl9Nm4RZlrouo-KK5lat-07HrVQ-kABBiMb-fikw2hD-NMvfi-iMy3JOtu_wmmPnC3LtFlCJ6FRwP2nflh4VmxucMzcJmD_m2ePEmzcgh2h2pHl1cxo7HzyqfNPuK00BqWJTCeJez9dfgHKGWx895EQLw\",\"firstLogin\":\"N\",\"serverPublicKey\":\"MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAxu9YsqaJpf3pEZgflLHRraUe08COmiZMVjd9tRT1AP1obc0xkNUT4htF0s1+vbydk8as8zA0KffG9kjtfA69oa7BPH3oFkxxvN/eN44hmdDNdgPkxj3GswNcg+yE2KXl4uYr2HKH/IpewR90RW/oqCf5pJDODAPFgUmaZhY3XwZEev1DqUZnPjPb5s5pOzi4vWxzYC+7TbxC6B2IPmpIaKhzyqZuLP7VCXgZxxTO8cY93QE5zP/zWnwGUwiWBqTMGOklfYOek31j3/SbMB3BtqDL6efckDJzqVTgrUkqG9gyUjDwJm9nKiE2dQ9bmatmeI7H6+EVjg/D5Fc8AlUVNaOPXrVEyk0N6jU/Dy1DMRkFr56ad29ywxCJny9Z3KxPtSB99zyUvm3I8DVPNQCzxFbit0nx7ZsI6XmpKl7PIHtB3ZR1yNbh9CfBB8Rt60/8bXBH0p1z9KIZ9qC+EhOL0rAxHj92somOme6Zlu5z5i1pr4uw84lgdvR+6eKA05N1wnUrVfbiLsf7Y/ecsDUppqVAoFNusMjDibGFS4LVcsEUs5VGXdr9D0cqY19mFjyckhl3IQdw7+B5DdZEFiAFZ1T4tLOti4aDgpsORNMdkmoXCGHEearH/52tTe6C0FG9PpJCTOvuuQ/jspELMpGN5rZoteMWvgDhHCYp9wRyNkUCAwEAAQ==\"}";

		ObjectMapper tobjectMapper = new ObjectMapper();
		UserLoginResponse obj = objectMapper.readValue(val, UserLoginResponse.class);
		System.out.println("aaa");
	}
}
