package com.mutecsoft.atalk.logic.model.user;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.mutecsoft.atalk.logic.model.AtalkPacketBase;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.logic.util.AesEncDecComplex;

/**
 * @PackageName com.mutecsoft.atalk.logic.model.auth
 * @fileName	DeleteUserRequest.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description :  사용자 삭제 요청
 * <pre>
 * 
 * </pre>
 */
public class DeleteUserRequest extends AtalkPacketBase {

	/**
	 * 
	 */
	private static final long serialVersionUID = -245976247312274504L;
    
	private String signUptoken;
    private Long userNo;
    
	public String getSignUptoken() {
		return signUptoken;
	}
	public void setSignUptoken(String signUptoken) {
		this.signUptoken = signUptoken;
	}
	public Long getUserNo() {
		return userNo;
	}
	public void setUserNo(Long userNo) {
		this.userNo = userNo;
	}
	@Override
	public String toJson() throws JsonProcessingException {
		return objectMapper.writeValueAsString(this);
	}
	@Override
	public SecureDataModel toFinalModel() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public SecureDataModel toFinalModel(String packetKey) throws Exception {
		if (packetKey == null || packetKey.equals("")) {
			return null;
		}
		SecureDataModel secureModel = new SecureDataModel();
		secureModel.setTransactinId(this.getTransactinId());
		String jsonData = this.toJson();
		
		byte [] encBuffer = AesEncDecComplex.encryptAesCtrWithRandomIv(
				jsonData.getBytes(), packetKey);
		String hexEncString = AesEncDecComplex.bytesToHex(encBuffer);

		secureModel.setData(hexEncString);
		return secureModel;
	}

	@Override
	public SecureDataModel toFinalModel(String seedValue, String packetKey) throws Exception {
		if (packetKey == null || packetKey.equals("")) {
			return null;
		}
		if (seedValue == null || seedValue.equals("")) {
			return null;
		}
		SecureDataModel secureModel = new SecureDataModel();
		secureModel.setTransactinId(this.getTransactinId());
		String jsonData = this.toJson();
		
		byte [] encBuffer = AesEncDecComplex.encryptAesCtrWithRandomIv(
				jsonData.getBytes(), packetKey);
		String hexEncString = AesEncDecComplex.bytesToHex(encBuffer);

		secureModel.setData(hexEncString);
		secureModel.setDataAfter(seedValue);
		
		return secureModel;
	}
}
