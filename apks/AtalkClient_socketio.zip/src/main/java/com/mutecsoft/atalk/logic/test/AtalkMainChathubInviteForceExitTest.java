package com.mutecsoft.atalk.logic.test;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mutecsoft.atalk.logic.AtalkComplex;
import com.mutecsoft.atalk.logic.model.chathub.ChatHubListInfo;
import com.mutecsoft.atalk.logic.model.chathub.InviteChathubRequest;
import com.mutecsoft.atalk.logic.model.chathub.InviteChathubResponse;
import com.mutecsoft.atalk.logic.model.chathub.KickOutChathubRequest;
import com.mutecsoft.atalk.logic.model.chathub.KickOutChathubResponse;
import com.mutecsoft.atalk.logic.model.chathub.ListChathubResponse;
import com.mutecsoft.atalk.logic.util.AtalkPacketUtil;

/**
 * 대화방 초대 후 강퇴
 * 
 * 
 */
public class AtalkMainChathubInviteForceExitTest {

	private static final Logger logger = LoggerFactory.getLogger(AtalkMainChathubInviteForceExitTest.class);

	public static void main(String [] args) throws Exception {

		final String userId = "user1003@aaa.com";
		final String passwordPlain = "111111";
		
		// 로그인 후 대화방 목록 조회
		ListChathubResponse responseChatListData  = AtalkMainChathubListTest.getChatHubInfoList(
				userId, passwordPlain);
		
		List<ChatHubListInfo> chatHubList = responseChatListData.getChatHubListInfo();
		Long targetChathubNo = null;
		
		Long targetUserNoInvited = 9L; // 초대 후 강퇴
		
		
		///////////////////////////////////////////////////////////
		ChatHubListInfo targetChathubInfo = null; // 파일대화 입력할 대화방 정보
		///////////////////////////////////////////////////////////
		for (ChatHubListInfo chathubObj : chatHubList) {
			
			if (chathubObj.getJoinYn().equals("Y")) {
				targetChathubNo = chathubObj.getChathubNo();
				targetChathubInfo = chathubObj;
				break;
			}
		}
		// 초대 후 강퇴
		logger.info("#### 3. START - INVITE USER TO CHATHUB INFO, chathub no : {}, user no : {}", 
				targetChathubNo, targetUserNoInvited);
		{
			String reqUrl =	AtalkMainPacketKeyTest.REQ_HOST_VAL + "/atalk/api/v1/chatHub/invite";
			InviteChathubRequest obj = new InviteChathubRequest();
			List<Long> invitedUserNoList = new ArrayList<Long>();
			invitedUserNoList.add(targetUserNoInvited);
			
	//		obj.setUserNo(AtalkComplex.instance().getUserInfo().getUserNo()); // ME
			obj.setChathubNo(targetChathubNo);
			obj.setInvitedUserNoList(invitedUserNoList);
			// enc 대화방 패킷키 복호화
//			String encChathubKey = targetChathubInfo.getEncChathubKey();
			
//			// 복호화된 대화방키
//			String decChathubKey = AtalkComplex.instance().decryptChathubKey(encChathubKey);
//			logger.info("#### CHATHUB KEY : {}", decChathubKey);
//			// 서버 public key 로 재암호화
//			String finalEncChathubKey = AtalkComplex.instance().encryptChathubKeyWithServerKey(decChathubKey);
//			obj.setEncPacketKey(finalEncChathubKey);
//			
			/////////////////////////////////////////////////////////////////////////
			InviteChathubResponse responseData = AtalkPacketUtil.requestAtalkMessage(
					obj, InviteChathubResponse.class, reqUrl);
			
			Long chathubNo = responseData.getChathubNo();
			List<Long> resInvitedUserNoList = responseData.getInvitedUserNoList();
			Long meNo = responseData.getUserNo();
			String invitedUserNameList = responseData.getInvitedUserNameList();
			
			logger.info("#### (RES) INVITE USER TO CHATHUB INFO, chathubNo: {}, meNo : {}, resInvitedUserNoList : {}, invitedUserNameList : {}",
					chathubNo, meNo, resInvitedUserNoList, invitedUserNameList);
			
		//	System.exit(0);
		}
		logger.info("#### 3. END - INVITE USER TO CHATHUB INFO, chathub no : {}, user no : {}",
				targetChathubNo, targetUserNoInvited);
		// 강퇴
		logger.info("#### 4. START - FORCE EXIT, chathub no : {}, user no : {}",
				targetChathubNo, targetUserNoInvited);
		{
			String reqUrl =	AtalkMainPacketKeyTest.REQ_HOST_VAL + "/atalk/api/v1/chatHub/forceExit";
			KickOutChathubRequest obj = new KickOutChathubRequest();
			List<Long> forExitUserNoList = new ArrayList<Long>();
			forExitUserNoList.add(targetUserNoInvited);		// 초대 후 다시 강퇴
			
			obj.setUserNo(AtalkComplex.instance().getUserInfo().getUserNo()); // ME
			obj.setChathubNo(targetChathubNo);
			obj.setKickedOutUserNoList(forExitUserNoList);
			
			/////////////////////////////////////////////////////////////////////////
			KickOutChathubResponse responseData = AtalkPacketUtil.requestAtalkMessage(
					obj, KickOutChathubResponse.class, reqUrl);
			
			Long chathubNo = responseData.getChathubNo();
			List<Long> resKickedOutUserNoList = responseData.getKickedOutUserNoList();
			Long meNo = responseData.getUserNo();
			String kickedOutUserNameList = responseData.getKickedOutUserList();
			
			logger.info("#### (RES) FORCE EXIT TO CHATHUB INFO, chathubNo : {}, meNo : {}, resKickedOutUserNoList : {}, kickedOutUserNameList : {}",
					chathubNo, meNo, resKickedOutUserNoList, kickedOutUserNameList);
		}
		logger.info("#### 4. STOP - FORCE EXIT, chathub no : {}, user no : {}",
				targetChathubNo, targetUserNoInvited);
	}
}
