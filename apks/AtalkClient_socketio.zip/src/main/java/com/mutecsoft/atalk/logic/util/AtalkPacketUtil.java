package com.mutecsoft.atalk.logic.util;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mutecsoft.atalk.logic.AtalkComplex;
import com.mutecsoft.atalk.logic.model.AtalkDataModelAll;
import com.mutecsoft.atalk.logic.model.AtalkPacketBase;
import com.mutecsoft.atalk.logic.model.SecureDataModel;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class AtalkPacketUtil {
	private static final Logger logger = LoggerFactory.getLogger(AtalkPacketUtil.class);

	/**
	 * invoke request
	 * 
	 * @param reqObj
	 * @return
	 * @throws Exception
	 */
	public static <R extends AtalkPacketBase> R
	requestAtalkMessage(Class<R> retClass, String url) throws Exception {
		R responseData = null;
		String url1 =	url;
		logger.info("############# 1. client -> server : send message");
		OkHttpClient client = new OkHttpClient().newBuilder()
				.connectTimeout(40, TimeUnit.SECONDS)  // Connection timeout
	            .readTimeout(40, TimeUnit.SECONDS)     // Read timeout
	            .writeTimeout(40, TimeUnit.SECONDS)    // Write timeout
	            .build();
		RequestBody emptyBody = RequestBody.create(new byte[0]);
	
		////////// ENCRYPT ACCESS TOKEN
		String encJwtHexToken = AtalkComplex.instance().generateEncAccessToken();
		// encJwtHexToken = jwtToken;
		logger.info("### access token(enchex) : {}", encJwtHexToken);
		////////// ENCRYPT ACCESS TOKEN
		Request request = new Request.Builder()
				.url(url1)
				.addHeader("Authorization", "Bearer " + encJwtHexToken) // Add JWT token here
				.post(emptyBody)
				.build();
		try (Response response = client.newCall(request).execute()) {
			if (response.isSuccessful()) {
				String responseJson = response.body().string();
				logger.info("Response: http code : {}, value : {}", 
						response.code()
						, responseJson);
				SecureDataModel respObj = SecureDataModel.fromBuffer(responseJson);
			
				responseData = SecureDataModel.fromEncHexBuffer(respObj.getData()
						, AtalkComplex.instance().getPACKET_KEY()
						, retClass);
				logger.info("### RESP DATA : {}",
						AtalkPacketBase.printAllFields(responseData));
				logger.info("#### RESP JSON : {}", responseData.toJson());
				
			} else {
				logger.error("Error: " + response.code());
				logger.error("@@@@@@@@@ ERR CASE 1");
			}
		} catch (Exception e) {
			logger.error("@@@@@@@@@ ERR CASE 2 : {}", e);
		}
		return responseData;
	}
	

	/**
	 * invoke request 인증없ㄴ이 요청
	 * 
	 * @param reqObj
	 * @return
	 * @throws Exception
	 */
	public static <R extends AtalkPacketBase> R
	requestAtalkMessageNoAuth(Class<R> retClass, String url) throws Exception {
		R responseData = null;
		String url1 =	url;
		logger.info("############# 1. client -> server : send message");
		OkHttpClient client = new OkHttpClient().newBuilder()
				.connectTimeout(40, TimeUnit.SECONDS)  // Connection timeout
	            .readTimeout(40, TimeUnit.SECONDS)     // Read timeout
	            .writeTimeout(40, TimeUnit.SECONDS)    // Write timeout
	            .build();
		RequestBody emptyBody = RequestBody.create(new byte[0]);
		////////// ENCRYPT ACCESS TOKEN
		Request request = new Request.Builder()
				.url(url1)
				.post(emptyBody)
				.build();
		try (Response response = client.newCall(request).execute()) {
			if (response.isSuccessful()) {
				String responseJson = response.body().string();
				logger.info("Response: http code : {}, value : {}", 
						response.code()
						, responseJson);
				SecureDataModel respObj = SecureDataModel.fromBuffer(responseJson);
			
				responseData = SecureDataModel.fromEncHexBuffer(respObj.getData()
						, AtalkComplex.instance().getPACKET_KEY()
						, retClass);
				logger.info("### RESP DATA : {}",
						AtalkPacketBase.printAllFields(responseData));
				logger.info("#### RESP JSON : {}", responseData.toJson());
				
			} else {
				logger.error("Error: " + response.code());
				logger.error("@@@@@@@@@ ERR CASE 1");
			}
		} catch (Exception e) {
			logger.error("@@@@@@@@@ ERR CASE 2 : {}", e);
		}
		return responseData;
	}
	
	/**
	 * invoke request
	 * 
	 * @param reqObj
	 * @return
	 * @throws Exception
	 */
	public static <T extends AtalkPacketBase, R extends AtalkPacketBase> R
	requestAtalkMessage(T reqObj, Class<R> retClass, String url) throws Exception {
		R responseData = null;
		String url1 =	url;
		AtalkDataModelAll secureModel = new AtalkDataModelAll();
		secureModel.setSecureModel(
				AtalkComplex.instance().toEncPacket(reqObj));
		logger.info("############# 1. client -> server : send message");
		String json = AtalkComplex.toPacketData(secureModel);
		logger.info("## REQDATA : {}", json);
		
		OkHttpClient client = new OkHttpClient().newBuilder()
				.connectTimeout(40, TimeUnit.SECONDS)  // Connection timeout
	            .readTimeout(40, TimeUnit.SECONDS)     // Read timeout
	            .writeTimeout(40, TimeUnit.SECONDS)    // Write timeout
	            .build();
		
		MediaType jsonMediaType = MediaType.get("application/json; charset=utf-8");
		RequestBody body = RequestBody.Companion.create(json, jsonMediaType);
		
		////////// ENCRYPT ACCESS TOKEN
		String encJwtHexToken = AtalkComplex.instance().generateEncAccessToken();
		// encJwtHexToken = jwtToken;
		logger.info("### access token(enchex) : {}", encJwtHexToken);
		////////// ENCRYPT ACCESS TOKEN
		Request request = new Request.Builder()
				.url(url1)
				.addHeader("Authorization", "Bearer " + encJwtHexToken) // Add JWT token here
				.post(body)
				.build();
		try (Response response = client.newCall(request).execute()) {
			if (response.isSuccessful()) {
				String responseJson = response.body().string();
				logger.info("Response: http code : {}, value : {}", 
						response.code()
						, responseJson);
				SecureDataModel respObj = SecureDataModel.fromBuffer(responseJson);
			
				responseData = SecureDataModel.fromEncHexBuffer(respObj.getData()
						, AtalkComplex.instance().getPACKET_KEY()
						, retClass);
				logger.info("### RESP DATA : {}",
						AtalkPacketBase.printAllFields(responseData));
				logger.info("#### RESP JSON : {}", responseData.toJson());
				
			} else {
				logger.error("Error: " + response.code());
				logger.error("@@@@@@@@@ ERR CASE 1");
			}
		} catch (Exception e) {
			logger.error("@@@@@@@@@ ERR CASE 2 : {}", e);
		}
		return responseData;
	}

	/**
	 * invoke request
	 * 
	 * @param reqObj
	 * @return
	 * @throws Exception
	 */
	public static <T extends AtalkPacketBase, R extends AtalkPacketBase> R
	requestAtalkMessagePlain(T reqObj, Class<R> retClass, String url) throws Exception {
		R responseData = null;
		String url1 =	url;
		
		logger.info("############# 1. client -> server : send message");
		ObjectMapper objMapper = new ObjectMapper();
		String json = objMapper.writeValueAsString(reqObj);
		logger.info("## REQDATA : {}", json);
		
		OkHttpClient client = new OkHttpClient().newBuilder()
				.connectTimeout(40, TimeUnit.SECONDS)  // Connection timeout
	            .readTimeout(40, TimeUnit.SECONDS)     // Read timeout
	            .writeTimeout(40, TimeUnit.SECONDS)    // Write timeout
	            .build();
		
		MediaType jsonMediaType = MediaType.get("application/json; charset=utf-8");
		RequestBody body = RequestBody.Companion.create(json, jsonMediaType);
		
		////////// ENCRYPT ACCESS TOKEN
		String encJwtHexToken = AtalkComplex.instance().generateEncAccessToken();
		// encJwtHexToken = jwtToken;
		logger.info("### access token(enchex) : {}", encJwtHexToken);
		////////// ENCRYPT ACCESS TOKEN
		Request request = new Request.Builder()
				.url(url1)
				.addHeader("Authorization", "Bearer " + encJwtHexToken) // Add JWT token here
				.post(body)
				.build();
		try (Response response = client.newCall(request).execute()) {
			if (response.isSuccessful()) {
				String responseJson = response.body().string();
				logger.info("Response: http code : {}, value : {}", 
						response.code()
						, responseJson);
				responseData = objMapper.readValue(responseJson, retClass);
				logger.info("### RESP DATA : {}",
						AtalkPacketBase.printAllFields(responseData));
				logger.info("#### RESP JSON : {}", responseData.toJson());
				
			} else {
				logger.error("Error: " + response.code());
				logger.error("@@@@@@@@@ ERR CASE 1");
			}
		} catch (Exception e) {
			logger.error("@@@@@@@@@ ERR CASE 2 : {}", e);
		}
		return responseData;
	}

	/**
	 * invoke request
	 * 
	 * @param reqObj
	 * @return
	 * @throws Exception
	 */
	public static <T extends AtalkPacketBase, R extends AtalkPacketBase> R
	requestAtalkMessageNoAuth(T reqObj, Class<R> retClass, String url) throws Exception {
		R responseData = null;
		String url1 =	url;
		AtalkDataModelAll secureModel = new AtalkDataModelAll();
		secureModel.setSecureModel(
				AtalkComplex.instance().toEncPacket(reqObj));
		logger.info("############# 1. client -> server : send message");
		String json = AtalkComplex.toPacketData(secureModel);
		logger.info("## REQDATA : {}", json);
		
		OkHttpClient client = new OkHttpClient().newBuilder()
				.connectTimeout(40, TimeUnit.SECONDS)  // Connection timeout
	            .readTimeout(40, TimeUnit.SECONDS)     // Read timeout
	            .writeTimeout(40, TimeUnit.SECONDS)    // Write timeout
	            .build();
		
		MediaType jsonMediaType = MediaType.get("application/json; charset=utf-8");
		RequestBody body = RequestBody.Companion.create(json, jsonMediaType);
		
		Request request = new Request.Builder()
				.url(url1)
				.post(body)
				.build();
		try (Response response = client.newCall(request).execute()) {
			if (response.isSuccessful()) {
				String responseJson = response.body().string();
				logger.info("Response: http code : {}, value : {}", 
						response.code()
						, responseJson);
				SecureDataModel respObj = SecureDataModel.fromBuffer(responseJson);
			
				responseData = SecureDataModel.fromEncHexBuffer(respObj.getData()
						, AtalkComplex.instance().getPACKET_KEY()
						, retClass);
				logger.info("### RESP DATA : {}",
						AtalkPacketBase.printAllFields(responseData));
				logger.info("#### RESP JSON : {}", responseData.toJson());
				
			} else {
				logger.error("Error: " + response.code());
				logger.error("@@@@@@@@@ ERR CASE 1");
			}
		} catch (Exception e) {
			logger.error("@@@@@@@@@ ERR CASE 2 : {}", e);
		}
		return responseData;
	}


	/**
	 * invoke request
	 * 
	 * @param reqObj
	 * @return
	 * @throws Exception
	 */
	public static <R extends AtalkPacketBase> R
	requestAtalkMessageByGetMethod(Class<R> retClass, String url) throws Exception {
		R responseData = null;
		String url1 =	url;
		OkHttpClient client = new OkHttpClient().newBuilder()
				.connectTimeout(40, TimeUnit.SECONDS)  // Connection timeout
	            .readTimeout(40, TimeUnit.SECONDS)     // Read timeout
	            .writeTimeout(40, TimeUnit.SECONDS)    // Write timeout
	            .build();
		////////// ENCRYPT ACCESS TOKEN
		String encJwtHexToken = AtalkComplex.instance().generateEncAccessToken();
		// encJwtHexToken = jwtToken;
		logger.info("### access token(enchex) : {}", encJwtHexToken);
		////////// ENCRYPT ACCESS TOKEN
		Request request = new Request.Builder()
				.url(url1)
				.addHeader("Authorization", "Bearer " + encJwtHexToken) // Add JWT token here
				.build();
		try (Response response = client.newCall(request).execute()) {
			if (response.isSuccessful()) {
				String responseJson = response.body().string();
				logger.info("Response: http code : {}, value : {}", 
						response.code()
						, responseJson);
				SecureDataModel respObj = SecureDataModel.fromBuffer(responseJson);
			
				responseData = SecureDataModel.fromEncHexBuffer(respObj.getData()
						, AtalkComplex.instance().getPACKET_KEY()
						, retClass);
				logger.info("### RESP DATA : {}",
						AtalkPacketBase.printAllFields(responseData));
				logger.info("#### RESP JSON : {}", responseData.toJson());
				
			} else {
				logger.error("Error: " + response.code());
				logger.error("@@@@@@@@@ ERR CASE 1");
			}
		} catch (Exception e) {
			logger.error("@@@@@@@@@ ERR CASE 2 : {}", e);
		}
		return responseData;
	}
	
	/**
	 * invoke request
	 * 
	 * @param reqObj
	 * @return
	 * @throws Exception
	 */
	public static <R extends AtalkPacketBase> R
	requestAtalkFileMessage(Class<R> retClass, String url, byte [] buffer, String fileName) throws Exception {
		R responseData = null;
		String url1 =	url;
		OkHttpClient client = new OkHttpClient().newBuilder()
				.connectTimeout(40, TimeUnit.SECONDS)  // Connection timeout
	            .readTimeout(40, TimeUnit.SECONDS)     // Read timeout
	            .writeTimeout(40, TimeUnit.SECONDS)    // Write timeout
	            .build();
		
		MediaType mediaType = MediaType.parse("application/octet-stream");

		// MultipartBody 생성
		MultipartBody requestBody = new MultipartBody.Builder()
				.setType(MultipartBody.FORM)
				.addFormDataPart("file", fileName,
						RequestBody.create(buffer, mediaType))
				.build();
		////////// ENCRYPT ACCESS TOKEN
		String encJwtHexToken = AtalkComplex.instance().generateEncAccessToken();
		// encJwtHexToken = jwtToken;
		logger.info("### access token(enchex) : {}", encJwtHexToken);
		////////// ENCRYPT ACCESS TOKEN
		Request request = new Request.Builder()
				.url(url1)
				.addHeader("Authorization", "Bearer " + encJwtHexToken) // Add JWT token here
				.post(requestBody)
				.build();
		
		try (Response response = client.newCall(request).execute()) {
			if (response.isSuccessful()) {
				String responseJson = response.body().string();
				logger.info("Response: http code : {}, value : {}", 
						response.code()
						, responseJson);
				SecureDataModel respObj = SecureDataModel.fromBuffer(responseJson);
			
				responseData = SecureDataModel.fromEncHexBuffer(respObj.getData()
						, AtalkComplex.instance().getPACKET_KEY()
						, retClass);
				logger.info("### RESP DATA : {}",
						AtalkPacketBase.printAllFields(responseData));
				logger.info("#### RESP JSON : {}", responseData.toJson());
				
			} else {
				logger.error("Error: " + response.code());
				logger.error("@@@@@@@@@ SIGNUP ERR CASE 1");
			}
		} catch (Exception e) {
			logger.error("@@@@@@@@@ SIGNUP ERR CASE 2 : {}", e);
		}
		return responseData;
	}
	
	
	
	/**
	 * download a file
	 * 
	 * @param url
	 * @return
	 * @throws Exception
	 */
	public static byte []
	downloadAttachedFile(String url) throws Exception {
		
		byte [] fileBuffer = null;
		
		String url1 =	url;
		OkHttpClient client = new OkHttpClient().newBuilder()
				.connectTimeout(40, TimeUnit.SECONDS)  // Connection timeout
	            .readTimeout(40, TimeUnit.SECONDS)     // Read timeout
	            .writeTimeout(40, TimeUnit.SECONDS)    // Write timeout
	            .build();

		RequestBody emptyBody = RequestBody.create(new byte[0]);

		////////// ENCRYPT ACCESS TOKEN
		String encJwtHexToken = AtalkComplex.instance().generateEncAccessToken();
		// encJwtHexToken = jwtToken;
		logger.info("### access token(enchex) : {}", encJwtHexToken);
		////////// ENCRYPT ACCESS TOKEN
		Request request = new Request.Builder()
				.url(url1)
				.addHeader("Authorization", "Bearer " + encJwtHexToken) // Add JWT token here
				.post(emptyBody)
				.build();
		
		try (Response response = client.newCall(request).execute()) {
			if (response.isSuccessful()) {
				ResponseBody body = response.body();

				fileBuffer = body.bytes();
				
			} else {
				logger.error("Error: " + response.code());
			}
		} catch (Exception e) {
			logger.error("@@@@@ ERR CASE 2 : {}", e);
		}
		return fileBuffer;
	}
	
	/**
	 * invoke request
	 * 
	 * @param <R>
	 * @param metadataJson
	 * @param retClass
	 * @param url
	 * @param fileNames
	 * @param bufferList
	 * @param fileNameList
	 * @return
	 * @throws Exception
	 */
	public static <R extends AtalkPacketBase> R
	requestAtalkFileListMessageWithoutAuth(
			SecureDataModel metadataObject
			, Class<R> retClass
			, String url
			, String fileNames
			, List<byte []> bufferList
			, List<String> fileNameList) throws Exception {
		R responseData = null;
		String url1 =	url;
		OkHttpClient client = new OkHttpClient().newBuilder()
				.connectTimeout(40, TimeUnit.SECONDS)  // Connection timeout
	            .readTimeout(40, TimeUnit.SECONDS)     // Read timeout
	            .writeTimeout(40, TimeUnit.SECONDS)    // Write timeout
	            .build();
		
		MediaType mediaType = MediaType.parse("application/octet-stream");

		// MultipartBody 생성
		MultipartBody.Builder requestBodyBuilder = new MultipartBody.Builder()
				.setType(MultipartBody.FORM);
		
		if (fileNames != null && !fileNames.isBlank()) {
			for (int i=0; i < fileNameList.size(); i++) {
				requestBodyBuilder.addFormDataPart(fileNames
						, fileNameList.get(i)
						, RequestBody.create(bufferList.get(i), mediaType));
			}
		}
		requestBodyBuilder.addFormDataPart("transactinId", metadataObject.getTransactinId());
		requestBodyBuilder.addFormDataPart("data", metadataObject.getData());
		////////// ENCRYPT ACCESS TOKEN
		Request request = new Request.Builder()
				.url(url1)
				.post(requestBodyBuilder.build())
				.build();
		
		try (Response response = client.newCall(request).execute()) {
			if (response.isSuccessful()) {
				String responseJson = response.body().string();
				logger.info("Response: http code : {}, value : {}", 
						response.code()
						, responseJson);
				SecureDataModel respObj = SecureDataModel.fromBuffer(responseJson);
			
				responseData = SecureDataModel.fromEncHexBuffer(respObj.getData()
						, AtalkComplex.instance().getPACKET_KEY()
						, retClass);
				logger.info("### RESP DATA : {}",
						AtalkPacketBase.printAllFields(responseData));
				logger.info("#### RESP JSON : {}", responseData.toJson());
				
			} else {
				logger.error("Error: " + response.code());
				logger.error("@@@@@@@@@ SIGNUP ERR CASE 1");
			}
		} catch (Exception e) {
			logger.error("@@@@@@@@@ SIGNUP ERR CASE 2 : {}", e);
		}
		return responseData;
	}


	/**
	 * invoke request
	 * 
	 * @param <R>
	 * @param metadataJson
	 * @param retClass
	 * @param url
	 * @param fileNames
	 * @param bufferList
	 * @param fileNameList
	 * @return
	 * @throws Exception
	 */
	public static <R extends AtalkPacketBase> R
	requestAtalkFileListMessageAuth(
			SecureDataModel metadataObject
			, Class<R> retClass
			, String url
			, String fileNames
			, List<byte []> bufferList
			, List<String> fileNameList) throws Exception {
		R responseData = null;
		String url1 =	url;
		OkHttpClient client = new OkHttpClient().newBuilder()
				.connectTimeout(40, TimeUnit.SECONDS)  // Connection timeout
	            .readTimeout(40, TimeUnit.SECONDS)     // Read timeout
	            .writeTimeout(40, TimeUnit.SECONDS)    // Write timeout
	            .build();
		
		MediaType mediaType = MediaType.parse("application/octet-stream");

		// MultipartBody 생성
		MultipartBody.Builder requestBodyBuilder = new MultipartBody.Builder()
				.setType(MultipartBody.FORM);
		
		if (fileNames != null && !fileNames.isBlank()) {
			for (int i=0; i < fileNameList.size(); i++) {
				requestBodyBuilder.addFormDataPart(fileNames
						, fileNameList.get(i)
						, RequestBody.create(bufferList.get(i), mediaType));
			}
		}
		requestBodyBuilder.addFormDataPart("transactinId", metadataObject.getTransactinId());
		requestBodyBuilder.addFormDataPart("data", metadataObject.getData());
		////////// ENCRYPT ACCESS TOKEN
		
		String encJwtHexToken = AtalkComplex.instance().generateEncAccessToken();
		// encJwtHexToken = jwtToken;
		logger.info("### access token(enchex) : {}", encJwtHexToken);
		////////// ENCRYPT ACCESS TOKEN
		Request request = new Request.Builder()
				.url(url1)
				.addHeader("Authorization", "Bearer " + encJwtHexToken) // Add JWT token here
				.post(requestBodyBuilder.build())
				.build();
		
		try (Response response = client.newCall(request).execute()) {
			if (response.isSuccessful()) {
				String responseJson = response.body().string();
				logger.info("Response: http code : {}, value : {}", 
						response.code()
						, responseJson);
				SecureDataModel respObj = SecureDataModel.fromBuffer(responseJson);
			
				responseData = SecureDataModel.fromEncHexBuffer(respObj.getData()
						, AtalkComplex.instance().getPACKET_KEY()
						, retClass);
				logger.info("### RESP DATA : {}",
						AtalkPacketBase.printAllFields(responseData));
				logger.info("#### RESP JSON : {}", responseData.toJson());
				
			} else {
				logger.error("Error: " + response.code());
				logger.error("@@@@@@@@@ ERR CASE 1");
			}
		} catch (Exception e) {
			logger.error("@@@@@@@@@ ERR CASE 2 : {}", e);
		}
		return responseData;
	}

}
