package com.mutecsoft.atalk.logic.test.scenario;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 로그인 시험
 * 
 * 
 */
public class AtalkMainScenario101 {

	private static final Logger logger = LoggerFactory.getLogger(AtalkMainScenario101.class);

	static String [][] userInfoList = {
			{"voyzer4@gmail.com", "최형태", "01037404298"}
	};

	public static void main(String [] args) throws Exception {
		String userId = "voyzer3@gmail.com";
		String password = "111111";
		String imei = "123455432122222";
		
		// 로그인
		AtalkMainLoginTest.login(userId, password, imei);
		
		System.exit(-1);
	}
}

