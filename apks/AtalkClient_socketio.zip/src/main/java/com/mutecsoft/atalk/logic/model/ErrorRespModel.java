package com.mutecsoft.atalk.logic.model;

import java.io.Serializable;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @PackageName com.mutecsoft.atalk.logic.model.auth
 * @fileName	ErrorRespModel.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description : 에러 모델
 * <pre>
 * 
 * </pre>
 */
public class ErrorRespModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -245976247312274504L;

	protected static final ObjectMapper errObjectMapper = new ObjectMapper();
	
	private Long code;
	private String message;
	
	public ErrorRespModel() {
		this.code = 0L;
		this.message = "";
	}
	public Long getCode() {
		return code;
	}
	public void setCode(Long code) {
		this.code = code;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
}
