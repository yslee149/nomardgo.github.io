package com.mutecsoft.atalk.logic.test.scenario;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 회원 가입
 * 
 */
public class AtalkMainScenario100 {

	private static final Logger logger = LoggerFactory.getLogger(AtalkMainScenario100.class);

	static String [][] userInfoList = {
			{"voyzer@gmail.com", "최형태", "01037404298"}
		// {"voyzer@mutecsoft.com", "최형태", "01037404298"}
	};

	public static void main(String [] args) throws Exception {
		
		// 회원가입
		for (String [] userInfo : userInfoList) {
			AtalkMainSignupTest.carryonWitUser(
					userInfo[0], userInfo[1], userInfo[2]);
		}
		{
			System.exit(-1);
		}
		
	}
}

