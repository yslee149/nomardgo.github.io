package com.mutecsoft.atalk.logic.model.amigoset;

import java.io.Serializable;
import java.util.List;

import com.mutecsoft.atalk.logic.model.amigo.Amigo;

/**
 * @PackageName com.mutecsoft.atalk.logic.model.auth
 * @fileName	AmigoSet.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description :  친구그룹
 * <pre>
 * 
 * </pre>
 */
public class AmigoSet implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -245976247312274504L;

	private Long amigoSetNo;
	private String amigoSetName;
	private List<Amigo> amigoList;

	public List<Amigo> getAmigoList() {
		return amigoList;
	}
	public void setAmigoList(List<Amigo> amigoList) {
		this.amigoList = amigoList;
	}
	public Long getAmigoSetNo() {
		return amigoSetNo;
	}
	public void setAmigoSetNo(Long amigoSetNo) {
		this.amigoSetNo = amigoSetNo;
	}
	public String getAmigoSetName() {
		return amigoSetName;
	}
	public void setAmigoSetName(String amigoSetName) {
		this.amigoSetName = amigoSetName;
	}
}
