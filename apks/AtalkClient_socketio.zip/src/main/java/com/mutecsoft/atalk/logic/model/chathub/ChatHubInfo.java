package com.mutecsoft.atalk.logic.model.chathub;

import java.io.Serializable;

/**
 * @PackageName com.mutecsoft.atalk.logic.model.chathub
 * @fileName	ChatHubInfo.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description : 대화방정보
 * <pre>
 * 
 * </pre>
 */
public class ChatHubInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -245976247312274504L;

	private Long chathubNo;
	private String chathubType;
	private String encChathubKey;
	private Long userNo;
	private Long usersNum;
	private String useYn;

	public String getEncChathubKey() {
		return encChathubKey;
	}
	public void setEncChathubKey(String encChathubKey) {
		this.encChathubKey = encChathubKey;
	}
	public Long getChathubNo() {
		return chathubNo;
	}
	public void setChathubNo(Long chathubNo) {
		this.chathubNo = chathubNo;
	}
	public String getChathubType() {
		return chathubType;
	}
	public void setChathubType(String chathubType) {
		this.chathubType = chathubType;
	}
	public Long getUserNo() {
		return userNo;
	}
	public void setUserNo(Long userNo) {
		this.userNo = userNo;
	}
	public Long getUsersNum() {
		return usersNum;
	}
	public void setUsersNum(Long usersNum) {
		this.usersNum = usersNum;
	}
	public String getUseYn() {
		return useYn;
	}
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}
}

