package com.mutecsoft.atalk.logic.model.chat;

import java.io.Serializable;

/**
 * @PackageName com.mutecsoft.atalk.logic.model.chat
 * @fileName	ChatFile.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description : 파일 대화내용
 * <pre>
 * 
 * </pre>
 */
public class ChatFile implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -245976247312274504L;

	private Long chatFileNo;
	private Long parentChatFileNo;
	
	private String fileType;
	private String dispFileName;
	
	private Long fileSize;
	private String downloadPath;
	public Long getChatFileNo() {
		return chatFileNo;
	}
	public void setChatFileNo(Long chatFileNo) {
		this.chatFileNo = chatFileNo;
	}
	public Long getParentChatFileNo() {
		return parentChatFileNo;
	}
	public void setParentChatFileNo(Long parentChatFileNo) {
		this.parentChatFileNo = parentChatFileNo;
	}
	public String getFileType() {
		return fileType;
	}
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	public String getDispFileName() {
		return dispFileName;
	}
	public void setDispFileName(String dispFileName) {
		this.dispFileName = dispFileName;
	}
	public Long getFileSize() {
		return fileSize;
	}
	public void setFileSize(Long fileSize) {
		this.fileSize = fileSize;
	}
	public String getDownloadPath() {
		return downloadPath;
	}
	public void setDownloadPath(String downloadPath) {
		this.downloadPath = downloadPath;
	}
}
