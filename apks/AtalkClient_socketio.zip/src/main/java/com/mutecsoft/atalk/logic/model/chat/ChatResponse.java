package com.mutecsoft.atalk.logic.model.chat;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.mutecsoft.atalk.logic.model.AtalkPacketBase;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.logic.util.AesEncDecComplex;

/**
 * @PackageName com.mutecsoft.atalk.logic.model.chat
 * @fileName	ChatResponse.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description : 대화 상세
 * <pre>
 * 
 * </pre>
 */
public class ChatResponse extends AtalkPacketBase {

	private Long chathubNo;	// 대화방번호
	private Long chatNo;	// 대화번호
	
	private String chatType;	// 대화타입
	private String chatSubType;	// 대화SUB타입
	
	private Long userNo;	// 작성자 번호
	private String userName;	// 작성자
	
	private String chatMessage;
	
	private String encChatKey;
	
	public String getEncChatKey() {
		return encChatKey;
	}
	public void setEncChatKey(String encChatKey) {
		this.encChatKey = encChatKey;
	}
	public Long getChathubNo() {
		return chathubNo;
	}
	public void setChathubNo(Long chathubNo) {
		this.chathubNo = chathubNo;
	}
	public Long getChatNo() {
		return chatNo;
	}
	public void setChatNo(Long chatNo) {
		this.chatNo = chatNo;
	}
	public String getChatType() {
		return chatType;
	}
	public void setChatType(String chatType) {
		this.chatType = chatType;
	}
	public String getChatSubType() {
		return chatSubType;
	}
	public void setChatSubType(String chatSubType) {
		this.chatSubType = chatSubType;
	}
	public Long getUserNo() {
		return userNo;
	}
	public void setUserNo(Long userNo) {
		this.userNo = userNo;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getChatMessage() {
		return chatMessage;
	}
	public void setChatMessage(String chatMessage) {
		this.chatMessage = chatMessage;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -245976247312274504L;
    
	@Override
	public String toJson() throws JsonProcessingException {
		String prettyJson = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(this);
		// return objectMapper.writeValueAsString(this);
		return prettyJson; 
	}
	@Override
	public SecureDataModel toFinalModel() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public SecureDataModel toFinalModel(String packetKey) throws Exception {
		if (packetKey == null || packetKey.equals("")) {
			return null;
		}
		SecureDataModel secureModel = new SecureDataModel();
		secureModel.setTransactinId(this.getTransactinId());
		String jsonData = this.toJson();
		
		byte [] encBuffer = AesEncDecComplex.encryptAesWithRandomIv(
				jsonData.getBytes(), packetKey);
		String hexEncString = AesEncDecComplex.bytesToHex(encBuffer);

		secureModel.setData(hexEncString);
		return secureModel;
	}

	@Override
	public SecureDataModel toFinalModel(String seedValue, String packetKey) throws Exception {
		if (packetKey == null || packetKey.equals("")) {
			return null;
		}
		if (seedValue == null || seedValue.equals("")) {
			return null;
		}
		SecureDataModel secureModel = new SecureDataModel();
		secureModel.setTransactinId(this.getTransactinId());
		String jsonData = this.toJson();
		
		byte [] encBuffer = AesEncDecComplex.encryptAesWithRandomIv(
				jsonData.getBytes(), packetKey);
		String hexEncString = AesEncDecComplex.bytesToHex(encBuffer);

		secureModel.setData(hexEncString);
		secureModel.setDataAfter(seedValue);
		
		return secureModel;
	}
}
