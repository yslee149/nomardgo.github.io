package com.mutecsoft.atalk.logic.model.chathub;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.mutecsoft.atalk.logic.model.AtalkPacketBase;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.logic.util.AesEncDecComplex;

/**
 * @PackageName com.mutecsoft.atalk.logic.model.chathub
 * @fileName	OpenChathubResponse.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description : 대화방 목록 정보
 * <pre>
 * 
 * </pre>
 */
public class ListChathubResponse extends AtalkPacketBase {

	/**
	 * 
	 */
	private static final long serialVersionUID = -245976247312274504L;
    
	private List<ChatHubListInfo> chatHubListInfo;
	
	private	String lastUpdateDt;
	
	public List<ChatHubListInfo> getChatHubListInfo() {
		return chatHubListInfo;
	}
	public void setChatHubListInfo(List<ChatHubListInfo> chatHubListInfo) {
		this.chatHubListInfo = chatHubListInfo;
	}
	public String getLastUpdateDt() {
		return lastUpdateDt;
	}
	public void setLastUpdateDt(String lastUpdateDt) {
		this.lastUpdateDt = lastUpdateDt;
	}
	@Override
	public String toJson() throws JsonProcessingException {
		String prettyJson = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(this);
		// return objectMapper.writeValueAsString(this);
		return prettyJson; 
	}
	@Override
	public SecureDataModel toFinalModel() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public SecureDataModel toFinalModel(String packetKey) throws Exception {
		if (packetKey == null || packetKey.equals("")) {
			return null;
		}
		SecureDataModel secureModel = new SecureDataModel();
		secureModel.setTransactinId(this.getTransactinId());
		String jsonData = this.toJson();
		
		byte [] encBuffer = AesEncDecComplex.encryptAesCtrWithRandomIv(
				jsonData.getBytes(), packetKey);
		String hexEncString = AesEncDecComplex.bytesToHex(encBuffer);

		secureModel.setData(hexEncString);
		return secureModel;
	}

	@Override
	public SecureDataModel toFinalModel(String seedValue, String packetKey) throws Exception {
		if (packetKey == null || packetKey.equals("")) {
			return null;
		}
		if (seedValue == null || seedValue.equals("")) {
			return null;
		}
		SecureDataModel secureModel = new SecureDataModel();
		secureModel.setTransactinId(this.getTransactinId());
		String jsonData = this.toJson();
		
		byte [] encBuffer = AesEncDecComplex.encryptAesCtrWithRandomIv(
				jsonData.getBytes(), packetKey);
		String hexEncString = AesEncDecComplex.bytesToHex(encBuffer);

		secureModel.setData(hexEncString);
		secureModel.setDataAfter(seedValue);
		
		return secureModel;
	}
	
	public boolean toFile(String filePath) {
		boolean bresult = false;
	    // Serialize
	    try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filePath))) {
	        oos.writeObject(this);
	        bresult = true;
	    } catch (IOException e) {
	    	e.printStackTrace();
	    } catch (Exception e) {
	    	
	    }
	    return bresult;
	}

	// public record PairChathubList<K, V>(K key, V value) {}

	/**
	 * 
	 * @param filePath
	 * @return
	 */
	// public static PairChathubList<ListChathubResponse, Map<Long, ChatHubListInfo>> fromFile(String filePath) {
	public static Object [] fromFile(String filePath) {
		
		Map<Long, ChatHubListInfo> chathubMap = new HashMap<Long, ChatHubListInfo>();
		
		ListChathubResponse chatHubList = null;
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filePath))) {
        	chatHubList = (ListChathubResponse) ois.readObject();
        	if (chatHubList != null && chatHubList.getChatHubListInfo() != null) {
        		chatHubList.getChatHubListInfo().forEach(val -> {
        			chathubMap.put(val.getChathubNo(), val);
        		});
        	}
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
	    } catch (Exception e) {
	    	e.printStackTrace();
	    }
	    // return new PairChathubList<>(chatHubList, chathubMap);
        return new Object [] { chatHubList, chathubMap };
	}
}
