package com.mutecsoft.atalk.logic.contant;

public class AtalkConstant {

	public static final int SIGNATURE_BOUND_POS = 684;
	
	public static final int MSG_CODE_READ_NOTI = 0x0a;
	public static final int MSG_CODE_INVITE_NOTI = 0x0b;
	public static final int MSG_CODE_KICKOUT_NOTI = 0x0c;
	public static final int MSG_CODE_EXIT_NOTI = 0x0d;
	public static final int MSG_CODE_RETREIVE_CHAT_NOTI = 0x0e;
	public static final int MSG_CODE_CHAT_NOTI = 0x0f;
	
}

