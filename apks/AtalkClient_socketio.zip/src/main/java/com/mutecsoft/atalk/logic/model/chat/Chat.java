package com.mutecsoft.atalk.logic.model.chat;

import java.io.Serializable;

/**
 * @PackageName com.mutecsoft.atalk.logic.model.chat
 * @fileName	Chat.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description : 대화내용 및 첨부파일 대화 정보
 * <pre>
 * 
 * </pre>
 */
public class Chat implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -245976247312274504L;

	private Long chathubNo;	// 대화방번호
	private Long chatNo;	// 대화번호

	private String chatType;	// 대화타입
	private String chatSubType;	// 대화SUB타입
	
	private Long userNo;	// 작성자 번호
	private String userName;	// 작성자
	
	private Long unreadCnt; // 
	private Long userCount;	// 참여자명수
	
	private String regDt;	// 등록일시
	
	private String extChat;
	
	private String alarmYn;	// 알림 여부

	private String chatMessage;
	
	private String chatExtUrl;		// 대용량 대화내용 VIEW PATH

	private ChatFile chatFileInfo;	// 파일 대화정보

	public String getExtChat() {
		return extChat;
	}

	public void setExtChat(String extChat) {
		this.extChat = extChat;
	}

	public String getChatSubType() {
		return chatSubType;
	}

	public void setChatSubType(String chatSubType) {
		this.chatSubType = chatSubType;
	}

	public String getChatMessage() {
		return chatMessage;
	}

	public void setChatMessage(String chatMessage) {
		this.chatMessage = chatMessage;
	}

	public Long getUnreadCnt() {
		return unreadCnt;
	}

	public void setUnreadCnt(Long unreadCnt) {
		this.unreadCnt = unreadCnt;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getChatExtUrl() {
		return chatExtUrl;
	}

	public void setChatExtUrl(String chatExtUrl) {
		this.chatExtUrl = chatExtUrl;
	}

	public Long getUserNo() {
		return userNo;
	}

	public void setUserNo(Long userNo) {
		this.userNo = userNo;
	}

	public Long getChathubNo() {
		return chathubNo;
	}

	public void setChathubNo(Long chathubNo) {
		this.chathubNo = chathubNo;
	}

	public Long getChatNo() {
		return chatNo;
	}

	public void setChatNo(Long chatNo) {
		this.chatNo = chatNo;
	}

	public String getChatType() {
		return chatType;
	}

	public void setChatType(String chatType) {
		this.chatType = chatType;
	}

	public String getRegDt() {
		return regDt;
	}

	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}

	public Long getUserCount() {
		return userCount;
	}

	public void setUserCount(Long userCount) {
		this.userCount = userCount;
	}

	public String getAlarmYn() {
		return alarmYn;
	}

	public void setAlarmYn(String alarmYn) {
		this.alarmYn = alarmYn;
	}

	public ChatFile getChatFileInfo() {
		return chatFileInfo;
	}

	public void setChatFileInfo(ChatFile chatFileInfo) {
		this.chatFileInfo = chatFileInfo;
	}
	
}

