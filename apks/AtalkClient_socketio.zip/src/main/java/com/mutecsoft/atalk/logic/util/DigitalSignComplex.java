package com.mutecsoft.atalk.logic.util;

import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.interfaces.RSAPrivateCrtKey;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.HashMap;

import javax.crypto.Cipher;

/**
 * 
 * 
 * @PackageName com.mutecsoft.atalk.logic.util
 * @fileName	com.mutecsoft.atalk.logic.util.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description : 占쎈탵筌욑옙占쎄쉭 占쎄텢占쎌뵥 筌ｌ꼶�봺
 * <pre>
 * 
 * </pre>
 */
public class DigitalSignComplex {

	
	/**
	 * step 1. digital signing message generation
	 * 
	 * @param length
	 * @return
	 */
	public static String generateSigningMessage(int length) {
		return RandomHexString.genSecureRandomHex(32);
	}
	
	/**
	 * step 2. calculate signing message hash
	 * 
	 * @param signingMessage
	 * @return
	 */
	public static String generateSigningMessageHash(String signingMessage) {
		int iterationCount = BufferComplex.sumHexDigits(signingMessage) % 100;
		return HashComplex.hashWithSha512(signingMessage, iterationCount);
	}
	
	/**
	 * step 3. generate signature with privateKey
	 * 
	 * @param signingMessage
	 * @param rsaPrivateKey
	 * @param rsaPublicKey
	 * @return
	 */
	public static String generateSignature(
			String signingMessage, String rsaPrivateKey, String rsaPublicKey) {
		int iterationCount = BufferComplex.sumHexDigits(signingMessage) % 50;
		
		String signatureValue = RsaComplex.encryptWithPrvkey(
				HashComplex.hashWithSha512(signingMessage, iterationCount)
				, rsaPrivateKey);
		
		System.out.println("signature length : " + signatureValue.length());
		System.out.println("rsaPublicKey length : " + rsaPublicKey.length());
		
		return String.format("%s%s", signatureValue, rsaPublicKey);
	}
	
	/**
	 * step 3. generate signature with privateKey
	 * 
	 * @param signingMessage
	 * @param rsaPrivateKey
	 * @param rsaPublicKey
	 * @return
	 * @throws Exception 
	 */
	public static String generateSignature(
			String signingMessage, RSAPrivateKey rsaPrivateKey, RSAPublicKey rsaPublicKey) throws Exception {
		int iterationCount = BufferComplex.sumHexDigits(signingMessage) % 50;
		
		String signatureValue = RsaComplex.encryptWithPrvkey(
				HashComplex.hashWithSha512(signingMessage, iterationCount)
				, rsaPrivateKey);
		
//		System.out.println("signature length : " + signatureValue.length());
//		System.out.println("rsaPublicKey length : " + rsaPublicKey.length());
		
		return String.format("%s%s", 
				signatureValue
				, RsaComplex.encodeBase64(rsaPublicKey.getEncoded()));
	}
	
	
	/**
	 * step 4. decrypt signature with privateKey
	 * 
	 * @param signature
	 * @param rsaPublicKey
	 * @return
	 */
	public static String decryptSignature(String signature, String rsaPublicKey) {
		
		return RsaComplex.decryptWithPubkey(
				signature
				, rsaPublicKey);
	}
	
	
	/**
	 * step 4. decrypt signature with privateKey
	 * 
	 * @param signature
	 * @param rsaPublicKey
	 * @return
	 */
	public static Boolean checkSignature(String signature, String signingMessage, String rsaPublicKey) {
		String signingHash = DigitalSignComplex.generateSigningMessageHash(signingMessage);
		String decryptedSigningHsh = DigitalSignComplex.decryptSignature(signature, rsaPublicKey);

//		System.out.println("## signingHash : " + signingHash);
//		System.out.println("## decryptedSigningHsh : " + decryptedSigningHsh);

		return (signingHash.equals(decryptedSigningHsh) ? Boolean.TRUE : Boolean.FALSE);

	}
	
	
	/**
	 * encrypt with pubkey
	 * 
	 * @param plainText
	 * @param publicKey
	 * @return
	 */
	public static String encrypt(String plainText, RSAPublicKey publicKey) {
		String encStrValue = "";
		try {
			// PublicKey publicKey = getRSAPublicKeyByEncoded(decodeBase64(publicKeyString));
	        Cipher cipher = Cipher.getInstance("RSA");
	        cipher.init(Cipher.ENCRYPT_MODE, publicKey);
			byte[] encStr = null;
	        encStr = cipher.doFinal(plainText.getBytes());
	        encStrValue = new String(Base64.getEncoder().encode(encStr));
	        
	        // System.out.println(encStrValue);
		} catch (Exception e) {	
		}
        return encStrValue;
	}

	/**
	 * encrypt with pubkey
	 * 
	 * @param plainText
	 * @param publicKeyString
	 * @return
	 */
	public static String encrypt(String plainText, String publicKeyString) {
		String encStrValue = "";
		try {
			PublicKey publicKey = getRSAPublicKeyByEncoded(decodeBase64(publicKeyString));
	        Cipher cipher = Cipher.getInstance("RSA");
	        cipher.init(Cipher.ENCRYPT_MODE, publicKey);
			byte[] encStr = null;
	        encStr = cipher.doFinal(plainText.getBytes());
	        // encStrValue = new String(Base64.getEncoder().encode(encStr));
	        encStrValue = new String(Base64.getEncoder().encode(encStr));
	        // System.out.println(encStrValue);
		} catch (Exception e) {	}
        return encStrValue;
	}
	
	
	/**
	 * encrypt with pubkey
	 * 
	 * @param plainText
	 * @param privatekey
	 * @return
	 */
	public static String encryptWithPrvkey(String plainText, RSAPrivateKey privatekey) {
		String encStrValue = "";
		try {
			// PublicKey publicKey = getRSAPublicKeyByEncoded(decodeBase64(publicKeyString));
			Cipher cipher = Cipher.getInstance("RSA");
			cipher.init(Cipher.ENCRYPT_MODE, privatekey);
			byte[] encStr = null;
			encStr = cipher.doFinal(plainText.getBytes());
			encStrValue = new String(Base64.getEncoder().encode(encStr));
			// System.out.println(encStrValue);
		} catch (Exception e) {	
		}
        return encStrValue;
	}

	/**
	 * encrypt with pubkey
	 * 
	 * @param plainText
	 * @param privatekeyString
	 * @return
	 */
	public static String encryptWithPrvkey(String plainText, String privatekeyString) {
		String encStrValue = "";
		try {
			PrivateKey privatekey = getRSAPrivateKeyByEncoded(decodeBase64(privatekeyString));
			Cipher cipher = Cipher.getInstance("RSA");
			cipher.init(Cipher.ENCRYPT_MODE, privatekey);
			byte[] encStr = null;
			encStr = cipher.doFinal(plainText.getBytes());
			encStrValue = new String(Base64.getEncoder().encode(encStr));
			// System.out.println(encStrValue);
		} catch (Exception e) {	}
		return encStrValue;
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////
	/**
	 * decrypt with private key
	 * 
	 * @param encStrValue
	 * @param publickey
	 * @return
	 */
	public static String decryptWithPubkey(String encStrValue, RSAPublicKey publickey) {
		String decStrValue = "";
		try {
	        byte [] encStrByteStream = Base64.getDecoder().decode(encStrValue);
	        Cipher cipher2 = Cipher.getInstance("RSA");
	        cipher2.init(Cipher.DECRYPT_MODE, publickey);
	        byte[] decStr = cipher2.doFinal(encStrByteStream);
	        // System.out.println(new String(decStr));
	        decStrValue = new String(decStr);		       
		} catch (Exception e) {	}
        return decStrValue;
	}
 
	/**
	 * decrypt with private key
	 * 
	 * @param encStrValue
	 * @param publickeyString
	 * @return
	 */
	public static String decryptWithPubkey(String encStrValue, String publickeyString) {
		String decStrValue = "";
		try {
	        PublicKey pubKey = getRSAPublicKeyByEncoded(decodeBase64(publickeyString));	        
	        byte [] encStrByteStream = Base64.getDecoder().decode(encStrValue);
	        // byte [] encStrByteStream = org.apache.commons.codec.binary.Base64.decodeBase64(encStrValue);
	        Cipher cipher2 = Cipher.getInstance("RSA");
	        cipher2.init(Cipher.DECRYPT_MODE, pubKey);
	        byte[] decStr = cipher2.doFinal(encStrByteStream);
	        // System.out.println(new String(decStr));
	        decStrValue = new String(decStr);		       
		} catch (Exception e) {	}
        return decStrValue;
	}
	
	/**
	 * decrypt with private key
	 * 
	 * @param encStrValue
	 * @param privKey
	 * @return
	 */
	public static String decrypt(String encStrValue, RSAPrivateKey privKey) {
		String decStrValue = "";
		try {
	        // byte [] encStrByteStream = org.apache.commons.codec.binary.Base64.decodeBase64(encStrValue);
	        byte [] encStrByteStream = Base64.getDecoder().decode(encStrValue);
	        Cipher cipher2 = Cipher.getInstance("RSA");
	        cipher2.init(Cipher.DECRYPT_MODE, privKey);
	        byte[] decStr = cipher2.doFinal(encStrByteStream);
	        // System.out.println(new String(decStr));
	        decStrValue = new String(decStr);		       
		} catch (Exception e) {	}
        return decStrValue;
	}
 
	/**
	 * decrypt with private key
	 * @param encStrValue
	 * @param privateKeyString
	 * @return
	 */
	public static String decrypt(String encStrValue, String privateKeyString) {
		String decStrValue = "";
		try {
	        PrivateKey privKey = getRSAPrivateKeyByEncoded(decodeBase64(privateKeyString));	        
	        byte [] encStrByteStream = Base64.getDecoder().decode(encStrValue);
	        // byte [] encStrByteStream = org.apache.commons.codec.binary.Base64.decodeBase64(encStrValue);
	        Cipher cipher2 = Cipher.getInstance("RSA");
	        cipher2.init(Cipher.DECRYPT_MODE, privKey);
	        byte[] decStr = cipher2.doFinal(encStrByteStream);
	        // System.out.println(new String(decStr));
	        decStrValue = new String(decStr);		       
		} catch (Exception e) {	}
        return decStrValue;
	}
 
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	 /**Get the key pair
	 * @return
	 * @throws NoSuchAlgorithmException
	 */
	public static HashMap<String, Object> getKeys(int bits)
			throws NoSuchAlgorithmException {
		HashMap<String, Object> map = new HashMap<String, Object>();
		KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance("RSA");
		keyPairGen.initialize(bits);
		KeyPair keyPair = keyPairGen.generateKeyPair();
		RSAPublicKey publicKey = (RSAPublicKey) keyPair.getPublic();
		RSAPrivateKey privateKey = (RSAPrivateKey) keyPair.getPrivate();
		map.put("PUBLIC", publicKey);
		map.put("PRIVATE", privateKey);
		return map;
	}
 
	
	/**
	  * generate public key by encodedPublicKey
	 * @param encodedPublicKey
	 * @return
	 */
	@SuppressWarnings("finally")
	private static PublicKey getRSAPublicKeyByEncoded(byte[] encodedPublicKey) {
		RSAPublicKey pubKey = null;
		try {
			//Only RSAPublicKeySpec and X509EncodedKeySpec supported for RSA public keys
			KeyFactory keyFactory = KeyFactory.getInstance("RSA");
			pubKey = (RSAPublicKey) keyFactory
					.generatePublic(new X509EncodedKeySpec(encodedPublicKey));
			
		} catch (Exception e) {
			System.err.println(e);
		} finally {
			return pubKey;
		}
	}
	
	/**
	  * generate private key by encodedPrivateKey
	 * @param encodedPrivateKey
	 * @return
	 */
	@SuppressWarnings("finally")
	private static PrivateKey getRSAPrivateKeyByEncoded(byte[] encodedPrivateKey) {
		PrivateKey pvkKey = null;
		try {
			PKCS8EncodedKeySpec pvkKeySpec = new PKCS8EncodedKeySpec(
					encodedPrivateKey);
			KeyFactory keyFactory = KeyFactory.getInstance("RSA");
			pvkKey = (RSAPrivateCrtKey) keyFactory
					.generatePrivate(pvkKeySpec);

		} catch (Exception e) {
			System.err.println(e);
			return null;
		} finally {
			return pvkKey;
		}
	}
 
	/**
	  * Convert public key to C# format
	 * @param key
	 * @return
	 * @throws Exception
	 */
	public  String encodePublicKeyToXml(PublicKey key) throws Exception {
		if (!RSAPublicKey.class.isInstance(key)) {
			return null;
		}
		RSAPublicKey pubKey = (RSAPublicKey) key;
		StringBuilder sb = new StringBuilder();
 
		sb.append("<RSAKeyValue>");
		sb.append("<Modulus>")
				.append(encodeBase64(removeMSZero(pubKey.getModulus()
						.toByteArray()))).append("</Modulus>");
		sb.append("<Exponent>")
				.append(encodeBase64(removeMSZero(pubKey.getPublicExponent()
						.toByteArray()))).append("</Exponent>");
		sb.append("</RSAKeyValue>");
		return sb.toString();
	}
 
	/**
	 * @param data
	 * @return
	 */
	private  byte[] removeMSZero(byte[] data) {
		byte[] data1;
		int len = data.length;
		if (data[0] == 0) {
			data1 = new byte[data.length - 1];
			System.arraycopy(data, 1, data1, 0, len - 1);
		} else
			data1 = data;
 
		return data1;
	}
 
	/**
	  * base64 encoding
	 * @param input
	 * @return
	 * @throws Exception
	 */
	public static String encodeBase64(byte[] input) throws Exception {
		/*
		Class clazz = Class
				.forName("com.sun.org.apache.xerces.internal.impl.dv.util.Base64");
		Method mainMethod = clazz.getMethod("encode", byte[].class);
		mainMethod.setAccessible(true);
		Object retObj = mainMethod.invoke(null, new Object[] { input });
		return (String) retObj;
		*/
		return new String(Base64.getEncoder().encode(input));
		
	}
 
	/**
	  * base64 decoding 
	 * @param input
	 * @return
	 * @throws Exception
	 */
	private static byte[] decodeBase64(String input) throws Exception {
		/*
		Class clazz = Class
				.forName("com.sun.org.apache.xerces.internal.impl.dv.util.Base64");
		Method mainMethod = clazz.getMethod("decode", String.class);
		mainMethod.setAccessible(true);
		Object retObj = mainMethod.invoke(null, input);
		return (byte[]) retObj;
		*/
		return Base64.getDecoder().decode(input.getBytes());
	}
	
	public static void main(String [] arg) throws Exception {
		{
			HashMap<String, Object> keyMap = getKeys(4096);
			RSAPublicKey pubkey = (RSAPublicKey)keyMap.get("PUBLIC");
			RSAPrivateKey privateKey = (RSAPrivateKey)keyMap.get("PRIVATE");
			
			System.out.println("pub key : " + encodeBase64(pubkey.getEncoded()));
			System.out.println(encodeBase64(pubkey.getEncoded()).length());
			System.out.println("private key : " + encodeBase64(privateKey.getEncoded()));
			
			System.out.println(encodeBase64(privateKey.getEncoded()).length());

			
			System.out.println("#### reverse case");
			{
				String encData = encryptWithPrvkey("Y3AhdWNAcExH", encodeBase64(privateKey.getEncoded()));
				System.out.println("encData : " + encData + ", len : " + encData.length());
				String decData = decryptWithPubkey(encData, encodeBase64(pubkey.getEncoded()));
				System.out.println("decData : " + decData);
			}
			
			{
				String encData = encrypt("Y3AhdWNAcExH", encodeBase64(pubkey.getEncoded()));
				System.out.println("encData : " + encData + ", len : " + encData.length());
				String decData = decrypt(encData, encodeBase64(privateKey.getEncoded()));
				System.out.println("decData : " + decData);
			}
			{
				String encData = encrypt("Y3AhdWNAcExH", pubkey);
				System.out.println("encData : " + encData + ", len : " + encData.length());
				String decData = decrypt(encData, privateKey);
				System.out.println("decData : " + decData);
			}
			
			{
				// digital sign test
				System.out.println("##################################################");
				
				System.out.println("##### digital signing test");
				
				
				String messageForSigning = RandomHexString.genSecureRandomHex(32);
				System.out.println("### messgae for signing : " + messageForSigning);
				
				
				System.out.println("##################################################");
			}
			
			
		}
		{
			System.out.println("#########################################################");
			String publicKeyVal = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAlKhg0kBQyGc5VZ1JeHiOGBzBACVOCr6gk8Z34OGg/Oqd8VCYQv+AUhRUwdg1QgvF9HoPhoLBo+jTaY79DDq/fIQ9gWffAcIUpBosiDwhfI1/v7SHFRsMGTt9QNLCs6Ry6LM+A/OZdGMvMbln3O8DnHB/GEtrzxyanPPrHUABCmDeenhAcAvOavbPXAXSEADELuAwBuyflMIMLdkJ5m8z1PM3ZDxvKfvuSoWaU0VGCgFgXYfuW5oDCJZDszBn7Z8RxBltXOGPlyGw3ikNRLbQik0fjFuBewISOIKRqfhALJTYDCk0owzO6uVHu5A8WcT+6F8u4PFXGnJSaDcqRi9kTQIDAQAB";
			
			
			String privateKeyVal = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCUqGDSQFDIZzlVnUl4eI4YHMEAJU4KvqCTxnfg4aD86p3xUJhC/4BSFFTB2DVCC8X0eg+GgsGj6NNpjv0MOr98hD2BZ98BwhSkGiyIPCF8jX+/tIcVGwwZO31A0sKzpHLosz4D85l0Yy8xuWfc7wOccH8YS2vPHJqc8+sdQAEKYN56eEBwC85q9s9cBdIQAMQu4DAG7J+Uwgwt2QnmbzPU8zdkPG8p++5KhZpTRUYKAWBdh+5bmgMIlkOzMGftnxHEGW1c4Y+XIbDeKQ1EttCKTR+MW4F7AhI4gpGp+EAslNgMKTSjDM7q5Ue7kDxZxP7oXy7g8VcaclJoNypGL2RNAgMBAAECggEACob1/E2jqt1sePyfdFGNNnXq0PjTUv1236AhYyJ3RRHUR39+mNgBHU7lRajq9Jdi2FJAgTUHQ3U8a3A9yTzrzISM2nohl71HuutDlg40DN70Wf4NxtfYfnzw/MMwGIqfvIzc6mi4yD4x3GKV0VZ3uf9ZcL3+j3cmF9FKKBMdP7/Ks0SsTWtuF79OwQdX+wWa03sMwWBl5ob0SIvXuAuqjrKR1QDHECqweZ9AIblzY0NoswzYwoPK64fJ2d4tSlhc0A3t1UerEq6+GJQyTPk1X8lsm0WPkhhoC6iSu/6trgV3WAyzXoHbFy31+K65cwL44zW/b84MOCNMnyqEkKfmXQKBgQDPSos6Z2rZWHxGyTUKtZnpasYkCafM5IYP4ZitXB04ZIj36jPjParMitjZK0hyScPqdE4Mx4Du3KTH0dUC7AQOWTLUVwmv/0U5ZrT+reN8uw4hXDzfffakYABZlNF/ZjyuoqZQmQX9+Q+kYNE7TjAGlyHC4BmoGujqPWj7xka9bwKBgQC3lseX335mB/nfGhBSuT7fHnYm4leP8sQTtqYsVg/d2l8TiY4WKJDcq6qsB/Zd/721+3RAYSeBwf76KWUmNG1xKf23WX5+b6jLIJ1S3lcycAzUjvyNYJxT+Mxxh0+W+stC+mpgXAm069G2oAtk5n2khLmNdIrmF+ObjRgAUhmUAwKBgCZOgUIuwFkf9/9gyXOMMcAn4ivguOitRnUC3KMUxbWZJpKh7irNR5X7Bq3DSOUN6q2WBqJn79S0Y6MljLa4hNtd8n25A+pJQzKjX0k9Oy/epXLWx80JSx3/O7FSRhDEBOzE0/VLAgd4EkLvPVs3TLq7DRslLLibGHXJGXCFqKbzAoGAFzEl/6qNFiiVyThKrZiXN6pqdJkNRLL/UBo3vcwVbwpCDn7HA0eWnTnWcqsC1XcUKSQd2HAthHfUVRfbnkrrNGuAkKPuldxXL2nsVeaej1GWXVe+0cFNnlIEyaa1SDZgbRKjU47s7v0HXhGzvshbQOg/ZH4/ebe02hal3IyCjK8CgYEAv7qmDyg1GRPRUaQl6XWoB2+D3Hn1cowaylP8wH8Cm6Ja91HVJEefTMotffWw7Lw9SOw0FKigAAPW+3f9hYpp/rGpNqUekKl9rX4h6oTAN2JILr+71jX8KI/cyRQT8ayt5JXiY1b9GWp0htbQqpJLLpcEifGf0ZV4FmCXOp+lkW8=";
						
			String encData = encrypt("Y3AhdWNAcExH", publicKeyVal);
			System.out.println("encData : " + encData + ", len : " + encData.length());
			String decData = decrypt(encData, privateKeyVal);
			System.out.println("decData : " + decData);
		}
		{
			String privateKeyVal = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCUqGDSQFDIZzlVnUl4eI4YHMEAJU4KvqCTxnfg4aD86p3xUJhC/4BSFFTB2DVCC8X0eg+GgsGj6NNpjv0MOr98hD2BZ98BwhSkGiyIPCF8jX+/tIcVGwwZO31A0sKzpHLosz4D85l0Yy8xuWfc7wOccH8YS2vPHJqc8+sdQAEKYN56eEBwC85q9s9cBdIQAMQu4DAG7J+Uwgwt2QnmbzPU8zdkPG8p++5KhZpTRUYKAWBdh+5bmgMIlkOzMGftnxHEGW1c4Y+XIbDeKQ1EttCKTR+MW4F7AhI4gpGp+EAslNgMKTSjDM7q5Ue7kDxZxP7oXy7g8VcaclJoNypGL2RNAgMBAAECggEACob1/E2jqt1sePyfdFGNNnXq0PjTUv1236AhYyJ3RRHUR39+mNgBHU7lRajq9Jdi2FJAgTUHQ3U8a3A9yTzrzISM2nohl71HuutDlg40DN70Wf4NxtfYfnzw/MMwGIqfvIzc6mi4yD4x3GKV0VZ3uf9ZcL3+j3cmF9FKKBMdP7/Ks0SsTWtuF79OwQdX+wWa03sMwWBl5ob0SIvXuAuqjrKR1QDHECqweZ9AIblzY0NoswzYwoPK64fJ2d4tSlhc0A3t1UerEq6+GJQyTPk1X8lsm0WPkhhoC6iSu/6trgV3WAyzXoHbFy31+K65cwL44zW/b84MOCNMnyqEkKfmXQKBgQDPSos6Z2rZWHxGyTUKtZnpasYkCafM5IYP4ZitXB04ZIj36jPjParMitjZK0hyScPqdE4Mx4Du3KTH0dUC7AQOWTLUVwmv/0U5ZrT+reN8uw4hXDzfffakYABZlNF/ZjyuoqZQmQX9+Q+kYNE7TjAGlyHC4BmoGujqPWj7xka9bwKBgQC3lseX335mB/nfGhBSuT7fHnYm4leP8sQTtqYsVg/d2l8TiY4WKJDcq6qsB/Zd/721+3RAYSeBwf76KWUmNG1xKf23WX5+b6jLIJ1S3lcycAzUjvyNYJxT+Mxxh0+W+stC+mpgXAm069G2oAtk5n2khLmNdIrmF+ObjRgAUhmUAwKBgCZOgUIuwFkf9/9gyXOMMcAn4ivguOitRnUC3KMUxbWZJpKh7irNR5X7Bq3DSOUN6q2WBqJn79S0Y6MljLa4hNtd8n25A+pJQzKjX0k9Oy/epXLWx80JSx3/O7FSRhDEBOzE0/VLAgd4EkLvPVs3TLq7DRslLLibGHXJGXCFqKbzAoGAFzEl/6qNFiiVyThKrZiXN6pqdJkNRLL/UBo3vcwVbwpCDn7HA0eWnTnWcqsC1XcUKSQd2HAthHfUVRfbnkrrNGuAkKPuldxXL2nsVeaej1GWXVe+0cFNnlIEyaa1SDZgbRKjU47s7v0HXhGzvshbQOg/ZH4/ebe02hal3IyCjK8CgYEAv7qmDyg1GRPRUaQl6XWoB2+D3Hn1cowaylP8wH8Cm6Ja91HVJEefTMotffWw7Lw9SOw0FKigAAPW+3f9hYpp/rGpNqUekKl9rX4h6oTAN2JILr+71jX8KI/cyRQT8ayt5JXiY1b9GWp0htbQqpJLLpcEifGf0ZV4FmCXOp+lkW8=";
		
			System.out.println("#########################################################");
			String encData = "fvJi2TTte6nFiQtgtshbaIAmaWT71T70ZYqRDCa6fZJJP1fFPX3Rtw/TVNPX3rVQD1/KVvHffQ65RpqpWA+pUk3z8bSQ824tQ+5NQ7/3+Oi37jfrXLspmHwqTXf9UMN+KC1AEnvzXhlXkAq0vZIUtPdgadEl6alaBT4Dx6EzHbcRlJPr+cl3ybnLwR63k44b4BO2/poXCZ21kiikNShCVvj/i0YdXeSD5r+R4TvtosNae2G3KFuwFGNyBKNwyoVg1qSCKoTYgEecWjUKpBxpJvCx4nKlrtIFanTdQJZ5STxUJ8YiVeKU5by3V3g2n50GuYWhrMHD22STOBwyFiSpnA==";
			System.out.println("encData : " + encData + ", len : " + encData.length());
			String decData = decrypt(encData, privateKeyVal);
			System.out.println("decData : " + decData);
		}
	}
}
