package com.mutecsoft.atalk.logic.test;

import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;
import okhttp3.OkHttpClient;

import javax.net.ssl.*;

import java.net.URI;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.concurrent.CountDownLatch;
public class AtalkSocketIoTest {
   public static void main(String[] args) throws Exception {
       // Step 1: Create SSLContext (trust all certificates for testing)
       SSLContext sslContext = createSSLContext();

       // Step 2: Create a custom OkHttpClient with SSL settings
       OkHttpClient okHttpClient = new OkHttpClient.Builder()
               .sslSocketFactory(sslContext.getSocketFactory(), new TrustAllX509TrustManager()) // Apply SSL
               .hostnameVerifier((hostname, session) -> true) // Accept all hostnames (for testing)
               .build();

       // Step 3: Configure secure Socket.IO connection
       IO.setDefaultOkHttpCallFactory(okHttpClient); // Set global OkHttpClient
       IO.setDefaultOkHttpWebSocketFactory(okHttpClient); // Set WebSocketFactory globally

       IO.Options options = IO.Options.builder()
               .setSecure(true) // Enable SSL
               .setReconnection(true) // Auto-reconnect
               .setForceNew(true) // Always create a new connection
               .build();

       // Step 4: Connect to the secure Socket.IO server
       Socket socket = IO.socket(new URI("wss://localhost:29095?token=11111111&user_no=12345"), options);

       // Step 5: Handle successful connection
       socket.on(Socket.EVENT_CONNECT, args1 -> {
           System.out.println("✅ Secure connection established!");
           socket.emit("message", "Hello from Secure Client!");
       });

       // Step 6: Handle incoming messages
       socket.on("message", (Emitter.Listener) args1 -> {
    	   
    	   if (args1 != null && args1.length > 0) {
    		   for (int i =0; i < args1.length; i++) {
    			   System.out.println("📩 Received: " + args1[i]);
    		   }
    	   }
       });

       // Step 7: Handle disconnection
       socket.on(Socket.EVENT_DISCONNECT, args1 -> {
           System.out.println("❌ Disconnected from server");
       });

       // Step 8: Connect to the server
       socket.connect();

       // Step 9: Prevent program from exiting
       new CountDownLatch(1).await();
    }

    /**
     * Create an SSLContext that trusts all certificates (for testing purposes).
     */
    private static SSLContext createSSLContext() throws Exception {
        TrustManager[] trustAllCertificates = new TrustManager[]{ new TrustAllX509TrustManager() };

        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(null, trustAllCertificates, new SecureRandom());
        return sslContext;
    }

    /**
     * Custom TrustManager that trusts all certificates (for testing only).
     */
    static class TrustAllX509TrustManager implements X509TrustManager {
        public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
        public void checkClientTrusted(X509Certificate[] certs, String authType) {}
        public void checkServerTrusted(X509Certificate[] certs, String authType) {}
    }
}
