package com.mutecsoft.atalk.logic.test.scenario;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mutecsoft.atalk.logic.AtalkComplex;
import com.mutecsoft.atalk.logic.model.amigo.AddAmigoResponse;
import com.mutecsoft.atalk.logic.model.amigo.AmigoListResponse;
import com.mutecsoft.atalk.logic.model.amigoset.AddAmigoSetRequest;
import com.mutecsoft.atalk.logic.model.amigoset.AddAmigoSetResponse;
import com.mutecsoft.atalk.logic.model.amigoset.AmigoSetListResponse;
import com.mutecsoft.atalk.logic.model.chat.ChatInfoResponse;
import com.mutecsoft.atalk.logic.model.chat.SendChatResponse;
import com.mutecsoft.atalk.logic.model.chathub.ChatHubInfo;
import com.mutecsoft.atalk.logic.model.chathub.ChatHubListInfo;
import com.mutecsoft.atalk.logic.model.chathub.ListChathubResponse;
import com.mutecsoft.atalk.logic.model.chathub.OpenChathubResponse;
import com.mutecsoft.atalk.logic.model.user.SearchUserResponse;

public class AtalkMainScenario7 {

	private static final Logger logger = LoggerFactory.getLogger(AtalkMainScenario7.class);

	public static void main(String [] args) throws Exception {

		// 회원가입, user77777
		// AtalkMainSignupTest777.carryon();
		
		// 로그인 user77777@abc.com
		AtalkMainLoginTest.carryonWithArg("user77777@abc.com", "777777777777777");

		logger.info("#### START - ADD AMIGO SET");
		
		AddAmigoSetRequest reqObj = new AddAmigoSetRequest();
		reqObj.setAmigoSetName("친구그룹1");
		reqObj.setDisplayYn("N");		// display 여부
		
		// 그룹정보 추가
		AddAmigoSetResponse amigoSetInfo = AtalkComplex.instance().addAmigoSet(reqObj);
		
		// 사용자 검색
		// SearchUserResponse userInfo = AtalkComplex.instance().searchUser("user5555");
		SearchUserResponse userInfo2 = AtalkComplex.instance().searchUser("user6666");
		
		// 친구 추가
		List<Long> userNoListToAdd = new ArrayList<Long>();
		// userNoListToAdd.add(userInfo.getUserList().get(0).getUserNo());
		userNoListToAdd.add(userInfo2.getUserList().get(0).getUserNo());
		
		AddAmigoResponse addAmigoResp = AtalkComplex.instance().addAmigo(userNoListToAdd);
		
		// 친구 목록 조회
		AmigoListResponse response = AtalkComplex.instance().getAmigoList();
		
		// 대화방 초대
		String chatTitle = "멀티방 대화방 제목";
		OpenChathubResponse resultObj = AtalkComplex.instance().openChathubWithTitle(
				chatTitle, userNoListToAdd);
		// 오픈 요청한 대화방 정보
		ChatHubInfo chathubInfo = resultObj.getChatHubInfo();
		
		// 대화 목록 조회
		ChatInfoResponse chatInfoObj = AtalkComplex.instance().chatList(
				chathubInfo.getChathubNo()
				, 0L  // 최근 대화부터 조회시 0, 이후에 이전 페이징요청시 결과 데이타의 ChatInfoResponse.lastChatNo 으로 채워야 함.
				, 10
				);

		// 대화방 대화 전송
		SendChatResponse chatResponse = AtalkComplex.instance().sendChat("chat message1", chathubInfo);
		
		// 대화방 목록 정보 조회
		String lastUpdateDt = "2000-01-01 12:00:00";
		ListChathubResponse chatHubList = AtalkComplex.instance().chatHubList(lastUpdateDt);
		
		//////////////////////////////////////////////////////////////////////////////////////////////
		{
			// 파일로 저장
			chatHubList.toFile("D://ATALK//log2/chathubList");
			
			// 파일에서 읽기
			// PairChathubList<ListChathubResponse, Map<Long, ChatHubListInfo>> chathubListInfo = ListChathubResponse.fromFile("D://ATALK//log2/chathubList");
//			ListChathubResponse listChatHubResp = chathubListInfo.key();
//			Map<Long, ChatHubListInfo> chatHubMap = chathubListInfo.value();

			Object [] chathubListInfo = ListChathubResponse.fromFile("D://ATALK//log2/chathubList");
		
			ListChathubResponse listChatHubResp = (ListChathubResponse) chathubListInfo[0];
			Map<Long, ChatHubListInfo> chatHubMap = (Map<Long, ChatHubListInfo>) chathubListInfo[1];
			
			String aa= listChatHubResp.toJson();
			logger.info("#### info : {}", aa);
		}
		//////////////////////////////////////////////////////////////////////////////////////////////
		
		// 대화방 정보 조회
		OpenChathubResponse chatHubInfo2 = AtalkComplex.instance().chatHubInfo(chatHubList.getChatHubListInfo().get(0).getChathubNo(), 10);
		
		
		
		// 두번째 대화방 목록 정보 조회
		// 두번째 조회시에는 목록 안줌. 증분이 변화가 없기 때문.  <- chatHubList.getLastUpdateDt() 이후
		chatHubList = AtalkComplex.instance().chatHubList(chatHubList.getLastUpdateDt());
		
		
	}
}

