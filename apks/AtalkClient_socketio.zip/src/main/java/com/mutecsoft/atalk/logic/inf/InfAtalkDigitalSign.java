package com.mutecsoft.atalk.logic.inf;

import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;

import com.mutecsoft.atalk.logic.model.digitalsign.PacketKeySeed;
import com.mutecsoft.atalk.logic.model.digitalsign.PacketKeySignature;

public interface InfAtalkDigitalSign {
	PacketKeySeed generatePacketKeySeed();
	
	PacketKeySignature generatePacketSignature(String packetKeySeedValue, RSAPrivateKey privateKey, RSAPublicKey pubKey) throws Exception;
}
