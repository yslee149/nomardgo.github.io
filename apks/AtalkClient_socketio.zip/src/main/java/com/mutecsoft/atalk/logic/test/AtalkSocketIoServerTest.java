package com.mutecsoft.atalk.logic.test;

import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;
import okhttp3.OkHttpClient;

import javax.net.ssl.*;

import com.corundumstudio.socketio.Configuration;
import com.corundumstudio.socketio.SocketIOServer;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.net.URI;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.concurrent.CountDownLatch;
public class AtalkSocketIoServerTest {
   public static void main(String[] args) throws Exception {
       // Step 1: Configure server with SSL
       Configuration config = new Configuration();
       config.setHostname("0.0.0.0"); // Allow connections from anywhere
       config.setPort(19092); // Use port 443 if running in production
       config.setOrigin("*");
       
       // Step 2: Enable SSL (TLS)
		try {
			InputStream keystoreStream = new FileInputStream(
				"D:\\WorkspaceMutecsoft\\alpinetalk-dev\\cert\\keystore.pfx");
		       config.setKeyStorePassword("12345"); // Change this
		       config.setKeyStore(keystoreStream); // Path to your keystore file
		       config.setKeyStoreFormat("PKCS12");  // Important: Use PKCS12 format

		} catch (Exception e) {
			System.out.println("@@@@@@@@@@");
		//	System.exit(-1);
		}
       // Step 3: Start server
       SocketIOServer server = new SocketIOServer(config);
       
       // Step 4: Add event listeners
       server.addConnectListener(client -> System.out.println("Client connected: " + client.getSessionId()));
       server.addDisconnectListener(client -> System.out.println("Client disconnected: " + client.getSessionId()));

       // Step 5: Start server and keep running
       server.start();
       System.out.println("✅ Secure Socket.IO server started on port: " + config.getPort());

       // Keep server running
       Runtime.getRuntime().addShutdownHook(new Thread(server::stop));
       System.out.println("gggg");
   }
}
