package com.mutecsoft.atalk.logic.model.chathub;

import java.io.Serializable;

/**
 * @PackageName com.mutecsoft.atalk.logic.model.chathub
 * @fileName	ChatHubUser.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description : 대화방 참여자 사용자정보
 * <pre>
 * 
 * </pre>
 */
public class ChatHubUser implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -245976247312274504L;

	private Long chatHubNo;
	
	private Long userNo;
	private String userName;
	private String statusMessage;
	private String profileFgThumbUrl;
	private String profileFgUrl;
	
	private String profileBgThumbUrl;
	private String profileBgUrl;
	
	///////////////////////////////////////////////////
	private String chathubName;
	private String mainChathubName;
	//
	private String joinYn;
	private String useYn;
	private String notiYn;
	private Long startChatNo;
	private Long readChatNo;
	private Long lastChatNo;
	
	public String getStatusMessage() {
		return statusMessage;
	}
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	public String getProfileFgThumbUrl() {
		return profileFgThumbUrl;
	}
	public void setProfileFgThumbUrl(String profileFgThumbUrl) {
		this.profileFgThumbUrl = profileFgThumbUrl;
	}
	public String getProfileFgUrl() {
		return profileFgUrl;
	}
	public void setProfileFgUrl(String profileFgUrl) {
		this.profileFgUrl = profileFgUrl;
	}
	public String getProfileBgThumbUrl() {
		return profileBgThumbUrl;
	}
	public void setProfileBgThumbUrl(String profileBgThumbUrl) {
		this.profileBgThumbUrl = profileBgThumbUrl;
	}
	public String getProfileBgUrl() {
		return profileBgUrl;
	}
	public void setProfileBgUrl(String profileBgUrl) {
		this.profileBgUrl = profileBgUrl;
	}
	public Long getChatHubNo() {
		return chatHubNo;
	}
	public void setChatHubNo(Long chatHubNo) {
		this.chatHubNo = chatHubNo;
	}
	public String getChathubName() {
		return chathubName;
	}
	public void setChathubName(String chathubName) {
		this.chathubName = chathubName;
	}
	public String getMainChathubName() {
		return mainChathubName;
	}
	public void setMainChathubName(String mainChathubName) {
		this.mainChathubName = mainChathubName;
	}
	public String getJoinYn() {
		return joinYn;
	}
	public void setJoinYn(String joinYn) {
		this.joinYn = joinYn;
	}
	public String getUseYn() {
		return useYn;
	}
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}
	public String getNotiYn() {
		return notiYn;
	}
	public void setNotiYn(String notiYn) {
		this.notiYn = notiYn;
	}
	public Long getStartChatNo() {
		return startChatNo;
	}
	public void setStartChatNo(Long startChatNo) {
		this.startChatNo = startChatNo;
	}
	public Long getReadChatNo() {
		return readChatNo;
	}
	public void setReadChatNo(Long readChatNo) {
		this.readChatNo = readChatNo;
	}
	public Long getLastChatNo() {
		return lastChatNo;
	}
	public void setLastChatNo(Long lastChatNo) {
		this.lastChatNo = lastChatNo;
	}
	public Long getUserNo() {
		return userNo;
	}
	public void setUserNo(Long userNo) {
		this.userNo = userNo;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}

}
