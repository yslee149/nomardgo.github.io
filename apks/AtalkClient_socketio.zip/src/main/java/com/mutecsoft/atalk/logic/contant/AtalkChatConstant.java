package com.mutecsoft.atalk.logic.contant;

public class AtalkChatConstant {
	
	public static final String openNewRoomMessageformat = "%s 방이 개설되었습니다.";
	
	public static final int defaultGetMessageCount = 10;
	
}
