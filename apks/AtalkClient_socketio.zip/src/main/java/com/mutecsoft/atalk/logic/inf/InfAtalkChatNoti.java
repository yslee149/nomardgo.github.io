package com.mutecsoft.atalk.logic.inf;

import com.mutecsoft.atalk.logic.model.noti.ChatDataNoti;
import com.mutecsoft.atalk.logic.model.noti.ExitChathubNoti;
import com.mutecsoft.atalk.logic.model.noti.InviteChathubNoti;
import com.mutecsoft.atalk.logic.model.noti.KickOutChathubNoti;
import com.mutecsoft.atalk.logic.model.noti.ReadChatNoti;
import com.mutecsoft.atalk.logic.model.noti.RetrieveChatNoti;

public interface InfAtalkChatNoti {

	void procExitChathubNoti(ExitChathubNoti notiObj);
	void procInviteChathubNoti(InviteChathubNoti notiObj);
	void procKickOutChathubNoti(KickOutChathubNoti notiObj);
	void procReadChatNoti(ReadChatNoti notiObj);
	void procRetrieveChatNoti(RetrieveChatNoti notiObj);
	void procChatDataNoti(ChatDataNoti notiObj);
}
