package com.mutecsoft.atalk.logic;

import java.io.File;
import java.net.URI;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mutecsoft.atalk.logic.config.PropertyLoader;
import com.mutecsoft.atalk.logic.contant.AtalkConstant;
import com.mutecsoft.atalk.logic.contant.EnumChatType;
import com.mutecsoft.atalk.logic.inf.InfAtalkChatNoti;
import com.mutecsoft.atalk.logic.model.AtalkDataModelAll;
import com.mutecsoft.atalk.logic.model.AtalkPacketBase;
import com.mutecsoft.atalk.logic.model.DummyRequest;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.logic.model.amigo.AddAmigoRequest;
import com.mutecsoft.atalk.logic.model.amigo.AddAmigoResponse;
import com.mutecsoft.atalk.logic.model.amigo.AmigoDetailResponse;
import com.mutecsoft.atalk.logic.model.amigo.AmigoListResponse;
import com.mutecsoft.atalk.logic.model.amigo.DeleteAmigoRequest;
import com.mutecsoft.atalk.logic.model.amigo.DeleteAmigoResponse;
import com.mutecsoft.atalk.logic.model.amigoset.AddAmigoSetRequest;
import com.mutecsoft.atalk.logic.model.amigoset.AddAmigoSetResponse;
import com.mutecsoft.atalk.logic.model.auth.UserLoginRequest;
import com.mutecsoft.atalk.logic.model.auth.UserLoginResponse;
import com.mutecsoft.atalk.logic.model.chat.Chat;
import com.mutecsoft.atalk.logic.model.chat.ChatExt;
import com.mutecsoft.atalk.logic.model.chat.ChatInfoRequest;
import com.mutecsoft.atalk.logic.model.chat.ChatInfoResponse;
import com.mutecsoft.atalk.logic.model.chat.ExtChatRequest;
import com.mutecsoft.atalk.logic.model.chat.ExtChatResponse;
import com.mutecsoft.atalk.logic.model.chat.SendChatRequest;
import com.mutecsoft.atalk.logic.model.chat.SendChatResponse;
import com.mutecsoft.atalk.logic.model.chat.SendFileChatRequest;
import com.mutecsoft.atalk.logic.model.chat.SendFileChatResponse;
import com.mutecsoft.atalk.logic.model.chathub.ChatHubInfo;
import com.mutecsoft.atalk.logic.model.chathub.ChatHubListInfo;
import com.mutecsoft.atalk.logic.model.chathub.ChatInfoLast;
import com.mutecsoft.atalk.logic.model.chathub.ChathubInfoRequest;
import com.mutecsoft.atalk.logic.model.chathub.ListChathubRequest;
import com.mutecsoft.atalk.logic.model.chathub.ListChathubResponse;
import com.mutecsoft.atalk.logic.model.chathub.OpenChathubRequest;
import com.mutecsoft.atalk.logic.model.chathub.OpenChathubResponse;
import com.mutecsoft.atalk.logic.model.chathub.OpenChathubWithTitleRequest;
import com.mutecsoft.atalk.logic.model.digitalsign.PacketKeySeed;
import com.mutecsoft.atalk.logic.model.noti.ChatDataNoti;
import com.mutecsoft.atalk.logic.model.noti.ExitChathubNoti;
import com.mutecsoft.atalk.logic.model.noti.InviteChathubNoti;
import com.mutecsoft.atalk.logic.model.noti.KickOutChathubNoti;
import com.mutecsoft.atalk.logic.model.noti.ReadChatNoti;
import com.mutecsoft.atalk.logic.model.noti.RetrieveChatNoti;
import com.mutecsoft.atalk.logic.model.pi.PiAgreementResponse;
import com.mutecsoft.atalk.logic.model.signup.SignupRequest;
import com.mutecsoft.atalk.logic.model.signup.SignupResponse;
import com.mutecsoft.atalk.logic.model.user.SearchUserRequest;
import com.mutecsoft.atalk.logic.model.user.SearchUserResponse;
import com.mutecsoft.atalk.logic.util.AesEncDecComplex;
import com.mutecsoft.atalk.logic.util.AtalkPacketUtil;
import com.mutecsoft.atalk.logic.util.BufferComplex;
import com.mutecsoft.atalk.logic.util.DigitalSignComplex;
import com.mutecsoft.atalk.logic.util.HashComplex;
import com.mutecsoft.atalk.logic.util.RandomHexString;
import com.mutecsoft.atalk.logic.util.RsaComplex;

import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class AtalkComplex {
	public static String REQ_HOST_VAL = "http://chillaxmax.kr:9095";
	// public static String REQ_HOST_VAL = "http://localhost:9095";
	
	public static String CNTXT_NAME = "/atalk3";
	// public static String CNTXT_NAME = "/atalk2";

	AtalkWebsocketClient atalkWebsocketClient;
	
	//////////// WEBSOCKET SECURE CONN INFO
	public static String WEBSOCKET_SECURE_CONN_HOST = "wss://chillaxmax.kr:29095";
	// public static String WEBSOCKET_SECURE_CONN_HOST = "wss://localhost:29095";
	
	private static final Logger logger = LoggerFactory.getLogger(AtalkComplex.class);
	
	int extChatBaseSize = 1000;
	
	Map<String, Object>	_keyMap = null;
	
	private static AtalkComplex _inst = null; 
	
	private AtalkDigitalSignImpl atalkDigitalSign = null;
	
	ObjectMapper objMapper = null;
	
	////////////////////////////////////////
	String packetSeedValue = null;
	String PACKET_KEY = null;
	
	String accessToken = null;
	String refreshToken = null;
	
	UserLoginResponse userInfo = null;
	
	String serverPublicKey = null;
	
	InfAtalkChatNoti atalkcChatNotiImpl = null;  // 로그인 후에 설정해야 함. 실시간 수신 메시지 처리용
	public UserLoginResponse getUserInfo() {
		
		return userInfo;
	}

	public void setUserInfo(UserLoginResponse userInfo) {
		this.userInfo = userInfo;
	}
	
	/**
	 * 
	 */
	private AtalkComplex() {}

	public void reset() {
		this.PACKET_KEY = null;
		this.packetSeedValue = null;
	}
	
	/**
	 * @throws Exception 
	 * 
	 */
	private void keyCompilation() throws Exception {

		Properties properties = PropertyLoader.loadProperties();
		String privateKeyPath = properties.getProperty("atalk.key.private-key-path");
		String publicKeyPath = properties.getProperty("atalk.key.public-key-path");
		
		if (Files.exists(Paths.get(privateKeyPath)) && Files.exists(Paths.get(publicKeyPath))) {
			byte [] bytes = Files.readAllBytes(Paths.get(privateKeyPath));
			String rsaPrivateKey = new String(bytes);
			bytes = Files.readAllBytes(Paths.get(publicKeyPath));
			String rsaPublicKey = new String(bytes);
			_keyMap = RsaComplex.loadKeyPair(rsaPrivateKey, rsaPublicKey);
		} else {
			_keyMap = RsaComplex.getKeys(4096);
//			RSAPublicKey pubkey = (RSAPublicKey)_inst._keyMap.get("PUBLIC");
//			RSAPrivateKey privateKey = (RSAPrivateKey)_keyMap.get("PRIVATE");
		}
	}
	
	/**
	 * 테스트용임. 키 바꿨을 때 동작여부
	 * 
	 * @throws Exception 
	 * 
	 */
	private void keyCompilation2() throws Exception {

		Properties properties = PropertyLoader.loadProperties();
		String privateKeyPath = properties.getProperty("atalk.key.private-key-path2");
		String publicKeyPath = properties.getProperty("atalk.key.public-key-path2");
		
		if (Files.exists(Paths.get(privateKeyPath)) && Files.exists(Paths.get(publicKeyPath))) {
			byte [] bytes = Files.readAllBytes(Paths.get(privateKeyPath));
			String rsaPrivateKey = new String(bytes);
			bytes = Files.readAllBytes(Paths.get(publicKeyPath));
			String rsaPublicKey = new String(bytes);
			_keyMap = RsaComplex.loadKeyPair(rsaPrivateKey, rsaPublicKey);
		} else {
			_keyMap = RsaComplex.getKeys(4096);
			
			// RsaComplex.toFile(_keyMap, "D:/AtalkClient/keys/myappPrivkey2", "D:/AtalkClient/keys/myappPubkey2");
		}
	}
	
	/**
	 * 
	 * @param mqHost
	 * @param mqPort
	 * @param mqUser
	 * @param mqPassword
	 * @param inf
	 * @throws Exception
	 */
//	public void postLoginSuccess(
//			String mqHost
//			, int mqPort
//			, String mqUser
//			, String mqPassword
//			, InfAtalkChatNoti inf) throws Exception {
//		Properties properties = PropertyLoader.loadProperties();
//		String privateKeyPath = properties.getProperty("atalk.key.private-key-path");
//		String publicKeyPath = properties.getProperty("atalk.key.public-key-path");
//		
//		if (!Files.exists(Paths.get(privateKeyPath)) 
//				|| !Files.exists(Paths.get(publicKeyPath))) {
//			RsaComplex.toFile(_keyMap, privateKeyPath, publicKeyPath);
//		}
//		this.atalkcChatNotiImpl = inf;
//		
//		this.mqHost= mqHost;
//		this.mqPort= mqPort;
//		this.mqUser= mqUser;
//		this.mqPassword= mqPassword;
//		// rabbitmq 
//		
//		Thread consumer = new Thread(new Runnable() {
//			
//			@Override
//			public void run() {
//				try {
//					String QUEUE_NAME = String.format("Q_%s_%d", 
//							AtalkComplex.instance().getUserInfo().getImei(),
//							AtalkComplex.instance().getUserInfo().getUserNo());
//					
//					ConnectionFactory factory = new ConnectionFactory();
//			        factory.setHost(AtalkComplex.instance().getMqHost());
//			        factory.setPort(AtalkComplex.instance().getMqPort());
//			        factory.setUsername(AtalkComplex.instance().getMqUser());
//			        factory.setPassword(AtalkComplex.instance().getMqPassword());
//		        
//		        	Connection connection = factory.newConnection();
//			        Channel channel = connection.createChannel();
//			        channel.queueDeclare(QUEUE_NAME, false, false, true, null);
//			        
//			        
//			        // MQ 실시간 메시지 처리
//			        DeliverCallback deliverCallback = (consumerTag, delivery) -> {
//			        	try {
//				        	String myMessage = new String(delivery.getBody(), "UTF-8");
//				            String pktSeedVal = myMessage.substring(myMessage.length() - 32);
//							// seedVal check
//							if (pktSeedVal.equals(AtalkComplex.instance().getPacketSeedValue())) {
//								
//								// realtime code value check
//								String codeVal = myMessage.substring(myMessage.length() - 34, myMessage.length() - 32);
//								int code = Integer.parseInt(codeVal, 16);
//								String notiJson = myMessage.substring(0, myMessage.length() - 34);
//								SecureDataModel respObj = SecureDataModel.fromBuffer(notiJson);
//								
//								switch(code) {
//								
//								case AtalkConstant.MSG_CODE_INVITE_NOTI:
//									{
//										InviteChathubNoti responseData = SecureDataModel.fromEncHexBuffer(respObj.getData()
//												, AtalkComplex.instance().getPACKET_KEY()
//												, InviteChathubNoti.class);
//										atalkcChatNotiImpl.procInviteChathubNoti(responseData);
//									}
//									break;
//								case AtalkConstant.MSG_CODE_EXIT_NOTI:
//									{
//										ExitChathubNoti responseData = SecureDataModel.fromEncHexBuffer(respObj.getData()
//												, AtalkComplex.instance().getPACKET_KEY()
//												, ExitChathubNoti.class);
//										atalkcChatNotiImpl.procExitChathubNoti(responseData);
//									}
//									break;
//								case AtalkConstant.MSG_CODE_KICKOUT_NOTI:
//									{
//										KickOutChathubNoti responseData = SecureDataModel.fromEncHexBuffer(respObj.getData()
//												, AtalkComplex.instance().getPACKET_KEY()
//												, KickOutChathubNoti.class);
//										atalkcChatNotiImpl.procKickOutChathubNoti(responseData);
//									}
//									break;
//								case AtalkConstant.MSG_CODE_READ_NOTI:
//									{
//										ReadChatNoti responseData = SecureDataModel.fromEncHexBuffer(respObj.getData()
//												, AtalkComplex.instance().getPACKET_KEY()
//												, ReadChatNoti.class);
//										atalkcChatNotiImpl.procReadChatNoti(responseData);
//									}
//									break;
//								case AtalkConstant.MSG_CODE_RETREIVE_CHAT_NOTI:
//									{
//										RetrieveChatNoti responseData = SecureDataModel.fromEncHexBuffer(respObj.getData()
//												, AtalkComplex.instance().getPACKET_KEY()
//												, RetrieveChatNoti.class);
//										atalkcChatNotiImpl.procRetrieveChatNoti(responseData);
//									}
//									break;
//								case AtalkConstant.MSG_CODE_CHAT_NOTI:
//								{
//									ChatDataNoti responseData = SecureDataModel.fromEncHexBuffer(respObj.getData()
//											, AtalkComplex.instance().getPACKET_KEY()
//											, ChatDataNoti.class);
//									atalkcChatNotiImpl.procChatDataNoti(responseData);
//								}
//								
//								default:
//										break;
//								}
//							}
//			        	} catch (Exception e) {
//			        		// 
//			        	}
//			        	
//			        };
//			        channel.basicConsume(QUEUE_NAME, true, deliverCallback, consumerTag -> { });
//		        } catch (Exception e) {
//		        	logger.error("@@@@ e: {}", e);
//		        }
//			}
//		});
//		consumer.start();
//	}

	/**
	 * 로그인 후 websocket secure 접속.
	 * 
	 * @param websocketConnUri
	 * @param inf
	 * @throws Exception
	 */
	public void postLoginSuccess(
			String websocketConnUri
			, InfAtalkChatNoti inf) throws Exception {
		Properties properties = PropertyLoader.loadProperties();
		String privateKeyPath = properties.getProperty("atalk.key.private-key-path");
		String publicKeyPath = properties.getProperty("atalk.key.public-key-path");
		
		if (!Files.exists(Paths.get(privateKeyPath)) 
				|| !Files.exists(Paths.get(publicKeyPath))) {
			RsaComplex.toFile(_keyMap, privateKeyPath, publicKeyPath);
		}
		this.atalkcChatNotiImpl = inf;
		
		Thread consumer = new Thread(new Runnable() {
			@Override
			public void run() {
				try {
					
					// Step 1: Create SSLContext (trust all certificates for testing)
					SSLContext sslContext = createSSLContext();

					// Step 2: Create a custom OkHttpClient with SSL settings
					OkHttpClient okHttpClient = new OkHttpClient.Builder()
							.sslSocketFactory(sslContext.getSocketFactory(), new TrustAllX509TrustManager()) // Apply SSL
							.hostnameVerifier((hostname, session) -> true) // Accept all hostnames (for testing)
							.build();

					// Step 3: Configure secure Socket.IO connection
					IO.setDefaultOkHttpCallFactory(okHttpClient); // Set global OkHttpClient
					IO.setDefaultOkHttpWebSocketFactory(okHttpClient); // Set WebSocketFactory globally

					IO.Options options = IO.Options.builder()
							.setSecure(true) // Enable SSL
							.setReconnection(true) // Auto-reconnect
							.setForceNew(true) // Always create a new connection
							.build();

					// Step 4: Connect to the secure Socket.IO server
					String genAccessToken = generateEncAccessToken();
					Long userNo = instance().userInfo.getUserNo();
					
					final String wssUri = WEBSOCKET_SECURE_CONN_HOST + "?token="+genAccessToken+"&user_no="+userNo; 
					Socket socket = IO.socket(new URI(wssUri), options);

					// Step 5: Handle successful connection
					socket.on(Socket.EVENT_CONNECT, args1 -> {
						System.out.println("✅ Secure connection established!");
						// socket.emit("message", "Hello from Secure Client!");
					});

					// Step 6: Handle incoming messages
					socket.on("message", (Emitter.Listener) args -> {
						try {
							logger.info("#### : args1 size : {}, data : {}", args.length, args[0]);
							for (Object message : args) {
					        	String myMessage = (String)message;
									
								// realtime code value check
								String codeVal = myMessage.substring(myMessage.length() - 2);
								int code = Integer.parseInt(codeVal, 16);
								String notiJson = myMessage.substring(0, myMessage.length() - 2);
								switch(code) {
								
								case AtalkConstant.MSG_CODE_INVITE_NOTI:
									{
										InviteChathubNoti responseData = AtalkPacketBase.fromJson(notiJson, InviteChathubNoti.class);
										atalkcChatNotiImpl.procInviteChathubNoti(responseData);
									}
									break;
								case AtalkConstant.MSG_CODE_EXIT_NOTI:
									{
										ExitChathubNoti responseData = AtalkPacketBase.fromJson(notiJson, ExitChathubNoti.class);
										atalkcChatNotiImpl.procExitChathubNoti(responseData);
									}
									break;
								case AtalkConstant.MSG_CODE_KICKOUT_NOTI:
									{
										KickOutChathubNoti responseData = AtalkPacketBase.fromJson(notiJson, KickOutChathubNoti.class);
										atalkcChatNotiImpl.procKickOutChathubNoti(responseData);
									}
									break;
								case AtalkConstant.MSG_CODE_READ_NOTI:
									{
										ReadChatNoti responseData = AtalkPacketBase.fromJson(notiJson, ReadChatNoti.class);
										atalkcChatNotiImpl.procReadChatNoti(responseData);
									}
									break;
								case AtalkConstant.MSG_CODE_RETREIVE_CHAT_NOTI:
									{
										RetrieveChatNoti responseData = AtalkPacketBase.fromJson(notiJson, RetrieveChatNoti.class);
										atalkcChatNotiImpl.procRetrieveChatNoti(responseData);
									}
									break;
								case AtalkConstant.MSG_CODE_CHAT_NOTI:
								{
									ChatDataNoti responseData = AtalkPacketBase.fromJson(notiJson, ChatDataNoti.class);
									atalkcChatNotiImpl.procChatDataNoti(responseData);
								}
								
								default:
										break;
								}
							}
			        	} catch (Exception e) {
			        		// 
			        	}
						
					});

					// Step 7: Handle disconnection
					socket.on(Socket.EVENT_DISCONNECT, args1 -> {
						
						// 재 로그인 처리 필요함.
						logger.error("@@@@ Disconnected from server");
					});
					// Step 8: Connect to the server
					socket.connect();
					// Step 9: Prevent program from exiting
					// new CountDownLatch(1).await();
		        } catch (Exception e) {
		        	logger.error("@@@@ e: {}", e);
		        }
			}
		});
		consumer.start();
	}
    
	
	/**
	 * 
	 * @return
	 * @throws Exception 
	 * @throws FileNotFoundException 
	 */
	public static AtalkComplex instance() throws Exception {
		if (_inst == null) {
			_inst = new AtalkComplex();
			_inst.atalkDigitalSign = new AtalkDigitalSignImpl();
			_inst.objMapper = new ObjectMapper();
			_inst.keyCompilation();
			// _inst.keyCompilation2();
		}
		return _inst;
	}
	
	public String getSigningMessage() throws NoSuchAlgorithmException {
		
//		RSAPublicKey pubkey = (RSAPublicKey)_keyMap.get("PUBLIC");
//		RSAPrivateKey privateKey = (RSAPrivateKey)_keyMap.get("PRIVATE");
//		
		String signingMessagePlain = DigitalSignComplex.generateSigningMessage(32);
		return signingMessagePlain;
	}
	
	public static String toPacketData(AtalkDataModelAll model) throws Exception {
		return AtalkComplex.instance().objMapper.writeValueAsString(model.getSecureModel());
	}
	
	public String getPacketSeedValue() {
		return packetSeedValue;
	}

	public void setPacketSeedValue(String packetSeedValue) {
		this.packetSeedValue = packetSeedValue;
	}
		
	////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////
	
	/**
	 * 
	 * @return
	 * @throws Exception 
	 */
	public AtalkDataModelAll generatePacketKeySeed() throws Exception {
		this.packetSeedValue = null;
		this.PACKET_KEY = null;
		
		AtalkDataModelAll requestDataModelAll = new AtalkDataModelAll();
		requestDataModelAll.setAtalkPacketBase(this.atalkDigitalSign.generatePacketKeySeed(), null);
		return requestDataModelAll;
	}
	
	/**
	 * 
	 * @param seedValue
	 * @return
	 * @throws Exception 
	 */
	public AtalkDataModelAll generateSignature() throws Exception {
		
		RSAPrivateKey prvKey = (RSAPrivateKey)_keyMap.get("PRIVATE");
		RSAPublicKey pubKey = (RSAPublicKey) _keyMap.get("PUBLIC");
		
		AtalkDataModelAll requestDataModelAll = new AtalkDataModelAll();
		requestDataModelAll.setAtalkPacketBase(
				this.atalkDigitalSign.generatePacketSignature(this.packetSeedValue, prvKey, pubKey)
				, null);
		return requestDataModelAll;
	}
	
	/**
	 * 
	 * 
	 * @param respModel
	 * @return
	 */
	public String determinePacketKey(SecureDataModel respModel) {
		RSAPrivateKey prvKey = (RSAPrivateKey)_keyMap.get("PRIVATE");
		this.PACKET_KEY = RsaComplex.decrypt(respModel.getData(), prvKey);
		return this.PACKET_KEY;
	}

	/**
	 * 
	 * @return
	 */
	public String getPACKET_KEY() {
		return this.PACKET_KEY;
	}
	
	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	public String getRefreshToken() {
		return refreshToken;
	}

	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken;
	}
	
	public String getPrivateKey() throws Exception {
		RSAPrivateKey prvKey = (RSAPrivateKey)_keyMap.get("PRIVATE");
		return RsaComplex.encodeBase64(prvKey.getEncoded());
	}
	
	public String getPublicKey() throws Exception {
		RSAPublicKey pubKey = (RSAPublicKey) _keyMap.get("PUBLIC");
		return RsaComplex.encodeBase64(pubKey.getEncoded());
	}

	
	public String getServerPublicKey() throws Exception {
		return this.serverPublicKey;
	}
	
	public void setServerPublicKey(String serverPublicKey) throws Exception {
		this.serverPublicKey = serverPublicKey;
	}

	public int getExtChatBaseSize() {
		return extChatBaseSize;
	}

	public void setExtChatBaseSize(int extChatBaseSize) {
		this.extChatBaseSize = extChatBaseSize;
	}
	
	/**
	 * 
	 * @param atalkPacketObj
	 * @return
	 * @throws Exception 
	 * @throws JsonProcessingException
	 */
	public SecureDataModel toEncPacket(AtalkPacketBase atalkPacketObj) throws Exception {

		return atalkPacketObj.toFinalModel(packetSeedValue, PACKET_KEY);
		
	}

	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	public String generateEncAccessToken() throws Exception {
		String jwtToken = getAccessToken();
		byte [] encJwtToken = AesEncDecComplex.encryptAesCtrWithRandomIv(
				jwtToken.getBytes()
				, getPACKET_KEY());
		String encJwtHexToken = AesEncDecComplex.bytesToHex(encJwtToken);
		encJwtHexToken = String.format("%s%s", encJwtHexToken, getPacketSeedValue());
		return encJwtHexToken;
	}
	
	/**
	 * 대화방 키 복호화
	 * 
	 * @param chathubEncKey
	 * @return
	 */
	public String decryptChathubKey(String chathubEncKey) {
		try {
			return RsaComplex.decrypt(chathubEncKey, this.getPrivateKey());
		} catch (Exception e) {
			return "";
		}
	}
	
	/**
	 * 대화방 키 서버 공개키로 암호화
	 * 
	 * @param chathubPlainKey
	 * @return
	 */
	public String encryptChathubKeyWithServerKey(String chathubPlainKey) {
		try {
			return RsaComplex.encrypt(chathubPlainKey, this.serverPublicKey);
		} catch (Exception e) {
			return "";
		}
	}







	public InfAtalkChatNoti getAtalkcChatNotiImpl() {
		return atalkcChatNotiImpl;
	}

	public void setAtalkcChatNotiImpl(InfAtalkChatNoti atalkcChatNotiImpl) {
		this.atalkcChatNotiImpl = atalkcChatNotiImpl;
	}

	//////////////////////////////////////////////////

	/**
	 * 
	 * @throws Exception
	 */
	public void determinePacketKey() throws Exception {
		String determinePacketKeyUrl1 = REQ_HOST_VAL + CNTXT_NAME +"/api/v1/digitalSign/seedvalue";
		String determinePacketKeyUrl2 = REQ_HOST_VAL + CNTXT_NAME +"/api/v1/digitalSign/doSign";
		String packetKeySeedValue = "";
		{
			AtalkDataModelAll secureModel = AtalkComplex.instance().generatePacketKeySeed();
			OkHttpClient client = new OkHttpClient().newBuilder()
							.connectTimeout(40, TimeUnit.SECONDS)  // Connection timeout
				            .readTimeout(40, TimeUnit.SECONDS)     // Read timeout
				            .writeTimeout(40, TimeUnit.SECONDS)    // Write timeout
				            .build();
			
			String json = AtalkComplex.toPacketData(secureModel);
			
			logger.info("## REQDATA : {}", json);
			
			MediaType jsonMediaType = MediaType.get("application/json; charset=utf-8");
			RequestBody body = RequestBody.Companion.create(json, jsonMediaType);
			Request request = new Request.Builder()
					.url(determinePacketKeyUrl1)
					.post(body)
					.build();
			try (Response response = client.newCall(request).execute()) {
				if (response.isSuccessful()) {
					logger.info("Response: http code : {}, value : {}",
							response.code()
							, response.body().string());
					AtalkComplex.instance().setPacketSeedValue(((PacketKeySeed)secureModel.getAtalkPacketBase()).getSeedValue());
					packetKeySeedValue = AtalkComplex.instance().getPacketSeedValue();
					logger.info("## packetKeySeedValue : {}", packetKeySeedValue);
				} else {
					logger.error("Error: " + response.code());
					logger.error("@@@@@@@@@ DIGITALSIGN HALTED CASE 1");
					
				}
			} catch (Exception e) {
				logger.error("@@@@@@@@@ DIGITALSIGN HALTED CASE 2 : {}", e);
				
			}
		}
		{
			AtalkDataModelAll secureModel = AtalkComplex.instance().generateSignature();
			OkHttpClient client = new OkHttpClient();
			String json = AtalkComplex.toPacketData(secureModel);
			
			logger.info("## REQDATA : {}", json);
			
			MediaType jsonMediaType = MediaType.get("application/json; charset=utf-8");
			RequestBody body = RequestBody.Companion.create(json, jsonMediaType);
			Request request = new Request.Builder()
					.url(determinePacketKeyUrl2)
					.post(body)
					.build();
			try (Response response = client.newCall(request).execute()) {
				if (response.isSuccessful()) {
					// logger.info("Response: " + response.body().string());
					String responseBuffer = response.body().string();
					logger.info("Response: {}", responseBuffer);
					SecureDataModel responseModel = SecureDataModel.fromBuffer(responseBuffer);
					String PACKET_KEY = AtalkComplex.instance().determinePacketKey(responseModel);
					
					logger.info("########## SET PACKET KEY : {}", PACKET_KEY);
					
				} else {
					logger.error("Error: " + response.code());
				}
			} catch (Exception e) {
				logger.error("@@@@ : " + e);
			}
		}
	}

	/**
	 * 개인정보 요청
	 * 
	 * @return
	 * @throws Exception
	 */
	public PiAgreementResponse getPersonalInfoAgreement() throws Exception {
		PiAgreementResponse responseData = null;
		String piAgreementContentUrl = REQ_HOST_VAL + CNTXT_NAME +"/api/v1/pi/getLatest";
		{
			responseData = AtalkPacketUtil.requestAtalkMessageNoAuth(
					new DummyRequest()
					, PiAgreementResponse.class
					, piAgreementContentUrl
					);
			if (responseData != null) {
				logger.info("### RESP DATA : {}",
						AtalkPacketBase.printAllFields(responseData));
				logger.info("#### RESP JSON : {}", responseData.toJson());
			}
		}
		return responseData;
	}
	
	/**
	 * 회원가입요청
	 * 
	 * @param signupReq
	 * @param multipartFileName
	 * @param profileFgFile
	 * @param profileBgFile
	 * @throws Exception
	 */
	public SignupResponse doSignup(SignupRequest signupReq
			, String multipartFileName
			, File profileFgFile
			, File profileBgFile) throws Exception {
		SignupResponse responseData = null;
		String signupUrl = REQ_HOST_VAL + CNTXT_NAME +"/api/v1/user/signup";
		{
			
			AtalkDataModelAll secureModel = new AtalkDataModelAll();
			secureModel.setSecureModel(
					AtalkComplex.instance().toEncPacket(signupReq));
			
			// 패킷키
			String packetKey = AtalkComplex.instance().getPACKET_KEY();
			
			List<String> fileNameList = new ArrayList<String>();
			List<byte []> profileEncBufferList = new ArrayList<byte []>();
			
			/////////////////////////////////////////////////////////////////////////
			if (profileFgFile != null && multipartFileName != null && !multipartFileName.isBlank()) {
				// foreground 프로필 이미지 버퍼 및 파일명 처리
				Object [] retFileObjArr = BufferComplex.getFileDataAndFileName(profileFgFile.getPath());
				byte [] plainBuffer = (byte [])retFileObjArr[0];
				String fileName =(String)retFileObjArr[1];

				fileNameList.add(fileName);
				byte [] encBuffer = AesEncDecComplex.encryptAesCtrWithRandomIv(
						plainBuffer
						, packetKey);
				profileEncBufferList.add(encBuffer);
				
				if (profileBgFile != null) {
					retFileObjArr = BufferComplex.getFileDataAndFileName(profileBgFile.getPath());
					plainBuffer = (byte [])retFileObjArr[0];
					fileName =(String)retFileObjArr[1];
					fileNameList.add(fileName);
					encBuffer = AesEncDecComplex.encryptAesCtrWithRandomIv(
							plainBuffer
							, packetKey);
					profileEncBufferList.add(encBuffer);
				}
				// foreground 프로필 이미지 버퍼 및 파일명 처리
			}
			/////////////////////////////////////////////////////////////////////////
			responseData = AtalkPacketUtil.requestAtalkFileListMessageWithoutAuth(
					secureModel.getSecureModel()
					, SignupResponse.class
					, signupUrl
					, multipartFileName
					, profileEncBufferList
					, fileNameList
					);
			if (responseData != null) {
				logger.info("### RESP DATA : {}",
						AtalkPacketBase.printAllFields(responseData));
				logger.info("#### RESP JSON : {}", responseData.toJson());
			}
		}
		return responseData;
	}
	
	/**
	 * 로그인 요청
	 * 
	 * @param userId
	 * @param passwordPlain
	 * @param imei
	 * @param deviceType
	 * @param pushToken
	 * @param atalkInf
	 * @throws Exception
	 */
	public void login(
			String userId
			, String passwordPlain
			, String imei
			, String deviceType
			, String pushToken
			, InfAtalkChatNoti atalkInf
			) throws Exception {
			
		String signupUrl = REQ_HOST_VAL + CNTXT_NAME +"/api/v1/auth/login";
		{
			UserLoginRequest reqObj = new UserLoginRequest();
			
			reqObj.setPassword(HashComplex.hashWithSha512(passwordPlain, 1));
			reqObj.setUserId(userId);
			reqObj.setClientPublicKey(AtalkComplex.instance().getPublicKey());
			reqObj.setImei(imei);
			reqObj.setDeviceType(deviceType);
			reqObj.setPushToken(pushToken);
			//MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA1O14NAJpoxj45hCf8hT0U7IzZrMLnhx+D0hJtVm0h2tvIUXRDiJkI2W+m20gWWoM667NuqlQ8A3Gb/KIe1YM/mqc1nY2nC969hfG/kL9fcD/vPMNDyOl0YMidpUdAI9vXEj9v++uaVP4OjtPstw5p9Me2aX1yGNj5onPtz6sfTqTdP9JsBPBXBdroS9BPxYqqiyFv97NWBSOm5b2RAX9FWV/pJc1PhohbuBZkKWR/WlBHoFhTCyhvrBDSWfjpLfXR1BXl9QC1XTvPthMsx5k23FCt1ybNc4JdDkhHPAcgIy02c515Bxb5vchPvqd0r7KvoDvyonvAy6Imor6jD3RJCkDCu28lJW4wZ7hr4KMC3cwlVc8jdXyVGmOdtPujFvEd7XW/NkYhzM7/mbAWAxEUmIFWRATZPt6fOu2tcY4d2scSQN+qluZE3nw/9iCHHIc7zY7NdSzlcCgFyOSMYqMYYV6BbvGcBvzDqytt2/gigGpA3JMRzqF3mCa8D7ZxXEfZ/QelPD+xwiVvLuYWtZOYUzqswaYWqPoy8arqkyCyGfiErRkkdzZ9CO4AZW/quTnC7EFBs8/PLwfJD9hS8x5l/dqiiKLzr0WISIp7fVHJZr9GZ8d1CFmH7oX0JPcjJN9h67mU9Q2MLxa0IW7nE3CyTlSQwF/hPrh8/iFL3EP4UkCAwEAAQ==
			
			logger.info(signupUrl);
			
			AtalkDataModelAll secureModel = new AtalkDataModelAll();
			secureModel.setSecureModel(
					AtalkComplex.instance().toEncPacket(reqObj));
			logger.info("############# 1. client -> server : login value");
			String json = AtalkComplex.toPacketData(secureModel);
			logger.info("## REQDATA : {}", json);
			
			OkHttpClient client = new OkHttpClient().newBuilder()
					.connectTimeout(40, TimeUnit.SECONDS)  // Connection timeout
		            .readTimeout(40, TimeUnit.SECONDS)     // Read timeout
		            .writeTimeout(40, TimeUnit.SECONDS)    // Write timeout
		            .build();
			
			MediaType jsonMediaType = MediaType.get("application/json; charset=utf-8");
			RequestBody body = RequestBody.Companion.create(json, jsonMediaType);
			Request request = new Request.Builder()
					.url(signupUrl)
					.post(body)
					.build();
			try (Response response = client.newCall(request).execute()) {
				if (response.isSuccessful()) {
					String responseJson = response.body().string();
					logger.info("Response: http code : {}, value : {}", 
							response.code()
							, responseJson);
					SecureDataModel respObj = SecureDataModel.fromBuffer(responseJson);
				
					final UserLoginResponse responseData = SecureDataModel.fromEncHexBuffer(respObj.getData()
							, AtalkComplex.instance().getPACKET_KEY()
							, UserLoginResponse.class);
					logger.info("### RESP DATA : {}",
							AtalkPacketBase.printAllFields(responseData));
					logger.info("#### RESP JSON : {}", responseData.toJson());
					if (!responseData.getError().getCode().equals(0L)) {
						logger.info("@@@@@@@@@ LOGIN FAILED : code : {}", 
								responseData.getError().getCode());
						return;
					}
					AtalkComplex.instance().setAccessToken(responseData.getAccessToken());
					AtalkComplex.instance().setRefreshToken(responseData.getRefreshToken());
					AtalkComplex.instance().setServerPublicKey(responseData.getServerPublicKey());
					AtalkComplex.instance().setUserInfo(responseData);
					
					AtalkComplex.instance().postLoginSuccess(
							AtalkComplex.WEBSOCKET_SECURE_CONN_HOST
								, atalkInf
							);
				} else {
					logger.error("Error: " + response.code());
					logger.error("@@@@@@@@@ LOGIN ERR CASE 1");
				}
			} catch (Exception e) {
				logger.error("@@@@@@@@@ LOGIN ERR CASE 2 : {}", e);
			}
		}
	}

	/**
	 * 로그인 요청
	 * 
	 * @param userId
	 * @param passwordPlain
	 * @param imei
	 * @param deviceType
	 * @param pushToken
	 * @param atalkInf
	 * @throws Exception
	 */
	public void loginTest(
			String userId
			, String passwordPlain
			, String imei
			, String deviceType
			, String pushToken
			, InfAtalkChatNoti atalkInf
			) throws Exception {
		
		keyCompilation2();
			
		String signupUrl = REQ_HOST_VAL + CNTXT_NAME +"/api/v1/auth/login";
		{
			UserLoginRequest reqObj = new UserLoginRequest();
			
			reqObj.setPassword(HashComplex.hashWithSha512(passwordPlain, 1));
			reqObj.setUserId(userId);
			reqObj.setClientPublicKey(AtalkComplex.instance().getPublicKey());
			reqObj.setImei(imei);
			reqObj.setDeviceType(deviceType);
			reqObj.setPushToken(pushToken);
			//MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA1O14NAJpoxj45hCf8hT0U7IzZrMLnhx+D0hJtVm0h2tvIUXRDiJkI2W+m20gWWoM667NuqlQ8A3Gb/KIe1YM/mqc1nY2nC969hfG/kL9fcD/vPMNDyOl0YMidpUdAI9vXEj9v++uaVP4OjtPstw5p9Me2aX1yGNj5onPtz6sfTqTdP9JsBPBXBdroS9BPxYqqiyFv97NWBSOm5b2RAX9FWV/pJc1PhohbuBZkKWR/WlBHoFhTCyhvrBDSWfjpLfXR1BXl9QC1XTvPthMsx5k23FCt1ybNc4JdDkhHPAcgIy02c515Bxb5vchPvqd0r7KvoDvyonvAy6Imor6jD3RJCkDCu28lJW4wZ7hr4KMC3cwlVc8jdXyVGmOdtPujFvEd7XW/NkYhzM7/mbAWAxEUmIFWRATZPt6fOu2tcY4d2scSQN+qluZE3nw/9iCHHIc7zY7NdSzlcCgFyOSMYqMYYV6BbvGcBvzDqytt2/gigGpA3JMRzqF3mCa8D7ZxXEfZ/QelPD+xwiVvLuYWtZOYUzqswaYWqPoy8arqkyCyGfiErRkkdzZ9CO4AZW/quTnC7EFBs8/PLwfJD9hS8x5l/dqiiKLzr0WISIp7fVHJZr9GZ8d1CFmH7oX0JPcjJN9h67mU9Q2MLxa0IW7nE3CyTlSQwF/hPrh8/iFL3EP4UkCAwEAAQ==
			
			logger.info(signupUrl);
			
			AtalkDataModelAll secureModel = new AtalkDataModelAll();
			secureModel.setSecureModel(
					AtalkComplex.instance().toEncPacket(reqObj));
			logger.info("############# 1. client -> server : login value");
			String json = AtalkComplex.toPacketData(secureModel);
			logger.info("## REQDATA : {}", json);
			
			OkHttpClient client = new OkHttpClient().newBuilder()
					.connectTimeout(40, TimeUnit.SECONDS)  // Connection timeout
		            .readTimeout(40, TimeUnit.SECONDS)     // Read timeout
		            .writeTimeout(40, TimeUnit.SECONDS)    // Write timeout
		            .build();
			
			MediaType jsonMediaType = MediaType.get("application/json; charset=utf-8");
			RequestBody body = RequestBody.Companion.create(json, jsonMediaType);
			Request request = new Request.Builder()
					.url(signupUrl)
					.post(body)
					.build();
			try (Response response = client.newCall(request).execute()) {
				if (response.isSuccessful()) {
					String responseJson = response.body().string();
					logger.info("Response: http code : {}, value : {}", 
							response.code()
							, responseJson);
					SecureDataModel respObj = SecureDataModel.fromBuffer(responseJson);
				
					final UserLoginResponse responseData = SecureDataModel.fromEncHexBuffer(respObj.getData()
							, AtalkComplex.instance().getPACKET_KEY()
							, UserLoginResponse.class);
					logger.info("### RESP DATA : {}",
							AtalkPacketBase.printAllFields(responseData));
					logger.info("#### RESP JSON : {}", responseData.toJson());
					if (!responseData.getError().getCode().equals(0L)) {
						logger.info("@@@@@@@@@ LOGIN FAILED : code : {}", 
								responseData.getError().getCode());
						return;
					}
					AtalkComplex.instance().setAccessToken(responseData.getAccessToken());
					AtalkComplex.instance().setRefreshToken(responseData.getRefreshToken());
					AtalkComplex.instance().setServerPublicKey(responseData.getServerPublicKey());
					AtalkComplex.instance().setUserInfo(responseData);
					
					AtalkComplex.instance().postLoginSuccess(
							AtalkComplex.WEBSOCKET_SECURE_CONN_HOST
								, atalkInf
							);
				} else {
					logger.error("Error: " + response.code());
					logger.error("@@@@@@@@@ SIGNUP ERR CASE 1");
				}
			} catch (Exception e) {
				logger.error("@@@@@@@@@ SIGNUP ERR CASE 2 : {}", e);
			}
		}
	}

	/**
	 * 친구 등록
	 * 
	 * @param newAmigoSetName
	 * @param displayYn
	 * @return
	 * @throws Exception
	 */
	public AddAmigoSetResponse addAmigoSet(AddAmigoSetRequest reqObj) throws Exception {
		AddAmigoSetResponse responseData = null;
		
		String url1 = REQ_HOST_VAL + CNTXT_NAME +"/api/v1/amigoSet/add";
		
		AtalkDataModelAll secureModel = new AtalkDataModelAll();
		secureModel.setSecureModel(
				AtalkComplex.instance().toEncPacket(reqObj));
		logger.info("############# 1. client -> server : add amigoset");
		String json = AtalkComplex.toPacketData(secureModel);
		logger.info("## REQDATA : {}", json);
		
		OkHttpClient client = new OkHttpClient().newBuilder()
				.connectTimeout(40, TimeUnit.SECONDS)  // Connection timeout
	            .readTimeout(40, TimeUnit.SECONDS)     // Read timeout
	            .writeTimeout(40, TimeUnit.SECONDS)    // Write timeout
	            .build();
		
		MediaType jsonMediaType = MediaType.get("application/json; charset=utf-8");
		RequestBody body = RequestBody.Companion.create(json, jsonMediaType);
		
		////////// ENCRYPT ACCESS TOKEN
		String encJwtHexToken = AtalkComplex.instance().generateEncAccessToken();
		// encJwtHexToken = jwtToken;
		logger.info("### access token(enchex) : {}", encJwtHexToken);
		////////// ENCRYPT ACCESS TOKEN
		Request request = new Request.Builder()
				.url(url1)
				.addHeader("Authorization", "Bearer " + encJwtHexToken) // Add JWT token here
				.post(body)
				.build();
		try (Response response = client.newCall(request).execute()) {
			if (response.isSuccessful()) {
				String responseJson = response.body().string();
				logger.info("Response: http code : {}, value : {}", 
						response.code()
						, responseJson);
				SecureDataModel respObj = SecureDataModel.fromBuffer(responseJson);
			
				responseData = SecureDataModel.fromEncHexBuffer(respObj.getData()
						, AtalkComplex.instance().getPACKET_KEY()
						, AddAmigoSetResponse.class);
				logger.info("### RESP DATA : {}",
						AtalkPacketBase.printAllFields(responseData));
				logger.info("#### RESP JSON : {}", responseData.toJson());
				// amigoSetNo = responseData.getAmigoSetNo();
			} else {
				logger.error("Error: " + response.code());
				logger.error("@@@@@@@@@ SIGNUP ERR CASE 1");
				
			}
		} catch (Exception e) {
			logger.error("@@@@@@@@@ SIGNUP ERR CASE 2 : {}", e);
			
		}
		return responseData;
	}


	/**
	 * 친구 삭제
	 * 
	 * @param newAmigoSetName
	 * @param displayYn
	 * @return
	 * @throws Exception
	 */
	public DeleteAmigoResponse removeAmigoList(List<Long> amigoUserNoList) throws Exception {
		DeleteAmigoResponse responseData = null;

		DeleteAmigoRequest reqObj = new DeleteAmigoRequest();
		
		reqObj.setAmigoUserNoList(amigoUserNoList);
		
		String url1 = REQ_HOST_VAL + CNTXT_NAME +"/api/v1/amigo/delete";
		
		AtalkDataModelAll secureModel = new AtalkDataModelAll();
		secureModel.setSecureModel(
				AtalkComplex.instance().toEncPacket(reqObj));
		logger.info("############# 1. client -> server : delete amigoset");
		String json = AtalkComplex.toPacketData(secureModel);
		logger.info("## REQDATA : {}", json);
		
		OkHttpClient client = new OkHttpClient().newBuilder()
				.connectTimeout(40, TimeUnit.SECONDS)  // Connection timeout
	            .readTimeout(40, TimeUnit.SECONDS)     // Read timeout
	            .writeTimeout(40, TimeUnit.SECONDS)    // Write timeout
	            .build();
		
		MediaType jsonMediaType = MediaType.get("application/json; charset=utf-8");
		RequestBody body = RequestBody.Companion.create(json, jsonMediaType);
		
		////////// ENCRYPT ACCESS TOKEN
		String encJwtHexToken = AtalkComplex.instance().generateEncAccessToken();
		// encJwtHexToken = jwtToken;
		logger.info("### access token(enchex) : {}", encJwtHexToken);
		////////// ENCRYPT ACCESS TOKEN
		Request request = new Request.Builder()
				.url(url1)
				.addHeader("Authorization", "Bearer " + encJwtHexToken) // Add JWT token here
				.post(body)
				.build();
		try (Response response = client.newCall(request).execute()) {
			if (response.isSuccessful()) {
				String responseJson = response.body().string();
				logger.info("Response: http code : {}, value : {}", 
						response.code()
						, responseJson);
				SecureDataModel respObj = SecureDataModel.fromBuffer(responseJson);
			
				responseData = SecureDataModel.fromEncHexBuffer(respObj.getData()
						, AtalkComplex.instance().getPACKET_KEY()
						, DeleteAmigoResponse.class);
				logger.info("### RESP DATA : {}",
						AtalkPacketBase.printAllFields(responseData));
				logger.info("#### RESP JSON : {}", responseData.toJson());
				// amigoSetNo = responseData.getAmigoSetNo();
			} else {
				logger.error("Error: " + response.code());
				logger.error("@@@@@@@@@ DELETE amigo response ERR CASE 1");
				
			}
		} catch (Exception e) {
			logger.error("@@@@@@@@@ DELETE amigo response ERR CASE 2 : {}", e);
		}
		return responseData;
	}

	
	/**
	 * 사용자 검색
	 * 
	 * @param searchName
	 * @throws Exception
	 */
	public SearchUserResponse searchUser(String searchName) throws Exception {
		SearchUserResponse responseData = null;
		String url1 = REQ_HOST_VAL + CNTXT_NAME +"/api/v1/search/user";
		
		SearchUserRequest reqObj = new SearchUserRequest();
		reqObj.setSearchWord(searchName);
		
		AtalkDataModelAll secureModel = new AtalkDataModelAll();
		secureModel.setSecureModel(
				AtalkComplex.instance().toEncPacket(reqObj));
		logger.info("############# 1. client -> server : search user");
		String json = AtalkComplex.toPacketData(secureModel);
		logger.info("## REQDATA : {}", json);
		
		OkHttpClient client = new OkHttpClient().newBuilder()
				.connectTimeout(40, TimeUnit.SECONDS)  // Connection timeout
	            .readTimeout(40, TimeUnit.SECONDS)     // Read timeout
	            .writeTimeout(40, TimeUnit.SECONDS)    // Write timeout
	            .build();
		
		MediaType jsonMediaType = MediaType.get("application/json; charset=utf-8");
		RequestBody body = RequestBody.Companion.create(json, jsonMediaType);
		
		////////// ENCRYPT ACCESS TOKEN
		String encJwtHexToken = AtalkComplex.instance().generateEncAccessToken();
		// encJwtHexToken = jwtToken;
		logger.info("### access token(enchex) : {}", encJwtHexToken);
		////////// ENCRYPT ACCESS TOKEN
		Request request = new Request.Builder()
				.url(url1)
				.addHeader("Authorization", "Bearer " + encJwtHexToken) // Add JWT token here
				.post(body)
				.build();
		try (Response response = client.newCall(request).execute()) {
			if (response.isSuccessful()) {
				String responseJson = response.body().string();
				logger.info("Response: http code : {}, value : {}", 
						response.code()
						, responseJson);
				SecureDataModel respObj = SecureDataModel.fromBuffer(responseJson);
			
				responseData = SecureDataModel.fromEncHexBuffer(respObj.getData()
						, AtalkComplex.instance().getPACKET_KEY()
						, SearchUserResponse.class);
				logger.info("### RESP DATA(searchUser) : {}",
						AtalkPacketBase.printAllFields(responseData));
				logger.info("#### RESP JSON(searchUser) : {}", responseData.toJson());
				
			} else {
				logger.error("Error: " + response.code());
				logger.error("@@@@@@@@@ SIGNUP ERR CASE 1");
				
			}
		} catch (Exception e) {
			logger.error("@@@@@@@@@ SIGNUP ERR CASE 2 : {}", e);
			
		}
		return responseData;
	}

	/**
	 * 친구 추가
	 * 
	 * @param amigoUserNoList
	 * @return
	 * @throws Exception
	 */
	public AddAmigoResponse addAmigo(List<Long> amigoUserNoList) throws Exception {
		AddAmigoResponse responseData = null;
		String url1 = REQ_HOST_VAL + CNTXT_NAME +"/api/v1/amigo/add";
		AddAmigoRequest reqObj = new AddAmigoRequest();
		
		reqObj.setAmigoUserNoList(amigoUserNoList);
		
		AtalkDataModelAll secureModel = new AtalkDataModelAll();
		secureModel.setSecureModel(
				AtalkComplex.instance().toEncPacket(reqObj));
		logger.info("############# 1. client -> server : add amigo");
		String json = AtalkComplex.toPacketData(secureModel);
		logger.info("## REQDATA : {}", json);
		
		OkHttpClient client = new OkHttpClient().newBuilder()
				.connectTimeout(40, TimeUnit.SECONDS)  // Connection timeout
	            .readTimeout(40, TimeUnit.SECONDS)     // Read timeout
	            .writeTimeout(40, TimeUnit.SECONDS)    // Write timeout
	            .build();
		
		MediaType jsonMediaType = MediaType.get("application/json; charset=utf-8");
		RequestBody body = RequestBody.Companion.create(json, jsonMediaType);
		
		////////// ENCRYPT ACCESS TOKEN
		String encJwtHexToken = AtalkComplex.instance().generateEncAccessToken();
		// encJwtHexToken = jwtToken;
		logger.info("### access token(enchex) : {}", encJwtHexToken);
		////////// ENCRYPT ACCESS TOKEN
		Request request = new Request.Builder()
				.url(url1)
				.addHeader("Authorization", "Bearer " + encJwtHexToken) // Add JWT token here
				.post(body)
				.build();
		try (Response response = client.newCall(request).execute()) {
			if (response.isSuccessful()) {
				String responseJson = response.body().string();
				logger.info("Response: http code : {}, value : {}", 
						response.code()
						, responseJson);
				SecureDataModel respObj = SecureDataModel.fromBuffer(responseJson);
				responseData = SecureDataModel.fromEncHexBuffer(respObj.getData()
						, AtalkComplex.instance().getPACKET_KEY()
						, AddAmigoResponse.class);
				logger.info("### RESP DATA : {}",
						AtalkPacketBase.printAllFields(responseData));
				logger.info("#### RESP JSON : {}", responseData.toJson());
				
			} else {
				logger.error("Error: " + response.code());
				logger.error("@@@@@@@@@ ADD AMIGO ERR CASE 1");
			}
		} catch (Exception e) {
			logger.error("@@@@@@@@@ ADD AMIGO ERR CASE 2 : {}", e);
		}
		return responseData;
	}
	
	/**
	 * 대화방 초대
	 * 
	 * @param userNoListToAdd
	 * @return
	 * @throws Exception 
	 */
	public OpenChathubResponse openChathub(List<Long> userNoListToAdd) throws Exception 
	{
		OpenChathubResponse responseData = null;
		String reqUrl =	REQ_HOST_VAL + CNTXT_NAME +"/api/v1/chatHub/openChathub";
		OpenChathubRequest obj = new OpenChathubRequest();
		
		obj.setUserNoList(userNoListToAdd);
		responseData = AtalkPacketUtil.requestAtalkMessage(
				obj, OpenChathubResponse.class, reqUrl);

//		chathubInfo = responseData.getChatHubInfo();
//		logger.info("#### CHATHUB NO : {}", chathubInfo.getChathubNo());
		return responseData;
	}
	
	/**
	 * 대화 전송
	 * 
	 * @param chatMessage
	 * @param chathubInfo
	 * @return
	 * @throws Exception
	 */
	public SendChatResponse sendChat(String chatMessage, ChatHubInfo chathubInfo) throws Exception 
	{
//		SendChatResponse responseData = null;
//		String reqUrl =	REQ_HOST_VAL + CNTXT_NAME +"/api/v1/chat/send";
//		
//		// 대화 암호화.
//		String plainKeyValue = AtalkComplex.instance().decryptChathubKey(chathubInfo.getEncChathubKey());
//		byte [] encChatMesageBuff = AesEncDecComplex.encryptAesWithRandomIv(
//				chatMessage.getBytes(Charset.forName("UTF-8"))
//				, plainKeyValue);
//		
//		final String encChatMessage = AesEncDecComplex.bytesToHex(encChatMesageBuff);
//		SendChatRequest obj = new SendChatRequest();
//		obj.setMessage(encChatMessage);
//		obj.setChathubNo(chathubInfo.getChathubNo());
//		responseData = AtalkPacketUtil.requestAtalkMessage(
//				obj, SendChatResponse.class, reqUrl);
//		return responseData;
		
		SendChatResponse responseData = null;
		String reqUrl =	REQ_HOST_VAL + CNTXT_NAME +"/api/v1/chat/send";
		
		SendChatRequest obj = new SendChatRequest();
		// 대화 내용 암호화.
		String plainKeyValue = AtalkComplex.instance().decryptChathubKey(chathubInfo.getEncChathubKey());
		byte [] encChatMesageBuff = AesEncDecComplex.encryptAesCtrWithRandomIv(
				chatMessage.getBytes(Charset.forName("UTF-8"))
				, plainKeyValue);
		
		// 대용량 대화 체크
		if (chatMessage.length() > AtalkComplex.instance().getExtChatBaseSize()) {
			String shortMessage = chatMessage.substring(0, AtalkComplex.instance().getExtChatBaseSize()
				);
			byte [] encShortMsgBuffer = AesEncDecComplex.encryptAesWithRandomIv(
					shortMessage.getBytes()
					, plainKeyValue);
			obj.setShortMessage(AesEncDecComplex.bytesToHex(encShortMsgBuffer));
		}
		final String encChatMessage = AesEncDecComplex.bytesToHex(encChatMesageBuff);
		
		// 3. 대화방에서 보여질 짧은 대화내용을 암호화키로 암호화.
		obj.setMessage(encChatMessage);
		obj.setChathubNo(chathubInfo.getChathubNo());
		responseData = AtalkPacketUtil.requestAtalkMessage(
				obj, SendChatResponse.class, reqUrl);
		return responseData;
	}

	/**
	 * 대화방 목록 정보 조회
	 * 
	 * @param updateDt
	 * @return
	 * @throws Exception
	 */
	public ListChathubResponse chatHubList(String updateDt) throws Exception {
		
		/////////// SECURE
		
		logger.info("#### inq CHATHUB LIST, last update : {}", updateDt);  
		String reqUrl =	REQ_HOST_VAL + CNTXT_NAME +"/api/v1/chatHub/list";
		ListChathubRequest obj = new ListChathubRequest();
		obj.setUpdateDt(updateDt);
		ListChathubResponse responseData = AtalkPacketUtil.requestAtalkMessage(
				obj, ListChathubResponse.class, reqUrl);
		
		List<ChatHubListInfo> chathubListInfo = responseData.getChatHubListInfo();			
		ChatInfoLast lastChatObj = null;
		if (chathubListInfo != null) {
			for (ChatHubListInfo chatObj : chathubListInfo) {
				// 1. 대화방의 ENC 대화방키 를 내 개인키로 복호화
				String plainChathubKey =AtalkComplex.instance().decryptChathubKey(
						chatObj.getEncChathubKey());
				
				// 2. 파일 버퍼를 대화방 암호화키로 암호화.
				logger.info("### plainChathubKey : {}", plainChathubKey);
				try {
					logger.info("### message(enc) : {}", chatObj.getLastChat());
					lastChatObj = chatObj.getLastChat();						
					lastChatObj.setChatMessage(
							new String(
									AesEncDecComplex.decryptAesCtrWithIv(
									AesEncDecComplex.hexToBytes(lastChatObj.getChatMessage())
									, plainChathubKey)));
					logger.info("### message(dec) : {}", lastChatObj.getChatMessage());
				} catch (Exception e) {
					// lastChatObj.setChatMessage("");
				}
			}
		}
		logger.info("#### responseData : {}",  responseData.toJson());
		return responseData;
	}

	/**
	 * 친구목록 정보조회
	 * 
	 * @throws Exception
	 */
	public AmigoListResponse getAmigoList() throws Exception {
		AmigoListResponse responseData = null;
		String reqUrl =	REQ_HOST_VAL + CNTXT_NAME +"/api/v1/amigo/list";
		responseData = AtalkPacketUtil.requestAtalkMessageByGetMethod(
				AmigoListResponse.class, reqUrl);
		return responseData;
	}

	/**
	 * 대화방 진입시 대화내용 목록 조회
	 * 
	 * @param updateDt
	 * @return
	 * @throws Exception
	 */
	public ChatInfoResponse chatList(Long targetChathubNo, Long lastBaseChatNo, int chatCount) throws Exception {
		String reqUrl =	REQ_HOST_VAL + CNTXT_NAME +"/api/v1/chat/chatList";
		ChatInfoRequest obj = new ChatInfoRequest();
		obj.setChathubNo(targetChathubNo);
		obj.setChatInqCount(chatCount);		// 10 개씩
		obj.setLastChatNo(lastBaseChatNo); // 
		
		logger.info("#### inq CHAT LIST, last update : {}", obj.toJson());  
		
		ChatInfoResponse responseData = AtalkPacketUtil.requestAtalkMessage(
				obj, ChatInfoResponse.class, reqUrl);
		lastBaseChatNo = responseData.getLastChatNo();
		
		List<Chat> chatList = responseData.getChatList();
		
		// 대화방 encrypt key
		String chathubEncKey = responseData.getChatHubInfo().getEncChathubKey();
		
		// 대화방 키 복호화
		String plainKeyValue = this.decryptChathubKey(
				chathubEncKey);
		
		for (Chat chatObj : chatList) {
			
			// decrypt data data
			try {
				String encMessage = chatObj.getChatMessage();
				byte [] encBuffer = AesEncDecComplex.hexToBytes(encMessage);
				byte [] decBuffer = AesEncDecComplex.decryptAesCtrWithIv(encBuffer, plainKeyValue);
				
				chatObj.setChatMessage(new String(decBuffer));
			} catch (Exception e) {}
		}
		logger.info("#### responseData : {}",  responseData.toJson());
		return responseData;
	}

	/**
	 * 대화방 진입시 대화내용 목록 조회
	 * 
	 * @param updateDt
	 * @return
	 * @throws Exception
	 */
	public OpenChathubResponse chatHubInfo(Long targetChathubNo, int chatCount) throws Exception {
		String reqUrl =	REQ_HOST_VAL + CNTXT_NAME +"/api/v1/chatHub/info";
		ChathubInfoRequest obj = new ChathubInfoRequest();
		obj.setChathubNo(targetChathubNo);
		obj.setReqChatCount(chatCount);		// 10 개씩
		
		logger.info("#### inq CHAT info, : {}", obj.toJson());  
		
		OpenChathubResponse responseData = AtalkPacketUtil.requestAtalkMessage(
				obj, OpenChathubResponse.class, reqUrl);
		List<Chat> chatList = responseData.getChatList();
		
		// 대화방 encrypt key
		String chathubEncKey = responseData.getChatHubInfo().getEncChathubKey();
		
		// 대화방 키 복호화
		String plainKeyValue = this.decryptChathubKey(
				chathubEncKey);
		
		for (Chat chatObj : chatList) {
			
			// decrypt data data
			try {
				String encMessage = chatObj.getChatMessage();
				byte [] encBuffer = AesEncDecComplex.hexToBytes(encMessage);
				byte [] decBuffer = AesEncDecComplex.decryptAesCtrWithIv(encBuffer, plainKeyValue);
				
				chatObj.setChatMessage(new String(decBuffer));
			} catch (Exception e) {}
		}
		logger.info("#### responseData(chatHubInfo) : {}",  responseData.toJson());
		return responseData;
	}
	
	/**
	 * 대화내용 복호화
	 * 
	 * @param encKey
	 * @param encMessage
	 * @return
	 * @throws Exception
	 */
	public String decryptChatMessage(String chathubEncKey, String encMessage) throws Exception {
		// 대화방 키 복호화
		String plainKeyValue = this.decryptChathubKey(
				chathubEncKey);
		
		String retMessage = encMessage;
		// decrypt data data
		try {
			byte [] encBuffer = AesEncDecComplex.hexToBytes(encMessage);
			byte [] decBuffer = AesEncDecComplex.decryptAesCtrWithIv(encBuffer, plainKeyValue);
			retMessage = new String(decBuffer);
		} catch (Exception e) {}
		
		return retMessage;
	}
	
	
	
	
	
	
	
	/////////////////////////////// INSECURE CASE /////////////////////////////////

	/**
	 * 대화방 진입시 대화내용 목록 조회
	 * 
	 * @param updateDt
	 * @return
	 * @throws Exception
	 */
	public ChatInfoResponse chatListPlain(Long targetChathubNo, Long lastBaseChatNo, int chatCount) throws Exception {
		
		String reqUrl =	REQ_HOST_VAL + CNTXT_NAME +"/api/plain/v1/chat/chatList";
		
		ChatInfoRequest obj = new ChatInfoRequest();
		obj.setChathubNo(targetChathubNo);
		obj.setChatInqCount(chatCount);		// 10 개씩
		obj.setLastChatNo(lastBaseChatNo); // 
		
		logger.info("#### inq CHAT LIST, last update : {}", obj.toJson());  
		
		ChatInfoResponse responseData = AtalkPacketUtil.requestAtalkMessagePlain(
				obj, ChatInfoResponse.class, reqUrl);
		lastBaseChatNo = responseData.getLastChatNo();
		logger.info("#### responseData : {}",  responseData.toJson());
		return responseData;
		
	}


	/**
	 * 대화 전송
	 * 
	 * @param chatMessage
	 * @param chathubInfo
	 * @return
	 * @throws Exception
	 */
	public SendChatResponse sendChatPlain(String chatMessage, ChatHubInfo chathubInfo) throws Exception 
	{
		SendChatResponse responseData = null;
		String reqUrl =	REQ_HOST_VAL + CNTXT_NAME +"/api/plain/v1/chat/send";
		
		SendChatRequest obj = new SendChatRequest();
		obj.setMessage(chatMessage);
		obj.setChathubNo(chathubInfo.getChathubNo());
		responseData = AtalkPacketUtil.requestAtalkMessagePlain(
				obj, SendChatResponse.class, reqUrl);
		return responseData;

	}


	/**
	 * 대화방 목록 정보 조회
	 * 
	 * @param updateDt
	 * @return
	 * @throws Exception
	 */
	public ListChathubResponse chatHubListPlain(String updateDt) throws Exception {
		logger.info("#### inq CHATHUB LIST, last update : {}", updateDt);  
		String reqUrl =	REQ_HOST_VAL + CNTXT_NAME +"/api/plain/v1/chatHub/list";
		ListChathubRequest obj = new ListChathubRequest();
		obj.setUpdateDt(updateDt);
		ListChathubResponse responseData = AtalkPacketUtil.requestAtalkMessagePlain(
				obj, ListChathubResponse.class, reqUrl);
		
		logger.info("#### responseData : {}",  responseData.toJson());
		return responseData;
	}

	/**
	 * 대화방 초대 (대화방 제목 포함)
	 * 
	 * @param title
	 * @param userNoListToAdd
	 * @return
	 * @throws Exception
	 */
	public OpenChathubResponse openChathubWithTitle(String title, List<Long> userNoListToAdd) throws Exception 
	{
		OpenChathubResponse responseData = null;
		String reqUrl =	REQ_HOST_VAL + CNTXT_NAME +"/api/v1/chatHub/openChathubWithTitle";
		OpenChathubWithTitleRequest obj = new OpenChathubWithTitleRequest();
		
		obj.setChathubMasterTitle(title);
		obj.setUserNoList(userNoListToAdd);
		responseData = AtalkPacketUtil.requestAtalkMessage(
				obj, OpenChathubResponse.class, reqUrl);

//		chathubInfo = responseData.getChatHubInfo();
//		logger.info("#### CHATHUB NO : {}", chathubInfo.getChathubNo());
		return responseData;
	}
	
	/////////////////////////////////////////////////////////////////////
	/**
	 * 프로필변경 (foreground or background)
	 * 
	 * @param profileFilePath
	 * @param bBackground
	 * @return
	 * @throws Exception
	 */
	public SearchUserResponse updateProfile(String profileFilePath, boolean bBackground) throws Exception 
	{
		SearchUserResponse responseData = null;
		try {
			String reqUrl =	null;
			if (bBackground) {
				reqUrl =	REQ_HOST_VAL + CNTXT_NAME + "/api/v1/profile/update/bg";
			} else {
				reqUrl =	REQ_HOST_VAL + CNTXT_NAME + "/api/v1/profile/update/fg";
			}
			DummyRequest obj = new DummyRequest();
			AtalkDataModelAll secureModel = new AtalkDataModelAll();
			secureModel.setSecureModel(
					AtalkComplex.instance().toEncPacket(obj));
			///////// profile image 처리
			// 패킷키
			String packetKey = AtalkComplex.instance().getPACKET_KEY();
			List<String> fileNameList = new ArrayList<String>();
			List<byte []> profileEncBufferList = new ArrayList<byte []>();
			
			/////////////////////////////////////////////////////////////////////////
			File profileFgFile = new File(profileFilePath);
			// foreground 프로필 이미지 버퍼 및 파일명 처리
			Object [] retFileObjArr = BufferComplex.getFileDataAndFileName(profileFgFile.getPath());
			byte [] plainBuffer = (byte [])retFileObjArr[0];
			String fileName =(String)retFileObjArr[1];

			fileNameList.add(fileName);
			byte [] encBuffer = AesEncDecComplex.encryptAesCtrWithRandomIv(
					plainBuffer
					, packetKey);
			profileEncBufferList.add(encBuffer);
			/////////////////////////////////////////////////////////////////////////

			String multipartFileName = "profileFile";
			/////////////////////////////////////////////////////////////////////////
			responseData = AtalkPacketUtil.requestAtalkFileListMessageAuth(
			secureModel.getSecureModel()
					, SearchUserResponse.class
					, reqUrl
					, multipartFileName
					, profileEncBufferList
					, fileNameList
					);
//			if (responseData != null) {
//				logger.info("### RESP DATA : {}",
//				AtalkPacketBase.printAllFields(responseData));
//				logger.info("#### RESP JSON : {}", responseData.toJson());
//			}
		} catch (Exception e) {
			logger.info("@@@@ : {}", e);
		}
		return responseData;
	}
	
	
	/////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////
	/**
	 * 대용량 대화 보기
	 * 
	 * @param chatMessage
	 * @param extChatUrl
	 * @param encChathubKey
	 * @return
	 * @throws Exception
	 */
	public ChatExt viewExtChat(
			String extChatUrl
			, String encChathubKey) throws Exception 
	{
		ChatExt chatExtObj = null;
		try {
			// String extChatUrl = extChatData.getChatData().getChatExtUrl();
			
			ExtChatRequest obj = new ExtChatRequest();
			obj.setPacketSeedValue(AtalkComplex.instance().getPacketSeedValue());
			
			ExtChatResponse responseData = AtalkPacketUtil.requestAtalkMessage(
					obj, ExtChatResponse.class, extChatUrl);
			
			chatExtObj = responseData.getChatData();
			/////////////////////////////////////////////////////////////////////
			// 1. 대화방의 ENC 대화방키 를 내 개인키로 복호화
			String plainChathubKey = AtalkComplex.instance().decryptChathubKey(
					encChathubKey);
			logger.info("### message_ext(enc) : {}", chatExtObj.getChatContent());
			chatExtObj.setChatContent(
					new String(
							AesEncDecComplex.decryptAesWithIv(
								AesEncDecComplex.hexToBytes(chatExtObj.getChatContent())
								, plainChathubKey)));
			logger.info("### message_ext(dec) : {}", chatExtObj.getChatContent());
		} catch (Exception e) {
			logger.info("@@@@ : {}", e);
		}
		return chatExtObj;
	}
	
	/**
	 * 파일 대화 입력
	 * 
	 * @param filePath
	 * @param chatHubNo
	 * @param extChatUrl
	 * @param encChathubKey
	 * @return
	 * @throws Exception
	 */
	public Chat sendFileChat(
			String filePath
			, Long chatHubNo
			, String encChathubKey) throws Exception 
	{
		Chat respFileChatObj = null;
		try {
			String reqUrl =	REQ_HOST_VAL + CNTXT_NAME + "/api/v1/chat/send/file";
			reqUrl = String.format("%s/%d/%s", reqUrl, chatHubNo, "I");
			
			SendFileChatRequest obj = new SendFileChatRequest();
			obj.setChathubNo(chatHubNo);
			
			Object [] retFileObjArr = BufferComplex.getFileDataAndFileName(filePath);
			
			byte [] plainBuffer = (byte [])retFileObjArr[0];
			String fileName =(String)retFileObjArr[1];

			/////////////////////////////////////////////////////////////////////////
			// 1. 대화방의 ENC 대화방키 를 내 개인키로 복호화
			String plainChathubKey = AtalkComplex.instance().decryptChathubKey(
					encChathubKey);
			logger.info("### plainChathubKey : {}", plainChathubKey);
			// 2. 파일 버퍼를 대화방 암호화키로 암호화.			
			byte [] encBuffer = AesEncDecComplex.encryptAesWithRandomIv(
					plainBuffer
					, plainChathubKey);
			
			// 3. 최종 버퍼 암호화된 파일 버퍼에 packetSeedBuffer, transaction id buffer 추가
			encBuffer =  BufferComplex.appendBytesMore(
					encBuffer
					, BufferComplex.hexToBytes(AtalkComplex.instance().getPacketSeedValue())
					, BufferComplex.hexToBytes(RandomHexString.genSecureRandomHex(16)));
			
			/////////////////////////////////////////////////////////////////////////
			SendFileChatResponse responseData = AtalkPacketUtil.requestAtalkFileMessage(
					SendFileChatResponse.class, reqUrl, encBuffer, fileName);
			
			Chat respChatObj = responseData.getChatData();
			respFileChatObj = respChatObj;
			// fileDownloadPath = respChatObj.getChatFileInfo().getDownloadPath();
			if (respChatObj.getChatType().equals(EnumChatType.MESSAGE_GENERAL_TYPE.getValue())
				|| (respChatObj.getChatType().equals(EnumChatType.MESSAGE_EXT_GENERAL_TYPE.getValue()))) {
				logger.info("### message(enc) : {}", respChatObj.getChatMessage());
				respChatObj.setChatMessage(
						new String(
								AesEncDecComplex.decryptAesWithIv(
								AesEncDecComplex.hexToBytes(respChatObj.getChatMessage())
								, plainChathubKey)));
				logger.info("### message(dec) : {}", respChatObj.getChatMessage());
			}
		} catch (Exception e) {
			logger.info("@@@@ : {}", e);
		}
		return respFileChatObj;
	}
	
	/**
	 * 파일 대화 입력
	 * 
	 * @param filePath
	 * @param chatHubNo
	 * @param extChatUrl
	 * @param encChathubKey
	 * @return
	 * @throws Exception
	 */
	public byte [] downloadFileChatData(
			String fileDownloadPath
			, Long chatHubNo
			, String encChathubKey) throws Exception 
	{
		String reqUrl =	fileDownloadPath;
		byte [] finalDecBuffer = null;
		try {
			byte [] encFileData = AtalkPacketUtil.downloadAttachedFile(
					reqUrl);
			// 1. 대화방의 ENC 대화방키 를 내 개인키로 복호화
			String plainChathubKey = AtalkComplex.instance().decryptChathubKey(
					encChathubKey);
			
			// 2. 파일버퍼 복호화.
			finalDecBuffer = AesEncDecComplex.decryptAesWithIv(
					encFileData
					, plainChathubKey);
//
//			// 3. 파일 다운로드.
//			final String filePathString = String.format("%s\\%s", 
//					"D:\\AtalkClient\\attfile"
//					, respFileChatObj.getChatFileInfo().getDispFileName());
//			Path filePath = Paths.get(filePathString);
//			try {
//				Files.write(filePath, finalDecBuffer);
//				System.out.println("File written successfully to: " + filePathString);
//			} catch (IOException e) {
//				logger.error("@@@@ : {}", e);
//			}
		} catch (Exception e) {
			logger.info("@@@@ : {}", e);
		}
		return finalDecBuffer;
	}
	
	/**
	 * 친구 정보조회
	 * 
	 * @param amigoUserNo
	 * @return
	 * @throws Exception
	 */
	public AmigoDetailResponse getAmigo(Long amigoUserNo) throws Exception {
		AmigoDetailResponse responseData = null;
		String reqUrl =	REQ_HOST_VAL + CNTXT_NAME +"/api/v1/amigo/list/" + String.valueOf(amigoUserNo);
		responseData = AtalkPacketUtil.requestAtalkMessageByGetMethod(
				AmigoDetailResponse.class, reqUrl);
		return responseData;
	}

	

	/**
	 * Create an SSLContext that trusts all certificates (for testing purposes).
	 */
	private static SSLContext createSSLContext() throws Exception {
		TrustManager[] trustAllCertificates = new TrustManager[]{ new TrustAllX509TrustManager() };
		SSLContext sslContext = SSLContext.getInstance("TLS");
		sslContext.init(null, trustAllCertificates, new SecureRandom());
		return sslContext;
	}

	/**
	 * Custom TrustManager that trusts all certificates (for testing only).
	 */
	static class TrustAllX509TrustManager implements X509TrustManager {
		public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
		public void checkClientTrusted(X509Certificate[] certs, String authType) {}
		public void checkServerTrusted(X509Certificate[] certs, String authType) {}
	}
}

