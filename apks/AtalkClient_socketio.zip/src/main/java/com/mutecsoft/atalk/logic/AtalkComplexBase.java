package com.mutecsoft.atalk.logic;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.mutecsoft.atalk.logic.model.SecureDataModel;

public abstract class AtalkComplexBase {
	public abstract String toPacketData(SecureDataModel model) throws JsonProcessingException;
}
