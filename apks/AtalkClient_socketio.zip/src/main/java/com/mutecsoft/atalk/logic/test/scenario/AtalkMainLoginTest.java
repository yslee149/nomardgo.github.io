package com.mutecsoft.atalk.logic.test.scenario;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.mutecsoft.atalk.logic.AtalkComplex;
import com.mutecsoft.atalk.logic.inf.InfAtalkChatNoti;
import com.mutecsoft.atalk.logic.model.noti.ChatDataNoti;
import com.mutecsoft.atalk.logic.model.noti.ExitChathubNoti;
import com.mutecsoft.atalk.logic.model.noti.InviteChathubNoti;
import com.mutecsoft.atalk.logic.model.noti.KickOutChathubNoti;
import com.mutecsoft.atalk.logic.model.noti.ReadChatNoti;
import com.mutecsoft.atalk.logic.model.noti.RetrieveChatNoti;

public class AtalkMainLoginTest {

	private static final Logger logger = LoggerFactory.getLogger(AtalkMainLoginTest.class);

	public static void main(String [] args) throws Exception {
		carryon();
	}

	static void carryon() throws Exception {
		logger.info("#### 1. START - DETERMINE PACKET KEY");
		AtalkComplex.instance().determinePacketKey();
		logger.info("#### 1. END - DETERMINE PACKET KEY");
		
		logger.info("#### 2. START - LOGIN");
		String userId = "voyzer@gmail.com";
		String passwordPlain = "111111";
		String imei = "44441111";
		String deviceType = "A";
		String pushToken = "push token";
		
		AtalkComplex.instance().login(
				userId
				, passwordPlain
				, imei
				, deviceType
				, pushToken
				, new InfAtalkChatNoti() {
					
					@Override
					public void procRetrieveChatNoti(RetrieveChatNoti notiObj) {
						// TODO Auto-generated method stub
						try {
							logger.info("#### : {}", notiObj.toJson());
						} catch (JsonProcessingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					
					@Override
					public void procReadChatNoti(ReadChatNoti notiObj) {
						try {
							logger.info("#### : {}", notiObj.toJson());
						} catch (JsonProcessingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					
					@Override
					public void procKickOutChathubNoti(KickOutChathubNoti notiObj) {
						try {
							logger.info("#### : {}", notiObj.toJson());
						} catch (JsonProcessingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					
					@Override
					public void procInviteChathubNoti(InviteChathubNoti notiObj) {
						try {
							logger.info("#### : {}", notiObj.toJson());
						} catch (JsonProcessingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					
					@Override
					public void procExitChathubNoti(ExitChathubNoti notiObj) {
						try {
							logger.info("#### : {}", notiObj.toJson());
						} catch (JsonProcessingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					
					@Override
					public void procChatDataNoti(ChatDataNoti notiObj) {
						try {
							logger.info("#### : {}", notiObj.toJson());
						} catch (JsonProcessingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				});
		logger.info("#### 2. END - LOGIN");
	}

	public static void carryonWithArg(String userId, String imei) throws Exception {
		logger.info("#### 1. START - DETERMINE PACKET KEY");
		AtalkComplex.instance().determinePacketKey();
		logger.info("#### 1. END - DETERMINE PACKET KEY");
		
		logger.info("#### 2. START - LOGIN");
		// userId = "user3@abc.com";
		String passwordPlain = "111111";
		// imei = "44441111";
		String deviceType = "A";
		String pushToken = "push token";
		
		AtalkComplex.instance().login(
				userId
				, passwordPlain
				, imei
				, deviceType
				, pushToken
				, new InfAtalkChatNoti() {
					
					@Override
					public void procRetrieveChatNoti(RetrieveChatNoti notiObj) {
						// TODO Auto-generated method stub
						try {
							logger.info("#### : {}", notiObj.toJson());
						} catch (JsonProcessingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					
					@Override
					public void procReadChatNoti(ReadChatNoti notiObj) {
						try {
							logger.info("#### : {}", notiObj.toJson());
						} catch (JsonProcessingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					
					@Override
					public void procKickOutChathubNoti(KickOutChathubNoti notiObj) {
						try {
							logger.info("#### : {}", notiObj.toJson());
						} catch (JsonProcessingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					
					@Override
					public void procInviteChathubNoti(InviteChathubNoti notiObj) {
						try {
							logger.info("#### : {}", notiObj.toJson());
						} catch (JsonProcessingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					
					@Override
					public void procExitChathubNoti(ExitChathubNoti notiObj) {
						try {
							logger.info("#### : {}", notiObj.toJson());
						} catch (JsonProcessingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					
					@Override
					public void procChatDataNoti(ChatDataNoti notiObj) {
						try {
							logger.info("#### : {}", notiObj.toJson());
						} catch (JsonProcessingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				});
		logger.info("#### 2. END - LOGIN");
		
//		logger.info("#### 3. START - CHANGE PASSWORD");
//		String chgPasswordPlain = "111111";
//		changePassword(userId, passwordPlain, chgPasswordPlain);
//		logger.info("#### 3. END - CHANGE PASSWORD");
//		
//		logger.info("#### 4. START - REFRESH TOKEN");
//		String refreshToken = AtalkComplex.instance().getRefreshToken();
//		refreshToken(refreshToken);
//		logger.info("#### 4. END - REFRESH TOKEN");
	}

	static void carryonWithArgNormal(String userId, String imei) throws Exception {
		logger.info("#### 1. START - DETERMINE PACKET KEY");
		AtalkComplex.instance().determinePacketKey();
		logger.info("#### 1. END - DETERMINE PACKET KEY");
		
		logger.info("#### 2. START - LOGIN");
		// userId = "user3@abc.com";
		String passwordPlain = "111111";
		// imei = "44441111";
		String deviceType = "A";
		String pushToken = "push token";
		
		AtalkComplex.instance().login(
				userId
				, passwordPlain
				, imei
				, deviceType
				, pushToken
				, new InfAtalkChatNoti() {
					
					@Override
					public void procRetrieveChatNoti(RetrieveChatNoti notiObj) {
						// TODO Auto-generated method stub
						try {
							logger.info("#### : {}", notiObj.toJson());
						} catch (JsonProcessingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					
					@Override
					public void procReadChatNoti(ReadChatNoti notiObj) {
						try {
							logger.info("#### : {}", notiObj.toJson());
						} catch (JsonProcessingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					
					@Override
					public void procKickOutChathubNoti(KickOutChathubNoti notiObj) {
						try {
							logger.info("#### : {}", notiObj.toJson());
						} catch (JsonProcessingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					
					@Override
					public void procInviteChathubNoti(InviteChathubNoti notiObj) {
						try {
							logger.info("#### : {}", notiObj.toJson());
						} catch (JsonProcessingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					
					@Override
					public void procExitChathubNoti(ExitChathubNoti notiObj) {
						try {
							logger.info("#### : {}", notiObj.toJson());
						} catch (JsonProcessingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					
					@Override
					public void procChatDataNoti(ChatDataNoti notiObj) {
						try {
							logger.info("#### : {}", notiObj.toJson());
						} catch (JsonProcessingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				});
		logger.info("#### 2. END - LOGIN");
		
//		logger.info("#### 3. START - CHANGE PASSWORD");
//		String chgPasswordPlain = "111111";
//		changePassword(userId, passwordPlain, chgPasswordPlain);
//		logger.info("#### 3. END - CHANGE PASSWORD");
//		
//		logger.info("#### 4. START - REFRESH TOKEN");
//		String refreshToken = AtalkComplex.instance().getRefreshToken();
//		refreshToken(refreshToken);
//		logger.info("#### 4. END - REFRESH TOKEN");
	}


	public static void login(String userId, String passwordPlain, String imei) throws Exception {
		logger.info("#### 1. START - DETERMINE PACKET KEY");
		AtalkComplex.instance().determinePacketKey();
		logger.info("#### 1. END - DETERMINE PACKET KEY");
		
		logger.info("#### 2. START - LOGIN");
		// imei = "44441111";
		String deviceType = "A";
		String pushToken = "push token";
		
		AtalkComplex.instance().login(
				userId
				, passwordPlain
				, imei
				, deviceType
				, pushToken
				, new InfAtalkChatNoti() {
					
					@Override
					public void procRetrieveChatNoti(RetrieveChatNoti notiObj) {
						// TODO Auto-generated method stub
						try {
							logger.info("#### NOTI : {}", notiObj.toJson());
						} catch (JsonProcessingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					
					@Override
					public void procReadChatNoti(ReadChatNoti notiObj) {
						try {
							logger.info("#### NOTI : {}", notiObj.toJson());
						} catch (JsonProcessingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					
					@Override
					public void procKickOutChathubNoti(KickOutChathubNoti notiObj) {
						try {
							logger.info("#### NOTI : {}", notiObj.toJson());
						} catch (JsonProcessingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					
					@Override
					public void procInviteChathubNoti(InviteChathubNoti notiObj) {
						try {
							logger.info("#### NOTI : {}", notiObj.toJson());
						} catch (JsonProcessingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					
					@Override
					public void procExitChathubNoti(ExitChathubNoti notiObj) {
						try {
							logger.info("#### : {}", notiObj.toJson());
						} catch (JsonProcessingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					
					@Override
					public void procChatDataNoti(ChatDataNoti notiObj) {
						try {
							logger.info("#### NOTI : {}", notiObj.toJson());
						} catch (JsonProcessingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				});
		logger.info("#### 2. END - LOGIN");
		
//		logger.info("#### 3. START - CHANGE PASSWORD");
//		String chgPasswordPlain = "111111";
//		changePassword(userId, passwordPlain, chgPasswordPlain);
//		logger.info("#### 3. END - CHANGE PASSWORD");
//		
//		logger.info("#### 4. START - REFRESH TOKEN");
//		String refreshToken = AtalkComplex.instance().getRefreshToken();
//		refreshToken(refreshToken);
//		logger.info("#### 4. END - REFRESH TOKEN");
	}

}
