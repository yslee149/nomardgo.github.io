package com.mutecsoft.atalk.logic.inf;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.mutecsoft.atalk.logic.model.SecureDataModel;

public interface InfAtalkComplex {

	String toPacketData(SecureDataModel model) throws JsonProcessingException;
}
