package com.mutecsoft.atalk.logic.model.chat;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.mutecsoft.atalk.logic.model.AtalkPacketBase;
import com.mutecsoft.atalk.logic.model.SecureDataModel;

import com.mutecsoft.atalk.logic.util.AesEncDecComplex;

/**
 * @PackageName com.mutecsoft.atalk.logic.model.chat
 * @fileName	ExtChatResponse.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description : 대화 삭제 응답
 * <pre>
 * 
 * </pre>
 */
public class ExtChatResponse extends AtalkPacketBase {

	/**
	 * 
	 */
	private static final long serialVersionUID = -245976247312274504L;
    
	private ChatExt chatData;
	public ChatExt getChatData() {
		return chatData;
	}
	public void setChatData(ChatExt chatData) {
		this.chatData = chatData;
	}
	@Override
	public String toJson() throws JsonProcessingException {
		String prettyJson = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(this);
		// return objectMapper.writeValueAsString(this);
		return prettyJson; 
	}
	@Override
	public SecureDataModel toFinalModel() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public SecureDataModel toFinalModel(String packetKey) throws Exception {
		if (packetKey == null || packetKey.equals("")) {
			return null;
		}
		SecureDataModel secureModel = new SecureDataModel();
		secureModel.setTransactinId(this.getTransactinId());
		String jsonData = this.toJson();
		
		byte [] encBuffer = AesEncDecComplex.encryptAesCtrWithRandomIv(
				jsonData.getBytes(), packetKey);
		String hexEncString = AesEncDecComplex.bytesToHex(encBuffer);

		secureModel.setData(hexEncString);
		return secureModel;
	}

	@Override
	public SecureDataModel toFinalModel(String seedValue, String packetKey) throws Exception {
		if (packetKey == null || packetKey.equals("")) {
			return null;
		}
		if (seedValue == null || seedValue.equals("")) {
			return null;
		}
		SecureDataModel secureModel = new SecureDataModel();
		secureModel.setTransactinId(this.getTransactinId());
		String jsonData = this.toJson();
		
		byte [] encBuffer = AesEncDecComplex.encryptAesCtrWithRandomIv(
				jsonData.getBytes(), packetKey);
		String hexEncString = AesEncDecComplex.bytesToHex(encBuffer);

		secureModel.setData(hexEncString);
		secureModel.setDataAfter(seedValue);
		
		return secureModel;
	}
}
