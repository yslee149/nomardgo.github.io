package com.mutecsoft.atalk.logic.test.scenario;


import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mutecsoft.atalk.logic.AtalkComplex;
import com.mutecsoft.atalk.logic.model.amigo.AmigoDetailResponse;
import com.mutecsoft.atalk.logic.model.amigo.AmigoListResponse;

/**
 * 친구목록 처리.
 * 
 * 
 */
public class AtalkMainScenario102 {

	private static final Logger logger = LoggerFactory.getLogger(AtalkMainScenario102.class);

	
	public static void main(String [] args) throws Exception {
		
		String userId = "voyzer2@gmail.com";
		String password = "111111";
		String imei = "333331111122222";
		
		// 로그인
		{
			AtalkMainLoginTest.login(userId, password, imei);
		
			String bearerToken = AtalkComplex.instance().generateEncAccessToken();
			System.out.println("Bearer :" + bearerToken);
			
		}
		Thread.sleep(99930000);
		{
			System.exit(0);
		}
		{
			AtalkMainLoginTest.login(userId, password, imei);
		
			String bearerToken = AtalkComplex.instance().generateEncAccessToken();
			System.out.println("Bearer :" + bearerToken);
			
		}
		// AmigoSetListResponse amigoList = AtalkComplex.instance().getAmigoList();
		
		
		
		Thread.sleep(100000);
		{
			System.exit(-1);
		}
		// 친구추가
		List<Long> amigoList = Arrays.asList(4L, 5L, 6L);
		AtalkComplex.instance().addAmigo(amigoList);
		
		// 친구목록 조회
		AmigoListResponse amigoListObj = AtalkComplex.instance().getAmigoList();
		
		// 친구삭제
		List<Long> amigoListToDel = Arrays.asList(4L);
		AtalkComplex.instance().removeAmigoList(amigoListToDel);
		
		// 친구목록 조회
		amigoListObj = AtalkComplex.instance().getAmigoList();
		
		// 친구 조회
		AmigoDetailResponse amigoDetail = AtalkComplex.instance().getAmigo(5L);
				
		System.exit(-1);
//		
//		// 대화방 목록 정보 조회
//		String lastUpdateDt = "2000-01-01 12:00:00";
//		ListChathubResponse chatHubList = AtalkComplex.instance().chatHubList(lastUpdateDt);
//		
//		// 첫번째 방 꺼냄
//		ChatHubListInfo chathubInfoObj = chatHubList.getChatHubListInfo().get(0);
//		
//		// 방번호하고, 암호화키만 꺼냄
//		ChatHubInfo chathubInfo = new ChatHubInfo();
//		chathubInfo.setChathubNo(chathubInfoObj.getChathubNo());
//		chathubInfo.setEncChathubKey(chathubInfoObj.getEncChathubKey());
//		
//		// 대화방 대화 전송(일반대화)
//		SendChatResponse chatResponse = AtalkComplex.instance().sendChat("chat message1", chathubInfo);
//		
//		// 파일 대화 전송 (대용량)
//		String localFilePath = "testimage.jpg";
//		Chat chatInfo = AtalkComplex.instance().sendFileChat(
//				localFilePath
//				, chathubInfo.getChathubNo()
//				, chathubInfo.getEncChathubKey());
//		
//		ChatFile fileChatInfo= chatInfo.getChatFileInfo();
//		
////		fileChatInfo.setDownloadPath(
////				fileChatInfo.getDownloadPath().replace("chillaxmax.kr", "localhost")
////				);
//		// 파일 다운로드
//		byte [] fileData = AtalkComplex.instance().downloadFileChatData(
//				fileChatInfo.getDownloadPath()
//				, fileChatInfo.getChatFileNo()
//				, chathubInfo.getEncChathubKey()
//				);
//		
//		logger.info("### file name (display): {}", fileChatInfo.getDispFileName());
//		logger.info("### file size : {}", fileData.length);
	}
	
}
