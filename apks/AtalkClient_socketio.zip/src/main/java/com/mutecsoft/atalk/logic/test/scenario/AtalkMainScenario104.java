package com.mutecsoft.atalk.logic.test.scenario;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mutecsoft.atalk.logic.AtalkComplex;
import com.mutecsoft.atalk.logic.model.chat.Chat;
import com.mutecsoft.atalk.logic.model.chat.ChatExt;
import com.mutecsoft.atalk.logic.model.chat.ChatFile;
import com.mutecsoft.atalk.logic.model.chat.SendChatResponse;
import com.mutecsoft.atalk.logic.model.chathub.ChatHubInfo;
import com.mutecsoft.atalk.logic.model.chathub.ChatHubListInfo;
import com.mutecsoft.atalk.logic.model.chathub.ListChathubResponse;
import com.mutecsoft.atalk.logic.model.chathub.OpenChathubResponse;

/**
 * 첨부파일 대화 전송 및 보기 시나리오
 * 
 * 
 */
public class AtalkMainScenario104 {

	private static final Logger logger = LoggerFactory.getLogger(AtalkMainScenario104.class);

	public static void main(String [] args) throws Exception {
		
		String [][] userInfoList = {
				{"testuser_0", "111112222200000", "01800000000"}
				, {"testuser_1", "111112222200001", "01800000001"}
				, {"testuser_2", "111112222200002", "01800000002"}
		};

		// 회원가입
		for (String [] userInfo : userInfoList) {
			AtalkMainSignupTest.carryonWitUserId(userInfo[0], userInfo[2]);
		}
		
		// 로그인
		 AtalkMainLoginTest.carryonWithArg("testuser_0@abc.com", "01800000000");
		
		// 대화방 목록 정보 조회
		String lastUpdateDt = "2000-01-01 12:00:00";
		ListChathubResponse chatHubList = AtalkComplex.instance().chatHubList(lastUpdateDt);
		
		// 첫번째 방 꺼냄
		ChatHubListInfo chathubInfoObj = chatHubList.getChatHubListInfo().get(0);
		
		// 방번호하고, 암호화키만 꺼냄
		ChatHubInfo chathubInfo = new ChatHubInfo();
		chathubInfo.setChathubNo(chathubInfoObj.getChathubNo());
		chathubInfo.setEncChathubKey(chathubInfoObj.getEncChathubKey());
		
		// 대화방 대화 전송(일반대화)
		SendChatResponse chatResponse = AtalkComplex.instance().sendChat("chat message1", chathubInfo);
		
		// 파일 대화 전송 (대용량)
		String localFilePath = "testimage.jpg";
		Chat chatInfo = AtalkComplex.instance().sendFileChat(
				localFilePath
				, chathubInfo.getChathubNo()
				, chathubInfo.getEncChathubKey());
		
		ChatFile fileChatInfo= chatInfo.getChatFileInfo();
		
//		fileChatInfo.setDownloadPath(
//				fileChatInfo.getDownloadPath().replace("chillaxmax.kr", "localhost")
//				);
		// 파일 다운로드
		byte [] fileData = AtalkComplex.instance().downloadFileChatData(
				fileChatInfo.getDownloadPath()
				, fileChatInfo.getChatFileNo()
				, chathubInfo.getEncChathubKey()
				);
		
		logger.info("### file name (display): {}", fileChatInfo.getDispFileName());
		logger.info("### file size : {}", fileData.length);
	}
	
}
