package com.mutecsoft.atalk.logic.test;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mutecsoft.atalk.logic.AtalkComplex;
import com.mutecsoft.atalk.logic.model.chat.Chat;
import com.mutecsoft.atalk.logic.model.chat.ChatInfoRequest;
import com.mutecsoft.atalk.logic.model.chat.ChatInfoResponse;
import com.mutecsoft.atalk.logic.model.chat.SendChatRequest;
import com.mutecsoft.atalk.logic.model.chat.SendChatResponse;
import com.mutecsoft.atalk.logic.model.chathub.ChatHubInfo;
import com.mutecsoft.atalk.logic.model.chathub.OpenChathubRequest;
import com.mutecsoft.atalk.logic.model.chathub.OpenChathubResponse;
import com.mutecsoft.atalk.logic.util.AesEncDecComplex;
import com.mutecsoft.atalk.logic.util.AtalkPacketUtil;

public class AtalkMainChathubTest {

	private static final Logger logger = LoggerFactory.getLogger(AtalkMainChathubTest.class);

	public static void main(String [] args) throws Exception {
		
		logger.info("#### 1. START - DETERMINE PACKET KEY");
		AtalkMainPacketKeyTest packetKeyTestObj = new AtalkMainPacketKeyTest();
		packetKeyTestObj.determinePacketKey();
		logger.info("#### 1. END - DETERMINE PACKET KEY");
		
		logger.info("#### 2. START - LOGIN");
		String userId = "user1003@aaa.com";
		String passwordPlain = "111111";
		String imei = "111112222233333";
		String deviceType = "A";
		String pushToken = "google fcm device token value";
		
		AtalkMainLoginTest.login(
				userId
				, passwordPlain
				, imei
				, deviceType
				, pushToken);
		logger.info("#### 2. END - LOGIN");
		
		//////////////////////////////////////////////////////////////////////////////////////
		
		ChatHubInfo chathubInfo = null;
		logger.info("#### 3. START - OPEN CHATHUB - MULTI CHATHUB");
		{
			String reqUrl =	AtalkMainPacketKeyTest.REQ_HOST_VAL + "/atalk/api/v1/chatHub/openChathub";
			OpenChathubRequest obj = new OpenChathubRequest();
			List<Long> userNoListToAdd = new ArrayList<Long>();
			
			userNoListToAdd.add(1L);
			userNoListToAdd.add(2L);
			userNoListToAdd.add(3L);
			
			obj.setUserNoList(userNoListToAdd);
			OpenChathubResponse responseData = AtalkPacketUtil.requestAtalkMessage(
					obj, OpenChathubResponse.class, reqUrl);
			
			chathubInfo = responseData.getChatHubInfo();
			logger.info("#### CHATHUB NO : {}", chathubInfo.getChathubNo());
		}
		logger.info("#### 3. END - OPEN CHATHUB - MULTI CHATHUB WITH MESSAGE");
		logger.info("#### 4. START - SEND CHAT, chathub no : {}", chathubInfo.getChathubNo());
		{
			String reqUrl =	AtalkMainPacketKeyTest.REQ_HOST_VAL + "/atalk/api/v1/chat/send";
			SendChatRequest obj = new SendChatRequest();
			
			// 대화 암호화.
			String chatMessage = "대화합시다. 대화.";
			String plainKeyValue = AtalkComplex.instance().decryptChathubKey(chathubInfo.getEncChathubKey());
			byte [] encChatMesageBuff = AesEncDecComplex.encryptAesWithRandomIv(
					chatMessage.getBytes(Charset.forName("UTF-8"))
					, plainKeyValue);
			
			
			final String encChatMessage = AesEncDecComplex.bytesToHex(encChatMesageBuff);
			obj.setMessage(encChatMessage);
			
			obj.setChathubNo(chathubInfo.getChathubNo());
			SendChatResponse responseData = AtalkPacketUtil.requestAtalkMessage(
					obj, SendChatResponse.class, reqUrl);
		}
		logger.info("#### 4. END - SEND CHAT, chathub no : {}", chathubInfo.getChathubNo());
		logger.info("#### 5. START - GET CHATHUB LIST INFO");
		{
			String reqUrl =	AtalkMainPacketKeyTest.REQ_HOST_VAL + "/atalk/api/v1/chat/chatList";
	
			ChatInfoRequest obj = new ChatInfoRequest();
			obj.setChathubNo(chathubInfo.getChathubNo());
			obj.setChatInqCount(10);		// 10 개씩
			obj.setLastChatNo(0L); // 가장 최근 데이타부터 조회시 0L
			
			ChatInfoResponse responseData = AtalkPacketUtil.requestAtalkMessage(
					obj, ChatInfoResponse.class, reqUrl);
			Long lastBaseChatNo = responseData.getLastChatNo();
			logger.info("#### lastBaseChatNo NO : {}", lastBaseChatNo);
			
			String plainChathubKey =AtalkComplex.instance().decryptChathubKey(chathubInfo.getEncChathubKey());
			List<Chat> chatList = responseData.getChatList();
			if (chatList != null) {
				for (Chat chatObj : chatList) {
					try {
						
						logger.info("### message(enc) : {}", chatObj.getChatMessage());
						
						chatObj.setChatMessage(
								new String(
										AesEncDecComplex.decryptAesWithIv(
										AesEncDecComplex.hexToBytes(chatObj.getChatMessage())
										, plainChathubKey)));
						
						logger.info("### message(dec) : {}", chatObj.getChatMessage());
					} catch (Exception e) {
						chatObj.setChatMessage("");
					}
				}
			}
		}
		logger.info("#### 5. END - GET CHATHUB LIST INFO");
	}
}
