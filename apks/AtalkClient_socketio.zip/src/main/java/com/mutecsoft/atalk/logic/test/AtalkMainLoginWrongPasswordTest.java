package com.mutecsoft.atalk.logic.test;

import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mutecsoft.atalk.logic.AtalkComplex;
import com.mutecsoft.atalk.logic.inf.InfAtalkChatNoti;
import com.mutecsoft.atalk.logic.model.AtalkDataModelAll;
import com.mutecsoft.atalk.logic.model.AtalkPacketBase;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.logic.model.auth.UserLoginRequest;
import com.mutecsoft.atalk.logic.model.auth.UserLoginResponse;
import com.mutecsoft.atalk.logic.model.noti.ChatDataNoti;
import com.mutecsoft.atalk.logic.model.noti.ExitChathubNoti;
import com.mutecsoft.atalk.logic.model.noti.InviteChathubNoti;
import com.mutecsoft.atalk.logic.model.noti.KickOutChathubNoti;
import com.mutecsoft.atalk.logic.model.noti.ReadChatNoti;
import com.mutecsoft.atalk.logic.model.noti.RetrieveChatNoti;
import com.mutecsoft.atalk.logic.util.HashComplex;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class AtalkMainLoginWrongPasswordTest {

	private static final Logger logger = LoggerFactory.getLogger(AtalkMainLoginWrongPasswordTest.class);

	public static void main(String [] args) throws Exception {
		
		logger.info("#### 1. START - DETERMINE PACKET KEY");
		AtalkMainPacketKeyTest packetKeyTestObj = new AtalkMainPacketKeyTest();
		packetKeyTestObj.determinePacketKey();
		logger.info("#### 1. END - DETERMINE PACKET KEY");
		
		logger.info("#### 2. START - LOGIN");
		String userId = "user1003@aaa.com";

		String passwordPlain = "222222";
		
		String imei = "111112222233333";
		String deviceType = "A";
		String pushToken = "google fcm device token value";
		
		AtalkMainLoginWrongPasswordTest.login(
				userId
				, passwordPlain
				, imei
				, deviceType
				, pushToken);
		logger.info("#### 2. END - LOGIN");

	}

	public static void login(
			String userId
			, String passwordPlain
			, String imei
			, String deviceType
			, String pushToken
			) throws Exception {
			
		String signupUrl = AtalkMainPacketKeyTest.REQ_HOST_VAL + "/atalk/api/v1/auth/login";
		{
			UserLoginRequest reqObj = new UserLoginRequest();
			
			reqObj.setPassword(HashComplex.hashWithSha512(passwordPlain, 1));
			reqObj.setUserId(userId);
			reqObj.setClientPublicKey(AtalkComplex.instance().getPublicKey());
			reqObj.setImei(imei);
			reqObj.setDeviceType(deviceType);
			reqObj.setPushToken(pushToken);
			//MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA1O14NAJpoxj45hCf8hT0U7IzZrMLnhx+D0hJtVm0h2tvIUXRDiJkI2W+m20gWWoM667NuqlQ8A3Gb/KIe1YM/mqc1nY2nC969hfG/kL9fcD/vPMNDyOl0YMidpUdAI9vXEj9v++uaVP4OjtPstw5p9Me2aX1yGNj5onPtz6sfTqTdP9JsBPBXBdroS9BPxYqqiyFv97NWBSOm5b2RAX9FWV/pJc1PhohbuBZkKWR/WlBHoFhTCyhvrBDSWfjpLfXR1BXl9QC1XTvPthMsx5k23FCt1ybNc4JdDkhHPAcgIy02c515Bxb5vchPvqd0r7KvoDvyonvAy6Imor6jD3RJCkDCu28lJW4wZ7hr4KMC3cwlVc8jdXyVGmOdtPujFvEd7XW/NkYhzM7/mbAWAxEUmIFWRATZPt6fOu2tcY4d2scSQN+qluZE3nw/9iCHHIc7zY7NdSzlcCgFyOSMYqMYYV6BbvGcBvzDqytt2/gigGpA3JMRzqF3mCa8D7ZxXEfZ/QelPD+xwiVvLuYWtZOYUzqswaYWqPoy8arqkyCyGfiErRkkdzZ9CO4AZW/quTnC7EFBs8/PLwfJD9hS8x5l/dqiiKLzr0WISIp7fVHJZr9GZ8d1CFmH7oX0JPcjJN9h67mU9Q2MLxa0IW7nE3CyTlSQwF/hPrh8/iFL3EP4UkCAwEAAQ==
			
			logger.info(signupUrl);
			
			AtalkDataModelAll secureModel = new AtalkDataModelAll();
			secureModel.setSecureModel(
					AtalkComplex.instance().toEncPacket(reqObj));
			logger.info("############# 1. client -> server : login value");
			String json = AtalkComplex.toPacketData(secureModel);
			logger.info("## REQDATA : {}", json);
			
			OkHttpClient client = new OkHttpClient().newBuilder()
					.connectTimeout(40, TimeUnit.SECONDS)  // Connection timeout
		            .readTimeout(40, TimeUnit.SECONDS)     // Read timeout
		            .writeTimeout(40, TimeUnit.SECONDS)    // Write timeout
		            .build();
			
			MediaType jsonMediaType = MediaType.get("application/json; charset=utf-8");
			RequestBody body = RequestBody.Companion.create(json, jsonMediaType);
			Request request = new Request.Builder()
					.url(signupUrl)
					.post(body)
					.build();
			try (Response response = client.newCall(request).execute()) {
				if (response.isSuccessful()) {
					String responseJson = response.body().string();
					logger.info("Response: http code : {}, value : {}", 
							response.code()
							, responseJson);
					SecureDataModel respObj = SecureDataModel.fromBuffer(responseJson);
				
					final UserLoginResponse responseData = SecureDataModel.fromEncHexBuffer(respObj.getData()
							, AtalkComplex.instance().getPACKET_KEY()
							, UserLoginResponse.class);
					logger.info("### RESP DATA : {}",
							AtalkPacketBase.printAllFields(responseData));
					logger.info("#### RESP JSON : {}", responseData.toJson());
					if (!responseData.getError().getCode().equals(0L)) {
						logger.info("@@@@@@@@@ LOGIN FAILED : code : {}", 
								responseData.getError().getCode());
						return;
					}
					AtalkComplex.instance().setAccessToken(responseData.getAccessToken());
					AtalkComplex.instance().setRefreshToken(responseData.getRefreshToken());
					AtalkComplex.instance().setServerPublicKey(responseData.getServerPublicKey());
					AtalkComplex.instance().setUserInfo(responseData);
					
					// 앱에서 실시간 메시지 처리

					AtalkComplex.instance().postLoginSuccess(
							AtalkComplex.WEBSOCKET_SECURE_CONN_HOST
								, new InfAtalkChatNoti() {
									
									// 대화 회수 실시간 메시지 처리
									@Override
									public void procRetrieveChatNoti(RetrieveChatNoti notiObj) {
										// TODO Auto-generated method stub
										
									}
									
									// 대화 읽음 실시간 메시지 처리
									@Override
									public void procReadChatNoti(ReadChatNoti notiObj) {
										// TODO Auto-generated method stub
										
									}
									
									// 대화방 강퇴 실시간 메시지 처리
									@Override
									public void procKickOutChathubNoti(KickOutChathubNoti notiObj) {
										// TODO Auto-generated method stub
										
									}
									
									// 대화방 초대 실시간 메시지 처리
									@Override
									public void procInviteChathubNoti(InviteChathubNoti notiObj) {
										// TODO Auto-generated method stub
										
									}
									
									// 대화방 퇴장 실시간 메시지 처리
									@Override
									public void procExitChathubNoti(ExitChathubNoti notiObj) {
										// TODO Auto-generated method stub
										
									}

									// 실시간 대화 처리
									@Override
									public void procChatDataNoti(ChatDataNoti notiObj) {
										// TODO Auto-generated method stub
										
									}
								}
							
							);
					
				} else {
					logger.error("Error: " + response.code());
					logger.error("@@@@@@@@@ SIGNUP ERR CASE 1");
					System.exit(1);
				}
			} catch (Exception e) {
				logger.error("@@@@@@@@@ SIGNUP ERR CASE 2 : {}", e);
				System.exit(2);
			}
		}
	}
	
}
