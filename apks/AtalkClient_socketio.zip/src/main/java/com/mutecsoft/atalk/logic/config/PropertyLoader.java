package com.mutecsoft.atalk.logic.config;

import java.io.InputStream;
import java.util.Properties;

public class PropertyLoader {

    public static Properties loadProperties() {
        Properties properties = new Properties();
        try (InputStream input = PropertyLoader.class.getClassLoader().getResourceAsStream("application.properties")) {
            if (input == null) {
                System.out.println("Sorry, unable to find application.properties");
                return null;
            }
            properties.load(input);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return properties;
    }
}
