package com.mutecsoft.atalk.logic.model.chathub;

import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.mutecsoft.atalk.logic.model.AtalkPacketBase;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.logic.util.AesEncDecComplex;

/**
 * @PackageName com.mutecsoft.atalk.logic.model.chathub
 * @fileName	OpenChathubRequest.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description :  chathub 개설 요청
 * <pre>
 * 
 * </pre>
 */
public class OpenChathubRequest extends AtalkPacketBase {

	/**
	 * 
	 */
	private static final long serialVersionUID = -245976247312274504L;

	private int notiTestToMe; // 1 : noti including me, 0 : no need to noti to me.
	private String timerYn;
	private int timeValue;
	private	List<Long> userNoList;
	
	private int reqChatCount = 10;

	public int getReqChatCount() {
		return reqChatCount;
	}
	public void setReqChatCount(int reqChatCount) {
		this.reqChatCount = reqChatCount;
	}

	public String getTimerYn() {
		return timerYn;
	}
	public void setTimerYn(String timerYn) {
		this.timerYn = timerYn;
	}
	public int getTimeValue() {
		return timeValue;
	}
	public void setTimeValue(int timeValue) {
		this.timeValue = timeValue;
	}
	public int getNotiTestToMe() {
		return notiTestToMe;
	}
	public void setNotiTestToMe(int notiTestToMe) {
		this.notiTestToMe = notiTestToMe;
	}
	public List<Long> getUserNoList() {
		return userNoList;
	}
	public void setUserNoList(List<Long> userNoList) {
		this.userNoList = userNoList;
	}
	@Override
	public String toJson() throws JsonProcessingException {
		return objectMapper.writeValueAsString(this);
	}
	@Override
	public SecureDataModel toFinalModel() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public SecureDataModel toFinalModel(String packetKey) throws Exception {
		if (packetKey == null || packetKey.equals("")) {
			return null;
		}
		SecureDataModel secureModel = new SecureDataModel();
		secureModel.setTransactinId(this.getTransactinId());
		String jsonData = this.toJson();
		
		byte [] encBuffer = AesEncDecComplex.encryptAesCtrWithRandomIv(
				jsonData.getBytes(), packetKey);
		String hexEncString = AesEncDecComplex.bytesToHex(encBuffer);

		secureModel.setData(hexEncString);
		return secureModel;
	}

	@Override
	public SecureDataModel toFinalModel(String seedValue, String packetKey) throws Exception {
		if (packetKey == null || packetKey.equals("")) {
			return null;
		}
		if (seedValue == null || seedValue.equals("")) {
			return null;
		}
		SecureDataModel secureModel = new SecureDataModel();
		secureModel.setTransactinId(this.getTransactinId());
		String jsonData = this.toJson();
		
		byte [] encBuffer = AesEncDecComplex.encryptAesCtrWithRandomIv(
				jsonData.getBytes(), packetKey);
		String hexEncString = AesEncDecComplex.bytesToHex(encBuffer);

		secureModel.setData(hexEncString);
		secureModel.setDataAfter(seedValue);
		
		return secureModel;
	}
}
