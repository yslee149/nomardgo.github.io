package com.mutecsoft.atalk.logic.test;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.DeliverCallback;

public class AtalkRabbitMqTest {

	private static final Logger logger = LoggerFactory.getLogger(AtalkRabbitMqTest.class);

    private final static String QUEUE_NAME = "Q_999999999999999_4";

    // private final static String RABBITMQ_HOST = "192.168.100.101";
    private final static String RABBITMQ_HOST = "chillaxmax.kr";
    private final static int RABBITMQ_PORT = 25672;
    // private final static int RABBITMQ_PORT = 5672;
    
    private final static String USER_NAME = "rabbit";
    private final static String USER_PASSWORD = "rabbitpassword";

	public static void main(String [] args) throws Exception {
		{
			Thread consumer = new Thread(new Runnable() {
				
				@Override
				public void run() {
					{
//						Map<String, Object> rabbitMqConf = new HashMap<>();
//						rabbitMqConf.put("x-expires", 60000); // Set TTL for queue to 60 seconds
//					    
						ConnectionFactory factory = new ConnectionFactory();
				        factory.setHost(RABBITMQ_HOST);
				        factory.setPort(RABBITMQ_PORT);
				        factory.setUsername(USER_NAME);
				        factory.setPassword(USER_PASSWORD);
				        try {
					        Connection connection = factory.newConnection();
					        Channel channel = connection.createChannel();
		
					        channel.queueDeclare(
					        		QUEUE_NAME
					        		, false
					        		, false
					        		, true
					        		, null);
					        System.out.println(" [*] Waiting for messages. To exit press CTRL+C");
		
					        DeliverCallback deliverCallback = (consumerTag, delivery) -> {
					            String message = new String(delivery.getBody(), "UTF-8");
					            System.out.println(" [x] 1 Received '" + message + "'");
					        };
					        channel.basicConsume(QUEUE_NAME, true, deliverCallback, consumerTag -> { });
				        } catch (Exception e) {
				        	logger.error("@@@@1 : {}", e);
				        }
				        
					}
				}
			});
			consumer.start();
		}
//		
//		{
//			Thread consumer = new Thread(new Runnable() {
//				
//				@Override
//				public void run() {
//					{
//						ConnectionFactory factory = new ConnectionFactory();
//				        factory.setHost(RABBITMQ_HOST);
//				        factory.setPort(RABBITMQ_PORT);
//				        factory.setUsername(USER_NAME);
//				        factory.setPassword(USER_PASSWORD);
//				        try {
//					        Connection connection = factory.newConnection();
//					        Channel channel = connection.createChannel();
//		
//					        channel.queueDeclare(QUEUE_NAME, false, false, true, null);
//					        System.out.println(" [*] Waiting for messages. To exit press CTRL+C");
//		
//					        DeliverCallback deliverCallback = (consumerTag, delivery) -> {
//					            String message = new String(delivery.getBody(), "UTF-8");
//					            System.out.println(" [x] 2 Received '" + message + "'");
//					        };
//					        channel.basicConsume(QUEUE_NAME, true, deliverCallback, consumerTag -> { });
//				        } catch (Exception e) {
//				        	logger.error("@@@@1 : {}", e.getMessage());
//				        }
//				        
//					}
//				}
//			});
//			consumer.start();
//		}
		
		try {
			Thread.sleep(3000);
		} catch (Exception e) {}

//		Thread producer = new Thread(new Runnable() {
//			
//			@Override
//			public void run() {
//				while (true) {
//					{
//						ConnectionFactory factory = new ConnectionFactory();
//				        factory.setHost(RABBITMQ_HOST);
//				        factory.setPort(RABBITMQ_PORT);
//				        factory.setUsername(USER_NAME);
//				        factory.setPassword(USER_PASSWORD);
//						try {
//							Connection connection = factory.newConnection();
//							Channel channel = connection.createChannel();
//							channel.queueDeclare(QUEUE_NAME, false, false, true, null);
//				            String message = "Hello, RabbitMQ!";
//				            channel.basicPublish("", QUEUE_NAME, null, message.getBytes());
//				            System.out.println(" [x] Sent '" + message + "'");
//				        } catch (Exception e) {
//				        	logger.error("@@@@2 : {}", e.getMessage());
//				        }
//					}
//					
//					{
//						ConnectionFactory factory = new ConnectionFactory();
//				        factory.setHost(RABBITMQ_HOST);
//				        factory.setPort(RABBITMQ_PORT);
//				        factory.setUsername(USER_NAME);
//				        factory.setPassword(USER_PASSWORD);
//						try {
//							Connection connection = factory.newConnection();
//							Channel channel = connection.createChannel();
//							channel.queueDeclare(QUEUE_NAME, false, false, true, null);
//				            String message = "Hello, RabbitMQ!";
//				            channel.basicPublish("", QUEUE_NAME, null, message.getBytes());
//				            System.out.println(" [x] Sent '" + message + "'");
//				        } catch (Exception e) {
//				        	logger.error("@@@@2 : {}", e.getMessage());
//				        }
//					}
//					try {
//						Thread.sleep(1000);
//					} catch (InterruptedException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
//				}
//			}
//		});
//		
//		producer.start();
//		
		Thread.sleep(30000);
		
	}
}
