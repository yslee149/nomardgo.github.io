package com.mutecsoft.atalk.logic.test;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mutecsoft.atalk.logic.AtalkComplex;
import com.mutecsoft.atalk.logic.model.AtalkDataModelAll;
import com.mutecsoft.atalk.logic.model.AtalkPacketBase;
import com.mutecsoft.atalk.logic.model.SecureDataModel;
import com.mutecsoft.atalk.logic.model.amigo.AddAmigoRequest;
import com.mutecsoft.atalk.logic.model.amigo.AddAmigoResponse;
import com.mutecsoft.atalk.logic.model.amigo.DeleteAmigoRequest;
import com.mutecsoft.atalk.logic.model.amigoset.AddAmigoSetRequest;
import com.mutecsoft.atalk.logic.model.amigoset.AddAmigoSetResponse;
import com.mutecsoft.atalk.logic.model.amigoset.AmigoSetListResponse;
import com.mutecsoft.atalk.logic.model.amigoset.DeleteAmigoSetResponse;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class AtalkMainAmigoTest {

	private static final Logger logger = LoggerFactory.getLogger(AtalkMainAmigoTest.class);

	public static void main(String [] args) throws Exception {
		
		logger.info("#### 1. START - DETERMINE PACKET KEY");
		AtalkMainPacketKeyTest packetKeyTestObj = new AtalkMainPacketKeyTest();
		packetKeyTestObj.determinePacketKey();
		logger.info("#### 1. END - DETERMINE PACKET KEY");
		
		logger.info("#### 2. START - LOGIN");
		String userId = "user1003@aaa.com";
		String passwordPlain = "111111";
		String imei = "111112222233333";
		String deviceType = "A";
		String pushToken = "google fcm device token value";
		
		AtalkMainLoginTest.login(
				userId
				, passwordPlain
				, imei
				, deviceType
				, pushToken);
		logger.info("#### 2. END - LOGIN");

		logger.info("#### 3. START - ADD AMIGO SET");
		String amigoSetName = "친구그룹1";
		Long amigoSetNoAdded = addAmigoSet(amigoSetName);
		logger.info("#### 3. END - ADD AMIGO SET");
		
		logger.info("#### 4. START - ADD AMIGO TO AMIGO");
		List<Long> userNoListToAdd = new ArrayList<Long>();
		
		userNoListToAdd.add(1L);
		userNoListToAdd.add(2L);
		userNoListToAdd.add(3L);
		userNoListToAdd.add(4L);
		
		addAmigo(amigoSetNoAdded, userNoListToAdd);
		logger.info("#### 4. END - ADD AMIGO TO AMIGO");
		
//		{
//			System.exit(0);
//		}
		Long amigoSetNoDelete = amigoSetNoAdded;
		
		List<Long> amigoSetNoList = new ArrayList<Long>();
		amigoSetNoList.add(amigoSetNoDelete);
		amigoSetNoList.add(1L);
		amigoSetNoList.add(2L);
			
		logger.info("#### 5. START - DELETE AMIGO FROM AMIGO SET");
		deleteAmigo(amigoSetNoDelete, amigoSetNoList);
		logger.info("#### 5. END - DELETE AMIGO FROM AMIGO SET");
//		{
//			System.exit(0);
//		}
		logger.info("#### 6. START - GET AMIGO LIST");
		getAmigoList();
		logger.info("#### 6. END - GET AMIGO LIST");
	}

	/**
	 * 
	 * @param amigoSetNo
	 * @param amigoUserNoList
	 * @return
	 * @throws Exception
	 */
	private static Long addAmigo(Long amigoSetNo, List<Long> amigoUserNoList) throws Exception {
		
		String url1 = AtalkMainPacketKeyTest.REQ_HOST_VAL + "/atalk/api/v1/amigo/add";
		{
			AddAmigoRequest reqObj = new AddAmigoRequest();
			reqObj.setAmigoUserNoList(amigoUserNoList);
			
			AtalkDataModelAll secureModel = new AtalkDataModelAll();
			secureModel.setSecureModel(
					AtalkComplex.instance().toEncPacket(reqObj));
			logger.info("############# 1. client -> server : add amigo");
			String json = AtalkComplex.toPacketData(secureModel);
			logger.info("## REQDATA : {}", json);
			
			OkHttpClient client = new OkHttpClient().newBuilder()
					.connectTimeout(40, TimeUnit.SECONDS)  // Connection timeout
		            .readTimeout(40, TimeUnit.SECONDS)     // Read timeout
		            .writeTimeout(40, TimeUnit.SECONDS)    // Write timeout
		            .build();
			
			MediaType jsonMediaType = MediaType.get("application/json; charset=utf-8");
			RequestBody body = RequestBody.Companion.create(json, jsonMediaType);
			
			////////// ENCRYPT ACCESS TOKEN
			String encJwtHexToken = AtalkComplex.instance().generateEncAccessToken();
			// encJwtHexToken = jwtToken;
			logger.info("### access token(enchex) : {}", encJwtHexToken);
			////////// ENCRYPT ACCESS TOKEN
			Request request = new Request.Builder()
					.url(url1)
					.addHeader("Authorization", "Bearer " + encJwtHexToken) // Add JWT token here
					.post(body)
					.build();
			try (Response response = client.newCall(request).execute()) {
				if (response.isSuccessful()) {
					String responseJson = response.body().string();
					logger.info("Response: http code : {}, value : {}", 
							response.code()
							, responseJson);
					SecureDataModel respObj = SecureDataModel.fromBuffer(responseJson);
				
					final AddAmigoResponse responseData = SecureDataModel.fromEncHexBuffer(respObj.getData()
							, AtalkComplex.instance().getPACKET_KEY()
							, AddAmigoResponse.class);
					logger.info("### RESP DATA : {}",
							AtalkPacketBase.printAllFields(responseData));
					logger.info("#### RESP JSON : {}", responseData.toJson());
					
				} else {
					logger.error("Error: " + response.code());
					logger.error("@@@@@@@@@ SIGNUP ERR CASE 1");
					System.exit(1);
				}
			} catch (Exception e) {
				logger.error("@@@@@@@@@ SIGNUP ERR CASE 2 : {}", e);
				System.exit(2);
			}
		}
		return amigoSetNo;
	}
	
	/**
	 * 
	 * @param amigoSetNo
	 * @param amigoUserNoList
	 * @throws Exception
	 */
	private static void deleteAmigo(Long amigoSetNo, List<Long> amigoUserNoList) throws Exception {
		
		String url1 = AtalkMainPacketKeyTest.REQ_HOST_VAL + "/atalk/api/v1/amigo/delete";
		{
			DeleteAmigoRequest reqObj = new DeleteAmigoRequest();
			reqObj.setAmigoUserNoList(amigoUserNoList);
			
			AtalkDataModelAll secureModel = new AtalkDataModelAll();
			secureModel.setSecureModel(
					AtalkComplex.instance().toEncPacket(reqObj));
			logger.info("############# 1. client -> server : add amigoset");
			String json = AtalkComplex.toPacketData(secureModel);
			logger.info("## REQDATA : {}", json);
			
			OkHttpClient client = new OkHttpClient().newBuilder()
					.connectTimeout(40, TimeUnit.SECONDS)  // Connection timeout
		            .readTimeout(40, TimeUnit.SECONDS)     // Read timeout
		            .writeTimeout(40, TimeUnit.SECONDS)    // Write timeout
		            .build();
			
			MediaType jsonMediaType = MediaType.get("application/json; charset=utf-8");
			RequestBody body = RequestBody.Companion.create(json, jsonMediaType);
			
			////////// ENCRYPT ACCESS TOKEN
			String encJwtHexToken = AtalkComplex.instance().generateEncAccessToken();
			// encJwtHexToken = jwtToken;
			logger.info("### access token(enchex) : {}", encJwtHexToken);
			////////// ENCRYPT ACCESS TOKEN
			Request request = new Request.Builder()
					.url(url1)
					.addHeader("Authorization", "Bearer " + encJwtHexToken) // Add JWT token here
					.post(body)
					.build();
			try (Response response = client.newCall(request).execute()) {
				if (response.isSuccessful()) {
					String responseJson = response.body().string();
					logger.info("Response: http code : {}, value : {}", 
							response.code()
							, responseJson);
					SecureDataModel respObj = SecureDataModel.fromBuffer(responseJson);
				
					final DeleteAmigoSetResponse responseData = SecureDataModel.fromEncHexBuffer(respObj.getData()
							, AtalkComplex.instance().getPACKET_KEY()
							, DeleteAmigoSetResponse.class);
					logger.info("### RESP DATA : {}",
							AtalkPacketBase.printAllFields(responseData));
					logger.info("#### RESP JSON : {}", responseData.toJson());
					
				} else {
					logger.error("Error: " + response.code());
					logger.error("@@@@@@@@@ SIGNUP ERR CASE 1");
					System.exit(1);
				}
			} catch (Exception e) {
				logger.error("@@@@@@@@@ SIGNUP ERR CASE 2 : {}", e);
				System.exit(2);
			}
		}
	}
	
	/**
	 * 
	 * @throws Exception
	 */
	private static void getAmigoList() throws Exception {
		
		String url1 = AtalkMainPacketKeyTest.REQ_HOST_VAL + "/atalk/api/v1/amigo/list";
		{
			logger.info("############# 1. client -> server : amigoset list");
			
			OkHttpClient client = new OkHttpClient().newBuilder()
					.connectTimeout(40, TimeUnit.SECONDS)  // Connection timeout
		            .readTimeout(40, TimeUnit.SECONDS)     // Read timeout
		            .writeTimeout(40, TimeUnit.SECONDS)    // Write timeout
		            .build();
			
			////////// ENCRYPT ACCESS TOKEN
			String encJwtHexToken = AtalkComplex.instance().generateEncAccessToken();
			// encJwtHexToken = jwtToken;
			logger.info("### access token(enchex) : {}", encJwtHexToken);
			////////// ENCRYPT ACCESS TOKEN
			Request request = new Request.Builder()
					.url(url1)
					.addHeader("Authorization", "Bearer " + encJwtHexToken) // Add JWT token here
					.build();
			try (Response response = client.newCall(request).execute()) {
				if (response.isSuccessful()) {
					String responseJson = response.body().string();
					logger.info("Response: http code : {}, value : {}", 
							response.code()
							, responseJson);
					SecureDataModel respObj = SecureDataModel.fromBuffer(responseJson);
				
					final AmigoSetListResponse responseData = SecureDataModel.fromEncHexBuffer(respObj.getData()
							, AtalkComplex.instance().getPACKET_KEY()
							, AmigoSetListResponse.class);
					logger.info("### RESP DATA : {}",
							AtalkPacketBase.printAllFields(responseData));
					logger.info("#### RESP JSON : {}", responseData.toJson());
					
				} else {
					logger.error("Error: " + response.code());
					logger.error("@@@@@@@@@ SIGNUP ERR CASE 1");
					System.exit(1);
				}
			} catch (Exception e) {
				logger.error("@@@@@@@@@ SIGNUP ERR CASE 2 : {}", e);
				System.exit(2);
			}
		}
	}


	/**
	 * 
	 * 
	 * @param newAmigoSetName
	 * @throws Exception
	 */
	private static Long addAmigoSet(String newAmigoSetName) throws Exception {
		
		Long amigoSetNo = 0L;
		String url1 = AtalkMainPacketKeyTest.REQ_HOST_VAL + "/atalk/api/v1/amigoSet/add";
		{
			AddAmigoSetRequest reqObj = new AddAmigoSetRequest();
			
			reqObj.setAmigoSetName(newAmigoSetName);
			
			AtalkDataModelAll secureModel = new AtalkDataModelAll();
			secureModel.setSecureModel(
					AtalkComplex.instance().toEncPacket(reqObj));
			logger.info("############# 1. client -> server : add amigoset");
			String json = AtalkComplex.toPacketData(secureModel);
			logger.info("## REQDATA : {}", json);
			
			OkHttpClient client = new OkHttpClient().newBuilder()
					.connectTimeout(40, TimeUnit.SECONDS)  // Connection timeout
		            .readTimeout(40, TimeUnit.SECONDS)     // Read timeout
		            .writeTimeout(40, TimeUnit.SECONDS)    // Write timeout
		            .build();
			
			MediaType jsonMediaType = MediaType.get("application/json; charset=utf-8");
			RequestBody body = RequestBody.Companion.create(json, jsonMediaType);
			
			////////// ENCRYPT ACCESS TOKEN
			String encJwtHexToken = AtalkComplex.instance().generateEncAccessToken();
			// encJwtHexToken = jwtToken;
			logger.info("### access token(enchex) : {}", encJwtHexToken);
			////////// ENCRYPT ACCESS TOKEN
			Request request = new Request.Builder()
					.url(url1)
					.addHeader("Authorization", "Bearer " + encJwtHexToken) // Add JWT token here
					.post(body)
					.build();
			try (Response response = client.newCall(request).execute()) {
				if (response.isSuccessful()) {
					String responseJson = response.body().string();
					logger.info("Response: http code : {}, value : {}", 
							response.code()
							, responseJson);
					SecureDataModel respObj = SecureDataModel.fromBuffer(responseJson);
				
					final AddAmigoSetResponse responseData = SecureDataModel.fromEncHexBuffer(respObj.getData()
							, AtalkComplex.instance().getPACKET_KEY()
							, AddAmigoSetResponse.class);
					logger.info("### RESP DATA : {}",
							AtalkPacketBase.printAllFields(responseData));
					logger.info("#### RESP JSON : {}", responseData.toJson());
					
					amigoSetNo = responseData.getAmigoSetNo();
				} else {
					logger.error("Error: " + response.code());
					logger.error("@@@@@@@@@ SIGNUP ERR CASE 1");
					System.exit(1);
				}
			} catch (Exception e) {
				logger.error("@@@@@@@@@ SIGNUP ERR CASE 2 : {}", e);
				System.exit(2);
			}
		}
		return amigoSetNo;
	}
}
