package com.mutecsoft.atalk.logic.test.scenario;

import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mutecsoft.atalk.logic.AtalkComplex;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class AtalkMainResetData {

	private static final Logger logger = LoggerFactory.getLogger(AtalkMainResetData.class);

	public static void main(String [] args) throws Exception {

		carryon();
	}

	static void carryon() {
		String resetAll = AtalkComplex.REQ_HOST_VAL + "/atalk/api/v1/svcctrl/resetAll";

		OkHttpClient client = new OkHttpClient().newBuilder()
				.connectTimeout(40, TimeUnit.SECONDS)  // Connection timeout
	            .readTimeout(40, TimeUnit.SECONDS)     // Read timeout
	            .writeTimeout(40, TimeUnit.SECONDS)    // Write timeout
	            .build();
		
		Request request = new Request.Builder()
				.url(resetAll)
				.get()
				.build();
		try (Response response = client.newCall(request).execute()) {
			if (response.isSuccessful()) {
				String responseData = response.body().string();
				logger.info("Response: http code : {}, value : {}", 
						response.code()
						, responseData);
			} else {
				logger.error("Error: " + response.code());
				logger.error("@@@@@@@@@ ERR CASE 1");
			}
		} catch (Exception e) {
			logger.error("@@@@@@@@@ ERR CASE 2 : {}", e);
		}
	}
}
