package com.mutecsoft.atalk.logic.test;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mutecsoft.atalk.logic.AtalkComplex;
import com.mutecsoft.atalk.logic.contant.EnumChatType;
import com.mutecsoft.atalk.logic.model.chat.Chat;
import com.mutecsoft.atalk.logic.model.chat.SendFileChatRequest;
import com.mutecsoft.atalk.logic.model.chat.SendFileChatResponse;
import com.mutecsoft.atalk.logic.model.chathub.ChatHubListInfo;
import com.mutecsoft.atalk.logic.model.chathub.ListChathubResponse;
import com.mutecsoft.atalk.logic.util.AesEncDecComplex;
import com.mutecsoft.atalk.logic.util.AtalkPacketUtil;
import com.mutecsoft.atalk.logic.util.BufferComplex;
import com.mutecsoft.atalk.logic.util.RandomHexString;

public class AtalkMainFileChatTest {

	private static final Logger logger = LoggerFactory.getLogger(AtalkMainFileChatTest.class);

	public static void main(String [] args) throws Exception {
		
		final String userId = "user1003@aaa.com";
		final String passwordPlain = "111111";

		// 로그인 후 대화방 목록 조회
		ListChathubResponse responseChatListData  = AtalkMainChathubListTest.getChatHubInfoList(
				userId, passwordPlain);
		
		List<ChatHubListInfo> chatHubList = responseChatListData.getChatHubListInfo();
		Long targetChathubNo = null;
		///////////////////////////////////////////////////////////
		ChatHubListInfo targetChathubInfo = null; // 파일대화 입력할 대화방 정보
		///////////////////////////////////////////////////////////
		for (ChatHubListInfo chathubObj : chatHubList) {
			
			if (chathubObj.getJoinYn().equals("Y")) {
				targetChathubNo = chathubObj.getChathubNo();
				targetChathubInfo = chathubObj;
				break;
			}
		}
		///////////////////////////////////////////////////////////////////////////////////
		// 파일 대화 입력
		String localFilePath = "testimage.jpg";
		String fileDownloadPath =  "";
		Chat respFileChatObj = null; 
		
		Long myUserNo = AtalkComplex.instance().getUserInfo().getUserNo();
		logger.info("############### START - SEND FILE CHAT(IMAGE), chathub no : {}, my user no : {}", 
				targetChathubNo, myUserNo);
		{
			String reqUrl =	AtalkMainPacketKeyTest.REQ_HOST_VAL + "/atalk/api/v1/chat/send/file";
			reqUrl = String.format("%s/%d/%s", reqUrl, targetChathubNo, "I");  // IMAGE 전송 URL
			
			SendFileChatRequest obj = new SendFileChatRequest();
			obj.setChathubNo(targetChathubNo);
			
			Object [] retFileObjArr = BufferComplex.getFileDataAndFileName(localFilePath);
			
			byte [] plainBuffer = (byte [])retFileObjArr[0];
			String fileName =(String)retFileObjArr[1];
			
			/////////////////////////////////////////////////////////////////////////
			
			// 1. 대화방의 ENC 대화방키 를 내 개인키로 복호화
			String plainChathubKey = AtalkComplex.instance().decryptChathubKey(
					targetChathubInfo.getEncChathubKey());
			logger.info("### plainChathubKey : {}", plainChathubKey);
			// 2. 파일 버퍼를 대화방 암호화키로 암호화.			
			byte [] encBuffer = AesEncDecComplex.encryptAesWithRandomIv(
					plainBuffer
					, plainChathubKey);
			
			// 3. 최종 버퍼 암호화된 파일 버퍼에 packetSeedBuffer, transaction id buffer 추가
			encBuffer =  BufferComplex.appendBytesMore(
					encBuffer
					, BufferComplex.hexToBytes(AtalkComplex.instance().getPacketSeedValue())
					, BufferComplex.hexToBytes(RandomHexString.genSecureRandomHex(16)));
			
			/////////////////////////////////////////////////////////////////////////
			
			SendFileChatResponse responseData = AtalkPacketUtil.requestAtalkFileMessage(
					SendFileChatResponse.class, reqUrl, encBuffer, fileName);
			
			Chat respChatObj = responseData.getChatData();
			respFileChatObj = respChatObj;
			try {
				fileDownloadPath = respChatObj.getChatFileInfo().getDownloadPath();
				if (respChatObj.getChatType().equals(EnumChatType.MESSAGE_GENERAL_TYPE.getValue())
					|| (respChatObj.getChatType().equals(EnumChatType.MESSAGE_EXT_GENERAL_TYPE.getValue()))) {
					logger.info("### message(enc) : {}", respChatObj.getChatMessage());
					respChatObj.setChatMessage(
							new String(
									AesEncDecComplex.decryptAesWithIv(
									AesEncDecComplex.hexToBytes(respChatObj.getChatMessage())
									, plainChathubKey)));
					logger.info("### message(dec) : {}", respChatObj.getChatMessage());
					logger.info("### DONWLOAD URL : {}", fileDownloadPath);
				}
			} catch (Exception e) {
				logger.info("@@@@ : {}", e);
			}
		}
		logger.info("############### END - SEND FILE CHAT(IMAGE), chathub no : {}, my user no : {}", targetChathubNo, myUserNo);
		
		logger.info("############### START - DOWNLOAD a FILE, chathub no : {}, my user no : {}", 
				targetChathubNo, myUserNo);
		
		{
			// String reqUrl =	AtalkMainPacketKeyTest.REQ_HOST_VAL + "/atalk/api/v1/chat/file";
			String reqUrl =	fileDownloadPath;
			logger.info("#### download url : {}", reqUrl);
			
			/////////////////////////////////////////////////////////////////////////
			byte [] encFileData = AtalkPacketUtil.downloadAttachedFile(
					reqUrl);
			
			// 1. 대화방의 ENC 대화방키 를 내 개인키로 복호화
			String plainChathubKey = AtalkComplex.instance().decryptChathubKey(
					targetChathubInfo.getEncChathubKey());
			logger.info("### plainChathubKey : {}", plainChathubKey);
			
			// 2. 파일버퍼 복호화.
			final byte [] finalDecBuffer = AesEncDecComplex.decryptAesWithIv(
					encFileData
					, plainChathubKey);

			// 3. 파일 다운로드.
			final String filePathString = String.format("%s\\%s", 
					"D:\\AtalkClient\\attfile"
					, respFileChatObj.getChatFileInfo().getDispFileName());
			Path filePath = Paths.get(filePathString);
			try {
				Files.write(filePath, finalDecBuffer);
				System.out.println("File written successfully to: " + filePathString);
			} catch (IOException e) {
				logger.error("@@@@ : {}", e);
			}
		}
		logger.info("############### END - DOWNLOAD a FILE, chathub no : {}, my user no : {}", targetChathubNo, myUserNo);
	}
}

