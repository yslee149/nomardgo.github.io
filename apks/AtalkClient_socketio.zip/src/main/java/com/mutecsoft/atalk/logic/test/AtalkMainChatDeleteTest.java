package com.mutecsoft.atalk.logic.test;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mutecsoft.atalk.logic.AtalkComplex;
import com.mutecsoft.atalk.logic.contant.EnumChatType;
import com.mutecsoft.atalk.logic.model.chat.Chat;
import com.mutecsoft.atalk.logic.model.chat.ChatInfoRequest;
import com.mutecsoft.atalk.logic.model.chat.ChatInfoResponse;
import com.mutecsoft.atalk.logic.model.chat.DeleteChatRequest;
import com.mutecsoft.atalk.logic.model.chat.DeleteChatResponse;
import com.mutecsoft.atalk.logic.model.chat.SendChatRequest;
import com.mutecsoft.atalk.logic.model.chat.SendChatResponse;
import com.mutecsoft.atalk.logic.model.chathub.ChatHubListInfo;
import com.mutecsoft.atalk.logic.model.chathub.ListChathubResponse;
import com.mutecsoft.atalk.logic.util.AesEncDecComplex;
import com.mutecsoft.atalk.logic.util.AtalkPacketUtil;

/**
 * 대화 삭제 테스트 (나에게서만 안보임)
 * 
 * 
 */
public class AtalkMainChatDeleteTest {

	private static final Logger logger = LoggerFactory.getLogger(AtalkMainChatDeleteTest.class);

	public static void main(String [] args) throws Exception {

		final String userId = "user1003@aaa.com";
		final String passwordPlain = "111111";
		Chat respChatObj = null;
		
		// 로그인 후 대화방 목록 조회
		ListChathubResponse responseChatListData  = AtalkMainChathubListTest.getChatHubInfoList(
				userId, passwordPlain);
		
		List<ChatHubListInfo> chatHubList = responseChatListData.getChatHubListInfo();
		Long targetChathubNo = null;
		Long targetChatNo = null;  // 삭제 대상 대화, 대화 입력 후 바로 삭제함.
		
		///////////////////////////////////////////////////////////
		ChatHubListInfo targetChathubInfo = null; // 파일대화 입력할 대화방 정보
		///////////////////////////////////////////////////////////
		for (ChatHubListInfo chathubObj : chatHubList) {
			
			if (chathubObj.getJoinYn().equals("Y")) {
				targetChathubNo = chathubObj.getChathubNo();
				targetChathubInfo = chathubObj;
				break;
			}
		}
		
		String plainChathubKey = null; // 복호화된 대화방 키.
		logger.info("#### 3. START - GET CHAT HUB INFO, chathub no : {}", targetChathubNo);
		{
			String reqUrl =	AtalkMainPacketKeyTest.REQ_HOST_VAL + "/atalk/api/v1/chat/send";
			SendChatRequest obj = new SendChatRequest();

			// 1. 대화방의 ENC 대화방키 를 내 개인키로 복호화
			plainChathubKey = AtalkComplex.instance().decryptChathubKey(
					targetChathubInfo.getEncChathubKey());
			logger.info("### plainChathubKey : {}", plainChathubKey);
			
			// 2. 대화내용을 대화방 암호화키로 암호화.			
			byte [] encBuffer = AesEncDecComplex.encryptAesWithRandomIv(
					chatMessage.getBytes()
					, plainChathubKey);
			
			
			if (chatMessage.length() > AtalkComplex.instance().getExtChatBaseSize()) {
				String shortMessage = chatMessage.substring(0, AtalkComplex.instance().getExtChatBaseSize()
					);
				byte [] encShortMsgBuffer = AesEncDecComplex.encryptAesWithRandomIv(
						shortMessage.getBytes()
						, plainChathubKey);
				obj.setShortMessage(AesEncDecComplex.bytesToHex(encShortMsgBuffer));
			}

			// 3. 대화방에서 보여질 짧은 대화내용을 암호화키로 암호화.
			obj.setMessage(AesEncDecComplex.bytesToHex(encBuffer));
			obj.setChathubNo(targetChathubNo); // 대화방 번호
			SendChatResponse responseData = AtalkPacketUtil.requestAtalkMessage(
					obj, SendChatResponse.class, reqUrl);
			/////////////////////////////////////////////////////////////////////////
			respChatObj = responseData.getChatData();
			targetChathubNo = responseData.getChatData().getChathubNo();
			
			try {
				if (respChatObj.getChatType().equals(EnumChatType.MESSAGE_GENERAL_TYPE.getValue())
					|| (respChatObj.getChatType().equals(EnumChatType.MESSAGE_EXT_GENERAL_TYPE.getValue()))) {
					logger.info("### message(enc) : {}", respChatObj.getChatMessage());
					respChatObj.setChatMessage(
							new String(
									AesEncDecComplex.decryptAesWithIv(
									AesEncDecComplex.hexToBytes(respChatObj.getChatMessage())
									, plainChathubKey)));
					logger.info("### message(dec) : {}", respChatObj.getChatMessage());
				}
			} catch (Exception e) {
				logger.info("@@@@ : {}", e);
			}
			logger.info("#### CHATHUB NO : {}", targetChathubNo);
		}
		logger.info("#### 3. END - GET CHAT HUB INFO");
		
		logger.info("#### 4. START - SEND CHAT, chathub no : {}", targetChathubNo);
		{
			String reqUrl =	AtalkMainPacketKeyTest.REQ_HOST_VAL + "/atalk/api/v1/chat/send";
			SendChatRequest obj = new SendChatRequest();
			
			// 1. 대화방의 ENC 대화방키 를 내 개인키로 복호화
			plainChathubKey = AtalkComplex.instance().decryptChathubKey(
					targetChathubInfo.getEncChathubKey());
			logger.info("### plainChathubKey : {}", plainChathubKey);
			
			// 2. 대화내용을 대화방 암호화키로 암호화.			
			byte [] encBuffer = AesEncDecComplex.encryptAesWithRandomIv(
					chatMessage.getBytes()
					, plainChathubKey);

			if (chatMessage.length() > AtalkComplex.instance().getExtChatBaseSize()) {
				String shortMessage = chatMessage.substring(0, AtalkComplex.instance().getExtChatBaseSize()
					);
				byte [] encShortMsgBuffer = AesEncDecComplex.encryptAesWithRandomIv(
						shortMessage.getBytes()
						, plainChathubKey);
				obj.setShortMessage(AesEncDecComplex.bytesToHex(encShortMsgBuffer));
			}

			// 3. 대화방에서 보여질 짧은 대화내용을 암호화키로 암호화.
			obj.setMessage(AesEncDecComplex.bytesToHex(encBuffer));
			obj.setChathubNo(targetChathubNo); // 대화방 번호
			SendChatResponse responseData = AtalkPacketUtil.requestAtalkMessage(
					obj, SendChatResponse.class, reqUrl);

			targetChathubNo = responseData.getChatData().getChathubNo();
			targetChatNo = responseData.getChatData().getChatNo();
			// chatHubNo = sendChat(obj);
			logger.info("#### CHATHUB NO : {}, CHAT_NO : {}", targetChathubNo, targetChatNo);
		}
		logger.info("#### 4. END - SEND CHAT");
		logger.info("#### 5. START - DELETE A CHAT, CHATHUB NO : {}, CHAT_NO : {}"
				, targetChathubNo, targetChatNo);
		Long lastBaseChatNo = 0L;
		{
			String reqUrl =	AtalkMainPacketKeyTest.REQ_HOST_VAL + "/atalk/api/v1/chat/delete";
			
			List<Long> chatNoList = new ArrayList<Long>();
			chatNoList.add(targetChatNo);
			
			DeleteChatRequest obj = new DeleteChatRequest();
			obj.setChathubNo(targetChathubNo);
			obj.setChtaNoList(chatNoList);
			
//			lastBaseChatNo = chatList(obj);
			DeleteChatResponse responseData = AtalkPacketUtil.requestAtalkMessage(
					obj, DeleteChatResponse.class, reqUrl);
			logger.info("#### DELETE RESULT : {}", responseData.getResult());
		}
		logger.info("#### 5. END - DELETE A CHAT, CHATHUB NO : {}, CHAT_NO : {}"
				, targetChathubNo, targetChatNo);
		logger.info("#### 6. START - CHAT LIST : 1st page by count 10");
		{
			String reqUrl =	AtalkMainPacketKeyTest.REQ_HOST_VAL + "/atalk/api/v1/chat/chatList";
			ChatInfoRequest obj = new ChatInfoRequest();
			obj.setChathubNo(targetChathubNo);
			obj.setChatInqCount(10);		// 10 개씩
			obj.setLastChatNo(lastBaseChatNo); // 가장 최근 데이타부터 조회시 0L
//			lastBaseChatNo = chatList(obj);
			ChatInfoResponse responseData = AtalkPacketUtil.requestAtalkMessage(
					obj, ChatInfoResponse.class, reqUrl);
			lastBaseChatNo = responseData.getLastChatNo();
			logger.info("#### lastBaseChatNo NO : {}", lastBaseChatNo);
		}
		logger.info("#### 6. END - CHAT LIST : 1st page by count 10");
	}
	
	static String chatMessage = "최근 인터넷의 빠른 성장과 전자출판으로 인해 정보에 접근하는 방법";
}


