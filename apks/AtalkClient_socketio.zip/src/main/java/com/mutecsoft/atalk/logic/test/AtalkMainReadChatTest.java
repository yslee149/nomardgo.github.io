package com.mutecsoft.atalk.logic.test;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mutecsoft.atalk.logic.model.chat.Chat;
import com.mutecsoft.atalk.logic.model.chat.ReadChatRequest;
import com.mutecsoft.atalk.logic.model.chat.ReadChatResponse;
import com.mutecsoft.atalk.logic.model.chathub.ChatHubListInfo;
import com.mutecsoft.atalk.logic.model.chathub.ListChathubResponse;
import com.mutecsoft.atalk.logic.util.AtalkPacketUtil;

public class AtalkMainReadChatTest {

	private static final Logger logger = LoggerFactory.getLogger(AtalkMainReadChatTest.class);

	public static void main(String [] args) throws Exception {

		final String userId = "user1003@aaa.com";
		final String passwordPlain = "111111";
		Chat respChatObj = null;
		
		// 로그인 후 대화방 목록 조회
		ListChathubResponse responseChatListData  = AtalkMainChathubListTest.getChatHubInfoList(
				userId, passwordPlain);
		
		List<ChatHubListInfo> chatHubList = responseChatListData.getChatHubListInfo();
		Long targetChathubNo = null;
		///////////////////////////////////////////////////////////
		ChatHubListInfo targetChathubInfo = null; // 파일대화 입력할 대화방 정보
		///////////////////////////////////////////////////////////
		for (ChatHubListInfo chathubObj : chatHubList) {
			
			if (chathubObj.getJoinYn().equals("Y")) {
				targetChathubNo = chathubObj.getChathubNo();
				targetChathubInfo = chathubObj;
				break;
			}
		}
		logger.info("#### 3. START - READ REQ, chathub no : {}", targetChathubNo);
		{
			String reqUrl =	AtalkMainPacketKeyTest.REQ_HOST_VAL + "/atalk/api/v1/chat/read";
			ReadChatRequest obj = new ReadChatRequest();
			obj.setChathubNo(targetChathubNo);

			/////////////////////////////////////////////////////////////////////////
			ReadChatResponse responseData = AtalkPacketUtil.requestAtalkMessage(
					obj, ReadChatResponse.class, reqUrl);
			logger.info("#### responseData : {}", responseData);
		}
		logger.info("#### 3. END -  READ REQ INFO");
	}
}


