package com.mutecsoft.atalk.logic.test;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mutecsoft.atalk.logic.AtalkComplex;
import com.mutecsoft.atalk.logic.model.AtalkDataModelAll;
import com.mutecsoft.atalk.logic.model.AtalkPacketBase;
import com.mutecsoft.atalk.logic.model.DummyRequest;
import com.mutecsoft.atalk.logic.model.pi.PiAgreementResponse;
import com.mutecsoft.atalk.logic.model.signup.SignupRequest;
import com.mutecsoft.atalk.logic.model.signup.SignupResponse;
import com.mutecsoft.atalk.logic.model.user.DeleteUserRequest;
import com.mutecsoft.atalk.logic.model.user.DeleteUserResponse;
import com.mutecsoft.atalk.logic.util.AesEncDecComplex;
import com.mutecsoft.atalk.logic.util.AtalkPacketUtil;
import com.mutecsoft.atalk.logic.util.BufferComplex;

public class AtalkMainSignupTest {

	private static final Logger logger = LoggerFactory.getLogger(AtalkMainSignupTest.class);

	public static void main(String [] args) throws Exception {
		
		/*
		"signup_key"
		"006B6A78"
		"0CBBAB08"
		"0D84DBF8"
		"0E9A66C0"
		"119AC1EC"
		"11F99868"
		"1285D0F4"
		"135786C0"
		"16ECD47C"
		"17CD7C68"
		"1A40BB50"
		"1D521CEC"
		"21A2E838"
		"26270244"
		"2A550ADC"
		"2A8C5320"
		"2B1B3D88"
		"2DD7F3A0"
		"2EEC6054"
		"31848AA4"
		"31E6EBC8"
		"34764288"
		"35010B88"
		"37A6A7F8"
		"398B6008"
		"3A2B7300"
		"3A6B996C"
		"3BE66800"
		"3E0D5EC8"
		"3F563418"
		"45A97B51"
		"45FBAF9D"
		"47AEADD5"
		"48C5B261"
		"4BAED045"
		"4C4B077D"
		"4FDD2761"
		"50796E41"
		"5C631A15"
		"5C825AE5"
		"5F0C0335"
		"6088C561"
		"61B77B09"
		"64D20351"
		"6DF1CA55"
		"6E0EDAD9"
		"6FC921F1"
		"703ACC95"
		"7A185E01"
		"81FE51F6"
		"8706538A"
		"88C6023E"
		"8BA9A67A"
		"8D72382A"
		"8E82B226"
		"904D01E6"
		"91BCA6D6"
		"9562E25A"
		"982B145A"
		"9A639F0A"
		"9A884E1E"
		"9E81C31E"
		"A2D3BEF6"
		"A3929C62"
		"A4750642"
		"A65D8AE2"
		"A7A18C6E"
		"A7FE82EA"
		"A81B3A22"
		"A9E2B1A2"
		"ADC26A72"
		"AF22A362"
		"B0C3C876"
		"B21A2636"
		"B52D7186"
		"B52D8BD2"
		"B5C08F6E"
		"B6852D32"
		"B6E3071E"
		"B8FB285E"
		"BDCEB136"
		"C1B42B97"
		"C80D792F"
		"CA195413"
		"D122801F"
		"D17F076B"
		"D57493EB"
		"D6832E0B"
		"E1A72CEF"
		"E49F8013"
		"E4CDFC3B"
		"E59274AF"
		"ED539F2B"
		"EDFCC04B"
		"EF56365F"
		"EFCDBB77"
		"F6E087BB"
		"F7AFD30F"
		"FD2A6047"
		"FDB2CE6B"
		*/

		
		logger.info("#### 1. START - DETERMINE PACKET KEY");
		AtalkMainPacketKeyTest packetKeyTestObj = new AtalkMainPacketKeyTest();
		packetKeyTestObj.determinePacketKey();
		logger.info("#### 1. END - DETERMINE PACKET KEY");
		
		PiAgreementResponse piIfnoResp = getPersonalInfoAgreement();
		
		signup_without_profiles(piIfnoResp.getPiVersion());
		
		signup_with_profiles(piIfnoResp.getPiVersion());
	}

	static void signup_with_profiles(Long piNo) throws Exception {
		logger.info("#### 4. START - SIGNUP WITH SIGNUPTOKEN and PROFILE FILES(FOREGROUND)");
		{
			String signUptoken = "";
			String userId = "user1002@aaa.com";
			String password = "111111";
			
			String userName = "user1002_name";
			String gender="M"; // M : male, F : female
			
			String birthDate = "2000-01-01";
			
			String phoneNumber = "01900001112";
			String statusMessage = "가입메시지";
			
			String lang = "ko"; // jp : japanese, cn : chinese, en : english, ko : korean
			
			String multipartFileName = "profileFiles";
		
			File profileFgFile = new File("D:\\AtalkClient\\profile_image\\profile_fg.jpg");
			File profileBgFile = null; // new File("D:\\AtalkClient\\profile_image\\profile_bg.jpg");
			
			SignupRequest signupReq = new SignupRequest();
			signupReq.setSignupToken(signUptoken);
			signupReq.setUserId(userId);
			signupReq.setPassword(password);
			
			signupReq.setUserName(userName);
			signupReq.setGender(gender);
			
			signupReq.setPiAgreeVersion(piNo);
			signupReq.setBirthDate(birthDate);
			
			signupReq.setPhoneNumber(phoneNumber);
			signupReq.setStatusMessage(statusMessage);
			signupReq.setLang(lang);
			
			SignupResponse resp = doSignup(signupReq
					, multipartFileName
					, profileFgFile
					, profileBgFile);
			
			// 시험용으로 사용자 삭제함. 반복 테스트 해야하기에
			DeleteUserRequest delUserReq = new DeleteUserRequest();
			delUserReq.setSignUptoken(signUptoken);
			delUserReq.setUserNo(resp.getUserNo());
			
			deleteUser(delUserReq);
			// delete user 사용자 삭제, 테스트용임.
			
			// System.exit(1);
		}
		logger.info("#### 4. END - SIGNUP");
		logger.info("#### 5. START - SIGNUP WITH SIGNUPTOKEN and PROFILE FILES(FOREGROUND, BACKGROUND)");
		{
			String signUptoken = "";
			String userId = "user1005@aaa.com";
			String password = "111111";
			
			String userName = "user1003_name";
			String gender="M"; // M : male, F : female
			
			String birthDate = "2000-01-01";
			
			String phoneNumber = "01900001112";
			String statusMessage = "가입메시지";
			
			String lang = "ko"; // jp : japanese, cn : chinese, en : english, ko : korean
			
			String multipartFileName = "profileFiles";
		
			File profileFgFile = new File("D:\\AtalkClient\\profile_image\\profile_fg.jpg");
			File profileBgFile = new File("D:\\AtalkClient\\profile_image\\profile_bg.jpg");
			
			
			SignupRequest signupReq = new SignupRequest();
			signupReq.setSignupToken(signUptoken);
			signupReq.setUserId(userId);
			signupReq.setPassword(password);
			
			signupReq.setUserName(userName);
			signupReq.setGender(gender);
			
			signupReq.setPiAgreeVersion(piNo);
			signupReq.setBirthDate(birthDate);
			
			signupReq.setPhoneNumber(phoneNumber);
			signupReq.setStatusMessage(statusMessage);
			signupReq.setLang(lang);
			
			SignupResponse resp = doSignup(signupReq
					, multipartFileName
					, profileFgFile
					, profileBgFile);
			
			// 시험용으로 사용자 삭제함. 반복 테스트 해야하기에
			DeleteUserRequest delUserReq = new DeleteUserRequest();
			delUserReq.setSignUptoken(signUptoken);
			delUserReq.setUserNo(resp.getUserNo());
			
			 deleteUser(delUserReq);
			// delete user 사용자 삭제, 테스트용임.
			
			// System.exit(1);
		}
		logger.info("#### 5. END - SIGNUP");
	}
	static void signup_without_profiles(Long piNo) throws Exception {
		logger.info("#### 2. START - SIGNUP WITH SIGNUPTOKEN");
		{
			String signUptoken = "FD2A6047";
			String userId = "user1003@aaa.com";
			String password = "111111";
			
			String userName = "user1000_name";
			String gender="M"; // M : male, F : female
			
			String birthDate = "2000-01-01";
			
			String phoneNumber = "01900001111";
			String statusMessage = "가입메시지";
			
			String lang = "ko"; // jp : japanese, cn : chinese, en : english, ko : korean
			
			SignupRequest signupReq = new SignupRequest();
			signupReq.setSignupToken(signUptoken);
			signupReq.setUserId(userId);
			signupReq.setPassword(password);
			
			signupReq.setUserName(userName);
			signupReq.setGender(gender);
			
			signupReq.setPiAgreeVersion(piNo);
			signupReq.setBirthDate(birthDate);
			
			signupReq.setPhoneNumber(phoneNumber);
			signupReq.setStatusMessage(statusMessage);
			signupReq.setLang(lang);
			
			SignupResponse resp = doSignup(signupReq, null, null, null);
			
			// 시험용으로 사용자 삭제함. 반복 테스트 해야하기에
			DeleteUserRequest delUserReq = new DeleteUserRequest();
			delUserReq.setSignUptoken(signUptoken);
			delUserReq.setUserNo(resp.getUserNo());
			
			// deleteUser(delUserReq);
			// delete user 사용자 삭제, 테스트용임.
			
			System.exit(1);
			
		}
		logger.info("#### 2. END - SIGNUP");
		logger.info("#### 3. START - SIGNUP WITHOUT SIGNUPTOKEN");
		{
			String signUptoken = "";
			String userId = "user1001@aaa.com";
			String password = "111111";
			
			String userName = "user1001_name";
			String gender="M"; // M : male, F : female
			
			String birthDate = "2000-01-01";
			
			String phoneNumber = "01900001112";
			String statusMessage = "가입메시지";
			
			String lang = "ko"; // jp : japanese, cn : chinese, en : english, ko : korean
			
			SignupRequest signupReq = new SignupRequest();
			signupReq.setSignupToken(signUptoken);
			signupReq.setUserId(userId);
			signupReq.setPassword(password);
			
			signupReq.setUserName(userName);
			signupReq.setGender(gender);
			
			signupReq.setPiAgreeVersion(piNo);
			signupReq.setBirthDate(birthDate);
			
			signupReq.setPhoneNumber(phoneNumber);
			signupReq.setStatusMessage(statusMessage);
			signupReq.setLang(lang);
			
			SignupResponse resp = doSignup(signupReq, null, null, null);
			
			// 시험용으로 사용자 삭제함. 반복 테스트 해야하기에
			DeleteUserRequest delUserReq = new DeleteUserRequest();
			delUserReq.setSignUptoken(signUptoken);
			delUserReq.setUserNo(resp.getUserNo());
			
			deleteUser(delUserReq);
			// delete user 사용자 삭제, 테스트용임.
			
			// System.exit(1);
		}
		logger.info("#### 3. END - SIGNUP");
	}

	/**
	 * 
	 * 
	 * @param signupReq
	 * @param multipartFileName
	 * @param profileFgFile
	 * @param profileBgFile
	 * @throws Exception
	 */
	static SignupResponse doSignup(SignupRequest signupReq
			, String multipartFileName
			, File profileFgFile
			, File profileBgFile) throws Exception {
		SignupResponse responseData = null;
		String signupUrl = AtalkMainPacketKeyTest.REQ_HOST_VAL + "/atalk/api/v1/user/signup";
		{
			
			AtalkDataModelAll secureModel = new AtalkDataModelAll();
			secureModel.setSecureModel(
					AtalkComplex.instance().toEncPacket(signupReq));
			logger.info("############# 1. client -> server : signup value");
			
			// String json = AtalkComplex.toPacketData(secureModel);
			// logger.info("## METADATA : {}", json);
			
			///////// profile image 처리
			// 패킷키
			String packetKey = AtalkComplex.instance().getPACKET_KEY();
			
			List<String> fileNameList = new ArrayList<String>();
			List<byte []> profileEncBufferList = new ArrayList<byte []>();
			
			/////////////////////////////////////////////////////////////////////////
			if (profileFgFile != null && multipartFileName != null && !multipartFileName.isBlank()) {
				// foreground 프로필 이미지 버퍼 및 파일명 처리
				Object [] retFileObjArr = BufferComplex.getFileDataAndFileName(profileFgFile.getPath());
				byte [] plainBuffer = (byte [])retFileObjArr[0];
				String fileName =(String)retFileObjArr[1];

				fileNameList.add(fileName);
				byte [] encBuffer = AesEncDecComplex.encryptAesWithRandomIv(
						plainBuffer
						, packetKey);
//				encBuffer =  BufferComplex.appendBytesMore(
//						encBuffer
//						, BufferComplex.hexToBytes(AtalkComplex.instance().getPacketSeedValue())
//						, BufferComplex.hexToBytes(RandomHexString.genSecureRandomHex(16)));
				profileEncBufferList.add(encBuffer);
				
				if (profileBgFile != null) {
					retFileObjArr = BufferComplex.getFileDataAndFileName(profileBgFile.getPath());
					plainBuffer = (byte [])retFileObjArr[0];
					fileName =(String)retFileObjArr[1];
					fileNameList.add(fileName);
					encBuffer = AesEncDecComplex.encryptAesWithRandomIv(
							plainBuffer
							, packetKey);
//					encBuffer =  BufferComplex.appendBytesMore(
//							encBuffer
//							, BufferComplex.hexToBytes(AtalkComplex.instance().getPacketSeedValue())
//							, BufferComplex.hexToBytes(RandomHexString.genSecureRandomHex(16)));
					profileEncBufferList.add(encBuffer);
				}
				// foreground 프로필 이미지 버퍼 및 파일명 처리
			}
			/////////////////////////////////////////////////////////////////////////
			responseData = AtalkPacketUtil.requestAtalkFileListMessageWithoutAuth(
					secureModel.getSecureModel()
					, SignupResponse.class
					, signupUrl
					, multipartFileName
					, profileEncBufferList
					, fileNameList
					);
			if (responseData != null) {
				logger.info("### RESP DATA : {}",
						AtalkPacketBase.printAllFields(responseData));
				logger.info("#### RESP JSON : {}", responseData.toJson());
			}
		}
		return responseData;
	}
	

	/**
	 * 
	 * @param delUserReq
	 * @throws Exception
	 */
	static void deleteUser(DeleteUserRequest delUserReq) throws Exception {
		String reqUrl = AtalkMainPacketKeyTest.REQ_HOST_VAL + "/atalk/api/v1/user/deleteUserTest";
		{
			AtalkDataModelAll secureModel = new AtalkDataModelAll();
			secureModel.setSecureModel(
					AtalkComplex.instance().toEncPacket(delUserReq));
			logger.info("############# 1. client -> server : signup value");
			/////////////////////////////////////////////////////////////////////////
			final DeleteUserResponse responseData = AtalkPacketUtil.requestAtalkMessageNoAuth(
					delUserReq, DeleteUserResponse.class, reqUrl);
			if (responseData != null) {
				logger.info("### RESP DATA : {}",
						AtalkPacketBase.printAllFields(responseData));
				logger.info("#### RESP JSON : {}", responseData.toJson());
			}
		}
		logger.info("#### 2. END - DELETE USER");
	}


	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	static PiAgreementResponse getPersonalInfoAgreement() throws Exception {
		PiAgreementResponse responseData = null;
		String piAgreementContentUrl = AtalkMainPacketKeyTest.REQ_HOST_VAL + "/atalk/api/v1/pi/getLatest";
		{
			logger.info("############# 1. client -> server : get personal info usage agreement content");
			/////////////////////////////////////////////////////////////////////////
			
			responseData = AtalkPacketUtil.requestAtalkMessageNoAuth(
					new DummyRequest()
					, PiAgreementResponse.class
					, piAgreementContentUrl
					);
			if (responseData != null) {
				logger.info("### RESP DATA : {}",
						AtalkPacketBase.printAllFields(responseData));
				logger.info("#### RESP JSON : {}", responseData.toJson());
			}
		}
		return responseData;
	}
}
