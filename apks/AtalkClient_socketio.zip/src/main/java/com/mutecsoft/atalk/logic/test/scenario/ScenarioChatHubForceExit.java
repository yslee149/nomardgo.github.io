package com.mutecsoft.atalk.logic.test.scenario;

import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.mutecsoft.atalk.logic.AtalkComplex;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * 대화방 강퇴
 * 
 * 
 */
public class ScenarioChatHubForceExit {

	private static final Logger logger = LoggerFactory.getLogger(ScenarioChatHubForceExit.class);

	static String [][] userInfoList = {
			{"testuser_0", "111112222200000", "01800000000"}
			, {"testuser_1", "111112222200001", "01800000001"}
			, {"testuser_2", "111112222200002", "01800000002"}
			, {"testuser_3", "111112222200003", "01800000003"}
	};
	static ObjectMapper mapper = new ObjectMapper();
	public static void main(String [] args) throws Exception {
		{
			String aa = "{ \"aa\" : 111, \"bbb\" : \"44444\" }";
			// Parse JSON and pretty-print
	        
	        Object jsonObject = mapper.readValue(aa, Object.class); // Convert to generic object
	        ObjectWriter writer =  mapper.writerWithDefaultPrettyPrinter();
	        String prettyJson = writer.writeValueAsString(jsonObject);

	        System.out.println(prettyJson);

	        // System.exit(-1);
		}
		// 로그인
		AtalkMainLoginTest.carryonWithArg("testuser_0@abc.com", "01800000000");

		{
			// String bearerToken = AtalkComplex.instance().getAccessToken();
			String encJwtHexToken = AtalkComplex.instance().generateEncAccessToken();
			System.out.println("Bearer " + encJwtHexToken);
			
			String url1 = AtalkComplex.REQ_HOST_VAL + AtalkComplex.CNTXT_NAME +"/api/plain/v1/chatHub/forceExit/20/11,13";
			OkHttpClient client = new OkHttpClient().newBuilder()
					.connectTimeout(40, TimeUnit.SECONDS)  // Connection timeout
		            .readTimeout(40, TimeUnit.SECONDS)     // Read timeout
		            .writeTimeout(40, TimeUnit.SECONDS)    // Write timeout
		            .build();
			// MediaType jsonMediaType = MediaType.get("application/json; charset=utf-8");
			
			RequestBody emptyBody = RequestBody.create(new byte[0]);
			Request request = new Request.Builder()
					.url(url1)
					.addHeader("Authorization", "Bearer " + encJwtHexToken) // Add JWT token here
					.post(emptyBody)
					.build();
			try (Response response = client.newCall(request).execute()) {
				if (response.isSuccessful()) {
					String responseJson = response.body().string();
					logger.info("Response: http code : {}, value : {}", 
							response.code()
							, responseJson);
					//////////////////////
					
					ObjectMapper mapper = new ObjectMapper();
			        Object jsonObject = mapper.readValue(responseJson, Object.class); // Convert to generic object
			        ObjectWriter writer =  mapper.writerWithDefaultPrettyPrinter();
			        String prettyJson = writer.writeValueAsString(jsonObject);

			        ///////////////////////////////
			        
			        System.out.println(prettyJson);
				} else {
					logger.error("Error: " + response.code());
					logger.error("@@@@@@@@@ ERR CASE 1");
				}
			} catch (Exception e) {
				logger.error("@@@@@@@@@ ERR CASE 2 : {}", e);
			}
		}
//		{
//			// String bearerToken = AtalkComplex.instance().getAccessToken();
//			String encJwtHexToken = AtalkComplex.instance().generateEncAccessToken();
//			System.out.println("Bearer " + encJwtHexToken);
//			
//			String url1 = AtalkComplex.REQ_HOST_VAL + AtalkComplex.CNTXT_NAME +"/api/v1/chatHub/openChathub/1";
//			OkHttpClient client = new OkHttpClient().newBuilder()
//					.connectTimeout(40, TimeUnit.SECONDS)  // Connection timeout
//		            .readTimeout(40, TimeUnit.SECONDS)     // Read timeout
//		            .writeTimeout(40, TimeUnit.SECONDS)    // Write timeout
//		            .build();
//			// MediaType jsonMediaType = MediaType.get("application/json; charset=utf-8");
//			
//			RequestBody emptyBody = RequestBody.create(new byte[0]);
//			Request request = new Request.Builder()
//					.url(url1)
//					.addHeader("Authorization", "Bearer " + encJwtHexToken) // Add JWT token here
//					.post(emptyBody)
//					.build();
//			try (Response response = client.newCall(request).execute()) {
//				if (response.isSuccessful()) {
//					String responseJson = response.body().string();
//					logger.info("Response: http code : {}, value : {}", 
//							response.code()
//							, responseJson);
//					
//					///////////////////////////////
//					SecureDataModel respObj = SecureDataModel.fromBuffer(responseJson);
//					String responseData = SecureDataModel.fromEncHexBuffer(respObj.getData()
//							, AtalkComplex.instance().getPACKET_KEY());
//					//////////////////////
//					
//					ObjectMapper mapper = new ObjectMapper();
//			        Object jsonObject = mapper.readValue(responseData, Object.class); // Convert to generic object
//			        ObjectWriter writer =  mapper.writerWithDefaultPrettyPrinter();
//			        String prettyJson = writer.writeValueAsString(jsonObject);
//
//			        ///////////////////////////////
//			        
//			        System.out.println(prettyJson);
//				} else {
//					logger.error("Error: " + response.code());
//					logger.error("@@@@@@@@@ ERR CASE 1");
//				}
//			} catch (Exception e) {
//				logger.error("@@@@@@@@@ ERR CASE 2 : {}", e);
//			}
//		}
	}
}
