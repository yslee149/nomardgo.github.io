package com.mutecsoft.atalk.logic.test.scenario;


import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mutecsoft.atalk.logic.AtalkComplex;
import com.mutecsoft.atalk.logic.model.amigo.AddAmigoResponse;
import com.mutecsoft.atalk.logic.model.amigo.AmigoListResponse;
import com.mutecsoft.atalk.logic.model.amigoset.AddAmigoSetRequest;
import com.mutecsoft.atalk.logic.model.amigoset.AddAmigoSetResponse;
import com.mutecsoft.atalk.logic.model.amigoset.AmigoSetListResponse;
import com.mutecsoft.atalk.logic.model.chat.ChatInfoResponse;
import com.mutecsoft.atalk.logic.model.chat.SendChatResponse;
import com.mutecsoft.atalk.logic.model.chathub.ChatHubInfo;
import com.mutecsoft.atalk.logic.model.chathub.ListChathubResponse;
import com.mutecsoft.atalk.logic.model.chathub.OpenChathubResponse;
import com.mutecsoft.atalk.logic.model.user.SearchUserResponse;

public class InsecureAtalkMainScenario4 {

	private static final Logger logger = LoggerFactory.getLogger(InsecureAtalkMainScenario4.class);

	public static void main(String [] args) throws Exception {
		
		// 로그인 user3@abc.com
		AtalkMainLoginTest.carryon();

		logger.info("#### START - ADD AMIGO SET");
		
		AddAmigoSetRequest reqObj = new AddAmigoSetRequest();
		reqObj.setAmigoSetName("친구그룹1");
		reqObj.setDisplayYn("N");		// display 여부
		
		logger.info("############################ 1");
		// 그룹정보 추가
		AddAmigoSetResponse amigoSetInfo = AtalkComplex.instance().addAmigoSet(reqObj);
		
		logger.info("############################ 2");
		// 사용자 검색
		SearchUserResponse userInfo = AtalkComplex.instance().searchUser("user4");
		
		logger.info("############################ 3");
		// 친구 추가
		List<Long> userNoListToAdd = new ArrayList<Long>();
		userNoListToAdd.add(userInfo.getUserList().get(0).getUserNo());
		
		AddAmigoResponse addAmigoResp = AtalkComplex.instance().addAmigo( userNoListToAdd);
		

		logger.info("############################ 4");
		
		// 친구 목록 조회
		AmigoListResponse response = AtalkComplex.instance().getAmigoList();
		
		logger.info("############################ 5");
		
		// 대화방 초대
		userNoListToAdd.add(userInfo.getUserList().get(0).getUserNo());
		OpenChathubResponse resultObj = AtalkComplex.instance().openChathub(userNoListToAdd);
		
		logger.info("############################ 6 : ROOM INFO");
		
		// 대화방 정보
		ChatHubInfo chathubInfo = resultObj.getChatHubInfo();
		
		logger.info("############################ 7");
		
		// 대화 목록 조회
		ChatInfoResponse chatInfoObj = AtalkComplex.instance().chatListPlain(
				chathubInfo.getChathubNo()
				, 0L  // 최근 대화부터 조회시 0, 이후에 이전 페이징요청시 결과 데이타의 ChatInfoResponse.lastChatNo 으로 채워야 함.
				, 10
				);
		logger.info("############################ 8");
		// 대화방 대화 전송
		SendChatResponse chatResponse = AtalkComplex.instance().sendChatPlain("chat message1", chathubInfo);
		
		logger.info("############################ 9");
		// 대화방 목록 정보 조회
		String lastUpdateDt = "2000-01-01 12:00:00";
		ListChathubResponse chatHubList = AtalkComplex.instance().chatHubListPlain(lastUpdateDt);
		
		logger.info("############################ 10");
		// 두번째 대화방 목록 정보 조회
		// 두번째 조회시에는 목록 안줌. 증분이 변화가 없기 때문.  <- chatHubList.getLastUpdateDt() 이후
		chatHubList = AtalkComplex.instance().chatHubListPlain(chatHubList.getLastUpdateDt());
		
		logger.info("############################ 11");
		
	}
}
