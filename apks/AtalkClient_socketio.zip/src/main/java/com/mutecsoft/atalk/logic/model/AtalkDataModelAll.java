package com.mutecsoft.atalk.logic.model;

import java.io.Serializable;

/**
 * @PackageName com.mutecsoft.atalk.logic.model
 * @fileName	AtalkDataModelAll.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description :
 * <pre>
 * 
 * </pre>
 */
public class AtalkDataModelAll implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8794053335049561276L;
	private SecureDataModel secureModel;
	private AtalkPacketBase atalkPacketBase;
	private int httpStatusCode;

	public void setAtalkPacketBase(AtalkPacketBase atalkPacketBase, String packetKey) throws Exception {
		this.atalkPacketBase = atalkPacketBase;
		setSecureModel(this.atalkPacketBase.toFinalModel());
	}

	public SecureDataModel getSecureModel() {
		return secureModel;
	}

	public void setSecureModel(SecureDataModel secureModel) {
		this.secureModel = secureModel;
	}

	public AtalkPacketBase getAtalkPacketBase() {
		return atalkPacketBase;
	}

	public void setAtalkPacketBase(AtalkPacketBase atalkPacketBase) {
		this.atalkPacketBase = atalkPacketBase;
	}

	public int getHttpStatusCode() {
		return httpStatusCode;
	}

	public void setHttpStatusCode(int httpStatusCode) {
		this.httpStatusCode = httpStatusCode;
	}
}
