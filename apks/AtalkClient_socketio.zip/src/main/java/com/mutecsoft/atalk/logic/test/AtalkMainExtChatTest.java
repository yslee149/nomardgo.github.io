package com.mutecsoft.atalk.logic.test;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mutecsoft.atalk.logic.AtalkComplex;
import com.mutecsoft.atalk.logic.contant.EnumChatType;
import com.mutecsoft.atalk.logic.model.chat.Chat;
import com.mutecsoft.atalk.logic.model.chat.ChatExt;
import com.mutecsoft.atalk.logic.model.chat.ExtChatRequest;
import com.mutecsoft.atalk.logic.model.chat.SendChatRequest;
import com.mutecsoft.atalk.logic.model.chat.SendChatResponse;
import com.mutecsoft.atalk.logic.model.chat.ExtChatResponse;
import com.mutecsoft.atalk.logic.model.chathub.ChatHubListInfo;
import com.mutecsoft.atalk.logic.model.chathub.ListChathubResponse;
import com.mutecsoft.atalk.logic.util.AesEncDecComplex;
import com.mutecsoft.atalk.logic.util.AtalkPacketUtil;

/**
 * 대용량 확장 대화 처리
 * 
 * 
 */
public class AtalkMainExtChatTest {

	private static final Logger logger = LoggerFactory.getLogger(AtalkMainExtChatTest.class);

	public static void main(String [] args) throws Exception {

		final String userId = "user1003@aaa.com";
		final String passwordPlain = "111111";
		
		Chat respChatObj = null;
		String extChatUrl = "";

		// 로그인 후 대화방 목록 조회
		ListChathubResponse responseChatListData  = AtalkMainChathubListTest.getChatHubInfoList(
				userId, passwordPlain);
		
		List<ChatHubListInfo> chatHubList = responseChatListData.getChatHubListInfo();
		Long targetChathubNo = null;
		///////////////////////////////////////////////////////////
		ChatHubListInfo targetChathubInfo = null; // 파일대화 입력할 대화방 정보
		///////////////////////////////////////////////////////////
		for (ChatHubListInfo chathubObj : chatHubList) {
			
			if (chathubObj.getJoinYn().equals("Y")) {
				targetChathubNo = chathubObj.getChathubNo();
				targetChathubInfo = chathubObj;
				break;
			}
		}
		// 확장 대화 입력
		Long myUserNo = AtalkComplex.instance().getUserInfo().getUserNo();
		
		logger.info("############### START - SEND EXTENDED CHAT, chathub no : {}, my user no : {}", 
				targetChathubNo, myUserNo);
		{
			String reqUrl =	AtalkMainPacketKeyTest.REQ_HOST_VAL + "/atalk/api/v1/chat/send";
			SendChatRequest obj = new SendChatRequest();

			// 1. 대화방의 ENC 대화방키 를 내 개인키로 복호화
			String plainKeyValue = AtalkComplex.instance().decryptChathubKey(
					targetChathubInfo.getEncChathubKey());
			logger.info("### plainChathubKey : {}", plainKeyValue);
			
			// 2. 대화내용을 대화방 암호화키로 암호화.			
			byte [] encBuffer = AesEncDecComplex.encryptAesWithRandomIv(
					chatMessage.getBytes()
					, plainKeyValue);
			
			// 대용량 대화 체크
			if (chatMessage.length() > AtalkComplex.instance().getExtChatBaseSize()) {
				String shortMessage = chatMessage.substring(0, AtalkComplex.instance().getExtChatBaseSize()
					);
				byte [] encShortMsgBuffer = AesEncDecComplex.encryptAesWithRandomIv(
						shortMessage.getBytes()
						, plainKeyValue);
				obj.setShortMessage(AesEncDecComplex.bytesToHex(encShortMsgBuffer));
			}

			// 3. 대화방에서 보여질 짧은 대화내용을 암호화키로 암호화.
			obj.setMessage(AesEncDecComplex.bytesToHex(encBuffer));
			obj.setChathubNo(targetChathubNo); // 대화방 번호
			SendChatResponse responseData = AtalkPacketUtil.requestAtalkMessage(
					obj, SendChatResponse.class, reqUrl);
			/////////////////////////////////////////////////////////////////////////
			respChatObj = responseData.getChatData();
			targetChathubNo = responseData.getChatData().getChathubNo();
			
			try {
				extChatUrl = responseData.getChatData().getChatExtUrl();
				if (respChatObj.getChatType().equals(EnumChatType.MESSAGE_GENERAL_TYPE.getValue())
					|| (respChatObj.getChatType().equals(EnumChatType.MESSAGE_EXT_GENERAL_TYPE.getValue()))) {
					logger.info("### message(enc) : {}", respChatObj.getChatMessage());
					respChatObj.setChatMessage(
							new String(
									AesEncDecComplex.decryptAesWithIv(
									AesEncDecComplex.hexToBytes(respChatObj.getChatMessage())
									, plainKeyValue)));
					logger.info("### message(dec) : {}", respChatObj.getChatMessage());
					logger.info("### EXT CHAT URL : {}", extChatUrl);
				}
			} catch (Exception e) {
				logger.info("@@@@ : {}", e);
			}
			logger.info("#### CHATHUB NO : {}", targetChathubNo);
		}
		logger.info("############### END - SEND EXTENDED CHAT, chathub no : {}, my user no : {}",
					targetChathubNo, myUserNo);
		logger.info("############### START - GET THE EXTEND CHAT, chathub no : {}, chat no : {}", 
				targetChathubNo, respChatObj.getChatNo());
		{
			String reqUrl =	extChatUrl;
			logger.info("#### EXT CHAT url : {}", reqUrl);
			
			// ExtChatResponse responseData = AtalkPacketUtil.requestAtalkMessageByGetMethod(ExtChatResponse.class, reqUrl);
			ExtChatRequest obj = new ExtChatRequest();
			obj.setPacketSeedValue(AtalkComplex.instance().getPacketSeedValue());
			
			ExtChatResponse responseData = AtalkPacketUtil.requestAtalkMessage(
					obj, ExtChatResponse.class, reqUrl);
			
			ChatExt chatExtObj = responseData.getChatData();
			
			/////////////////////////////////////////////////////////////////////
			// 1. 대화방의 ENC 대화방키 를 내 개인키로 복호화
			String plainChathubKey = AtalkComplex.instance().decryptChathubKey(
					targetChathubInfo.getEncChathubKey());
			logger.info("### plainChathubKey : {}", plainChathubKey);
			try {
				logger.info("### message_ext(enc) : {}", chatExtObj.getChatContent());
				chatExtObj.setChatContent(
						new String(
								AesEncDecComplex.decryptAesWithIv(
								AesEncDecComplex.hexToBytes(chatExtObj.getChatContent())
								, plainChathubKey)));
				logger.info("### message_ext(dec) : {}", chatExtObj.getChatContent());
			} catch (Exception e) {
				logger.info("@@@@ : {}", e);
			}
		}
		logger.info("############### END - GET THE EXTEND CHAT, chathub no : {}, chat no : {}", 
				targetChathubNo, respChatObj.getChatNo());
	}
	
//	static String chatMessage = "최근 인터넷의 빠른 성장과 전자출판으로 인해 정보에 접근하는 방법";
	
	static String chatMessage = "최근 인터넷의 빠른 성장과 전자출판으로 인해 정보에 접근하는 방법이 상당히 변화하고 있다. 이와 함께,"
			+ "디지털 문서에서 적합한 정보를 결정하고 효율적으로 추출할 필요가 있을 것이다. 이 연구는 디지털 문서에서 여러 "
			+ "가지 정보를 추출하기 위해 템플릿 마이닝이 사용될 수 있음을 제시하고, 참조연결시스템과 관련된 연구를 고찰하였다. "
			+ "또한 실제적으로 논문 샘플을 분석한 결과를 이용하여 참조정보를 위한 템플릿을 구축하고, 이 템플릿을 이용하여 수작업으로"
			+ " 논문 샘플을 테스트한 결과, 템플릿 마이닝의 이용은 인용 데이터베이스를 자동으로 만들 수 있는 가능성을 보여주었다."
			+ ""
			+ "Recently, the way information is accessed has changed significantly because of "
			+ "the rapid growth of the Internet and a move toward electronic publishing. With "
			+ "that condition, there will be a need to efficiently determine and extract relevant "
			+ "information from digital documents. This study has proposed that template mining can "
			+ "be used for extracting different kinds of information from digital documents, and "
			+ "described research of reference linking system and then built template for citation information"
			+ " using analysis result of sample articles. Also, this study has shown the potential of "
			+ "template mining to automatically create citation databases."
			+ "최근 인터넷의 빠른 성장과 전자출판으로 인해 정보에 접근하는 방법이 상당히 변화하고 있다. 이와 함께,"
			+ "디지털 문서에서 적합한 정보를 결정하고 효율적으로 추출할 필요가 있을 것이다. 이 연구는 디지털 문서에서 여러 "
			+ "가지 정보를 추출하기 위해 템플릿 마이닝이 사용될 수 있음을 제시하고, 참조연결시스템과 관련된 연구를 고찰하였다. "
			+ "또한 실제적으로 논문 샘플을 분석한 결과를 이용하여 참조정보를 위한 템플릿을 구축하고, 이 템플릿을 이용하여 수작업으로"
			+ " 논문 샘플을 테스트한 결과, 템플릿 마이닝의 이용은 인용 데이터베이스를 자동으로 만들 수 있는 가능성을 보여주었다."
			+ ""
			+ "Recently, the way information is accessed has changed significantly because of "
			+ "the rapid growth of the Internet and a move toward electronic publishing. With "
			+ "that condition, there will be a need to efficiently determine and extract relevant "
			+ "information from digital documents. This study has proposed that template mining can "
			+ "be used for extracting different kinds of information from digital documents, and "
			+ "described research of reference linking system and then built template for citation information"
			+ " using analysis result of sample articles. Also, this study has shown the potential of "
			+ "template mining to automatically create citation databases.";
}

