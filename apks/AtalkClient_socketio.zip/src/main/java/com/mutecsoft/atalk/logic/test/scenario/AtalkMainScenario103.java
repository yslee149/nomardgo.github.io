package com.mutecsoft.atalk.logic.test.scenario;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mutecsoft.atalk.logic.AtalkComplex;
import com.mutecsoft.atalk.logic.model.chathub.OpenChathubResponse;
public class AtalkMainScenario103 {

	private static final Logger logger = LoggerFactory.getLogger(AtalkMainScenario103.class);

	static String [][] userInfoList = {
			{"testuser_0", "111112222200000", "01800000000"}
	};

	public static void main(String [] args) throws Exception {

		String userId = "voyzer@gmail.com";
		String password = "111111";
		String imei = "123455432122222";
		
		// 로그인
		AtalkMainLoginTest.login(userId, password, imei);
		
		OpenChathubResponse resultObj = null;

		// 대화방 생성
		List<Long> userNoListToAdd = Arrays.asList(4L, 5L, 6L);
		
		String chatTitle = "멀티방 대화방 제목111111";
		resultObj = AtalkComplex.instance().openChathubWithTitle(
				chatTitle, userNoListToAdd);
		
		System.exit(-1);
//		
//		ChatHubInfo chathubInfo = resultObj.getChatHubInfo();
//		
//		// 대화 목록 조회
//		ChatInfoResponse chatInfoObj = AtalkComplex.instance().chatList(
//				chathubInfo.getChathubNo()
//				, 0L  // 최근 대화부터 조회시 0, 이후에 이전 페이징요청시 결과 데이타의 ChatInfoResponse.lastChatNo 으로 채워야 함.
//				, 10
//				);
//
//		// 대화방 대화 전송
//		SendChatResponse chatResponse = AtalkComplex.instance().sendChat("chat message1", chathubInfo);
//		
//		// 대화방 목록 정보 조회
//		String lastUpdateDt = "2000-01-01 12:00:00";
//		ListChathubResponse chatHubList = AtalkComplex.instance().chatHubList(lastUpdateDt);
//		
//		//////////////////////////////////////////////////////////////////////////////////////////////
//		{
//			// 파일로 저장
//			chatHubList.toFile("D://ATALK//log2/chathubList");
//			
//			// 파일에서 읽기
////			PairChathubList<ListChathubResponse, Map<Long, ChatHubListInfo>> chathubListInfo = ListChathubResponse.fromFile("D://ATALK//log2/chathubList");
////		
////			ListChathubResponse listChatHubResp = chathubListInfo.key();
////			Map<Long, ChatHubListInfo> chatHubMap = chathubListInfo.value();
////			
//			Object [] chathubListInfo = ListChathubResponse.fromFile("D://ATALK//log2/chathubList");
//			
//			ListChathubResponse listChatHubResp = (ListChathubResponse) chathubListInfo[0];
//			Map<Long, ChatHubListInfo> chatHubMap = (Map<Long, ChatHubListInfo>) chathubListInfo[1];
//			
//			
//			String aa= listChatHubResp.toJson();
//			logger.info("#### info : {}", aa);
//		}
//		//////////////////////////////////////////////////////////////////////////////////////////////
//		
//		// 대화방 정보 조회
//		OpenChathubResponse chatHubInfo2 = AtalkComplex.instance().chatHubInfo(chatHubList.getChatHubListInfo().get(0).getChathubNo(), 10);
//		
//		
//		
//		// 두번째 대화방 목록 정보 조회
//		// 두번째 조회시에는 목록 안줌. 증분이 변화가 없기 때문.  <- chatHubList.getLastUpdateDt() 이후
//		chatHubList = AtalkComplex.instance().chatHubList(chatHubList.getLastUpdateDt());
//		
		
	}
}

