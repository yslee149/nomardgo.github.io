package com.mutecsoft.atalk.logic.util;

import java.security.SecureRandom;

/**
 * 
 * @author voyzer
 *
 */
public class RandomHexString {

    private static final String HEX_CHARS = "0123456789ABCDEF";

    public static String genSecureRandomHex(int length) {
        SecureRandom secureRandom = new SecureRandom();
        StringBuilder hexString = new StringBuilder(length);

        for (int i = 0; i < length; i++) {
            int randomIndex = secureRandom.nextInt(HEX_CHARS.length());
            hexString.append(HEX_CHARS.charAt(randomIndex));
        }
        return hexString.toString();
    }
    
    public static void main(String[] args) {
    	String val = RandomHexString.genSecureRandomHex(16);
    	System.out.println(val);
    	
    	byte [] b = BufferComplex.hexToBytes(val);
    	System.out.println(b.length);
    	System.out.println(BufferComplex.bytesToHex(b));
    }
}
