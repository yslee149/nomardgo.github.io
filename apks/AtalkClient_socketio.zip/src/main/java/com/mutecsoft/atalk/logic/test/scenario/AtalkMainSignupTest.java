package com.mutecsoft.atalk.logic.test.scenario;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mutecsoft.atalk.logic.AtalkComplex;
import com.mutecsoft.atalk.logic.model.pi.PiAgreementResponse;
import com.mutecsoft.atalk.logic.model.signup.SignupRequest;

public class AtalkMainSignupTest {

	private static final Logger logger = LoggerFactory.getLogger(AtalkMainSignupTest.class);
	
	public static void main(String [] args) throws Exception {
		
	}

	/**
	 * 회원가입
	 * 
	 * @throws Exception
	 */
	public static void carryonWitUser(String userEmail, String userName, String phoneNumber) throws Exception {
		String signUptoken = "";
		
		String password = "111111";
		
		String userId = userEmail;
		String gender="M"; // M : male, F : female
		
		String birthDate = "2000-01-01";
		String statusMessage = "가입메시지222";
		String lang = "jp"; // jp : japanese, cn : chinese, en : english, ko : korean
		
		logger.info("#### 1. START - DETERMINE PACKET KEY");
		AtalkComplex.instance().determinePacketKey();
		logger.info("#### 1. END - DETERMINE PACKET KEY");
		
		logger.info("#### 2. START - PRIVATE INFO");
		PiAgreementResponse piIfnoResp = AtalkComplex.instance().getPersonalInfoAgreement();
		logger.info("#### 2. END - PRIVATE INFO");
		
		logger.info("#### 3. START - SIGNUP");
		
		SignupRequest signupReq = new SignupRequest();
		signupReq.setSignupToken(signUptoken);
		signupReq.setUserId(userId);
		signupReq.setPassword(password);
		
		signupReq.setUserName(userName);
		signupReq.setGender(gender);
		
		signupReq.setPiAgreeVersion(1L);
		signupReq.setPfAgreeVersion(1L);
		signupReq.setSiAgreeVersion(1L);
		
		signupReq.setBirthDate(birthDate);
		
		signupReq.setPhoneNumber(phoneNumber);
		signupReq.setStatusMessage(statusMessage);
		signupReq.setLang(lang);
		
		AtalkComplex.instance().doSignup(signupReq
				, "profileFiles"
				, new File("D:\\AtalkClient\\profile_image\\profile_fg.jpg")
				, new File("D:\\AtalkClient\\profile_image\\profile_bg.jpg"));
		
		logger.info("#### 3. END - SIGNUP");
	}
	

	/**
	 * 회원가입
	 * 
	 * @throws Exception
	 */
	public static void carryonWitUserId(String userName, String phoneNumber) throws Exception {
		String signUptoken = "";
		
		String password = "111111";
		
		String userId = userName + "@abc.com";
		String gender="M"; // M : male, F : female
		
		String birthDate = "2000-01-01";
		String statusMessage = "가입메시지222";
		String lang = "ko"; // jp : japanese, cn : chinese, en : english, ko : korean
		
		logger.info("#### 1. START - DETERMINE PACKET KEY");
		AtalkComplex.instance().determinePacketKey();
		logger.info("#### 1. END - DETERMINE PACKET KEY");
		
		logger.info("#### 2. START - PRIVATE INFO");
		PiAgreementResponse piIfnoResp = AtalkComplex.instance().getPersonalInfoAgreement();
		logger.info("#### 2. END - PRIVATE INFO");
		
		logger.info("#### 3. START - SIGNUP");
		
		SignupRequest signupReq = new SignupRequest();
		signupReq.setSignupToken(signUptoken);
		signupReq.setUserId(userId);
		signupReq.setPassword(password);
		
		signupReq.setUserName(userName);
		signupReq.setGender(gender);
		
		signupReq.setPiAgreeVersion(piIfnoResp.getPiVersion());
		signupReq.setBirthDate(birthDate);
		
		signupReq.setPhoneNumber(phoneNumber);
		signupReq.setStatusMessage(statusMessage);
		signupReq.setLang(lang);
		
		AtalkComplex.instance().doSignup(signupReq, null, null, null);
		
		logger.info("#### 3. END - SIGNUP");
	}
	
	/**
	 * 회원가입
	 * 
	 * @throws Exception
	 */
	public static void carryonWitUserIdWithAuthToken(String userName, String phoneNumber) throws Exception {
		String signUptoken = "";
		
		String password = "111111";
		
		String userId = userName + "@abc.com";
		String gender="M"; // M : male, F : female
		
		String birthDate = "2000-01-01";
		String statusMessage = "가입메시지222";
		String lang = "ko"; // jp : japanese, cn : chinese, en : english, ko : korean
		
		logger.info("#### 1. START - DETERMINE PACKET KEY");
		AtalkComplex.instance().determinePacketKey();
		logger.info("#### 1. END - DETERMINE PACKET KEY");
		
		logger.info("#### 2. START - PRIVATE INFO");
		PiAgreementResponse piIfnoResp = AtalkComplex.instance().getPersonalInfoAgreement();
		logger.info("#### 2. END - PRIVATE INFO");
		
		logger.info("#### 3. START - SIGNUP");
		
		SignupRequest signupReq = new SignupRequest();
		signupReq.setSignupToken(signUptoken);
		signupReq.setUserId(userId);
		signupReq.setPassword(password);
		
		signupReq.setUserName(userName);
		signupReq.setGender(gender);
		
		signupReq.setPiAgreeVersion(piIfnoResp.getPiVersion());
		signupReq.setBirthDate(birthDate);
		
		signupReq.setPhoneNumber(phoneNumber);
		signupReq.setStatusMessage(statusMessage);
		signupReq.setLang(lang);
		
		AtalkComplex.instance().doSignup(signupReq, null, null, null);
		
		logger.info("#### 3. END - SIGNUP");
	}
}
