package com.mutecsoft.atalk.logic.inf;

public interface InfAtalkChathub {

	
}
