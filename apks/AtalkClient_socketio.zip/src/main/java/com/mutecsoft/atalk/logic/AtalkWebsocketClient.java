package com.mutecsoft.atalk.logic;

import java.net.URI;

import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;

import com.mutecsoft.atalk.logic.inf.InfAtalkChatNoti;

public class AtalkWebsocketClient extends WebSocketClient {

	private InfAtalkChatNoti inf;
	
	public AtalkWebsocketClient(URI serverUri, InfAtalkChatNoti inf) {
		super(serverUri);
		
		this.inf = inf;
	}

	@Override
	public void onOpen(ServerHandshake handshakedata) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onMessage(String message) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onClose(int code, String reason, boolean remote) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onError(Exception ex) {
		// TODO Auto-generated method stub
		
	}

}
