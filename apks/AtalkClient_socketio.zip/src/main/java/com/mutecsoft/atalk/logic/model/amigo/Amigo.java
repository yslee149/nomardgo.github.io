package com.mutecsoft.atalk.logic.model.amigo;

import java.io.Serializable;

/**
 * @PackageName com.mutecsoft.atalk.logic.model.auth
 * @fileName	Amigo.java
 * @author voyzer
 * @Date   2024. 10. 1.
 * @description : 친구정보
 * <pre>
 * 
 * </pre>
 */
public class Amigo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -245976247312274504L;

	private Long userNo;
	private String userName;
	private String nickname;
	
	private String statusMessage;
	private String profileFgThumbUrl;
	private String profileFgUrl;
	
	private String profileBgThumbUrl;
	private String profileBgUrl;
	
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getStatusMessage() {
		return statusMessage;
	}
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	public String getProfileFgThumbUrl() {
		return profileFgThumbUrl;
	}
	public void setProfileFgThumbUrl(String profileFgThumbUrl) {
		this.profileFgThumbUrl = profileFgThumbUrl;
	}
	public String getProfileFgUrl() {
		return profileFgUrl;
	}
	public void setProfileFgUrl(String profileFgUrl) {
		this.profileFgUrl = profileFgUrl;
	}
	public String getProfileBgThumbUrl() {
		return profileBgThumbUrl;
	}
	public void setProfileBgThumbUrl(String profileBgThumbUrl) {
		this.profileBgThumbUrl = profileBgThumbUrl;
	}
	public String getProfileBgUrl() {
		return profileBgUrl;
	}
	public void setProfileBgUrl(String profileBgUrl) {
		this.profileBgUrl = profileBgUrl;
	}
	public Long getUserNo() {
		return userNo;
	}
	public void setUserNo(Long userNo) {
		this.userNo = userNo;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
}
